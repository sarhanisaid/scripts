
#------------------------------------------------------------------------
# Default configuration file for the molecularpdos.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


#
# How to define a few default parameters for MOPDOS i.e.,
# Gaussian-smearing and degauss set to 0.1 eV
#
#MOPDOS {
#    ngauss = 0 
#    degauss = 0.00735
#}

namespace eval ::pwtk {

    #
    # MOPDOS namelist
    #
    append mathparse_real_variables(MOPDOS) {
         DeltaE
         Emax
         Emin
         degauss
    }
    append mathparse_int_variables(MOPDOS) {
         i_atmwfc_beg_full
         i_atmwfc_beg_part
         i_atmwfc_end_full
         i_atmwfc_end_part
         i_bnd_beg_full
         i_bnd_beg_part
         i_bnd_end_full
         i_bnd_end_part
         ngauss
    }
}
