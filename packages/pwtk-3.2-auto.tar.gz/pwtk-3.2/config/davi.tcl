
#------------------------------------------------------------------------
# Default configuration file for the turbo_davidson.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # LR_INPUT namelist
    #
    append mathparse_real_variables(LR_INPUT) {
         max_seconds
    }
    append mathparse_int_variables(LR_INPUT) {
         lr_verbosity
    }

    #
    # LR_DAV namelist
    #
    append mathparse_real_variables(LR_DAV) {
         broadening
         finish
         reference
         residue_conv_thr
         start
         step
    }
    append mathparse_int_variables(LR_DAV) {
         max_iter
         num_basis_max
         num_eign
         num_init
         p_nbnd_occ
         p_nbnd_virt
    }
}
