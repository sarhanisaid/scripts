# ------------------------------------------------------------------------
# 
# File: pwtk.tcl -- PWTK main configuration file (simplified version)
#
# This is the main configuration file for PWTK. It contains basic
# configuration, such as the location of Quantum ESPRESSO executables
# and how to run them...
#
# This is a simple example of the pwtk.tcl file.
# ------------------------------------------------------------------------

#
# HOW TO RUN QUANTUM ESPRESSO (QE) EXECUTABLES
# (e.g.:  prefix bin_dir/pw.x postfix -in INPUT > OUTPUT)

# how to run executables (prefix)
# (this snippet auto-detects the number of available processors)
try {
    set np [exec nproc]
    while { [catch {exec mpirun -n $np echo yes}] && $np > 1 } {
        set np [expr { $np > 2 ? $np / 2 : 1 }]
    }
    if { $np > 1 } {
        prefix mpirun -n $np
    }
}

set env(OMP_NUM_THREADS) 1

## the directory containing the QE executables (bin_dir);
## needed only if QE executables are not on $PATH
#bin_dir $env(HOME)/bin/qe-7.3.1


#
# DEFAULT DIRECTORIES
#

## directory containing pseudopotentials (pseudo_dir);
## needed only if 'pseudo_dir' != $HOME/espresso/pseudo 
## and the ESPRESSO_PSEUDO environment variable is undefined

#pseudo_dir    $env(HOME)/pw/pseudo

## disable auto-downloading of pseudopotentials from the internet
#pseudo_auto_download off


## directories where the scatch files will be written (outdir)

outdir_prefix   [file join [::fileutil::tempdir] $env(USER) QE]
outdir_postfix  [pid]; # N.B. outdir == outdir_prefix/outdir_postfix


#wfcdir_prefix  [outdir_prefix]
#wfcdir_postfix [pid]
