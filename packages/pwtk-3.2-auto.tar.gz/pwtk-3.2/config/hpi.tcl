
#------------------------------------------------------------------------
# Default configuration file for the hp.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # INPUTHP namelist
    #
    append mathparse_real_variables(INPUTHP) {
         alpha_mix(*)
         conv_thr_chi
         dist_thr
         docc_thr
         ethr_nscf
         max_seconds
         rmax
         thresh_init
    }
    append mathparse_int_variables(INPUTHP) {
         equiv_type(*)
         find_atpert
         iverbosity
         last_q
         lmin
         niter_max
         nmix
         nq1
         nq2
         nq3
         num_neigh
         start_q
    }

    set ntyp_variables(INPUTHP) 1

    append ntyp_dimensions(INPUTHP) {
         equiv_type
         perturb_only_atom
         skip_type
    }
}
