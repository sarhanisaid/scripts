
#------------------------------------------------------------------------
# Default configuration file for the matdyn.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # MATDYN namelist
    #
    append mathparse_real_variables(MATDYN) {
         amass(*)
         at(*)
         degauss
         deltaE
    }
    append mathparse_int_variables(MATDYN) {
         l1
         l2
         l3
         ndos
         nk1
         nk2
         nk3
         ntyp
    }

    set ntyp_variables(MATDYN) 1

    append ntyp_dimensions(MATDYN) {
         amass
    }
}
