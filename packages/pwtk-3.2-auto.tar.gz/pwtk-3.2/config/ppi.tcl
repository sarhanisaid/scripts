
#------------------------------------------------------------------------
# Default configuration file for the pp.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # INPUTPP namelist
    #
    append mathparse_real_variables(INPUTPP) {
         degauss_ldos
         delta_e
         emax
         emin
         sample_bias
    }
    append mathparse_int_variables(INPUTPP) {
         kband(*)
         kpoint(*)
         plot_num
         spin_component
         spin_component(*)
    }

    #
    # PLOT namelist
    #
    append mathparse_real_variables(PLOT) {
         e1(*)
         e2(*)
         e3(*)
         radius
         weight(*)
         x0(*)
    }
    append mathparse_int_variables(PLOT) {
         iflag
         nfile
         nx
         ny
         nz
         output_format
    }
}
