
#------------------------------------------------------------------------
# Default configuration file for the ld1.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # LD1_INPUT namelist
    #
    append mathparse_real_variables(LD1_INPUT) {
         beta
         cau_fact
         deld
         dx
         emaxld
         eminld
         rlderiv
         rmax
         rpwe
         rytoev_fact
         tr2
         xmin
         zed
    }
    append mathparse_int_variables(LD1_INPUT) {
         isic
         iswitch
         latt
         lsd
         max_out_wfc
         nld
         rel
    }

    #
    # LD1_INPUTP namelist
    #
    append mathparse_real_variables(LD1_INPUTP) {
         rcloc
         rcore
         rho0
         rmatch_augfun
         rmatch_augfun_nc
         zval
    }
    append mathparse_int_variables(LD1_INPUTP) {
         lloc
         pseudotype
    }

    #
    # LD1_TEST namelist
    #
    append mathparse_real_variables(LD1_TEST) {
         decut
         ecutmax
         ecutmin
         rcutv
         rm
    }
    append mathparse_int_variables(LD1_TEST) {
         lsdts(*)
         nconf
    }
}
