
#------------------------------------------------------------------------
# Default configuration file for the ph.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # INPUTPH namelist
    #
    append mathparse_real_variables(INPUTPH) {
         alpha_mix(*)
         amass(*)
         dek
         el_ph_sigma
         eth_ns
         eth_rps
         max_seconds
         tr2_ph
    }
    append mathparse_int_variables(INPUTPH) {
         ahc_nbnd
         ahc_nbndskip
         el_ph_nsigma
         k1
         k2
         k3
         last_irr
         last_q
         modenum
         nat_todo
         niter_ph
         nk1
         nk2
         nk3
         nmix_ph
         nq1
         nq2
         nq3
         start_irr
         start_q
    }

    set ntyp_variables(INPUTPH) 1

    append ntyp_dimensions(INPUTPH) {
         amass
    }
}
