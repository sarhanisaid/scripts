
#------------------------------------------------------------------------
# Default configuration file for the turbo_lanczos.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # LR_INPUT namelist
    #
    append mathparse_int_variables(LR_INPUT) {
         lr_verbosity
         restart_step
    }

    #
    # LR_CONTROL namelist
    #
    append mathparse_real_variables(LR_CONTROL) {
         scissor
    }
    append mathparse_int_variables(LR_CONTROL) {
         charge_response
         ipol
         itermax
         n_ipol
    }

    #
    # LR_POST namelist
    #
    append mathparse_real_variables(LR_POST) {
         epsil
         omeg
    }
    append mathparse_int_variables(LR_POST) {
         plot_type
         w_T_npol
    }
}
