
#------------------------------------------------------------------------
# Default configuration file for the pwcond.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # INPUTCOND namelist
    #
    append mathparse_real_variables(INPUTCOND) {
         bdl
         bdr
         bds
         denergy
         ecut2d
         energy0
         epsproj
         ewind
         max_seconds
         orbj_fin
         orbj_in
    }
    append mathparse_int_variables(INPUTCOND) {
         ikind
         iofspin
         last_e
         last_k
         nenergy
         nz1
         start_e
         start_k
         tk_plot
    }
}
