
### time interval for checking if the calculation has finished on the remote host (time is expressed as 30s, 5min, 2h ...)

set remote(time_interval)  30s

### max number of connection attempts if the host is down;
##  a connection attempt is made once per $remote(time_interval); 
##  if $remote(max_attempts) < 0, try forever

set remote(max_attempts) 1000


### rsync program (-au is a good idea; -v = verbose)
set remote(rsync)  {rsync -avu}
## with a jump host
#set remote(rsync)  {rsync -avu -e {ssh -J hostname.domain.name}}


### program for remote copying (aka scp; BEWARE: do not use rsync)

## without options:
set remote(rcp)  scp
## with options (e.g. how to specify a jump host)
#set remote(rcp)  {scp -J hostname.domain.name}


### program for connecting to remote host (e.g. ssh)

## without options:
set remote(rsh)  ssh
## with options (e.g. how to specify a jump host)
#set remote(rsh)  {ssh -J hostname.domain.name}


### ssh options for runnig scripts in background

set remote(rsh_bg_opts) {-x -n -f}


### Bourne shell on remote host

set remote(shell)  sh


### nohup program on remote host

set remote(nohup)  nohup


### ssh options for checking if a host is alive

set remote(rsh_alive_opts) {-q -o StrictHostKeyChecking=no -o BatchMode=yes -o ConnectTimeout=10 -o ServerAliveInterval=10 -o TCPKeepAlive=yes}
