# ------------------------------------------------------------------------
# 
# SH -- Bourne shell
#
# This is a configuration file for dummy emulation of queuing system
# (for testing purposes mainly).  Instead of queuing system driver, a
# simple sh is used.
#
# ------------------------------------------------------------------------

profile default {
    #!/bin/sh
} {
    prefix "mpirun -np 2"
}
