
#------------------------------------------------------------------------
# Default configuration file for the pw2wannier90.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # INPUT_PW2WAN namelist
    #
    append mathparse_real_variables(INPUT_PW2WAN) {
         scdm_mu
         scdm_sigma
    }
    append mathparse_int_variables(INPUT_PW2WAN) {
         atom_proj_exclude(*)
         reduce_unk_factor
    }

    set ntyp_variables(INPUT_PW2WAN) 1

    append ntyp_dimensions(INPUT_PW2WAN) {
         atomic_number
    }
}
