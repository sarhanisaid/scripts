
#------------------------------------------------------------------------
# Default configuration file for the pprism.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # RISM_INPUTPP namelist
    #

    set ntyp_variables(RISM_INPUTPP) 1

    append ntyp_dimensions(RISM_INPUTPP) {
         atomic_number
    }

    #
    # RISM_PLOT namelist
    #
    append mathparse_real_variables(RISM_PLOT) {
         e1(*)
         e2(*)
         e3(*)
         radius
         x0(*)
    }
    append mathparse_int_variables(RISM_PLOT) {
         iflag
         lebedev
         nx
         ny
         nz
         output_format
    }
}
