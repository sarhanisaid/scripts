# ------------------------------------------------------------------------
# 
# File: pwtk.tcl -- PWTK main configuration file
#
# This is the main configuration file for PWTK. It contains basic
# configuration, such as the location of Quantum ESPRESSO executables
# and how to run them...
#
# By default everything is commented.
# (copy either this file or ./pwtk_simple.tcl into ~/.pwtk/pwtk.tcl
#  and edit it there according to your needs)
# ------------------------------------------------------------------------


##
## HOW TO RUN QUANTUM ESPRESSO (QE) EXECUTABLES
## (e.g.:  prefix bin_dir/pw.x postfix -in INPUT > OUTPUT)

## how to run executables (prefix);
## manual setup:
#prefix mpirun -n 4

## or auto-detection of the number of available processors:
#try {
#    set np [exec nproc]
#    while { [catch {exec mpirun -n $np echo yes}] && $np > 1 } {
#        set np [expr { $np > 2 ? $np / 2 : 1 }]
#    }
#    if { $np > 1 } {
#        prefix mpirun -n $np
#    }
#}

#postfix ""

## the directory containing the QE executables (bin_dir);
## needed only if QE executables are not on $PATH
#bin_dir $env(HOME)/bin/qe-7.3.1


## for containers use something along the lines:

#prefix "singularity exec /path/to/container.sif mpirun -np N"
#serial_prefix "singularity exec /path/to/container.sif"
#bin_query false


##
## DEFAULT DIRECTORIES
##

## directory containing pseudopotentials (pseudo_dir);
## needed only if 'pseudo_dir' != $HOME/espresso/pseudo 
## and the ESPRESSO_PSEUDO environment variable is undefined

#pseudo_dir    $env(HOME)/pw/pseudo

## disable auto-downloading of pseudopotentials from the internet
#pseudo_auto_download off


## directories where the scratch files will be written (outdir)
## (e.g. outdir == outdir_prefix/outdir_postfix)

## either:
#outdir_prefix /scratch/$env(USER)/QE
#outdir_postfix [pid]

#wfcdir_prefix /scratch/$env(USER)/QE
#wfcdir_postfix [pid]

## or:
#outdir /scratch/$env(USER)/QE
#wfcdir /scratch/$env(USER)/QE


## some XCRYSDEN and XSF relates stuff
## (needed if pwi2xsf and pwo2xsf are not on $PATH)

#set PWI2XSF /path/to/pwi2xsf.sh
#set PWO2XSF /path/to/pwo2xsf.sh


## bader program
## (needed if bader is not on $PATH)

#set BADER /path/to/bader
