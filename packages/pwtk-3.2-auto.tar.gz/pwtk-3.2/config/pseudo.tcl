# ------------------------------------------------------------------------
#
# pseudo.tcl --
#
# Configuration file for the PSEUDO utility.
#
# This configuration file is sourced from the ::pwtk::pseudo namespace.
#
# ------------------------------------------------------------------------

#****iv*
# VARIABLE
#    ::pwtk::pseudo::opts
# 
# PURPOSE
#   Default options for the ::pwtk::pseudo::etot_test &
#   ::pwtk::pseudo::etot_test_many commands

array set opts {
    ecutwfc_list {30 60 90 120}
    dual         -16
    thr           1e-3
    upscale       4
    ncalc         6
    low_factor    0.8
    high_factor   2.0
    min_ecutwfc   10.0
    max_ecutwfc   1000.0    
}


#****iv*
# VARIABLE
#    ::pwtk::pseudo::gpData
#
# PURPOSE
#   Default options for the "pseudo" Gnuplot plots

set gpData(options) {
    print    '-'
    tmargin  3
    rmargin  7
    xlabel   {'ecutwfc  (Ry)'}
    ylabel   {'Total energy (Ry)'}
    mxtics   2
    mytics   2 
    ytics    nomirror
    format.y '%.4f'
}
