
#------------------------------------------------------------------------
# Default configuration file for the cp.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # CONTROL namelist
    #
    append mathparse_real_variables(CONTROL) {
         dt
         ekin_conv_thr
         etot_conv_thr
         forc_conv_thr
         max_seconds
    }
    append mathparse_int_variables(CONTROL) {
         iprint
         isave
         ndr
         ndw
         nstep
    }

    #
    # SYSTEM namelist
    #
    append mathparse_real_variables(SYSTEM) {
         A
         B
         C
         Hubbard_U(*)
         celldm(*)
         cosAB
         cosAC
         cosBC
         degauss
         ecfixed
         ecutrho
         ecutwfc
         exx_fraction
         london_rcut
         london_s6
         q2sigma
         qcutz
         tot_charge
         tot_magnetization
         ts_vdw_econv_thr
    }
    append mathparse_int_variables(SYSTEM) {
         ibrav
         nat
         nbnd
         nr1
         nr1b
         nr1s
         nr2
         nr2b
         nr2s
         nr3
         nr3b
         nr3s
         nspin
         ntyp
    }

    set ntyp_variables(SYSTEM) 1

    append ntyp_dimensions(SYSTEM) {
         Hubbard_U
         Hubbard_alpha
         Hubbard_beta
         angle1
         angle2
         london_c6
         london_rvdw
         starting_charge
         starting_magnetization
    }
    append ntyp_multidimensions(SYSTEM) {
         Hubbard_occ 0
         starting_ns_eigenvalue 2
    }

    #
    # ELECTRONS namelist
    #
    append mathparse_real_variables(ELECTRONS) {
         ampre
         conv_thr
         efield
         ekincw
         electron_damping
         emass
         emass_cutoff
         fnosee
         grease
         lambda_cold
         ortho_eps
         passop
    }
    append mathparse_int_variables(ELECTRONS) {
         electron_maxstep
         epol
         maxiter
         n_inner
         niter_cg_restart
         niter_cold_restart
         ortho_max
         ortho_para
    }

    #
    # IONS namelist
    #
    append mathparse_real_variables(IONS) {
         amprp(*)
         fnhscl(*)
         fnosep
         greasp
         ion_damping
         ion_radius(*)
         tempw
         tolp
    }
    append mathparse_int_variables(IONS) {
         iesr
         ion_nstepe
         ndega
         nhgrp(*)
         nhpcl
         nhptyp
    }

    set ntyp_variables(IONS) 1

    append ntyp_dimensions(IONS) {
         amprp
         fnhscl
         ion_radius
         nhgrp
         tranp
    }

    #
    # CELL namelist
    #
    append mathparse_real_variables(CELL) {
         cell_damping
         cell_factor
         fnoseh
         greash
         press
         temph
         wmass
    }

    #
    # PRESS_AI namelist
    #
    append mathparse_real_variables(PRESS_AI) {
         P_ext
         P_fin
         P_in
         Surf_t
         dthr
         rho_thr
    }

    #
    # WANNIER namelist
    #
    append mathparse_real_variables(WANNIER) {
         efx0
         efx1
         efy0
         efy1
         efz0
         efz1
         exx_dis_cutoff
         exx_me_rcut_pair
         exx_me_rcut_self
         exx_poisson_eps
         exx_ps_rcut_pair
         exx_ps_rcut_self
         maxwfdt
         tolw
         wf_friction
         wf_q
         wfdt
    }
    append mathparse_int_variables(WANNIER) {
         calwf
         exx_neigh
         nit
         nsd
         nsteps
         nwf
         sw_len
         wffort
         wfsd
    }
}
