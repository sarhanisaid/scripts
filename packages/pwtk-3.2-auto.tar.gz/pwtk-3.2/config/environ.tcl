
#------------------------------------------------------------------------
# Default configuration file for the ENVIRON input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # ENVIRON namelist
    #
    append mathparse_real_variables(ENVIRON) {
         atomicspread(*)
         cion(*)
         cionmax
         env_confine
         env_ecut
         env_optical_permittivity
         env_pressure
         env_static_permittivity
         env_surface_tension
         environ_thr
         rion
         sc_carrier_density
         sc_chg_thr
         sc_electrode_chg
         sc_permittivity
         temperature
         zion(*)
    }
    append mathparse_int_variables(ENVIRON) {
         env_dielectric_regions
         env_electrolyte_ntyp
         env_external_charges
         env_nrep(*)
         environ_nskip
         system_axis
         system_dim
         system_ntyp
         verbose
    }

    set ntyp_variables(ENVIRON) 1

    append ntyp_dimensions(ENVIRON) {
         atomicspread
         cion
         zion
    }

    #
    # BOUNDARY namelist
    #
    append mathparse_real_variables(BOUNDARY) {
         alpha
         corespread(*)
         electrolyte_alpha
         electrolyte_distance
         electrolyte_rhomax
         electrolyte_rhomin
         electrolyte_softness
         electrolyte_spread
         electrolyte_tbeta
         field_asymmetry
         field_factor
         field_max
         field_min
         filling_spread
         filling_threshold
         radial_scale
         radial_spread
         rhomax
         rhomin
         sc_distance
         sc_spread
         softness
         solvationrad(*)
         solvent_distance
         solvent_radius
         solvent_spread
         tbeta
    }
    append mathparse_int_variables(BOUNDARY) {
         ifdtype
         nfdpoint
         stype
    }

    set ntyp_variables(BOUNDARY) 1

    append ntyp_dimensions(BOUNDARY) {
         corespread
         solvationrad
    }

    #
    # ELECTROSTATIC namelist
    #
    append mathparse_real_variables(ELECTROSTATIC) {
         inner_mix
         inner_tol
         mix
         screening
         step
         tol
    }
    append mathparse_int_variables(ELECTROSTATIC) {
         inner_maxstep
         maxstep
         ndiis
         pbc_axis
         pbc_dim
    }
}
