# ------------------------------------------------------------------------
#
# pdos.tcl --
#
# Configuration file for the PDOS utility.
#
# This configuration file is sourced from the ::pwtk namespace.
#
# ------------------------------------------------------------------------


#****iv*
# VARIABLE
#    ::pwtk::orbitalIndex
#
# PURPOSE
#   Order of orbitals in projwfc.x
#******

array set orbitalIndex {
    ldos 0
    
    s  1
    
    pz 1
    px 2
    py 3
    
    dz2    1 
    dzx    2
    dxz    2
    dzy    3
    dyz    3
    dx2y2  4 
    dxy    5
}



#****iv*
# VARIABLE
#    ::pwtk::orbitalGroup
#
# PURPOSE
#   Definition of group-orbitals, such as T2g & Eg
#******

array set orbitalGroup {
    t2g  {dxy + dxz + dyz}
    eg   {dx2y2 + dz2}
}
