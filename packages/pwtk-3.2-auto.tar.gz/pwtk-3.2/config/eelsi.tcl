
#------------------------------------------------------------------------
# Default configuration file for the turbo_eels.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # LR_INPUT namelist
    #
    append mathparse_int_variables(LR_INPUT) {
         lr_verbosity
         restart_step
    }

    #
    # LR_CONTROL namelist
    #
    append mathparse_real_variables(LR_CONTROL) {
         alpha_mix(*)
         end
         epsil
         ethr_nscf
         increment
         q1
         q2
         q3
         start
    }
    append mathparse_int_variables(LR_CONTROL) {
         itermax
         units
    }
}
