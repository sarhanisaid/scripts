
#------------------------------------------------------------------------
# Default configuration file for the OSCDFT input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # OSCDFT namelist
    #
    append mathparse_real_variables(OSCDFT) {
         conv_thr_multiplier
         final_conv_thr
         max_conv_thr
         max_multiplier
         min_conv_thr
         min_gamma_n
         min_multiplier
    }
    append mathparse_int_variables(OSCDFT) {
         iteration_type
         maxiter
         miniter
         n_oscdft
         warm_up_niter
    }
}
