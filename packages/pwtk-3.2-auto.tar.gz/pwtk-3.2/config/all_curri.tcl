
#------------------------------------------------------------------------
# Default configuration file for the all_currents.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # ENERGY_CURRENT namelist
    #
    append mathparse_real_variables(ENERGY_CURRENT) {
         delta_t
         eta
         ethr_big_step
         ethr_small_step
    }
    append mathparse_int_variables(ENERGY_CURRENT) {
         first_step
         last_step
         n_max
         n_repeat_every_step
         n_workers
         step_mul
         step_rem
         worker_id
    }
}
