# ------------------------------------------------------------------------
#
# sbco -- Scan-Bond Constrained-Optimization
#
# This is configuration file for SBCO.
#
# ------------------------------------------------------------------------

variable sbco_default
array set sbco_default {
    mass1       1.0
    mass2       1.0
    auto        false
    increment   0.1
    tolerance   0.0001
    unit        angstrom
    first_opt   true
    post_relax  false
    post_neb    false
    CI_scheme   auto
}

# These are the equivalent specs as above but specified with the SBCO namelist:
#
# SBCO {
#     mass       =   1.0 1.0
#     auto       =   false
#     increment  =   0.1
#     tolerance  =   0.0001
#     unit       =   angstrom
#     first_opt  =   true
#     post_relax =   false
#     post_neb   =   false
#     CI_scheme  =   auto
# }
#
# Explanation of the SBCO namelist variables:
#
#   SBCO {
#       bond        =  1 2          ... bond betwen atom1 & atom2	 
#       mass        =  1.0 1.0      ... masses of the atom1 and atom2 (used to determine how 
#                                       to move atom1 and atom2; heavier atom moves less)
#       nsteps      =  5            ... number of constrained-optimization steps to perform
#       auto        =  false        ... if true, stop the scan when energy starts decreasing
#       increment   =  0.1          ... increment for bond length	 
#       tolerance   =  0.0001       ... tolerance for maintain the bond at prescribed length
#       unit        =  angstroms    ... unit of increment (angstrom|bohr|alat)
#       first_opt   =  true         ... fully optimize the 1st SBCO image without any CONSTRAINTS card
#       post_relax  =  true         ... make a full relaxation without any constraint after the SBCO calculation
#       post_neb    =  false        ... perform a NEB calculation after the SBCO calculation to verify the TS
#       CI_scheme   =  auto         ... the CI_scheme used for the sbco_postNeb calculation
#   }
