
#------------------------------------------------------------------------
# Default configuration file for the kcw.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # KCW_CONTROL namelist
    #
    append mathparse_real_variables(KCW_CONTROL) {
         spread_thr
    }
    append mathparse_int_variables(KCW_CONTROL) {
         kcw_iverbosity
         mp1
         mp2
         mp3
         spin_component
    }

    #
    # WANNIER namelist
    #
    append mathparse_int_variables(WANNIER) {
         num_wann_emp
         num_wann_occ
    }

    #
    # SCREEN namelist
    #
    append mathparse_real_variables(SCREEN) {
         eps_inf
         tr2
    }
    append mathparse_int_variables(SCREEN) {
         i_orb
         niter
         nmix
    }

    #
    # HAM namelist
    #
}
