# ------------------------------------------------------------------------
#
# eos --  equation-of-state: i.e. automatic determination of lattice
# parameter and bulk modules (so far only for cubic systems)
#
# This is configuration file for eos.
#
# ------------------------------------------------------------------------


variable eos

# note: distances in bohrs, bulk-modulus in kbar
array set eos {
    mode       auto
    B0         550
    a0        -1.0
    npoints    15
    scale_min  0.96
    scale_max  1.04

    dB0        3.5
    B0_small   100
    B0_medium  550
    B0_high    3000
    da0        0.1

    use_estimator_points false

    use_stress  true
    restart     false
}
