# ------------------------------------------------------------------------
# 
# SLURM
#
# This is the configuration file for PWTK's SLURM utility. It contains
# the definition of the default profile.
#
# SLURM profiles are defined as:
#
#    slurm_profile name1 {
#       #!/bin/sh
#       #SBATCH --option=value
#       #SBATCH ...
#    } {
#       # here PWTK specifics can be specified
#    }
#
# ------------------------------------------------------------------------

slurm_profile default {
    #!/bin/sh
    #SBATCH --nodes=1
    #SBATCH --ntasks=8
    #SBATCH --time=6:00:00
} {
    prefix mpirun -np 8
}

## one more example
#slurm_profile long {
#    #!/bin/sh
#    #SBATCH --partition=long
#    #SBATCH --ntasks=64
#    #SBATCH --time=2-00:00:00
#} {
#    prefix mpirun -np 64
#}

## modules can be loaded with 'slurm_head'
#slurm_head {
#   module load QuantumESPRESSO/7.3.1
#}
