# ------------------------------------------------------------------------
#
# viewers.tcl --
#
# Configuration file for PWTK's document viewers.
#
# This configuration file is sourced from the ::pwtk namespace.
#
# ------------------------------------------------------------------------


#****iv*
# VARIABLE
#    ::pwtk::viewers
# PURPOSE
#   List of possible viewers to check for a given image/doc type.
#
# TODO
#   Support txt-viewing (do we need it? Probably not!)

array set ::pwtk::viewers {
    pdf {atril evince okular gv}
    png {eom eog gwenview display}
    svg {eom eog gwenview inkview display atril}
}


