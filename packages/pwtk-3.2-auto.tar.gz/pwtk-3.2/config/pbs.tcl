# ------------------------------------------------------------------------
# 
# PBS
#
# This is the configuration file for PWTK's PBS utility. It contains
# the definition of the default profile.
#
# PBS profiles are defined as:
#
#    pbs_profile name1 {
#       #!/bin/sh
#       #PBS -option attribute=value
#       #PBS -option attribute=value
#    } {
#       # here PWTK specifics can be specified
#    }
#
#
# ------------------------------------------------------------------------


pbs_profile default {
    #!/bin/sh
    #PBS -l select=8:ncpus=1
    #PBS -l walltime=02:00:00

    cd $PBS_O_WORKDIR
} {
    prefix mpiexec -np 8
}

## one more example
#pbs_profile longpar {
#    #!/bin/sh
#    #PBS -q longpar
#    #PBS -l select=64:ncpus=2
#    #PBS -l walltime=24:00:00
#
#    cd $PBS_O_WORKDIR
#} {
#    prefix mpiexec -np 64
#}


## modules can be loaded with 'pbs_head'
## N.B. note that pbs_head applies to all profiles
#       (i.e. only one head can be defined)
#pbs_head {
#   module load qe-7.3
#}
