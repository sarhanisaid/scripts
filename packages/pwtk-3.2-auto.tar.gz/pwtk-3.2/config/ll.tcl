# ------------------------------------------------------------------------
# 
# LL (LoadLeveler)
#
# This is the configuration file for PWTK's LoadLeveler utility. It
# contains the definition of the default profile.
#
# LL profiles are defined as:
#
#    ll_profile name1 {
#       #!/bin/sh
#       # @ keyword1 = value1
#       # @ keyword2 = value2
#    } {
#       # here PWTK specifics can be specified
#    }
#
# ------------------------------------------------------------------------

ll_profile default {
    #!/bin/sh
    # @ job_type         = parallel
    # @ wall_clock_limit = 6:00:00
    # @ node             = 1
    # @ total_tasks      = 8
    # @ notification     = never
    # @ queue
}

## one more example: how to define ll and pwtk profiles at the same time:
#ll_profile longpar {
#    #!/bin/sh
#    # @ job_type         = parallel
#    # @ class            = longpar
#    # @ wall_clock_limit = 24:00:00
#    # @ node             = 1
#    # @ total_tasks      = 64
#    # @ notification     = never
#    # @ queue
#} {
#    prefix poe
#}

## modules can be loaded with 'll_head'
#ll_head {
#   module load qe-7.3
#}
