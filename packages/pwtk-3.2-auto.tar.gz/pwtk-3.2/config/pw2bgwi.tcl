
#------------------------------------------------------------------------
# Default configuration file for the pw2bgw.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # INPUT_PW2BGW namelist
    #
    append mathparse_real_variables(INPUT_PW2BGW) {
         wfng_dk1
         wfng_dk2
         wfng_dk3
    }
    append mathparse_int_variables(INPUT_PW2BGW) {
         real_or_complex
         rhog_nvmax
         rhog_nvmin
         vxc_diag_nmax
         vxc_diag_nmin
         vxc_offdiag_nmax
         vxc_offdiag_nmin
         wfng_nk1
         wfng_nk2
         wfng_nk3
         wfng_nvmax
         wfng_nvmin
    }
}
