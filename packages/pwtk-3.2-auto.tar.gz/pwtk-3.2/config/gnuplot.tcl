# ------------------------------------------------------------------------
#
# gnuplot.tcl --
#
# Configuration file for PWTK's Gnuplotting.
#
# This configuration file is sourced from the ::pwtk::gp namespace.
#
# ------------------------------------------------------------------------


#****iv*
# ARRAY
#   ::pwtk::gp::options
#
# PURPOSE
#   PWTK's pre-set options for gnuplot plots (as to make plots nicer).
#
#******

array set options {
    samples    200
    mxtics     2
    mytics     2    
    grid       {lt -1 lc '#bbbbbb'}
    style.fill {transparent solid 0.4}
    xzeroaxis  {lt -1}
    yzeroaxis  {lt -1}
    key        {samplen 2}
}


#****iv*
# ARRAY
#   ::pwtk::gp::mapOptions
#
# PURPOSE
#   PWTK's pre-set options for gnuplot heatmaps.
#
#******

array set mapOptions {
    samples    200
    isosamples 50,50
    pm3d       {map interpolate 0,0}
    
    contour    base
    cntrparam  {levels auto 10}
    
    key        off
    
    mxtics     2
    mytics     2    
}
#    xzeroaxis  {lt -1}
#    yzeroaxis  {lt -1}


#****iv*
# ARRAY
#   ::pwtk::gp::surfOptions
#
# PURPOSE
#   PWTK's pre-set options for gnuplot 3D surface plots.
#
#******

# consider:
#    for        {[i=1:20] linetype i linecolor black}

array set surfOptions {
    samples    200
    isosamples 50,50
    hidden3d   defaults
    pm3d       {at s interpolate 0,0 lighting}

    contour    surface
    cntrparam  {levels auto 10}

    key        off
    
    mxtics     2
    mytics     2    
}
#    xzeroaxis  {lt -1}
#    yzeroaxis  {lt -1}


#****iv*
# ARRAY
#   ::pwtk::gp::surfmapOptions
#
# PURPOSE
#   PWTK's pre-set options for gnuplot 3D surface with map@base plots.
#
#******

array set surfmapOptions [array get surfOptions]
array set surfmapOptions {
    pm3d       {at bs interpolate 0,0 lighting}
    contour    both
}


#****iv*
# ARRAY
#   ::pwtk::gp::palette
#
# PURPOSE
#   12 PWTK's pre-defined pm3d palettes.
#
#******

array set palette {
    gnuplot {rgbformulae 7,5,15}
    
    green-red-violet {rgbformulae 3,11,6}
    
    green-blue-red-orange {defined (0 "green", 1 "blue", 2 "red", 3 "orange")}
    
    rgb {defined (0  1 0 0,  1  0 1 0,  2  0 0 1)}
    
    pale-rainbow {rgbformulae 33,13,10}
    
    rainbow {file "-"
        0.750   0.243   0.95
        0.000   0.322   0.95
        0.173   0.816   0.95
        0.408   0.950   0.176
        0.95    0.950   0.000
        1.000   0.635   0.0
        1.000   0.0     0.0
        end}

    blue-white-red {file "-"
        0.0 0.0 1.0
        0.63 0.63 1.0
        1.0 1.0 1.0
        1.0 0.63 0.63
        1.0 0.0 0.0
        end}

    dark-blue-white-red {file "-"
        0.0 0.0 0.5
        0.6 0.6 1.0
        1.0 1.0 1.0
        1.0 0.6 0.6
        0.5 0.0 0.0
        end}
    
    ocean {rgbformulae 23,28,3}
    
    AFM {rgbformulae 34,35,36 }
    
    STM {file "-"
       0.0 0.0 0.0
       0.48 0.14 0.02
       0.78 0.63 0.07
       1.0 1.0 1.0
       end}

    grayscale {defined (0  0 0 0, 1  1 1 1)}
}


#****iv*
# LIST
#   ::pwtk::gp::known_options
#
# DESCRIPTION
#   The purpose of "known_options" is to have a "logically" sorted
#   options in PWTK's generated Gnuplot scripts (Gnuplot's options are
#   options that are set with the Gnuplot's "set" command).
#
# BEWARE
#   Options consisting of more than one word, such as "format x" is
#   specified as format.x
#
#******

set known_options {
    tmargin     
    rmargin 
    bmargin 
    lmargin 

    samples

    isosamples    
    hidden3d
    pm3d
    palette
    contour
    cntrparam
    
    origin
    view

    xtics 
    ytics
    ztics
    x2tics 
    y2tics
    cbtics
    
    mxtics 
    mytics
    mztics
    mx2tics 
    my2tics
    mcbtics

    xrange 
    yrange
    zrange
    x2range     
    y2range 
    cbrange
    
    format.x 
    format.y
    format.z
    format.x2 
    format.y2 
    format.cb
    
    xzeroaxis 
    yzeroaxis 

    grid 
    style.fill

    xlabel  
    ylabel
    zlabel
    x2label 
    y2label 
    cblabel

    key     
    title       
}


#****iv*
# ARRAY
#   ::pwtk::gp::pwtk2gp
#
# PURPOSE
#   Array holding the matching between PWTK and Gnuplot terminal
#   names. Its structure is the following:
#
#      pwtk2gp(pwtkName) == gnuplotName
#
# BEWARE
#   The empty Gnuplot's terminal, {}, stands for a default Gnuplot's terminal
#   (which is probably a window terminal); it's PWTK name is "win".
#******

array set pwtk2gp {
    ps  postscript
    eps postscript
    png pngcairo
    pdf pdfcairo
    win {}
}


#****iv*
# ARRAY
#   ::pwtk::gp::gp
#
# PURPOSE
#   The "main" config data (such as terminals, fonts...) for Gnuplot plots.
#
# BEWARE
#   1. PWTK's terminal names eps, pdf, and png are named as
#      postscript, pdfcairo, and pngcairo in Gnuplot
#
#   2. during initialization: gp(terminals) is set to a merge of
#      file.terminals, win.terminals, txt.terminals
#
#   3. an empty win.terminal stands for Gnuplot's defult terminal
#      (which is most-likely a window-type terminal)
#******

array set gp {
    file.terminals {postscript pdfcairo svg pngcairo}
    win.terminals  {qt wxt x11 {}}
    txt.terminals  {dumb}

    workflow.terminal pdf
    
    font         Arial
    fontSize     14
    svg.fontSize 18
    png.fontSize 15
    
    #eps.portrait.size   0.8,0.4
    #eps.landscape.size  0.53,0.6
    eps.portrait.size  5,3.5
    eps.landscape.size 5,3.5
    eps.fontscale  0.9
    eps.pointscale 1.0
    
    #pdf.size   4,3
    pdf.size   5,3.5
    pdf.fontscale 0.66
    pdf.pointscale 0.7
    
    png.size   800,575
    
    #size       640,460
    size       800,575
    
    lw         1.1
}
#pause      mouse
#pauseText  "Click"

#eps.portrait.size   0.8,0.4  --> 5.6in,4in
#eps.landscape.size  0.53,0.6 --> 5.3in,3.6in

# defaults for Gnuplot 'with' specs for:
# * datafiles
# * functions
# * DOS, PDOS, MOPDOS, BANDS
#
# GLOSSARY:
# * _dw  = spin-down (used for spin-down states)
# * _mol = used for "molecule" for MOPDOS
# * bands_dos_ = used for DOS plotted alongside BANDS (aka plot_bands -dos ...)
#
# ARRAY ELEMENTS
# * datafile_with -- generic 'with' for datafiles used by ::pwtk::plot
# * function_with -- generic 'with' for functions used by ::pwtk::plot

# * bands_with    -- Gnuplot 'with' specs for spaghetti BANDS
# * bands_with_dw -- Gnuplot 'with' specs for spin-down spaghetti BANDS

# * bands_dos_with    -- Gnuplot 'with' specs for DOS plotted alongside BANDS          
# * bands_dos_with_dw -- Gnuplot 'with' specs for spin-down DOS plotted alongside BANDS

# * bands_dos_fill_color    -- fill color for filledcurve for DOS plotted alongside BANDS
# * bands_dos_fill_color_dw -- fill color for filledcurve for spin-down DOS plotted alongside BANDS

# * dos_with        -- 'with' specs for DOS
# * dos_with_dw     -- 'with' specs for spin-down DOS
# * dos_with_mol    -- 'with' specs for molecular PDOS plotted together with MOPDOS
# * dos_with_mol_dw -- 'with' specs for molecular spin-down PDOS plotted together with MOPDOS

# * dos_fill_color        -- fill color for filledcurve for DOS
# * dos_fill_color_dw     -- fill color for filledcurve for spin-down DOS
# * dos_fill_color_mol    -- fill color for filledcurve for molecular PDOS plotted together with MOPDOS
# * dos_fill_color_mol_dw -- fill color for filledcurve for molecular spin-down PDOS plotted together with MOPDOS

# * intdos_with -- 'with' specs for Integrated DOS
# * intdos_text_color -- textcolor of the "Integrated DOS" label and y2tics

array set gp {
    datafile_with {linespoints lw 3 pt 6}
    function_with {l lw 3}

    bands_with    {linespoints lt 1 lw 2 pt 7 ps 0.3}
    bands_with_dw {linespoints lt 2 lw 2 pt 7 ps 0.3}

    bands_dos_with    {l lt 1 lw 2}
    bands_dos_with_dw {l lt 2 lw 2}

    bands_dos_fill_color    {lt 1}
    bands_dos_fill_color_dw {lt 2}

    intdos_with        {l lt 6 lw 2 dt (10,2,4,2)}
    intdos_text_color {lt 6}

    dos_with        {l lt 1 lw 3}
    dos_with_dw     {l lt 1 lw 3}
    dos_with_mol    {l lt 2 lw 3}
    dos_with_mol_dw {l lt 2 lw 3}
    
    dos_fill_color        {lt 1}
    dos_fill_color_dw     {lt 1}
    dos_fill_color_mol    {lt 2}
    dos_fill_color_mol_dw {lt 2}

}


#****iv*
# CONTINUED
#   ::pwtk::gp::gp
#
# Config for multiplot:
#
#   npmax == maximum number of plots per page
#   np    == number of plots per pag
#   npN   == limiting np values for determinning nxN values, if np > npN ==> nx = nxN
#   nxN   == number of plots in X-dir for a given npN
#   font.nxN == font size for a given nxN
#
#   spin.*** == spin-PDOS-like plots (plots with positive and negative Y-values,
#               i.e., f(x) & -f(x))
#******

array set gp {
    #eps.multisize  1.0,1.0
    eps.multisize  11.69,8.27
    pdf.multisize  11.69,8.27
    multisize      1200,800

    landscape.npmax 25
    portrait.npmax  28

    landscape.np1 4
    landscape.np2 9
    landscape.np3 20
    landscape.np4 30

    landscape.nx0 2
    landscape.nx1 3
    landscape.nx2 4
    landscape.nx3 5
    landscape.nx4 6

    portrait.np1 4
    portrait.np2 10
    portrait.np3 21
    portrait.np4 32
    
    portrait.nx0 1
    portrait.nx1 2
    portrait.nx2 3
    portrait.nx3 4
    portrait.nx4 5

    spin.landscape.np1 4
    spin.landscape.np2 9
    spin.landscape.np3 20
    spin.landscape.np4 30

    spin.landscape.nx0 2
    spin.landscape.nx1 3
    spin.landscape.nx2 4
    spin.landscape.nx3 5
    spin.landscape.nx4 6
    
    spin.portrait.np1 4
    spin.portrait.np2 9
    spin.portrait.np3 20
    spin.portrait.np4 30

    spin.portrait.nx0 1
    spin.portrait.nx1 2
    spin.portrait.nx2 3
    spin.portrait.nx3 4
    spin.portrait.nx4 5

    fontSize.nx0 14
    fontSize.nx1 11
    fontSize.nx2 9    
    fontSize.nx3 8
    fontSize.nx4 7
}


#****iv*
# LIST
#   ::pwtk::gp::plot_options
#
# DESCRIPTION
#   Specs for command-line options for the Gnuplot's 'plot'.
#******

set plot_options {
    {xt.arg {}  "X-tics (aka xtics)"}
    {yt.arg {}  "Y-tics (aka ytics)"}
    {x2t.arg {} "X2-tics (aka x2tics)"}
    {y2t.arg {} "Y2-tics (aka y2tics)"}

    {mx.arg {}  "minor X-tics (aka mxtics)"}
    {my.arg {}  "minor Y-tics (aka mxtics)"}
    {mx2.arg {} "minor X2-tics (aka mx2tics)"}
    {my2.arg {} "minor Y2-tics (aka my2tics)"}

    {xl.arg {}  "X-axis label"}
    {yl.arg {}  "Y-axis label"}
    {x2l.arg {} "X2-axis label"}
    {y2l.arg {} "Y2-axis label"}

    {xr.arg {}  "X-range"}
    {yr.arg {}  "Y-range"}
    {x2r.arg {} "X2-range"}
    {y2r.arg {} "Y2-range"}

    {xf.arg {}  "format for X-axis (e.g. %.2f)"}
    {yf.arg {}  "format for Y-axis (e.g. %.2f)"}
    {x2f.arg {} "format for X2-axis (e.g. %.2f)"}
    {y2f.arg {} "format for Y2-axis (e.g. %.2f)"}

    {tm.arg {} "top margin"}
    {bm.arg {} "bottom margin"}
    {lm.arg {} "left margin"}
    {rm.arg {} "right margin"}
    
    {key.arg  {}  "key (or legend) containing a title for each plot in the graph"}
    {grid.arg {}  "grid, e.g., -grid {lt -1 dt (5,1,2,1)})"}
    {title.arg {} "title, e.g., -title {'This is title' font 'Arial,12'}"}

    {u.arg  {}  "Gnuplot's \"using\" plot specification"}
    {w.arg  {}  "Gnuplot's \"with\" plot specification"}
    {x.arg  {}  "extra Gnuplot commands/configuration"}
    
    {out.arg {} "rootname for the Gnuplot-script and image file"}
    {t.arg   {} "terminal for the plot"}
    {s.arg   {} "terminal size, specified as sx,sy"}
    {v          "visualize generated plot image (for file terminals)"}
}


#****iv*
# LIST
#   ::pwtk::gp::plot_usage
#
# DESCRIPTION
#   The "usage" list of command-line options for the Gnuplot's 'plot'.
#******

set plot_usage {
    {-xt  XTICS}
    {-yt  YTICS}
    {-x2t X2TICS}
    {-y2t Y2TICS}
    {}
    {-mx  MXTICS}
    {-my  MYTICS}
    {-mx2 MX2TICS}
    {-my2 MY2TICS}
    {}
    {-xl  XLABEL}
    {-yl  YLABEL}
    {-x2l X2LABEL}
    {-y2l Y2LABEL}
    {}
    {-xr  XRANGE}
    {-yr  YRANGE}
    {-x2r X2RANGE}
    {-y2r Y2RANGE}
    {}
    {-xf  XFORMAT}
    {-yf  YFORMAT}
    {-x2f X2FORMAT}
    {-y2f Y2FORMAT}
    {}
    {-tm TOP_MARGIN}
    {-bm BOTTOM_MARGIN}
    {-lm LEFT_MARGIN}
    {-rm RIGHT_MARGIN}
    {}
    {-key KEY}
    {-grid GRID}
    {-title TITLE}
    {}
    {-u USING}
    {-w WITH}
    {-x EXTRA}
    {}
    {-out ROOTNAME}
    {-t TERMINAL}
    {-s PX,PY}
    {-v}
}


#****iv*
# LIST
#   ::pwtk::gp::splot_options
#
# DESCRIPTION
#   Specs for command-line options for the Gnuplot's 'splot'.
#******

set splot_options {
    {type.arg surface "type of splot"}
    {pal.arg  {} "color palette"}
    {i.arg    {} "interpolation degree"}
    {contour     "plot contours"}
    {cc.arg   {} "color of contours"}
    {clw.arg  {} "contour linewidth"}

    {xt.arg  {}  "X-tics (aka xtics)"}
    {yt.arg  {}  "Y-tics (aka ytics)"}
    {zt.arg  {}  "Z-tics (aka ztics)"}
    {cbt.arg {}  "CB-tics (aka cbtics)"}
    {x2t.arg {}  "X2-tics (aka x2tics)"}
    {y2t.arg {}  "Y2-tics (aka y2tics)"}

    {mx.arg  {}  "minor X-tics (aka mxtics)"}
    {my.arg  {}  "minor Y-tics (aka mxtics)"}
    {mz.arg  {}  "minor Z-tics (aka mztics)"}
    {mcb.arg {}  "minor CB-tics (aka mcbtics)"}
    {mx2.arg {}  "minor X2-tics (aka mx2tics)"}
    {my2.arg {}  "minor Y2-tics (aka my2tics)"}

    {xl.arg  {}  "X-axis label"}
    {yl.arg  {}  "Y-axis label"}
    {zl.arg  {}  "Z-axis label"}
    {cbl.arg {}  "CB-axis label"}
    {x2l.arg {}  "X2-axis label"}
    {y2l.arg {}  "Y2-axis label"}

    {xr.arg  {}  "X-range"}
    {yr.arg  {}  "Y-range"}
    {zr.arg  {}  "Z-range"}
    {cbr.arg {}  "CB-range"}
    {x2r.arg {}  "X2-range"}
    {y2r.arg {}  "Y2-range"}

    {xf.arg  {}  "format for X-axis (e.g. %.2f)"}
    {yf.arg  {}  "format for Y-axis (e.g. %.2f)"}
    {zf.arg  {}  "format for Z-axis (e.g. %.2f)"}
    {cbf.arg {}  "format for CB-axis (e.g. %.2f)"}
    {x2f.arg {}  "format for X2-axis (e.g. %.2f)"}
    {y2f.arg {}  "format for Y2-axis (e.g. %.2f)"}

    {tm.arg {} "top margin"}
    {bm.arg {} "bottom margin"}
    {lm.arg {} "left margin"}
    {rm.arg {} "right margin"}
    
    {key.arg  {}  "key (or legend) containing a title for each plot in the graph"}
    {grid.arg {}  "grid, e.g., -grid {lt -1 dt (5,1,2,1)})"}
    {title.arg {} "title, e.g., -title {'This is title' font 'Arial,12'}"}
   
    {u.arg   {}  "Gnuplot's \"using\" splot specification"}
    {w.arg   {}  "Gnuplot's \"with\" splot specification"}
    {x.arg   {}  "extra Gnuplot commands/configuration"} 

    {out.arg {}  "rootname for the Gnuplot-script and image file"}
    {t.arg   {}  "terminal for the plot"}
    {s.arg   {}  "terminal size, specified as sx,sy"}
    {v           "visualize generated plot image (for file terminals)"}
}

#****iv*
# LIST
#   ::pwtk::gp::splot_usage
#
# DESCRIPTION
#   The "usage" list of command-line options for the Gnuplot's 'splot'.
#******

set splot_usage {
    {-type TYPE}
    {-pal  PALETTE}
    {-i    INTERPOLATION}
    {-contour}
    {-cc   CONTOUR_COLOR}
    {-clw  CONTOUR_LINEWIDTH}
    {}
    {-xt  XTICS}
    {-yt  YTICS}
    {-zt  ZTICS}
    {-cbt CBTICS}
    {-x2t X2TICS}
    {-y2t Y2TICS}
    {}
    {-mx  MXTICS}
    {-my  MYTICS}
    {-mz  MZTICS}
    {-mcb MCBTICS}
    {-mx2 MX2TICS}
    {-my2 MY2TICS}
    {}
    {-xl  XLABEL}
    {-yl  YLABEL}
    {-zl  ZLABEL}
    {-cbl CBLABEL}
    {-x2l X2LABEL}
    {-y2l Y2LABEL}
    {}
    {-xr  XRANGE}
    {-yr  YRANGE}
    {-zr  ZRANGE}
    {-cbr CBRANGE}
    {-x2r X2RANGE}
    {-y2r Y2RANGE}
    {}
    {-xf  XFORMAT}
    {-yf  YFORMAT}
    {-zf  ZFORMAT}
    {-cbf CBFORMAT}
    {-x2f X2FORMAT}
    {-y2f Y2FORMAT}
    {}
    {-tm TOP_MARGIN}
    {-bm BOTTOM_MARGIN}
    {-lm LEFT_MARGIN}
    {-rm RIGHT_MARGIN}
    {}
    {-key KEY}
    {-grid GRID}
    {-title TITLE}
    {}
    {-u USING}
    {-w WITH}
    {-x EXTRA}
    {}
    {-out ROOTNAME}
    {-t TERMINAL}
    {-s PX,PY}
    {-v}
}


#****iv*
# LIST
#   ::pwtk::gp::deprecated_options
#
# DESCRIPTION
#   Deprecated command-line options for the Gnuplot's 'plot', i.e.:
#   * -e was replaced by -x
#******

set deprecated_options {
    {-e -x}
}
