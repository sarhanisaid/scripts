
#------------------------------------------------------------------------
# Default configuration file for the pw.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # CONTROL namelist
    #
    append mathparse_real_variables(CONTROL) {
         dt
         etot_conv_thr
         forc_conv_thr
         max_seconds
    }
    append mathparse_int_variables(CONTROL) {
         gdir
         iprint
         nberrycyc
         nppstr
         nstep
    }

    #
    # SYSTEM namelist
    #
    append mathparse_real_variables(SYSTEM) {
         A
         B
         C
         Hubbard_alpha(*)
         Hubbard_beta(*)
         Hubbard_occ(*)
         angle1(*)
         angle2(*)
         block_1
         block_2
         block_height
         celldm(*)
         cosAB
         cosAC
         cosBC
         degauss
         degauss_cond
         eamp
         ecfixed
         ecutfock
         ecutrho
         ecutvcut
         ecutwfc
         emaxpos
         eopreg
         esm_efield
         esm_w
         exx_fraction
         fixed_magnetization(*)
         gcscf_beta
         gcscf_conv_thr
         gcscf_mu
         lambda
         localization_thr
         london_c6(*)
         london_rcut
         london_rvdw(*)
         london_s6
         nelec_cond
         q2sigma
         qcutz
         sci_cb
         sci_vb
         screening_parameter
         sic_gamma
         starting_charge(*)
         starting_magnetization(*)
         starting_ns_eigenvalue(*)
         tot_charge
         tot_magnetization
         ts_vdw_econv_thr
         xdm_a1
         xdm_a2
         zgate
    }
    append mathparse_int_variables(SYSTEM) {
         dftd3_version
         edir
         esm_nfit
         ibrav
         nat
         nbnd
         nbnd_cond
         nextffield
         nqx1
         nqx2
         nqx3
         nr1
         nr1s
         nr2
         nr2s
         nr3
         nr3s
         nspin
         ntyp
         origin_choice
         report
         space_group
    }

    set ntyp_variables(SYSTEM) 1

    append ntyp_dimensions(SYSTEM) {
         Hubbard_alpha
         Hubbard_beta
         angle1
         angle2
         london_c6
         london_rvdw
         starting_charge
         starting_magnetization
    }
    append ntyp_multidimensions(SYSTEM) {
         Hubbard_occ 0
         starting_ns_eigenvalue 2
    }

    #
    # ELECTRONS namelist
    #
    append mathparse_real_variables(ELECTRONS) {
         conv_thr
         conv_thr_init
         conv_thr_multi
         diago_thr_init
         efield
         efield_cart(*)
         mixing_beta
    }
    append mathparse_int_variables(ELECTRONS) {
         diago_cg_maxiter
         diago_david_ndim
         diago_gs_nblock
         diago_ppcg_maxiter
         diago_rmm_ndim
         electron_maxstep
         exx_maxstep
         mixing_fixed_ns
         mixing_ndim
    }

    #
    # IONS namelist
    #
    append mathparse_real_variables(IONS) {
         delta_t
         fire_alpha_init
         fire_dtmax
         fire_f_dec
         fire_f_inc
         fire_falpha
         tempw
         tolp
         trust_radius_ini
         trust_radius_max
         trust_radius_min
         upscale
         w_1
         w_2
    }
    append mathparse_int_variables(IONS) {
         bfgs_ndim
         fire_nmin
         nraise
    }

    #
    # CELL namelist
    #
    append mathparse_real_variables(CELL) {
         cell_factor
         press
         press_conv_thr
         wmass
    }

    #
    # FCP namelist
    #
    append mathparse_real_variables(FCP) {
         fcp_conv_thr
         fcp_delta_t
         fcp_mass
         fcp_mu
         fcp_tempw
         fcp_tolp
         fcp_velocity
    }
    append mathparse_int_variables(FCP) {
         fcp_ndiis
         fcp_nraise
    }

    #
    # RISM namelist
    #
    append mathparse_real_variables(RISM) {
         ecutsolv
         laue_buffer_left
         laue_buffer_right
         laue_expand_left
         laue_expand_right
         laue_starting_left
         laue_starting_right
         laue_wall_epsilon
         laue_wall_rho
         laue_wall_sigma
         laue_wall_z
         mdiis1d_step
         mdiis3d_step
         rism1d_bond_width
         rism1d_conv_thr
         rism1d_dielectric
         rism1d_molesize
         rism3d_conv_level
         rism3d_conv_thr
         smear1d
         smear3d
         solute_epsilon(*)
         solute_sigma(*)
         tempv
    }
    append mathparse_int_variables(RISM) {
         laue_nfit
         mdiis1d_size
         mdiis3d_size
         nsolv
         rism1d_maxstep
         rism1d_nproc
         rism3d_maxstep
    }

    set ntyp_variables(RISM) 1

    append ntyp_dimensions(RISM) {
         solute_epsilon
         solute_lj
         solute_sigma
    }
}
