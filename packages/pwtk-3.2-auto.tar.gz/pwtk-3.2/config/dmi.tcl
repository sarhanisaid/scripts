
#------------------------------------------------------------------------
# Default configuration file for the dynmat.x input (auto-generated)
#------------------------------------------------------------------------
#
# Below several variables are defined, i.e.:
#
# 1. A list of namelist variables for which the math-parsing is enabled.
#    It is safe to math-parse all variables of REAL and INTEGER type.
#
#    If the variable is not a dimension or multidimension, its is labeled
#    with the '(*)' postfix, e.g.: celldm(*)
#
# 2. A list of dimensions and multidimensions that run over atomic
#    types (aka 'ntyp' dimensions). Namelists that contain them are
#    marked with the ntyp_variables($namelist) variable.
#
#------------------------------------------------------------------------


namespace eval ::pwtk {

    #
    # DYNMAT namelist
    #
    append mathparse_real_variables(DYNMAT) {
         amass(*)
         el_ph_sigma
         q(*)
    }
    append mathparse_int_variables(DYNMAT) {
         axis
         el_ph_nsig
    }

    set ntyp_variables(DYNMAT) 1

    append ntyp_dimensions(DYNMAT) {
         amass
    }
}
