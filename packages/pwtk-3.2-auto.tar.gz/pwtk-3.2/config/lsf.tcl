# ------------------------------------------------------------------------
# 
# LSF
#
# This is the configuration file for PWTK's LSF utility. It contains
# the definition of the default profile.
#
# LSF profiles are defined as:
#
#    lsf_profile name1 {
#       #!/bin/sh
#       #BSUB -option1 value1
#       #BSUB -option2 value2
#    } {
#       # here PWTK specifics can be specified
#    }
#
# ------------------------------------------------------------------------


lsf_profile default {
    #!/bin/sh
    #BSUB -n 8
    #BSUB -W 6:00
} {
    prefix mpirun -np 8
}

## one more example
#lsf_profile longpar {
#    #!/bin/sh
#    #BSUB -q longpar
#    #BSUB -n 64
#    #BSUB -W 24:00
#} {
#    prefix mpirun -np 64
#}

## modules can be loaded with 'lsf_head'
#lsf_head {
#   module load qe-7.3
#}
