#
# $RCSfile: init.tcl,v $ --
#
# 
#   PWTK == PWscf's ToolKit
#
#   This is the init file for PWTK, where all the namespaces are
#   defined and an initialization is performed.
#
#
# Copyright (c) 2009-2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: init.tcl,v 1.25 2021/05/03 14:23:29 tone Exp $ 
#

if { ! [info exists env(PWTK)] } {
    puts stderr "\nTo run PWTK, the PWTK environmental variable must be defined !!!\n"
    exit 1
}

#proc tracer {varname args} {
#    upvar #0 $varname var
#    puts "$varname was updated to be \"$var\"
#          from 
#          [info level 1]
#          from
#          [info level 2]"
#}
#trace add variable ::name write "tracer ::name"

# set precision to double precission
#set tcl_precision 16


namespace eval ::pwtk {
    variable library [file dirname [info script]]
    variable version [gets [open [file join $library VERSION] r]]
    lappend auto_path [file join $library src]

    variable pkg_init_script "set ::env(PWTK) $::env(PWTK)
lappend auto_path $::env(PWTK)
package require pwtk
pwtk::import_exported
"
    
    if { [info exists ::PWTK_APPLICATION] && $::PWTK_APPLICATION } {    
        # welcome greater
        set host_ [info hostname]
        set date_ [clock format [clock seconds]]
    
        if { ! [info exists _silent] } {
            print "========================================================================"
            print "*** PWTK-$::pwtk::version    (PWscf ToolKit: a Tcl scripting environment)"
            print "========================================================================"
            print "(for more info about PWTK, see http://pwtk.ijs.si/)\n"
            print "Running on host: $host_"
            print "PWTK: [::pwtk::varvalue env(PWTK)]"
            print "Date: $date_"     
            print "PID:  [pid]\n"
        }
    }

    variable input_name_list ""; # name of all PWTK namelists and
                                 # cards, see ::pwtk::inputSpecs_
    
    variable prog2runCmd; # an array that associates a given QE
                          # executable with its runCmd
    
    variable prog2inNN; # an array that associates a given QE executable
                        # with its PWTK input namespace name
    
    # Names of some QE namelists (e.g. INPUT) are made more specific
    # in PWTK. Below is the list of such exceptions that are manually
    # coded. Note that further exceptions are added in src/auto-inputs.tcl
    # - all exceptions can be listed with the ***TODO-CMD***
    variable QE2PWTKname
    #foreach {prog type QEname PWTKname} {
    #    dynmat.x        namelist INPUT       DYNMAT
    #    matdyn.x        namelist INPUT       MATDYN
    #    q2r.x           namelist INPUT       Q2R
    #    molecularpdos.x namelist INPUTMOPDOS MOPDOS
    #    neb.x           supercard     {BEGIN/END} {}
    #    neb.x           supercard     {BEGIN_PATH_INPUT/END_PATH_INPUT} {}
    #    neb.x           supercard     {BEGIN_ENGINE_INPUT/END_ENGINE_INPUT} {}
    #} {
    #    # N.B. the PWTKname variable is so-far nowhere used, but this
    #    # is a good idea
    #    set QE2PWTKname($prog,$type,$QEname) $PWTKname
    #}
    
    variable RUNopt
    # elements of RUNopt array:
    #    RUNopt(CONTAINER_EXEC)
    #    RUNopt(NICE)
    #    RUNopt(NICE_CMD)
    #    RUNopt(PREFIX)
    #    RUNopt(SERIAL_PREFIX)
    #    RUNopt(POSTFIX)
    #    RUNopt(SERIAL_POSTFIX)
    #    RUNopt(input_handle)
    
    set RUNopt(input_handle) "-in"

    variable QEdir
    # elements of QEdir array:
    #    QEdir(BIN_DIR)
    #    QEdir(ESPRESSO_TMPDIR)
    #    QEdir(ESPRESSO_WFCDIR)
    #    QEdir(ESPRESSO_PSEUDO)
    #    QEdir(outdirPrefix)
    #    QEdir(outdirPostfix)
    #    QEdir(wfcdirPrefix)
    #    QEdir(wfcdirPostfix)

    #set QEdir(ESPRESSO_PSEUDO) [varvalue ::env(ESPRESSO_PSEUDO)]; # DO NOT: rely on enviromental variable (let QE determine's it)
    #set QEdir(ESPRESSO_TMPDIR) [varvalue ::env(ESPRESSO_TMPDIR)]; # DO NOT: rely on enviromental variable (let QE determine's it)
    set QEdir(ESPRESSO_WFCDIR) [varvalue ::env(ESPRESSO_WFCDIR)]; # DO: because QE does not consider ESPRESSO_WFCDIR !
    
    variable QEprog    
    # elements of QEprog array:
    #    QEprog(PW)
    #    QEprog(CP)
    #    QEprog(NEB)
    #    QEprog(PH)
    #    QEprog(DYNMAT)
    #    QEprog(MATDYN)
    #    QEprog(Q2R)
    #    QEprog(PP)
    #    QEprog(PROJWFC)
    #    QEprog(DOS)
    #    QEprog(BANDS)
    #    QEprog(MOLECULARPDOS)
    #    QEprog(HP)
    #    QEprog(TURBO_DAVIDSON)
    #    QEprog(TURBO_LANCZOS)
    #    QEprog(TURBO_EELS)
    #    QEprog(TURBO_SPECTRUM)
    #    QEprog(TURBO_MAGNON)
    #    ...

    variable state
    set state(stopOnError) 1
    set state(restart)     0
    set state(bin_query)   1
    set state(backup_io)   0
    set state(environ)     off
    set state(pseudo_auto_download) 1

    # math parsing of input variables
    
    variable mathparse_real_variables
    variable mathparse_int_variables
    variable mathparse_variable; # soon to be deprecated

    # formats for printing coordinates
    
    variable fmt_coor
    variable fmt_atmPos
    set fmt_coor(4)   "  %-4s   %16.12f %16.12f %16.12f\n"
    set fmt_coor(7)   "  %-4s   %16.12f %16.12f %16.12f   %16.12f %16.12f %16.12f\n"
    set fmt_atmPos(4) $fmt_coor(4)
    set fmt_atmPos(7) "  %-4s   %16.12f %16.12f %16.12f   %1s  %1s  %1s\n"
    
    # http://physics.nist.gov/constants
    # (CODATA Internationally recommended 2018 values)

    variable bohr2angs  0.529177210903
    variable angs2bohr  [expr {1.0 / $bohr2angs}]

    variable ry2ev 13.605693122994017
    variable ha2ev [expr {2.0*$ry2ev}]
    variable ev2ry [expr {1.0 / $ry2ev}]    
    variable ev2ha [expr {1.0 / $ha2ev}]
    
    variable ry2kjm 1312.7498197399127 
    variable ha2kjm [expr {2.0*$ry2kjm}]
    variable kjm2ry [expr {1.0 / $ry2kjm}]
    variable kjm2ha [expr {1.0 / $ha2kjm}]
    variable pi     3.14159265358979323844
    variable tpi    [expr {2.0*$pi}]

    variable run_options
    variable run_extra_options
    variable catch_error 0
    
    # ARRAY: "ntyp_variables(namelistName)"; it designates which
    # namelist should undergo var(AtomicSymbol) --> var(AtomicIndex)
    # transformation when constructing the input

    variable ntyp_variables

    # direct use of stopOnError is obsolete
    
    variable stopOnError
    foreach p {"" ::} {
        trace add variable ${p}stopOnError write {apply {{v1 v2 op} {
            upvar 1 $v1 value
            ::pwtk::deprecated "do not use the stopOnError variable directly, use the stopOnError routine instead, e.g.:\nEither: stopOnError on\nOr:     stopOnError off"
            ::pwtk::stopOnError $value
        }}}
    }

    # auto-inputs

    variable auto_inNN_list ""; # tracks all auto-defined inputs;
                                # used for auto-generation of documentation
    
    # options for run type commands

    set run_options {
	{append         "treat the output file in append mode (default = overwrite)"}
	{serial         "run the calculation is serial mode (default = parallel)"}
	{prefix.arg  {} "explicitly specify the prefix for parallel execution"}
	{postfix.arg {} "explicitly specify the postfix for parallel execution"}
	{exec.arg    {} "explicitly specify the pw.x executable"}
	{ihandle.arg {} "explicitly set the input handle"}
        {bg             "run calculation in background"}
    }
    set run_extra_options {
	{outdir_clean  0 "clean the outdir before running the calculation"}
    }

    proc loadConfig_ {namespace file} {
	# load the configuration file in the $namespace scope !
	# First loads config/$file, then $HOME/.pwtk/$file if it exists.
	global env
	set script {
	    if { [file exists $env(PWTK)/config/$file] } { 
                source $env(PWTK)/config/$file
            } else {
                ::pwtk::warning "config file $env(PWTK)/config/$file does not exist"
            }
	    if { [file exists $env(HOME)/.pwtk/$file] } { 
		source $env(HOME)/.pwtk/$file 
	    }
	}
	namespace eval $namespace [subst -nocommands $script]
    }
    
    proc getVar_ {var} {
	# return the value of the variable
	
	# try if global $var exists, else try with ::pwtk::$var
	
	if { [info exists ::$var] } {
	    upvar ::$var varname
	    return $varname
	} elseif { [info exists ::pwtk::$var] } {
	    upvar ::pwtk::$var varname
	    return $varname
	}
	
	# check also if the ESPRESSO_*** enviromental variable exists
	if { [regexp {^ESPRESSO_} $var] } {
	    global env
	    if { [info exists env($var)] } {
		return $env($var)
	    }
	}
	return ""	    
    }
    proc getDir_ {var} {
        # similar to getVar_ but it returns either a quouted value,
        # i.e., '$value' or an empty string
        set value [getVar_ $var]
        if { $value != "" } {
            return '${value}'
        } else {
            return ""
        }
    }

    # bacground jobs: time interval (in ms) for checking if a given background job finished
    variable time_interval_ms 500
    
    # 
    # remote mode
    #
    variable remote
    ::pwtk::loadConfig_ ::pwtk remote.tcl
    set remote(time_interval_ms) [::pwtk::time2ms $remote(time_interval)]; # in miliseconds

    #
    # PDOS
    #
    variable orbitalIndex
    variable orbitalGroup
    ::pwtk::loadConfig_ ::pwtk pdos.tcl

    #
    # document/image viewers
    #
    ::pwtk::loadConfig_ ::pwtk viewers.tcl

    #
    # pwi2xsf, pwo2xsf, bader ...
    #
    variable BADER
    variable LOBSTER
    variable PWI2XSF
    variable PWO2XSF

    set BADER   [getExecutable bader]
    set LOBSTER [getExecutable lobster]
    set PWI2XSF [getExecutable [varvalue ::env(XCRYSDEN_TOPDIR)]/scripts/pwi2xsf.sh pwi2xsf.sh pwi2xsf]
    set PWO2XSF [getExecutable [varvalue ::env(XCRYSDEN_TOPDIR)]/scripts/pwo2xsf.sh pwo2xsf.sh pwo2xsf]

    #
    # EXPORTed COMMANDS
    #
    
    # runXX cmds (i.e., plain commands for running PWTK-supported QE executables)
    
    variable runXX_exportList {
        runXX   rerunXX
	runPW	rerunPW
	runCP	rerunCP
	runPH	rerunPH
	runNEB	rerunNEB
	runPP
	runPROJWFC
        runMOLECULARPDOS
	runMOPDOS
        runDOS
        runBANDS
	runDYNMAT
	runMATDYN
        runQ2R
        runHP
        runDAVID    rerunDAVID
        runDAVIDSON rerunDAVIDSON        
        runLANCZOS  rerunLANCZOS        
        runEELS     rerunEELS
        runSPECTRUM
    }

    # cmds related to programs, directories and execution

    variable runAndDir_exportList {
	outdir
	outdir_clean
	outdir_create
	outdir_postfix
	outdir_prefix
	outdir_prefix_append
	outdir_query
        outdir_backup
	
	wfcdir
	wfcdir_clean
	wfcdir_create
	wfcdir_postfix
	wfcdir_prefix
	wfcdir_prefix_append
	wfcdir_query
        wfcdir_backup

	pseudo_dir
	bin_dir
        bin_query

        nice
        container
	prefix
	postfix
        serial_prefix
        serial_postfix

        prog
	pw
        cp
	neb
	pp
	projwfc
        dos
	bands
        molecularpdos
	ph
	dynmat
        matdyn
        q2r
        hp
        turbo_davidson
        turbo_lanczos
        turbo_eels
        turbo_spectrum
        
        dryrunPW        
        dryrunCP
        dryrunNEB
        runPW_remedy
        run
        execute
        try_exec

        remedy
        prerun
        postrun
        treatrun

        afterDone
        delayed_eval
        delayed_eval_finish
        
        restart
        stopOnError
        
	backup_io
	input_handle
        ihandle
	import
	abort
	warning
	infoMsg
        print
        printTitle
	
	relax
        relax_fromPWO
        relax_fromXSF
	vc-relax
        vc-relax_fromPWO
        vc-relax_fromXSF
        run_fromPWO
        run_fromXSF
	restart_fromIO

        bg
        bg_wait

        run_id
        run_ids
        run_wait
        
	remote
        remote_get
        remote_id
        remote_ids
        remote_pidwait
        remote_wait
        rexec
        rtclsh
        rsync
        rcp
        rmkdir
        
        thread
        thread_id
        thread_ids
        thread_wait

        tpool
        
        propagate
        propagate_clear
        
        catch_error
        eval_in_dir

        measure_time
        time2ms
        time2s
        time2unit
    }

    # cmds related to input data 

    variable input_exportList
    foreach inputType {
	pwi
        cpi
	ppi 
	pri 
	phi
	nebi
	dmi
        mdi
        q2ri
        di
        bi
        mpdi
        hpi
        davi
        lani
        eelsi
        speci
        magi
        environ
    } {
	foreach cmd {
	    fprint 
	    get
            clear
	} {
	    append input_exportList ${inputType}_${cmd}\n
	}
    }
    append input_exportList {
        phi_getTitle
        phi_getAffix
        mdi_getAffix
        q2ri_getAffix
    }
    # extra input cmds
    append input_exportList {
	pwi_visualize
        cpi_visualize
	nebi_visualize
	input_clear
	input_push
	input_pop
	input_pushpop
        input_peek
        input_stack_level
    }

    # cmds related to outputs
    
    append output_exportList {
        pwo_totene
        pwo_totfor
        pwo_totmag
        pwo_etot  
        pwo_efermi
        pwo_press 
        pwo_dipole
        pwo_ibrav
        pwo_alat 
        pwo_volume
        pwo_nat
        pwo_ntyp
        pwo_nelec
        pwo_nbnd
        pwo_ecutwfc
        pwo_ecutrho
        pwo_conv_thr
        pwo_mixing_beta
        pwo_etot_conv_thr
        pwo_forc_conv_thr
        pwo_xc
        
        dmo_vibSpectrum
    }

    # cmds related to queuing system ...

    variable queue_exportList

    # N.B. "queue" was taken out from queueSystem on Wed Feb 28 12:40:54 PM CET 2024
    foreach queueSystem {
        slurm
	ll 
	lsf
        pbs
	sh
    } {
        append queue_exportList [string toupper $queueSystem]\n
        
	foreach queueCmd {
            head
            tail       
            get 
            clear
            fprint
            profile
            profileDefault
            pwtk_profile
            pwtk_profileDefault
	} {
	    append queue_exportList ${queueSystem}_${queueCmd}\n
	}
    }

    # extra utility cmds ...
    
    variable util_exportList {
        varvalue
        seq
        ifset
        readFile
        writeFile
        load_from

        report
        
	eos_run
        flo_run
	sbco_run 
	sbco_postNeb
	difden_run
	difden_segmentSpec
        calcmol
        smilesToCoor
        smi2coor
        smi2png
        smi2svg
        smi2xsf

        scanpar
        write
        finish
        plot
        multiplot
        heatmap
        splot

        display
        imageTile

        pdos_run
        pdos_atm_files 
        sumldos
        sumldosFiles
        sumpdos
        sumpdosFiles
        orbitalGroup
        ldos_fullplot
        pdos_fullplot
        ldos_multiplot
        pdos_multiplot
        pdos_plot
        ldos_plot

        dos_run
        dos_plot
        bands_run
        bands_plot
        mopdos_run
        mopdos_plot

        pw_pp_bader
        pp_bader

        auto_neb
        manual_neb
        neb_plot
        neb_refine
        neb_refine_auto
        neb_refine_merge
        FASTNEB
        fast_neb
        SPINNEB
        re_spin_neb

        pseudo_etot_test
        pseudo_etot_test_many
        pseudo_download
        pseudo_auto_download

        lobster_run
        lobster_plot
        lobster_multiplot
        lobster_sumdos
        lobster_getinfo
        lobster_datafy

        dummy
    }
    
    # assign all exported-lists to "exportList" (used at the end of
    # init.tcl to namespace-export)
    variable exportList [concat $util_exportList $runXX_exportList $runAndDir_exportList $input_exportList $output_exportList $queue_exportList]
}


#****n* Generic input support/::pwtk::input
# NAME
#   ::pwtk::input
#
# DESCRIPTION
#   This namespace handles input data, such as Fortran namelists (see
#   Namelists), QE cards (see Cards) and "scripts" (see Scripts) and
#   provides the commands for input data stacking (see: Stacking).
#
#   There are commands that set, query, modify, print, clear, and
#   stack input data.
#
#   For developers: the ::pwtk::input namespace provides an API for
#   generic handling of input data. An implementation of a given
#   specific input will use the functionality of this namespace, and
#   should define at least the ::pwtk::***::get command, which returns
#   the content of the input (e.g. see ::pwtk::pwi::get). To maintain
#   a consistent API, each such implementation should also define the
#   following two short-cut procs (that should be exported):
#   * ::pwtk::***_get -- returns the content of the input 
#   * ::pwtk::***_fprint -- prints the content of the input to a file or stdout
#   * ::pwtk::***_clear -- clears the content of the input
#
#******

namespace eval ::pwtk::input {

    variable input       ""
    variable channel     stdout
    variable stack       ""
    variable stackLevel  0

    # export the following commands

    variable exportList {
	namelist
	namelistPrint
	namelistGet
	namelistGetPWTK
        namelistGetVarValue        
	namelistClear

	namelist.affix
	namelist.affixPrint
	namelist.affixGet
	namelist.affixPrintAffix
	namelist.affixGetAffix
        
	card
	cardFlags
	cardContent
	cardPrepend
	cardAppend
	cardPrint
	cardGet
	cardGetPWTK
	cardGetContent
	cardGetFlags
	cardClear

	script
	scriptPrepend
	scriptAppend
	scriptPrint
	scriptGet
	scriptClear
        
	printAll
    } 
}


# N.B. this is needed to load the input commands to make 
# ::pwtk::inputSpecs_ functional
source [file join $::pwtk::library src input.tcl]


#****a* Programs/cp.x input
# DESCRIPTION
# Handling of the cp.x input. For further details, see ::pwtk::cpi.
#******
#****n* cp.x input/::pwtk::cpi
# NAME
#   ::pwtk::cpi
# DESCRIPTION
#   Namespace for handling the cp.x input.
#
#   CPI == CP.x Input
#
# COMMANDS
#   * cpi_fprint    -- print the content of the cp.x input file either to stdout or to file
#   * cpi_get       -- return the content of the cp.x input 
#   * cpi_clear     -- clear the content of the cp.x input
#   * cpi_visualize -- vizualize the structure from the cp.x input with xcrysden
#
#   Note that many ::pwtk::pwi routines can be used also for cp.x,
#   because pw.x and cp.x inputs are very similar, hence ::pwtk::pwi
#   routines should also largely work for cp.x
#  
#******
namespace eval ::pwtk::cpi {
    set ::pwtk::prog2inNN(cp.x)   ::pwtk::cpi
    set ::pwtk::prog2runCmd(cp.x) ::pwtk::runCP
    
    # "all_atomic_species" are used in ::pwtk::cpi::get
    variable all_atomic_species

    ::pwtk::inputSpecs_ cp.x [namespace current] {
        { namelist CONTROL {} }
        { namelist SYSTEM.ntyp {} }
        { namelist ELECTRONS {} }
        { namelist IONS.ntyp {} }
        { namelist CELL {} }
        { namelist PRESS_AI {} }
        { namelist WANNIER {} }
        { card_wo_flags ATOMIC_SPECIES {} }
        { card ATOMIC_POSITIONS {} }
        { card_wo_flags ATOMIC_VELOCITIES {} }
        { card CELL_PARAMETERS {} }
        { card REF_CELL_PARAMETERS {} }
        { card_wo_flags CONSTRAINTS {} }
        { card_wo_flags OCCUPATIONS {} }
        { card_wo_flags ATOMIC_FORCES {} }
        { card_wo_flags PLOT_WANNIER {} }
        { card {AUTOPILOT ENDRULES} AUTOPILOT }        
    }

    ## define all the cp.x namelist
    #
    #variable namelist_flow_list {
    #    CONTROL
    #    SYSTEM
    #    ELECTRONS
    #    IONS
    #    CELL
    #    PRESS_AI
    #    WANNIER
    #}
    #
    ## define all the cp.x cards
    #
    #variable card_flow_list {
    #    ATOMIC_SPECIES
    #    ATOMIC_POSITIONS
    #    ATOMIC_VELOCITIES
    #
    #    CELL_PARAMETERS
    #    REF_CELL_PARAMETERS
    #
    #    CONSTRAINTS
    #    OCCUPATIONS
    #    
    #    ATOMIC_FORCES
    #    PLOT_WANNIER
    #    AUTOPILOT
    #}
    #variable input_flow_list [concat $namelist_flow_list $card_flow_list]
    
    variable exportList {
	load_fromCPI
    }

    ## create commands for all the namelists
    #
    #foreach name_ $namelist_flow_list {
    #    set ::pwtk::ntyp_variables($name_) 1
    #    proc $name_ {content} "::pwtk::input::namelist $name_ \$content"
    #}
    #
    ## create commands for all the cards
    #
    #foreach card $card_flow_list {
    #    proc $card {args} "eval ::pwtk::input::card $card \$args"
    #}    

    # load configuration files

    ::pwtk::loadConfig_ ::pwtk::cpi cpi.tcl
}


#****a* Programs/pw.x input
# DESCRIPTION
# Handling of the pw.x input. For further details, see ::pwtk::pwi.
#******
#****n* pw.x input/::pwtk::pwi
# NAME
#   ::pwtk::pwi
# DESCRIPTION
#   Namespace for handling the pw.x input data.
#
#   PWI == PW.x Input
#
# COMMANDS
#   * pwi_fprint    -- print the content of the pw.x input either to stdout or to file
#   * pwi_get       -- return the content of the pw.x input
#   * pwi_clear     -- clear the content of the pw.x input
#   * pwi_visualize -- vizualize the structure from the pw.x input file with xcrysden
#******

namespace eval ::pwtk::pwi {
    set ::pwtk::prog2inNN(pw.x)   ::pwtk::pwi
    set ::pwtk::prog2runCmd(pw.x) ::pwtk::runPW

    # "all_atomic_species" are used in ::pwtk::pwi::get and
    # ::pwtk::pwi::getAllAtomicLabels, which is used by
    # ::pwtk::input::namelistAtmSymb2Ityp
    variable all_atomic_species

    ::pwtk::inputSpecs_ pw.x [namespace current] {
        { namelist CONTROL {} }
        { namelist SYSTEM.ntyp {} }
        { namelist ELECTRONS {} }
        { namelist IONS {} }
        { namelist CELL {} }
        { namelist FCP {} }
        { namelist RISM.ntyp {} }
        { card_wo_flags ATOMIC_SPECIES {} }
        { card CELL_PARAMETERS {} }
        { card ATOMIC_POSITIONS {} }
        { card K_POINTS {} }
        { card ADDITIONAL_K_POINTS {} }
        { card_wo_flags CONSTRAINTS {} }
        { card_wo_flags OCCUPATIONS {} }
        { card ATOMIC_VELOCITIES {} }
        { card_wo_flags ATOMIC_FORCES {} }
        { card SOLVENTS {} }
        { card_w_flags HUBBARD {} }
    }

    ## define all the pw.x namelist
    #
    #variable namelist_flow_list {
    #    CONTROL
    #    SYSTEM
    #    ELECTRONS
    #    IONS
    #    CELL
    #    FCP
    #    RISM
    #}
    #
    ## define all the pw.x cards
    #
    #variable card_flow_list {
    #    ATOMIC_SPECIES
    #    CELL_PARAMETERS
    #    ATOMIC_POSITIONS
    #    K_POINTS
    #    ADDITIONAL_K_POINTS
    #    CONSTRAINTS
    #    OCCUPATIONS
    #    ATOMIC_VELOCITIES
    #    ATOMIC_FORCES
    #    SOLVENTS
    #    HUBBARD
    #}

    #variable input_flow_list [concat $namelist_flow_list $card_flow_list]

    variable exportList {
	load_fromPWI

	insertAtoms
	deleteAtoms
	deleteAtomsRange
        deleteAtomsLast
        deleteAtoms1st
        displaceAtoms
	replaceCoor
	fixAtoms
	fixAtomsRange
        fixAtomsLast
        fixAtoms1st
	substituteAtmType
        substituteAtom
        substituteAtoms
        
	CELL_PARAMETERS_fromPWO
	CELL_PARAMETERS_fromXSF

	ATOMIC_POSITIONS_fromPWO
	ATOMIC_POSITIONS_fromXSF
	ATOMIC_POSITIONS_fromCRD

	CELL_PARAMETERS_and_ATOMIC_POSITIONS_fromPWO
	CELL_PARAMETERS_and_ATOMIC_POSITIONS_fromXSF
    }

    ## create commands for all the namelists
    #
    #foreach name_ $namelist_flow_list {
    #    set ::pwtk::ntyp_variables($name_) 1
    #    proc $name_ {content} "::pwtk::input::namelist $name_ \$content"
    #}
    #
    ## create commands for the cards (skip K_POINTS, which is special)
    #
    #foreach card $card_flow_list {
    #    if { $card != "K_POINTS" } {
    #        proc $card {args} "eval ::pwtk::input::card $card \$args"
    #    }
    #}

    
    # special handling of K_POINTS card, usage:
    #
    #    K_POINTS ?flag? content
    #
    # or for flag==gamma
    #
    #    K_POINTS flag 

    proc K_POINTS {args} {
	if { [llength $args] == 1 } {
	    # perhaps: flags == gamma ?
	    set flags   [lindex $args 0]
	    set content ""
            if { ! [string match -nocase *gamma* $flags] } {
                # not gamma !
                set content $flags
                set flags ""
            }
	} else {
	    set flags   [lindex $args 0]
	    set content [lindex $args 1]
	}	
	::pwtk::input::card K_POINTS $flags $content
    }

    # load configuration files

    ::pwtk::loadConfig_ ::pwtk::pwi pwi.tcl
}

#****a* 5.2. Outputs/pw.x output
# DESCRIPTION
# Handling of the pw.x output. For further details, see ::pwtk::pwo.
#******
#****n* pw.x output/::pwtk::pwo
# NAME
#   ::pwtk::pwo
# DESCRIPTION
#   Namespace for handling the pw.x output.
#
#   PWO == PW.x Output
#******

namespace eval ::pwtk::pwo {}


#****a* Programs/ph.x input
# DESCRIPTION
# Handling of the ph.x input.  For further details, see ::pwtk::phi.
#******
#****n* ph.x input/::pwtk::phi
# NAME
#   ::pwtk::phi
# DESCRIPTION
#   Namespace for handling the ph.x (phonon) input.
#
#   PHI == PH.x Input
#******

namespace eval ::pwtk::phi {
    set ::pwtk::prog2inNN(ph.x)   ::pwtk::phi
    set ::pwtk::prog2runCmd(ph.x) ::pwtk::runPH

    ::pwtk::inputSpecs_ pw.x [namespace current] {
        { namelist.affix INPUTPH.ntyp {} }
    }
    #variable input_flow_list INPUTPH
    # set ::pwtk::ntyp_variables(INPUTPH) 1
    proc INPUTPH {args} " eval ::pwtk::phi::input_ \$args "

    variable exportList {
	load_fromPHI
    }

    # load configuration files

    ::pwtk::loadConfig_ ::pwtk::phi phi.tcl
}


#****a* Programs/neb.x input
# DESCRIPTION
# Handling of the neb.x input. For further details, see ::pwtk::nebi.
#******
#****n* neb.x input/::pwtk::nebi
# NAME
#   ::pwtk::nebi
#
# DESCRIPTION
#   Namespace for handling the neb.x input.
#
#   NEBI == NEB.x Input
#******

namespace eval ::pwtk::nebi {
    set ::pwtk::prog2inNN(neb.x)   ::pwtk::nebi
    set ::pwtk::prog2runCmd(neb.x) ::pwtk::runNEB

    # I am not really sure what this will do:
    
    ::pwtk::inputSpecs_ neb.x [namespace current] {
        { card {BEGIN END} {} }
        { card {BEGIN_PATH_INPUT END_PATH_INPUT} {} }
        { namelist PATH {} }
        { card_wo_flags CLIMBING_IMAGES {} }
        { card {BEGIN_ENGINE_INPUT END_ENGINE_INPUT} {} }
        { card {BEGIN_POSITIONS END_POSITIONS} POSITIONS }
    }

    #variable input_flow_list {
    #    PATH CLIMBING_IMAGES POSITIONS
    #}    

    #set ::pwtk::ntyp_variables(PATH) 1; # not really needed, because PATH has no ntyp-type variables

    # redefining (explicit card_wo_flags): 
    proc CLIMBING_IMAGES  {content} { ::pwtk::input::card CLIMBING_IMAGES  $content }
    proc POSITIONS {content}        { ::pwtk::input::card POSITIONS  $content }

    variable exportList {
	load_fromNEBI
        
        addImage
        addImageCoor_fromPWO
        addImageCoor_fromXSF
        addImageCoor_fromCRD

        deleteImageCharges
        deleteImages

        getImage
        getImageAtmPos
        getImageCharge
        getImageUnit
        getPositions

        POSITIONS_fromAXSF
        POSITIONS_fromCRD
        POSITIONS_fromPATH
        
        replaceImage
        setImageCharge
        setImageCharges
    }

    # load configuration files

    ::pwtk::loadConfig_ ::pwtk::nebi nebi.tcl
}

#****a* 5.2. Outputs/neb.x output
# DESCRIPTION
# Handling of the neb.x output. For further details, see ::pwtk::nebo.
#******
#****n* neb.x output/::pwtk::nebo
# NAME
#   ::pwtk::nebo
#
# DESCRIPTION
#   Namespace for handling the neb.x output.
#
#   NEBO == NEB.x Output
#******
namespace eval ::pwtk::nebo {}


#****n* neb.x output/::pwtk::path
# NAME
#   ::pwtk::path
#
# DESCRIPTION
#   Namespace for handling the neb.x path files.
#******
namespace eval ::pwtk::path {}


#****a* Programs/pp.x input
# DESCRIPTION
# Handling of the pp.x input. For further details, see ::pwtk::ppi.
#******
#****n* pp.x input/::pwtk::ppi
# NAME
#   ::pwtk::ppi
# DESCRIPTION
#   Namespace for handling the pp.x (post-processing) input.
#
#   PPI == PP.x Input
#******

namespace eval ::pwtk::ppi {
    set ::pwtk::prog2inNN(pp.x)   ::pwtk::ppi
    set ::pwtk::prog2runCmd(pp.x) ::pwtk::runPP

    ::pwtk::inputSpecs_ neb.x [namespace current] {
        { namelist INPUTPP {} }
        { namelist PLOT {} }
    }
    ## not really needed, because pp.x has no ntyp-type variables
    #set ::pwtk::ntyp_variables(INPUTPP) 1
    #set ::pwtk::ntyp_variables(PLOT) 1
    #variable input_flow_list {
    #    INPUTPP
    #    PLOT
    #}
    #proc INPUTPP {content} "::pwtk::input::namelist INPUTPP \$content"
    #proc PLOT    {content} "::pwtk::input::namelist PLOT    \$content"

    variable exportList {
	load_fromPPI
    }

    # load configuration files

    ::pwtk::loadConfig_ ::pwtk::ppi ppi.tcl    
}


#****a* Programs/projwfc.x input
# DESCRIPTION
# Handling of the projwfc.x input. For further details, see ::pwtk::pri.
#******
#****n* projwfc.x input/::pwtk::pri
# NAME
#   ::pwtk::pri
# DESCRIPTION
#   Namespace for handling the projwfc.x input.
#
#   PRI == PRojwfc.x Input
#******

namespace eval ::pwtk::pri {
    set ::pwtk::prog2inNN(projwfc.x)   ::pwtk::pri
    set ::pwtk::prog2runCmd(projwfc.x) ::pwtk::runPROJWFC

    ::pwtk::inputSpecs_ projwfc.x [namespace current] {
        { namelist PROJWFC {} }
    }

    ##set ::pwtk::ntyp_variables(PROJWFC) 1
    #variable input_flow_list {
    #    PROJWFC
    #}
    #proc PROJWFC {content} "::pwtk::input::namelist PROJWFC \$content"
    
    variable exportList {
	load_fromPRI
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::pri pri.tcl
}

#****a* Programs/dynmat.x input
# DESCRIPTION
# Handling of the dynmat.x input. For further details, see ::pwtk::dmi.
#******
#****n* dynmat.x input/::pwtk::dmi
# NAME
#   ::pwtk::dmi
# DESCRIPTION
#   Namespace for handling the dynmat.x input.
#
#   DMI == DynMat.x Input
#
#   Beware that ::pwtk::dmi uses the DYNMAT namelist to specify the
#   input of dynmat.x, whereas the dynmat.x program actually uses the
#   INPUT namelist.
#******

namespace eval ::pwtk::dmi {
    set ::pwtk::prog2inNN(dynmat.x)   ::pwtk::dmi
    set ::pwtk::prog2runCmd(dynmat.x) ::pwtk::runDYNMAT

    ::pwtk::inputSpecs_ dynmat.x [namespace current] {
        { namelist INPUT.ntyp DYNMAT }
    }

    #set ::pwtk::ntyp_variables(DYNMAT) 1
    #variable input_flow_list {
    #    DYNMAT
    #}
    #proc DYNMAT {content} "::pwtk::input::namelist DYNMAT \$content"

    variable exportList {
	load_fromDMI
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::dmi dmi.tcl
}


#****a* 5.2. Outputs/dynmat.x output
# DESCRIPTION
# Handling of the dynmat.x output. For further details, see ::pwtk::dmo.
#******
#****n* dynmat.x output/::pwtk::dmo
# NAME
#   ::pwtk::dmo
# DESCRIPTION
#   Namespace for handling the dynmat.x output.
#
#   DMO == DynMat.x Output
#******

namespace eval ::pwtk::dmo {}


#****a* Programs/matdyn.x input
# DESCRIPTION
# Handling of the matdyn.x input. For further details, see ::pwtk::mdi.
#******
#****n* matdyn.x input/::pwtk::mdi
# NAME
#   ::pwtk::mdi
# DESCRIPTION
#   Namespace for handling the matdyn.x input.
#
#   MDI == MatDyn.x Input
#
#   Beware that ::pwtk::mdi uses the MATDYN namelist to specify the
#   input of matdyn.x, whereas the matdyn.x program actually uses the
#   INPUT namelist.
#******

namespace eval ::pwtk::mdi {
    set ::pwtk::prog2inNN(matdyn.x)   ::pwtk::mdi
    set ::pwtk::prog2runCmd(matdyn.x) ::pwtk::runMATDYN

    ::pwtk::inputSpecs_ matdyn.x [namespace current] {
        { namelist.affix INPUT.ntyp MATDYN }
    }

    #set ::pwtk::ntyp_variables(MATDYN) 1
    #variable input_flow_list {
    #    MATDYN
    #}    
    #proc MATDYN {namelist {affix {}}} {
    #    ::pwtk::input::namelist MATDYN $namelist
    #    if { $affix != {} } {
    #        ::pwtk::input::card MATDYN.affixCards [::pwtk::input::card_math_parser [string trim $affix]]
    #    }
    #}
    variable exportList {
	load_fromMDI
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::mdi mdi.tcl    
}


#****a* Programs/q2r.x input
# DESCRIPTION
# Handling of the q2r.x input. For further details, see ::pwtk::q2ri.
#******
#****n* q2r.x input/::pwtk::q2ri
# NAME
#   ::pwtk::q2ri
# DESCRIPTION
#   Namespace for handling the matsyn.x input.
#
#   Q2RI == Q2R.x Input
#
#   Beware that ::pwtk::q2ri uses the Q2R namelist to specify the
#   input of q2r.x, whereas the q2r.x program actually uses the
#   INPUT namelist.
#******

namespace eval ::pwtk::q2ri {
    set ::pwtk::prog2inNN(q2r.x)   ::pwtk::q2ri
    set ::pwtk::prog2runCmd(q2r.x) ::pwtk::runQ2R

    ::pwtk::inputSpecs_ q2r.x [namespace current] {
        { namelist.affix INPUT Q2R }
    }

    #set ::pwtk::ntyp_variables(Q2R) 1
    #variable input_flow_list {
    #    Q2R
    #}
    #proc Q2R {namelist {affix {}}} {
    #    ::pwtk::input::namelist Q2R $namelist
    #    if { $affix != {} } {
    #        ::pwtk::input::card Q2R.affixCards [::pwtk::input::card_math_parser [string trim $affix]]
    #    }
    #}

    variable exportList {
	load_fromQ2RI
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::q2ri q2ri.tcl
}


#****a* Programs/hp.x input
# DESCRIPTION
# Handling of the hp.x input. For further details, see ::pwtk::hpi.
#******
#****n* hp.x input/::pwtk::hpi
# NAME
#   ::pwtk::hpi
# DESCRIPTION
#   Namespace for handling the hp.x input.
#
#   HPI == HP.x Input
#
#******
namespace eval ::pwtk::hpi {
    set ::pwtk::prog2inNN(hp.x)   ::pwtk::hpi
    set ::pwtk::prog2runCmd(hp.x) ::pwtk::runHP

    ::pwtk::inputSpecs_ hp.x [namespace current] {
        { namelist INPUTHP.ntyp {} }
    }
    
    #set ::pwtk::ntyp_variables(INPUTHP) 1
    #variable input_flow_list {
    #    INPUTHP
    #}
    #proc INPUTHP {content} {
    #    ::pwtk::input::namelist INPUTHP $content
    #}

    variable exportList {
	load_fromHPI
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::hpi hpi.tcl
}


#****a* Programs/dos.x input
# DESCRIPTION
# Handling of the dos.x input. For further details, see ::pwtk::di.
#******
#****n* dos.x input/::pwtk::di
# NAME
#   ::pwtk::di
# DESCRIPTION
#   Namespace for handling the dos.x input.
#
#   DI == Dos.x Input
#******
namespace eval ::pwtk::di {
    set ::pwtk::prog2inNN(dos.x)   ::pwtk::di
    set ::pwtk::prog2runCmd(dos.x) ::pwtk::runDOS

    ::pwtk::inputSpecs_ dos.x [namespace current] {
        { namelist DOS {} }
    }

    #set ::pwtk::ntyp_variables(DOS) 1
    #variable input_flow_list {
    #    DOS
    #}
    #proc DOS {content} {
    #    ::pwtk::input::namelist DOS $content
    #}
    
    variable exportList {
	load_fromDI
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::di di.tcl
}


#****a* Programs/bands.x input
# DESCRIPTION
# Handling of the bands.x input. For further details, see ::pwtk::bi.
#******
#****n* bands.x input/::pwtk::bi
# NAME
#   ::pwtk::bi
# DESCRIPTION
#   Namespace for handling the bands.x input.
#
#   BI == Bands.x Input
#******
namespace eval ::pwtk::bi {
    set ::pwtk::prog2inNN(bands.x)   ::pwtk::bi
    set ::pwtk::prog2runCmd(bands.x) ::pwtk::runBANDS

    ::pwtk::inputSpecs_ bands.x [namespace current] {
        { namelist BANDS {} }
    }

    #set ::pwtk::ntyp_variables(BANDS) 1
    #variable input_flow_list {
    #    BANDS
    #}
    #proc BANDS {content} {
    #    ::pwtk::input::namelist BANDS $content
    #}

    variable exportList {
	load_fromBI
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::bi bi.tcl
}

#****a* Programs/molecularpdos.x input
# DESCRIPTION
# Handling of the molecularpdos.x input. For further details, see ::pwtk::mpdi.
#******
#****n* molecularpdos.x input/::pwtk::mpdi
# NAME
#   ::pwtk::mpdi
# DESCRIPTION
#   Namespace for handling the molecularpdos.x input.
#
#   MPDI == MolecularPDos.x Input
#******
namespace eval ::pwtk::mpdi {
    set ::pwtk::prog2inNN(molecularpdos.x)   ::pwtk::mpdi
    set ::pwtk::prog2runCmd(molecularpdos.x) ::pwtk::runMOPDOS

    ::pwtk::inputSpecs_ molecularpdos.x [namespace current] {
        { namelist INPUTMOPDOS MOPDOS }
    }

    #set ::pwtk::ntyp_variables(MOPDOS) 1
    #proc MOPDOS {content} {
    #    ::pwtk::input::namelist MOPDOS $content
    #}
    #variable input_flow_list MOPDOS

    # exeception: support INPUTMOPDOS
    proc INPUTMOPDOS {content} {
        ::pwtk::deprecated "please use MOPDOS instead of INPUTMOPDOS"
        MOPDOS $content
    }    
    
    variable exportList {
	load_fromMPDI INPUTMOPDOS
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::mpdi mpdi.tcl
}


#****a* Programs/Linear-response inputs
# DESCRIPTION
# Handling of the linear-response inputs (used internally by PWTK). For further details, see ::pwtk::lri.
#******
#****n* Linear-response inputs/::pwtk::lri
# NAME
#   ::pwtk::lri
# DESCRIPTION
#   Parent namespace for handling the inputs for turbo_***.x set of
#   programs, i.e., for programs that use LR_*** namelists.
#
#   # LRI = Linear-Response Input
#
#   Used internally by PWTK.
#
#******
namespace eval ::pwtk::lri {
    foreach cmd_ {
        LR_INPUT
        LR_DAV
        LR_CONTROL
        LR_POST
    } {
        proc $cmd_ {content} " ::pwtk::input::namelist $cmd_ \$content "

        # BEWARE: we need to export these cmds so that davi, lani, eelsi, and speci can import them !!!
	namespace export $cmd_
    }
}



#****a* Programs/turbo_davidson.x input
# DESCRIPTION
# Handling of the turbo_davidson.x input. For further details, see ::pwtk::davi.
#******
#****n* turbo_davidson.x input/::pwtk::davi
# NAME
#   ::pwtk::davi
# DESCRIPTION
#   Namespace for handling the turbo_davidson.x input.
#
#   DAVI == turbo_DAVidson.x Input
#
#******
namespace eval ::pwtk::davi {
    set ::pwtk::prog2inNN(turbo_davidson.x)   ::pwtk::davi
    set ::pwtk::prog2runCmd(turbo_davidson.x) ::pwtk::runDAVIDSON

    ::pwtk::inputSpecs_ turbo_davidson.x [namespace current] {
        { namelist LR_INPUT {} }
        { namelist LR_DAV {} }
    }

    #variable namelist_flow_list {
    #    LR_INPUT
    #    LR_DAV
    #}
    #variable input_flow_list $namelist_flow_list
    
    #foreach nml $namelist_flow_list {
    #    if { [info procs $nml] ne {} } {
    #        rename $nml {}
    #    }
    #    namespace import ::pwtk::lri::$nml
    #}

    variable exportList {
	load_fromDAVI
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::davi davi.tcl
}


#****a* Programs/turbo_lanczos.x input
# DESCRIPTION
# Handling of the turbo_lanczos.x input. For further details, see ::pwtk::lani.
#******
#****n* turbo_lanczos.x input/::pwtk::lani
# NAME
#   ::pwtk::lani
# DESCRIPTION
#   Namespace for handling the turbo_lanczos.x input.
#
#   LANI == turbo_LANczos.x Input
#
#******
namespace eval ::pwtk::lani {
    set ::pwtk::prog2inNN(turbo_lanczos.x)   ::pwtk::lani
    set ::pwtk::prog2runCmd(turbo_lanczos.x) ::pwtk::runLANCZOS

    ::pwtk::inputSpecs_ turbo_lanczos.x [namespace current] {
        { namelist LR_INPUT {} }
        { namelist LR_CONTROL {} }
        { namelist LR_POST {} }
    }

    #variable namelist_flow_list {
    #    LR_INPUT
    #    LR_CONTROL
    #    LR_POST        
    #}
    #variable input_flow_list $namelist_flow_list
    
    #foreach nml $namelist_flow_list {
    #    rename $nml {}
    #    namespace import ::pwtk::lri::$nml
    #}

    variable exportList {
	load_fromLANI
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::lani lani.tcl
}


#****a* Programs/turbo_eels.x input
# DESCRIPTION
# Handling of the turbo_eels.x input. For further details, see ::pwtk::eelsi.
#******
#****n* turbo_eels.x input/::pwtk::eelsi
# NAME
#   ::pwtk::eelsi
# DESCRIPTION
#   Namespace for handling the turbo_eels.x input.
#
#   EELSI == turbo_EELS.x Input
#
#******
namespace eval ::pwtk::eelsi {
    set ::pwtk::prog2inNN(turbo_eels.x)   ::pwtk::eelsi
    set ::pwtk::prog2runCmd(turbo_eels.x) ::pwtk::runEELS

    ::pwtk::inputSpecs_ turbo_eels.x [namespace current] {
        { namelist LR_INPUT {} }
        { namelist LR_CONTROL {} }
    }

    #variable namelist_flow_list {
    #    LR_INPUT
    #    LR_CONTROL
    #}
    #variable input_flow_list $namelist_flow_list

    #foreach nml $namelist_flow_list {
    #    rename $nml {}
    #    namespace import ::pwtk::lri::$nml
    #}

    variable exportList {
	load_fromEELSI
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::eelsi eelsi.tcl
}


#****a* Programs/turbo_spectrum.x input
# DESCRIPTION
# Handling of the turbo_spectrum.x. For further details, see ::pwtk::speci.
#******
#****n* turbo_spectrum.x input/::pwtk::speci
# NAME
#   ::pwtk::speci
# DESCRIPTION
#   Namespace for handling the turbo_spectrum.x input.
#
#   SPECI == turbo_SPECtrum.x Input
#
#******
namespace eval ::pwtk::speci {
    set ::pwtk::prog2inNN(turbo_spectrum.x)   ::pwtk::speci
    set ::pwtk::prog2runCmd(turbo_spectrum.x) ::pwtk::runSPECTRUM

    ::pwtk::inputSpecs_ turbo_spectrum.x [namespace current] {
        { namelist LR_INPUT {} }
    }

    #variable namelist_flow_list {
    #    LR_INPUT
    #    LR_CONTROL
    #}
    #variable input_flow_list $namelist_flow_list
    
    #foreach nml $namelist_flow_list {
    #    rename $nml {}
    #    namespace import ::pwtk::lri::$nml
    #}    

    variable exportList {
	load_fromSPECI
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::speci speci.tcl
}


#****a* Programs/turbo_magnon.x input
# DESCRIPTION
# Handling of the turbo_magnon.x. For further details, see ::pwtk::magi.
#******
#****n* turbo_magnon.x input/::pwtk::magi
# NAME
#   ::pwtk::magi
# DESCRIPTION
#   Namespace for handling the turbo_magnon.x input.
#
#   MAGI == turbo_MAGnon.x Input
#
#******
namespace eval ::pwtk::magi {
    set ::pwtk::prog2inNN(turbo_magnon.x)   ::pwtk::magi
    set ::pwtk::prog2runCmd(turbo_magnon.x) ::pwtk::runMAGNON

    ::pwtk::inputSpecs_ turbo_magnon.x [namespace current] {
        { namelist LR_INPUT {} }
        { namelist LR_CONTROL {} }
    }

    #variable namelist_flow_list {
    #    LR_INPUT
    #    LR_CONTROL
    #}
    #variable input_flow_list $namelist_flow_list
    
    #foreach nml $namelist_flow_list {
    #    rename $nml {}
    #    namespace import ::pwtk::lri::$nml
    #} 
    variable exportList {
	load_fromMAGI
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::magi magi.tcl
}


#****a* Plugins/ENVIRON input
# DESCRIPTION
# Handling of the Environ "environ.in" input. For further details, see ::pwtk::environ.
#******
#****n* ENVIRON input/::pwtk::environ
# NAME
#   ::pwtk::environ
#
# DESCRIPTION
#   Namespace for handling the ENVIRON calculations and ENVIRON's
#   |html <tt>environ.in</tt> input.
#
#   Environ calculations are turned on by calling:
#  
#       environ on
#
#   This command adds a --environ to the POSTFIX, hence pw.x (or cp.x,
#   neb.x) are then executed by runPW as:
#
#       pw.x --environ ...
#
# Note that when Environ is turned on, the call to runPW (or runCP,
# runNEB) also makes a backup copy of the environ.in file. For
# example, the following call:
#    runPW example
# will make a backup copy of environ.in to environ.example.in
#
#   To turn off Environ, use:
#
#       environ off
#
#   As a utility, there are also "environ from_scratch" and "environ restart", i.e.:
#      environ from_scratch
#   is equivalent to
#      environ on
#      ENVIRON { environ_restart = .false. }
#   and
#      environ restart
#   is equivalent to
#      environ on
#      ENVIRON { environ_restart = .true. }
#******
namespace eval ::pwtk::environ {
    variable plugin environ
    
    lappend ::pwtk::plugin(list) environ
    array set ::pwtk::plugin {
        environ,flag  -environ 
        environ,input  environ.in 
        environ,programs  {pw.x cp.x neb.x turbo_davidson.x turbo_lanczos.x turbo_eels.x turbo_magnon.x turbo_spectrum.x xspectra.x} 
        environ,restartScript  {ENVIRON { environ_restart = .true. }}
        environ,scratchScript  {ENVIRON { environ_restart = }}
    }

    ::pwtk::pluginSpecs_ environ  {
        { namelist ENVIRON.ntyp {} }
        { namelist BOUNDARY.ntyp {} }
        { namelist ELECTROSTATIC {} }
        { card EXTERNAL_CHARGES {} }
        { card DIELECTRIC_REGIONS {} }
    }

    #variable namelist_flow_list {
    #    ENVIRON
    #    BOUNDARY
    #    ELECTROSTATIC
    #}
    #variable card_flow_list {
    #    EXTERNAL_CHARGES
    #    DIELECTRIC_REGIONS
    #}
    #variable input_flow_list [concat $namelist_flow_list $card_flow_list]
    
    ## create commands for all the namelists
    #
    #foreach name_ $namelist_flow_list {
    #    set ::pwtk::ntyp_variables($name_) 1
    #    proc $name_ {content} "::pwtk::input::namelist $name_ \$content"
    #}
    #
    ## create commands for all the cards
    #
    #foreach card $card_flow_list {
    #    proc $card {args} "eval ::pwtk::input::card $card \$args"
    #}    


    variable exportList {
        environ
	load_environ.in
        save_environ.in
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::environ environ.tcl
}


#****a* 5.9. Batch Queuing/Queue-generic-API
# NAME
#   ::pwtk::queue
#
# PURPOSE
#   This namespace is used internally by PWTK.
#
# DESCRIPTION
#   Namespace for generic support of batch queueing systems.  Any
#   implementation of the support for a particular batch queueing
#   system should use the ::pwtk::queue API.
#
#   Any actual implementation of a specific queing systems should
#   define at least the init proc:
#   * init -- for initialization (see e.g. ::pwtk::slurm::init)
#
#   Optionally, it may also define the following procs:
#   * submit -- to tell PWTK how to submit jobs to particular queuing system
#               (if not defined, a generic ::pwtk::queue::submit is used)
#   * optionParser -- for selecting the option parser
#   * addOptionsToCmdLine_  -- proc used for optionParser == none
#   * addOptionsToBatchScript_ -- proc used for optionParser == parse
#
#******

#****n* Queue-generic-API/::pwtk::queue
# NAME
#   ::pwtk::queue
#
# SEE
#    For description see 5.9. Batch Queuing/Queue-generic-API
#******

namespace eval ::pwtk::queue {
    variable queue
    variable batchScript
    variable counter
    variable direct
    variable profile
    variable pwtk_profile    
}


#****n* 5.9. Batch Queuing/::pwtk::slurm
# NAME
#   ::pwtk::slurm
# DESCRIPTION
#   Implementation of handling of the SLURM batch queueing system.
#  
#   SLURM == Simple Linux Utility for Resource Management
#******

namespace eval ::pwtk::slurm {
    # initialize
    init
    
    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::slurm slurm.tcl

    # backward compatibility
    ::pwtk::queue::compatibility
}


#****n* 5.9. Batch Queuing/::pwtk::ll
# NAME
#   ::pwtk::ll
# DESCRIPTION
#   Implementation of handling of the LL (Load Leveler) batch queueing
#   system.
#  
#   LL == Load-Leveler
#******

namespace eval ::pwtk::ll {
    # initialize
    init
    
    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::ll ll.tcl

    # backward compatibility
    ::pwtk::queue::compatibility
}


#****n* 5.9. Batch Queuing/::pwtk::lsf
# NAME
#   ::pwtk::lsf
# DESCRIPTION
#   Implementation of handling of the Platform LSF batch queueing
#   system.
#******

namespace eval ::pwtk::lsf {    
    # initialize
    init
    
    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::lsf lsf.tcl

    # backward compatibility
    ::pwtk::queue::compatibility
}


#****n* 5.9. Batch Queuing/::pwtk::pbs
# NAME
#   ::pwtk::pbs
# DESCRIPTION
#   Implementation of handling of the Platform PBS batch queueing
#   system.
#******

namespace eval ::pwtk::pbs {    
    # initialize
    init
    
    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::pbs pbs.tcl

    # backward compatibility
    ::pwtk::queue::compatibility
}


#****n* 5.9. Batch Queuing/::pwtk::sh
# NAME
#   ::pwtk::sh
# DESCRIPTION
#   Implementation of dummy shell emulation of the batch queueing system.
#******

namespace eval ::pwtk::sh {    
    # initialize
    init

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::sh sh.tcl

    # backward compatibility
    ::pwtk::queue::compatibility
}


#****n* EOS/::pwtk::eos
# NAME
#   ::pwtk::eos
#
# DESCRIPTION
#   The namescape where the EOS utility resides. EOS stands for
#   equation-of-state. The purpose of this namespace is the
#   implementation of the automatic "A" lattice parameter search and bulk
#   modulus calculation. For noncubic systems, only the "A" lattice parameter
#   is optimized, keeping the cell-shape intact.
#
# SEE ALSO
#   For more info see the ::pwtk::eos::EOS
#
#******

namespace eval ::pwtk::eos { 
    variable eos
    variable eos_default

    variable exportList {
        EOS
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::eos eos.tcl

    # eos definitions in config/eos.tcl are used as eos_defaults
    array set eos_default [array get eos]
}


#****n* DIFDEN/::pwtk::difden
# NAME
#   ::pwtk::difden
# DESCRIPTION
#   The DIFDEN acronym stands for difference-density. The purpose of
#   this namespace is the implementation of the automatic "difden"
#   calculation.
# SEE ALSO
#   For more info see the ::pwtk::difden::DIFDEN
#
#******

namespace eval ::pwtk::difden { 
    variable difden

    variable exportList {
        DIFDEN
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::difden difden.tcl
}


#****n* FLO/::pwtk::flo
# NAME
#   ::pwtk::flo
# DESCRIPTION
#   FLO == first_last_opt
#
#   Namespace for the FLO calculation: this is a path-type transition
#   state search (i.e. neb or smd), where the first and last images
#   are first optimized by pw.x relax calculations and only then the
#   neb.x path calculation is performed using the optimized
#   coordinates for the first & last images.
#
#******

namespace eval ::pwtk::flo {}

#****n* PSEUDO/::pwtk::pseudo
# NAME
#   ::pwtk::pseudo
#
# DESCRIPTION
#   The namescape for the PSEUDO utility, aimed at testing
#   pseudopotentials: so far, it uses poor-man's total-energy
#   criterium, where the convergence of total-energy vs ecutwfc &
#   ecutrho is tested.
#
#******

namespace eval ::pwtk::pseudo {
    variable opts
    variable gpData
    ::pwtk::loadConfig_ ::pwtk::pseudo pseudo.tcl
}


#****n* Gnuplot/::pwtk::gp
# NAME
#   ::pwtk::gp
#
# DESCRIPTION
#   Namespace for script-oriented and configurable commands for
#   making plots with Gnuplot ( http://www.gnuplot.info/ ).
#
#******
namespace eval ::pwtk::gp {    
    # variables used by ::pwtk::gp
    # (they are initialized in ../config/gnuplot.tcl)
    variable known_options
    variable gp
    variable options
    variable pwtk2gp

    # plot counters
    variable plot_id
    variable multiplot_id
    variable splot_id

    ::pwtk::loadConfig_ ::pwtk::gp gnuplot.tcl
}


#****n* SBCO/::pwtk::sbco
# NAME
#   ::pwtk::sbco
# DESCRIPTION
#   The SBCO stands for Scan-Bond Constrained-Optimization
#
#   This is an implementation of the goldie-oldie constrained type
#   optimizations, i.e., SBCO performs a scan over the length of a
#   specified bond and at each snapshot it optimizes the rest of the
#   degrees of freedom.
#
#   BEWARE: the SBCO calculation requires external program: xsf2_manipulator 
#******

namespace eval ::pwtk::sbco { 
    variable sbco
    variable sbco_default

    variable exportList {
        SBCO
    }

    # load configuration files
    ::pwtk::loadConfig_ ::pwtk::sbco sbco.tcl
}


#****n* xsf_struct_utils/::pwtk::xsf
# NAME
#   ::pwtk::xsf
# DESCRIPTION
#   This namespaces provides some procs for transforming the
#   XSF-formatted stuctural data. See: xsf_struct_utils.
#******
namespace eval ::pwtk::xsf {}


#****n* LOBSTER/::pwtk::lobster
# NAME
#   ::pwtk::lobster
# DESCRIPTION
#   This namespaces contains the implementation of the LOBSTER
#   chemical-bonding analysis. It requires the LOBSTER program:
#   http://www.cohp.de/
#******
namespace eval ::pwtk::lobster {
    variable exportList LOBSTER
    proc LOBSTER {content} {
        ::pwtk::input::card LOBSTER $content
    }
}


#****n* Types/::pwtk::type
# DESCRIPTION
#   Namespace for a few commands for checking the types of variables/arguments/options.
#******
namespace eval ::pwtk::type {}

# load Tcllib's cmdline, fileutil & math::linearalgebra packages

lappend auto_path [file join $::pwtk::library external cmdline]
lappend auto_path [file join $::pwtk::library external fileutil]
lappend auto_path [file join $::pwtk::library external math]
package require cmdline
package require fileutil
package require math::linearalgebra

# load tclu package
#lappend auto_path [file join $::pwtk::library lib]
#package require tclu

# load the Jose F. Nieves's ssh package

lappend auto_path [file join $::pwtk::library external ssh]
package require ssh
::ssh::executable $::pwtk::remote(rsh)

# add traces on the ::pwtk::remote array
# * remote(rsh) to call ::ssh::executable if the value of ::pwtk::remote(rsh) changes
# * remote(time_interval) to recalculate remote(time_interval_ms) if the value of remote(time_interval) changes

trace add variable ::pwtk::remote write {apply {{v1 v2 op} {
    upvar 1 $v1 var
    switch -exact -- $v2 {
        rsh { ::ssh::executable $var(rsh) }
        time_interval { set var(time_interval_ms) [::pwtk::time2ms $var(time_interval)] }
    }}}}

# load the (semi)auto-defined support for QE programs, inputs, and plugins

source [file join $::pwtk::library src auto-inputs.tcl]
source [file join $::pwtk::library src auto-plugins.tcl]
source [file join $::pwtk::library src auto-defaults.tcl]

#
# load the main configuration file (this should be done at the end)
#
::pwtk::loadConfig_ ::pwtk pwtk.tcl

#
# export PWTK commands (and import "input_flow_list" cmds to global namespace)
#
::pwtk::ifset tcl_interactive 0
foreach ns [concat ::pwtk [namespace children ::pwtk]] {
    foreach listName {
        input_flow_list
        exportList
    } {
        if { [info exists ${ns}::$listName] } {
            upvar #0 ${ns}::$listName elist
            namespace eval ${ns} namespace export {*}$elist

            # import "input_flow_list" cmds to global namespace
            if { $listName == "input_flow_list" } {
                foreach pwtk_cmd_ $elist {
                    namespace import -force ${ns}::$pwtk_cmd_
                }
            }

            if { $tcl_interactive } {
                # inform tclreadline about exported PWTK cmds
                foreach cmd_ $elist {
                    ::tclreadline::readline add $cmd_
                }
            }               
        }
    }
}

proc ::pwtk::import_exported {} {
    # import exported cmds to the global namespace
    namespace eval :: {
        foreach ns [concat ::pwtk [namespace children ::pwtk]] {
            foreach listName {
                exportList
            } {
                if { [info exists ${ns}::$listName] } {
                    upvar #0 ${ns}::$listName elist                
                    foreach pwtk_cmd_ $elist {
                        namespace import -force ${ns}::$pwtk_cmd_
                    }
                }
            }
        }

        # import also gp command
        namespace import ::gp::gp
    }
}
proc ::pwtk::load_test {} {
    namespace eval ::pwtk { namespace export test }
    namespace eval :: { namespace import ::pwtk::test }
}


# if PWTK is used as the application, do some extra initialization
#
# BEWARE: namelist and cards commands should be imported into the
# global namespace anyway because in many instances PWTK code used them as such

if { [info exists PWTK_APPLICATION] && $PWTK_APPLICATION } {
    
    # import exported cmds to global namespace

    ::pwtk::import_exported
    
    # define some constants (as global variables)

    set bohr2angs  $::pwtk::bohr2angs
    set angs2bohr  $::pwtk::angs2bohr
    set ry2ev      $::pwtk::ry2ev
    set ev2ry      $::pwtk::ev2ry
    set ha2ev      $::pwtk::ha2ev      
    set ev2ha      $::pwtk::ev2ha 
    set ry2kjm     $::pwtk::ry2kjm
    set kjm2ry     $::pwtk::kjm2ry
    set ha2kjm     $::pwtk::ha2kjm
    set kjm2ha     $::pwtk::kjm2ha
    set pi         $::pwtk::pi
    set tpi        $::pwtk::tpi   
    
    ## welcome greater
    #
    #set host_ [info hostname]
    #set date_ [clock format [clock seconds]]
    #
    #if { ! [info exists _silent] } {
    #    ::pwtk::print "========================================================================"
    #    ::pwtk::print "*** PWTK-$::pwtk::version    (PWscf ToolKit: a Tcl scripting environment)"
    #    ::pwtk::print "========================================================================"
    #    ::pwtk::print "(for more info about PWTK, see http://pwtk.ijs.si/)\n"
    #    ::pwtk::print "Running on host: $host_"
    #    ::pwtk::print "PWTK: [::pwtk::varvalue env(PWTK)]"
    #    ::pwtk::print "Date: $date_"     
    #    ::pwtk::print "PID:  [pid]\n"
    #}
}

# replace rc (release candidate) with b (beta) or dev (development) with a1 to satisfy "package" version numbering
package provide pwtk [regsub rc [regsub {dev$} $::pwtk::version a1] b]
