set minussign
set term pngcairo enhanced color font 'Arial,11' size 1000,667 background '#ffffff'
set output "pwtk-palette.png"

set pm3d; set palette
set pm3d map
set cbrange [-10:10]
set xrange [-10:10]
set yrange [*:*]
unset ztics
unset ytics
set samples 101
set isosamples 2
set xtics 2
set format x ""

set format cb "%+2.0f"

set rmargin 0
set lmargin 0
set tmargin 0
set bmargin 0

unset key
set multiplot layout 3,4
#set palette model RGB

# gnuplot default

set palette color model RGB rgbformulae 7,5,15
set title "gnuplot"
splot x

# gnuplot green-red-violet
set palette rgbformulae 3,11,6
set title "green-red-violet"
splot x

# green-blue-red-orange
set palette defined ( 0 "green", 1 "blue", 2 "red", 3 "orange" ) 
set title "green-blue-red-orange"
splot x

# xc rgb
set palette defined (0  1 0 0,  1  0 1 0,  2  0 0 1)
set title "rgb"
splot x

# gnuplot rainbow
set palette rgbformulae 33,13,10
set title "pale-rainbow"
splot x

set palette file "-"
0.750   0.243   0.95
0.000   0.322   0.95
0.173   0.816   0.95
0.408   0.950   0.176
0.95    0.950   0.000
1.000   0.635   0.0
1.000   0.0     0.0
end
set title "rainbow"
splot x
## xc rainbow
#set palette file "-"
#0  1 0 0
#1  1 0.5 0
#2  1 1 0
#3  0 1 0
#4  0 1 1
#5  0 0 1
#6  0.7 0 1
#end
#set title "rainbow"
#splot x

# xc blue-white-red
set palette file "-"
0.0 0.0 1.0
0.63 0.63 1.0
1.0 1.0 1.0
1.0 0.63 0.63
1.0 0.0 0.0
end
set title "blue-white-red"
splot x

# xc dark-bluew-white-red
set palette file "-"
0.0 0.0 0.5
0.6 0.6 1.0
1.0 1.0 1.0
1.0 0.6 0.6
0.5 0.0 0.0
end
set title "dark-blue-white-red"
splot x

# gnuplot ocean
set palette rgbformulae 23,28,3
set title "ocean"
splot x

# gnuplot AFM hot
set palette rgbformulae 34,35,36
set title "AFM"
splot x

# xc STM
set palette file "-"
       0.0 0.0 0.0
       0.48 0.14 0.02
       0.78 0.63 0.07
       1.0 1.0 1.0
       end
set title "STM"
splot x


# grayscale
set palette defined (0  0 0 0, 1  1 1 1)
set title "grayscale"
splot x

# or
#set palette gray

#pause -1