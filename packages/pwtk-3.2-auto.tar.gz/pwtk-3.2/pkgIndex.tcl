set channel [open [file join $dir VERSION] r]
# replace rc (release candidate) with b (beta) or dev (development) with a1 to satisfy "package" version numbering
set version [regsub rc [regsub {dev$} [gets $channel] a1] b]
close $channel

set ::env(PWTK) $dir
package ifneeded pwtk $version [list source [file join $dir init.tcl]]
