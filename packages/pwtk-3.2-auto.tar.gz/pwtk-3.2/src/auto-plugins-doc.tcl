#
# $RCSfile: auto-plugins-doc.tcl,v $ --
#
#      This file contains the documentation for the auto generated
#      support for QE plugins (see auto-plugins.tcl).
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: auto-plugins-doc.tcl,v 1.0 2024/01/01 00:00:00 kokalj Exp $ 
#


#****a* Plugins/OSCDFT input
# DESCRIPTION
# Handling of the OSCDFT oscdft.in input. For further details, see ::pwtk::oscdft.
#******

#****n* OSCDFT input/::pwtk::oscdft
# NAME
#   ::pwtk::oscdft
#
# DESCRIPTION
#   Namespace for handling the OSCDFT calculations and OSCDFT's
#   |html <tt>oscdft.in</tt> input.
#
#   OSCDFT calculations are turned on by calling:
#  
#       oscdft on
#
#   This command adds the -oscdft flag to POSTFIX, hence pw.x is
#   then executed by ::pwtk::runPW as:
#
#       pw.x -oscdft ...
#
#   Note that when OSCDFT is turned on, the call to ::pwtk::runXX also makes
#   a backup copy of the oscdft.in file. For example, the following call:
#
#       runPW example
#
#   will make a backup copy of oscdft.in to oscdft.example.in
#
#   To turn off OSCDFT, use:
#
#       oscdft off
#
#******

#****f* ::pwtk::oscdft/::pwtk::oscdft::fprint
# USAGE
#   ::pwtk::oscdft::fprint ?FILE?        
# PURPOSE
#   Print the content of the OSCDFT input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::oscdft/::pwtk::oscdft::get
# USAGE
#   ::pwtk::oscdft::get
# DESCRIPTION    
#   Returns the content of the OSCDFT input 
#******

#****f* ::pwtk::oscdft/::pwtk::oscdft::clear
# USAGE
#   ::pwtk::oscdft::clear
# PURPOSE
#   Clear the OSCDFT input data.
#******

#****f* ::pwtk::oscdft/::pwtk::oscdft::load_oscdft.in
# USAGE
#   ::pwtk::oscdft::load_oscdft.in FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing OSCDFT input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the OSCDFT input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* ::pwtk::oscdft/::pwtk::oscdft::oscdft
# USAGE
#   oscdft ?SWITCH?
#
# PURPOSE
#   Activate or deactivate the OSCDFT plugin. If the SWITCH argument is
#   omitted, the current OSCDFT status is returned, which can be "on" or "off".
#
# USAGE 
#    oscdft on
# or
#    oscdft off
# or
#    oscdft
#
# DESCRIPTION
# The oscdft command can be called as:
#
# |html &bull; <b>oscdft on</b> implies adding the <b>-oscdft</b> flag to POSTFIX (e.g., pw.x -oscdft)
#
# |html &bull; <b>oscdft off</b> implies removing the  <b>-oscdft</b> flag from POSTFIX
#
# |html &bull; <b>oscdft</b> queiries the current oscdft status (on or off)   
#
# WARNINGS 
#   To use the OSCDFT plugin, QE needs to be compiled with OSCDFT enabled.
#******

#****f* ::pwtk::oscdft/::pwtk::oscdft::save_oscdft.in
# USAGE
#   save_oscdft.in FILE
# PURPOSE
#   Save the OSCDFT data to oscdft.in and also its backup to the 'FILE' file.
#******

#****a* Plugins/ARTN input
# DESCRIPTION
# Handling of the ARTN artn.in input. For further details, see ::pwtk::artn.
#******

#****n* ARTN input/::pwtk::artn
# NAME
#   ::pwtk::artn
#
# DESCRIPTION
#   Namespace for handling the ARTN calculations and ARTN's
#   |html <tt>artn.in</tt> input.
#
#   ARTN calculations are turned on by calling:
#  
#       artn on
#
#   This command adds the -partn flag to POSTFIX, hence pw.x is
#   then executed by ::pwtk::runPW as:
#
#       pw.x -partn ...
#
#   Note that when ARTN is turned on, the call to ::pwtk::runXX also makes
#   a backup copy of the artn.in file. For example, the following call:
#
#       runPW example
#
#   will make a backup copy of artn.in to artn.example.in
#
#   To turn off ARTN, use:
#
#       artn off
#
#   There are also 'artn restart' and 'artn from_scratch' modes (the
#   first restarts the ARTN calculation and the latter resets it
#   back to from-scratch
#******

#****f* ::pwtk::artn/::pwtk::artn::fprint
# USAGE
#   ::pwtk::artn::fprint ?FILE?        
# PURPOSE
#   Print the content of the ARTN input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::artn/::pwtk::artn::get
# USAGE
#   ::pwtk::artn::get
# DESCRIPTION    
#   Returns the content of the ARTN input 
#******

#****f* ::pwtk::artn/::pwtk::artn::clear
# USAGE
#   ::pwtk::artn::clear
# PURPOSE
#   Clear the ARTN input data.
#******

#****f* ::pwtk::artn/::pwtk::artn::load_artn.in
# USAGE
#   ::pwtk::artn::load_artn.in FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing ARTN input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the ARTN input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* ::pwtk::artn/::pwtk::artn::artn
# USAGE
#   artn ?SWITCH?
#
# PURPOSE
#   Activate or deactivate the ARTN plugin. If the SWITCH argument is
#   omitted, the current ARTN status is returned, which can be "on" or "off".
#
# USAGE 
#    artn on
# or
#    artn off
# or
#    artn restart
# or
#    artn from_scratch
# or
#    artn
#
# DESCRIPTION
# The 'artn' command can be called as:
#
# |html &bull; <b>artn on</b> implies adding the <b>-partn</b> flag to POSTFIX (e.g., pw.x -partn)
#
# |html &bull; <b>artn off</b> implies removing the <b>-partn</b> flag from POSTFIX
#
# |html &bull; <b>artn restart</b> implies adding the <b>-partn</b> flag to POSTFIX and setting the ARTN calculation mode to restart
#
# |html &bull; <b>artn from_scratch</b> implies adding the <b>-partn</b> flag to POSTFIX and setting the ARTN calculation mode to from-scratch
#
# |html &bull; <b>artn</b> queiries the current artn status (on or off)   
#
# WARNINGS 
#   To use the ARTN plugin, QE needs to be compiled with ARTN enabled.
#******

#****f* ::pwtk::artn/::pwtk::artn::save_artn.in
# USAGE
#   save_artn.in FILE
# PURPOSE
#   Save the ARTN data to artn.in and also its backup to the 'FILE' file.
#******

