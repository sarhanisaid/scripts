#
# $RCSfile: pwi.tcl,v $ --
#
#      This file contains the procs for handling the pw.x input.
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: pwi.tcl,v 1.21 2021/05/03 14:21:08 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::pwi_fprint    {{file {}}} { uplevel ::pwtk::pwi::fprint $file }
proc ::pwtk::pwi_get       {}          { uplevel ::pwtk::pwi::get }
proc ::pwtk::pwi_clear     {}          { uplevel ::pwtk::pwi::clear }
proc ::pwtk::pwi_visualize {}          { uplevel ::pwtk::pwi::visualize }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::pwi/::pwtk::pwi::fprint
# SYNOPSIS
proc ::pwtk::pwi::fprint {{file {}}} {
    # PURPOSE
    #   Print the content of pw.x input data to a file or to stdout if the
    #   file was not specified.
    # ARGUMENTS
    #   * file -- [optional] filename to print to (default = stdout)
    # SOURCE

    ::pwtk::input::fprint_ ::pwtk::pwi $file
}
#****

#****f* ::pwtk::pwi/::pwtk::pwi::clear
# SYNOPSIS
proc ::pwtk::pwi::clear {} {
    # PURPOSE
    #   Clear the stored pw.x input data.
    # SOURCE
    variable input_flow_list
    
    foreach name $input_flow_list {
	::pwtk::input::clear $name
    }
}
#****


#****f* ::pwtk::pwi/::pwtk::pwi::get
# SYNOPSIS
proc ::pwtk::pwi::get {} {
    # PURPOSE
    #   Return the content of the pw.x input. 
    # SOURCE

    variable input_flow_list
    variable all_atomic_species

    set all_atomic_species [::pwtk::input::cardGetContent ATOMIC_SPECIES]
    
    ::pwtk::input::pushpop {

        ## check the ntyp vs ATOMIC_SPECIES compatibility    
        #if { [getNTyp] != [::pwtk::input::namelistGetVarValue SYSTEM ntyp] } {
        #    pwtk::infoMsg "ntyp and number of atomic species specified in ATOMIC_SPECIES card\nare not equal; filtering out unused atomic species"
        #}
    
        # EXCEPTION: starting from QE v4.0, the pw.x aborts if unused
        # atomic species are specified, which is what we don't want:
        # filter-out unused species
        
        ATOMIC_SPECIES [filterAtomicSpecies]
        SYSTEM " ntyp = [getNTyp] "
        
        # convenient feature: make a dummy call to ELECTRONS as this
        # namelist must be always present, even if it is empty
        
        ELECTRONS {}
        
        ::pwtk::input::clear_
        
        foreach name $input_flow_list {	
            loadDefaults_ $name
            ::pwtk::input::appendInput_ $name
        }
    
        set result [::pwtk::input::get_]
    }
    # at this point, unfiltered ATOMIC_SPECIES are restored

    unset all_atomic_species
    
    return $result
}
#****


#****f* ::pwtk::pwi/::pwtk::pwi::visualize
# SYNOPSIS
proc ::pwtk::pwi::visualize {} {
    # PURPOSE
    #   Visualize the structure from pw.x input file with xcrysden. If
    #   xcrysden is not detected, the input file is merely printed to
    #   stdout.    
    # SOURCE

    global env
    if { [info exists env(XCRYSDEN_TOPDIR)] || [auto_execok xcrysden] != "" } {
	set input [::fileutil::tempfile pw.]
	::pwtk::pwi_fprint $input
	catch {exec xcrysden --pwi $input}
    } else {
	# we don't have xcrysden: simply print the input to
	# stdout
	::pwtk::pwi_fprint
    }
}
#****

#****f* ::pwtk::pwi/::pwtk::pwi::ibrav
# SYNOPSIS
proc ::pwtk::pwi::ibrav {} {
    # PURPOSE
    #   Get the value of SYSTEM ibrav variable. This is a convenience proc.
    # SOURCE
    return [::pwtk::input::namelistGetVarValue SYSTEM ibrav]
}
#****


#****f* ::pwtk::pwi/::pwtk::pwi::alat
# SYNOPSIS
proc ::pwtk::pwi::alat {} {
    # PURPOSE
    #   Get the value of "alat" in Bohr (i.e. celldm(1) or A,
    #   depending on which is specified). If neither is specified, the
    #   alat is deduced from CELL_PARAMETERS, but if CELL_PARAMETERS
    #   are not defined, 0.0 is returned.
    #
    # BEWARE
    #   For ibrav==0 && (CELL_PARAMETERS angstrom|bohr), the size of
    #   the 1st lattice vector is used to calculate alat.
    #
    # RETURN VALUE
    #   The value of "alat" in bohr units or 0.0 if alat is undefined.
    #
    # SOURCE

    set A    [::pwtk::pwi::aA] 
    set alat [::pwtk::input::namelistGetVarValue SYSTEM celldm(1)]

    if { $A != "" && $alat != "" } {
	pwtk::error "both A and celldm(1) are specified. Specify only one of them!" 1
    }

    if { $A != "" } {
	set alat [expr $::pwtk::angs2bohr * $A]
    }

    # take care of ibrav == 0

    set ibrav [::pwtk::pwi::ibrav]
    if { $ibrav == 0 || $ibrav eq "" } {
        # Problem:
        #   for ibrav==0, "alat" either depends on (celldm(1) or A) or on
        #   the size of the 1st vector in "CELL_PARAMETERS angstrom | bohr",
        #   but "alat" may be queried before CELL_PARAMETERS are defined or
        #   in the CELL_PARAMETER definition itself.
        #
        # Solution:
        #   if CELL_PARAMETER is undefined, assume "CELL_PARAMETERS alat"
        #   else calculate alat from CELL_PARAMETERS angstrom | bohr
        
        set unit [::pwtk::input::cardGetFlags CELL_PARAMETERS trim]
        set cell [::pwtk::input::cardGetContent CELL_PARAMETERS]
        if { $cell eq {} } {
            set unit alat
        } else {
            set a [::pwtk::norm3 [lrange $cell 0 2]]
        }

        # from input_pw.html:
        #   if neither unit nor lattice parameter are specified, 'bohr'
        #   is assumed - DEPRECATED, will no longer be allowed
        #
        if { $unit eq {} && $alat eq {} } {
            set unit bohr
        }

        #  N.B.:
        #  for CELL_PERAMETERS without unit: if celldm(1) or A is
        #  defined, it implies CELL_PERAMETERS in alat and alat was
        #  already obtained above

        if { [string match *angstrom* $unit] } {
            set alat [expr {$::pwtk::angs2bohr*$a}]
        }
        if { [string match *bohr* $unit] } {
            set alat $a
        }
    }

    # if alat is not set, return 0.0
    
    if { $alat == "" } {
	set alat 0.0
    }

    return $alat
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::celldm3
# SYNOPSIS
proc ::pwtk::pwi::celldm3 {} {
    # PURPOSE
    #   Get the value of celldm(3) or C in units of alat, depending on
    #   which is specified. If neither is specified 0.0 is returned.
    #
    # RETURN VALUE
    #   Either the value of celldm(3) or C converted to alat units.
    #   If neither celldm(3) nor C are defined, 0.0 is returned.
    #
    # SOURCE

    set C       [::pwtk::pwi::cC]
    set celldm3 [::pwtk::input::namelistGetVarValue SYSTEM celldm(3)]

    if { $C != "" && $celldm3 != "" } {
	::pwtk::error "both C and celldm(3) are specified, specify only one of them !!!" 1
    }

    if { $C != "" } {
        set alat [::pwtk::pwi::alat]
        if { $alat == 0.0 } {
            ::pwtk::warning "from [::pwtk::procName]: neither celldm(1) nor A are specified, cannot calculate celldm(3)"
        } else {            
            set celldm3 [expr $::pwtk::angs2bohr * $C / $alat]
        }
    }
    ::pwtk::ifset celldm3 0.0    
    
    return $celldm3
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::load_fromPWI
# SYNOPSIS
proc ::pwtk::pwi::load_fromPWI {pwi {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing pw.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * pwi -- filename of the pw.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?
    #
    # SOURCE
    
    ::pwtk::fileMustExist $pwi "pw.x input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current pw.x input data ...
	::pwtk::pwi::clear
    }

    # pw.x input file must contain the CONTROL namelist

    if { [catch {::pwtk::readNamelists $pwi CONTROL 1}] } {
	::pwtk::error "input file \"$pwi\" does not appear to be a pw.x input file" 1
    }

    # read the namelists & cards

    set output [::pwtk::readNamelists $pwi $::pwtk::pwi::namelist_flow_list]
    append output [::pwtk::readCards $pwi $::pwtk::pwi::card_flow_list]
    
    eval $output
    ::pwtk::input::namelists_ityp2atmSymb_ $::pwtk::pwi::namelist_flow_list 
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::setNAtoms
# SYNOPSIS
proc ::pwtk::pwi::setNAtoms {} {
    # PURPOSE
    #   Set the "nat" variable of SYSTEM namelist to the number of
    #   atoms in ATOMIC_POSITIONS card
    # SOURCE
    
    SYSTEM "nat = [::pwtk::pwi::getNAtoms]"
}
#******

#****f* ::pwtk::pwi/::pwtk::pwi::insertAtoms
# SYNOPSIS
proc ::pwtk::pwi::insertAtoms {where atmPos} {
    # PURPOSE
    #   Insert specified atoms to ATOMIC_POSITIONS card. The unit of
    #   coordinates is implicitly set to the unit used in the last
    #   call to ATOMIC_POSITIONS card.
    #
    # ARGUMENTS
    #   * where  -- where to insert atoms (begin|end): in front or after the existing atoms
    #   * atmPos -- atomic positions data in the units as specified by ATOMIC_POSITIONS card
    # SOURCE

    set atmPos [::pwtk::purifyCoor $atmPos]
    set oldPos [::pwtk::purifyCoor [::pwtk::input::cardGetContent ATOMIC_POSITIONS]]

    switch -glob -- $where {
	beg* {
	    set pos [::pwtk::purifyCoor ${atmPos}\n${oldPos}]
	}
	end {
	    set pos [::pwtk::purifyCoor ${oldPos}\n${atmPos}]
	} default {
	    ::pwtk::error "wrong value of \"where\" argument, $where, must be begin or end."
	}
    }

    ::pwtk::input::cardContent ATOMIC_POSITIONS $pos
    ::pwtk::pwi::setNAtoms
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::deleteAtoms
# SYNOPSIS
proc ::pwtk::pwi::deleteAtoms {deleteList} {
    # PURPOSE
    #   Delete requested atoms from ATOMIC_POSITIONS card.
    #
    # ARGUMENTS
    #   * deleteList -- list of indices of atoms to delete; index of
    #                   the first atom is 1 (list of atoms can also have
    #                   a symbolic compact syntax supported by
    #                   ::pwtk::parseRangeString)    
    # SOURCE
    
    set natoms [::pwtk::pwi::getNAtoms]

    set sortedList [lsort -integer -decreasing [::pwtk::parseRangeString $deleteList $natoms]]
    set atmPosList [split [::pwtk::purifyCoor [::pwtk::input::cardGetContent ATOMIC_POSITIONS]] \n]
    if { $atmPosList eq {} && $deleteList ne {} } {
        ::pwtk::error "atomic structure is empty: cannot delete atoms [join $sortedList {, }]" 1
    }
    
    # check that indices are in range

    foreach index $sortedList { ::pwtk::int_in_range1_ $index $natoms }

    # delete atoms
    
    foreach del $sortedList {
	set d2 [expr {$del - 2}]
	set atmPosList "[lrange $atmPosList 0 $d2] [lrange $atmPosList $del end]"
    }

    ::pwtk::input::cardContent ATOMIC_POSITIONS [::pwtk::purifyCoor [join $atmPosList \n]]
    ::pwtk::pwi::setNAtoms
}
#******

#****f* ::pwtk::pwi/::pwtk::pwi::deleteAtomsRange
# SYNOPSIS
proc ::pwtk::pwi::deleteAtomsRange {from to} {
    # PURPOSE
    #   Delete atoms from ATOMIC_POSITIONS card starting from atom $from to atom $to.
    # ARGUMENTS
    #   * from,to  -- specify the [from,to] range of atoms to delete
    # SOURCE

    set nat  [::pwtk::pwi::getNAtoms]
    set from [::pwtk::parseIndex1 $from $nat]
    set to   [::pwtk::parseIndex1 $to   $nat]

    ::pwtk::pwi::deleteAtoms $from-$to
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::deleteAtomsLast
# SYNOPSIS
proc ::pwtk::pwi::deleteAtomsLast {natoms} {
    # PURPOSE
    #   Delete the last $natoms atoms from the ATOMIC_POSITIONS card.
    #
    # ARGUMENTS
    # * natoms -- number of atoms to delete
    # SOURCE

    set nat [::pwtk::pwi::getNAtoms]
    ::pwtk::pwi::deleteAtomsRange $nat-$natoms+1  $nat
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::deleteAtoms1st
# SYNOPSIS
proc ::pwtk::pwi::deleteAtoms1st  {natoms} {
    # PURPOSE
    #   Delete the first $natoms atoms from the ATOMIC_POSITIONS card.
    #
    # ARGUMENTS
    # * natoms -- number of atoms to delete
    # SOURCE
    
    ::pwtk::pwi::deleteAtomsRange 1 $natoms
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::displaceAtoms
# SYNOPSIS
proc ::pwtk::pwi::displaceAtoms {dispVec {whichAtoms all}} {
    # PURPOSE
    #   Displace atoms in ATOMIC_POSITIONS card.
    #
    # ARGUMENTS
    # * dispvec -- displacement vector as a list of three numbers
    # * whichAtoms -- list of atoms to displace. The index of the first atom is 1.
    #                 (list of atoms can also have  a symbolic compact syntax
    #                  supported by ::pwtk::parseRangeString)
    #
    # RETURN VALUE
    # The new content of the ATOMIC_POSITIONS card.
    #
    # SOURCE

    # dispVec may be specified as math expression
    set dispVec [::pwtk::vecMathParser $dispVec]
    
    if { [llength $dispVec] != 3 || ![::pwtk::type::numberlist real $dispVec] } {
        ::pwtk::error "expected a 3D numeric vector, but got: $dispVec" 1
    }

    set whichAtoms [lsort -integer [::pwtk::parseRangeString $whichAtoms [getNAtoms]]]
    set atmPosList [split [::pwtk::purifyCoor [::pwtk::input::cardGetContent ATOMIC_POSITIONS]] \n]
    set result ""
    foreach atom $atmPosList {
        incr iat
        set atm [lindex $atom 0]
        set pos [lrange $atom 1 3]
        set ifv [lrange $atom 4 6]
        if { $iat in $whichAtoms } {
            set pos [::math::linearalgebra::add [::pwtk::vecMathParser $pos] $dispVec]
        }
        if { $ifv eq {} } {
            append result [format $::pwtk::fmt_atmPos(4) $atm {*}$pos]
        } else {
            append result [format $::pwtk::fmt_atmPos(7) $atm {*}$pos {*}$ifv]
        }
    }
    return [::pwtk::input::cardContent ATOMIC_POSITIONS $result]
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::aA
# SYNOPSIS
proc ::pwtk::pwi::aA {} {
    # PURPOSE
    #   Get the 'A' lattice parameter from SYSTEM namelist or an empty
    #   string if it is not defined.
    # SOURCE
    return [::pwtk::input::namelistGetVarValue SYSTEM -nocase A]
}
#******

#****f* ::pwtk::pwi/::pwtk::pwi::cC
# SYNOPSIS
proc ::pwtk::pwi::cC {} {
    # PURPOSE
    #   Get the 'C' lattice parameter from SYSTEM namelist or an empty
    #   string if it is not defined.
    # SOURCE    
    return [::pwtk::input::namelistGetVarValue SYSTEM -nocase C]
}
#******

#****f* ::pwtk::pwi/::pwtk::pwi::CELL_PARAMETERS_fromPWO
# SYNOPSIS
proc ::pwtk::pwi::CELL_PARAMETERS_fromPWO {pwoFile {index end}} {
    # PURPOSE
    #   Load a CELL_PARAMETERS card from the pw.x output file.
    #   CELL_PARAMETERS are loaded only if the record is present in
    #   the pw.x output file unless index==0 or index==end (in this
    #   case the initial lattice-vectors are returned; for index==end,
    #   the initial lattice-vectors are returned if CELL_PARAMETERS
    #   records are missing in the output).
    #
    # ARGUMENTS
    #   * pwoFile -- name of pw.x output file
    #   * index -- (optional, default = end) which lattice to
    #              load. The index of 0 indicates the first lattice
    #              found in the pw.x output. The index for the last
    #              lattice can be specified by string "end".
    #
    # SIDE EFFECTS    
    #   1. The ibrav is set to 0 if CELL_PARAMETERS are found in $pwoFile and loaded into PWTK.
    #   2. 
    #
    # SOURCE
    
    set vec [::pwtk::pwo::getPrimVec -k $pwoFile $index]
    
    if { $vec eq "" } {
        ::pwtk::warning "failed to load CELL_PARAMETERS with index = $index\nfrom the PWO file '$pwoFile'; record not found"
    } else {
        set ibrav [::pwtk::pwi::ibrav]
        if { $ibrav != 0 } {
            ::pwtk::infoMsg "from [::pwtk::procName]:\nsetting ibrav = 0,\nwhile loading CELL_PARAMETERS from the PWO file '$pwoFile'"
            SYSTEM " ibrav = 0 "
        }

        if { [string match {*alat*} $vec] } {
            # CELL_PAREMETERS in alat: alat must be defined in the SYSTEM namelist
            
            set alat_not_set [expr { [::pwtk::pwi::aA] eq {} &&             
                                     [::pwtk::input::namelistGetVarValue SYSTEM celldm(1)] eq {} }]
                
            if { ! [string match {*=*} $vec] } {
                # we have the initial lattice vectors: CELL_PARAMETERS (alat)
                if { $alat_not_set } {
                    set pwo_alat [::pwtk::pwo::alat $pwoFile 0]
                    
                    ::pwtk::infoMsg "from [::pwtk::procName]:\nsetting celldm(1) = $pwo_alat,\nwhile loading the initial lattice vectors from the PWO file '$pwoFile'"
                    
                    SYSTEM " celldm(1) = $pwo_alat "
                }
            } else {
                # we have: CELL_PARAMETERS (alat= 21.08089896)

                set iron_alat [::pwtk::pwi::alat]
                set pwo_vec   $vec
                set cell_line [lindex [split $vec \n] 0]
                set alat      [lindex [split $cell_line =\)] 1]

                if { $alat_not_set } {
                    ::pwtk::warning "from [::pwtk::procName]:\nCELL_PARAMETERS are specified in alat units in '$pwoFile',\nbut alat is currently not set.\n
Using the alat calculated from the CELL_PARAMETERS record in '$pwoFile',\ni.e., setting celldm(1) = $alat"
                    
                    SYSTEM " celldm(1) = $alat "                    
                } else {
                    # we need to rescale cell_parameters wrt iron and new alat            
                    set vec [::pwtk::scaleVec $alat/$iron_alat [::pwtk::purifyVec $vec]]
            
                    ::pwtk::infoMsg "from [::pwtk::procName]:\n\"$cell_line\" line found in '$pwoFile';\n
rescaling cell vectors from PWO by a factor $alat/$iron_alat\n* extracted cell vectors:\n$pwo_vec\n
* rescaled cell vectors:\nCELL_PARAMETERS (alat)\n[::pwtk::CELL_PARAMETERS_math_parser $vec]"
                }
            }
            #
            CELL_PARAMETERS (alat) [::pwtk::purifyVec $vec]
            #
        } else {
            # we have: CELL_PARAMETERS (angstrom) or CELL_PARAMETERS (bohr)
            # unset celldm & A
            SYSTEM { celldm(1) = , A = , a = }
            CELL_PARAMETERS [lindex $vec 1] [::pwtk::purifyVec $vec]
        }
    }
}
#****


#****f* ::pwtk::pwi/::pwtk::pwi::ATOMIC_POSITIONS_fromPWO
# SYNOPSIS
proc ::pwtk::pwi::ATOMIC_POSITIONS_fromPWO {pwoFile {index end}} {
    # PURPOSE
    #   Load new ATOMIC_POSITIONS cards from pw.x output
    #   file.
    #
    # ARGUMENTS
    #   * pwoFile -- name of pw.x output file
    #   * index -- (optional, default = end) which coordinates to load. The
    #              index of 0 indicates the first coordinates found in
    #              the pw.x output. The index for the last coordinates
    #              can be specified by string "end".    
    # SOURCE    

    ::pwtk::fileMustExist $pwoFile "pw.x output"
    set coor [::pwtk::pwo::getAtmPos -k $pwoFile $index]

    # perhaps the pwoFile is abnornal and contains no coordinates    
    if { $coor != "" } {
        ATOMIC_POSITIONS [lindex $coor 1] [::pwtk::purifyCoor $coor]
    } else {
        pwtk::warning "no coordinates found in pw.x output file: $pwoFile "
    }
    ::pwtk::pwi::setNAtoms
}
#****


#****f* ::pwtk::pwi/::pwtk::pwi::CELL_PARAMETERS_and_ATOMIC_POSITIONS_fromPWO
# SYNOPSIS
proc ::pwtk::pwi::CELL_PARAMETERS_and_ATOMIC_POSITIONS_fromPWO {pwoFile {index end}} {
    # PURPOSE
    #   Load new CELL_PARAMETERS and ATOMIC_POSITION cards from pw.x
    #   output file. CELL_PARAMETERS are loaded only if the record is
    #   present in the pw.x output file.
    #
    # ARGUMENTS
    #   * pwoFile -- name of pw.x output file
    #   * index -- (optional, default = end) which lattice &
    #              coordinates to load. The index of 0 indicates the
    #              first lattice & and the first coordinates found in
    #              the pw.x output. The index for the last lattice &
    #              coordinates can be specified by string "end".
    #    
    # SIDE EFFECTS    
    #   The ibrav is set to 0 if CELL_PARAMETERS are found in $pwoFile and loaded into PWTK.
    #
    # SOURCE
    
    CELL_PARAMETERS_fromPWO  $pwoFile $index 
    ATOMIC_POSITIONS_fromPWO $pwoFile $index 
}
#****


#****f* ::pwtk::pwi/::pwtk::pwi::ATOMIC_POSITIONS_fromXSF
# SYNOPSIS
proc ::pwtk::pwi::ATOMIC_POSITIONS_fromXSF {args} {
    # USAGE
    #   ::pwtk::pwi::ATOMIC_POSITIONS_fromXSF ?options? xsfFile
    #
    # OPTIONS
    #   * -alat   ... keep coordinates in alat units, i.e., do not convert them to Angstroms (default)
    #   * -noalat ... transform alat coordinates to Angstrom or Bohr units
    #   * -ifpos  ... copy if_pos(:) fields from current (old) coordinates
    #   * -image index ... which image (snapshot) to use from AXSF file
    #
    # PURPOSE
    #   Load coordinates from XSF file into ATOMIC_POSITIONS card. If
    #   the -ifpos options is specified, then the if_pos(:) fields from
    #   the current (old) ATOMIC_POSITIONS card will be loaded into
    #   new card.
    #
    #   Beware that "alat" in pw.x and XSF2 have slightly different
    #   meanings: "alat" in XSF is always the length of A-lattice
    #   vector, whereas in pw.x input this is not always the case. To
    #   prevent the usage of "alat" coordinates, specify -noalat
    #   option and the coordinates will be transformed to Angstrom or
    #   Bohr units, depending on the units in which the lattice
    #   vectors are specified in the XSF file.
    #
    # ARGUMENTS
    #   * xsfFile -- name of XSF file
    #
    # SOURCE

    set options {
	{alat   "do no tranform 'alat' coordinates to Angstroms"}
        {noalat "do not use coordinates in alat unit, tranform them to Angstrom or Bohr units"}
        {ifpos  "copy if_pos(:) fields from current (old) coordinates"}
        {image.arg 1  "which image to use from AXSF file"}
    }
    array set opt [::cmdline::getoptions args $options [list [lindex [info level 0] 0] options:]]

    if { $opt(alat) && $opt(noalat) } {
        pwtk::error "conflicting options -alat and -noalat specified, please use just one of them" 1
    }
    if { [llength $args] > 1 } {
        pwtk::error "wrong usage: should be ::pwtk::pwi::ATOMIC_POSITIONS_fromXSF ?options? xsfFile, but got:\n
::pwtk::pwi::ATOMIC_POSITIONS_fromXSF $args" 1
    }
    
    # parse XSF-file
    set xsfFile [lindex $args 0]
    ::pwtk::fileMustExist $xsfFile XSF
    set unit [::pwtk::xsf::getPrimCoorUnit $xsfFile]
    set coor [::pwtk::atmPosToCoor [::pwtk::purifyCoor [::pwtk::xsf::getPrimCoor $xsfFile $opt(image)]] ]

    # NOTE: -alat is default, hence query $opt(noalat) !
    
    if { $opt(noalat) && $unit == "alat" } {
        # The -noalat option was specified, hence "alat" coordinates
        # will be tranformed to Angstrom or Bohr units, depending on
        # the units in which the lattice vectors are specified in the
        # XSF file.
        #
        # RATIONALE: the unit for PRIMCOORD in XSF file can be only
        # angstrom, whereas XSF2 also supports bohr, crystal, and alat
        # units. However BEWARE that "alat" in XSF is always the
        # length of A-lattice vector, whereas in pw.x input this is
        # not always the case.        

        set unit [::pwtk::xsf::getPrimVecUnit $xsfFile]
        set vecs [::pwtk::purifyVec [::pwtk::xsf::getPrimVec $xsfFile]]

        ::pwtk::infoMsg "from ATOMIC_POSITIONS_fromXSF: in the \"$xsfFile\" file,
the coordinates are specified in alat units, converting them to $unit units"

        set xsf_alat [::pwtk::norm [lrange $vecs 0 2]]
        set coor     [::pwtk::scaleCoor $xsf_alat $coor]        
    }
    
    if { $opt(ifpos) == 1 } {	
	replaceCoor $coor $unit
    } else {
	ATOMIC_POSITIONS $unit $coor
    }

    # update the "nat" variable
    ::pwtk::pwi::setNAtoms
}   
#****


#****f* ::pwtk::pwi/::pwtk::pwi::CELL_PARAMETERS_fromXSF
# SYNOPSIS
proc ::pwtk::pwi::CELL_PARAMETERS_fromXSF {xsfFile} {
    # PURPOSE
    #   Load cell vectors from XSF file into CELL_PARAMETERS card.
    #
    # SIDE EFFECTS    
    #  The ibrav is set to 0.
    #
    # ARGUMENTS
    #   * xsfFile -- name of XSF file
    #   * symmetry -- the symmetry flag for CELL_PARAMETERS, either cubic or hexagonal (optional, default = cubic)
    # SOURCE

    ::pwtk::fileMustExist $xsfFile XSF
    
    # check if ibrav = 0
    set ibrav [::pwtk::input::namelistGetVarValue SYSTEM ibrav]
    if { $ibrav != 0 } {
	::pwtk::infoMsg "setting ibrav = 0, while loading cell vectors from XSF file: $xsfFile"
        # also unset the celldm() & A
	SYSTEM " ibrav = 0 , celldm(1) = , A = , a = "
    }

    # beware that the unit for PRIMVEC vectors in XSF file can be only
    # angstrom, while XSF2 also supports bohr. This is directly
    # portable to CELL_PARAMETERS
    
    set unit [::pwtk::xsf::getPrimVecUnit $xsfFile]
    set vec  [::pwtk::purifyVec [::pwtk::xsf::getPrimVec $xsfFile]]
    
    CELL_PARAMETERS $unit $vec
}   
#****


#****f* ::pwtk::pwi/::pwtk::pwi::CELL_PARAMETERS_and_ATOMIC_POSITIONS_fromXSF
# SYNOPSIS
proc ::pwtk::pwi::CELL_PARAMETERS_and_ATOMIC_POSITIONS_fromXSF {args} {
    # USAGE
    #   ::pwtk::pwi::CELL_PARAMETERS_and_ATOMIC_POSITIONS_fromXSF ?options? xsfFile
    #
    # OPTIONS
    #   * -alat   ... keep coordinates in alat units (do not convert them to Angstroms)
    #   * -noalat ... transform alat coordinates to Angstrom or Bohr units
    #   * -ifpos  ... copy if_pos(:) fields from current (old) coordinates
    #   * -image index ... which image (snapshot) to use from AXSF file
    #
    #  PURPOSE
    #   Load new CELL_PARAMETERS and ATOMIC_POSITION cards from the XSF file.
    #
    # SIDE EFFECTS    
    #   The ibrav is set to 0.
    #
    # ARGUMENTS
    #   * xsfFile -- name of XSF file
    #
    # SOURCE    
    
    CELL_PARAMETERS_fromXSF [lindex $args end]
    eval ATOMIC_POSITIONS_fromXSF $args
}
#****


#****f* ::pwtk::pwi/::pwtk::pwi::ATOMIC_POSITIONS_fromCRD
# SYNOPSIS
proc ::pwtk::pwi::ATOMIC_POSITIONS_fromCRD {crdFile imageIndex} {
    # USAGE
    #   ::pwtk::pwi::ATOMIC_POSITIONS_fromCRD crdFile imageIndex
    #
    # PURPOSE
    #   Load the coordinates of the specified image from the neb.x CRD
    #   file into the ATOMIC_POSITIONS card.
    #
    #   Irrespective of the 'imageIndex', the fix-atoms fields are
    #   always taken from the first image because only the first image
    #   contains them.
    #
    #   The index of the first image is 1.
    #
    # ARGUMENTS
    # * crdFile ... the neb.x CRD file (aka *.crd)
    # * imageIndex ... index of image to extract from the CRD file
    #
    # SOURCE
    
    ::pwtk::fileMustExist $crdFile "neb.x CRD"

    # read the *.crd file and transform lines into a list
    
    set crdL [split [string trim [::pwtk::readFile $crdFile]] \n]
    
    # get the number of images
    
    set nimages 0
    foreach line $crdL {
        if { [regexp _IMAGE $line] } { incr nimages }
    }
    if { $nimages == 0 } {
        # not a CRD file
        ::pwtk::error "no images find in the '$crdFile' file" 1
    }
    set imageIndex [::pwtk::parseIndex1 $imageIndex $nimages]

    # check image index
    
    if { $imageIndex < 1 } {
        ::pwtk::warning "using the first image because the specified 'imageindex' < 1"        
        set imageIndex 1
    } elseif { $imageIndex > $nimages } {
        ::pwtk::warning "using the last image because the specified 'imageindex' > number-of-images"
        set imageIndex $nimages
    }

    # read images
    
    set ii 0
    set iat 0
    set nat 0
    set lpos 0
    foreach line $crdL {        
        if { [regexp _IMAGE $line] } {
            incr ii
            set lpos 0
        } elseif { [regexp ATOMIC_POSITIONS $line] } {
            set unit($ii) [lindex $line 1]
            set lpos 1
            set iat  0
        } elseif { [regexp TOTAL_CHARGE $line] } {
            set lpos 0
        } elseif { $lpos } {
            # read the atomic positions
            incr iat
            if { $iat > $nat } { set nat $iat }
            lassign $line symb($ii,$iat) x($ii,$iat) y($ii,$iat) z($ii,$iat) ifx($ii,$iat) ify($ii,$iat) ifz($ii,$iat)
        }
    }

    # construct atomic positions and load them into ATOMIC_POSITIONS card

    set pos {}
    set ii $imageIndex
    for {set iat 1} {$iat <= $nat} {incr iat} {
        if { [info exists x($ii,$iat)] && [info exists x(1,$iat)] } {
            append pos [format $::pwtk::fmt_atmPos(7) \
                            $symb($ii,$iat) $x($ii,$iat) $y($ii,$iat) $z($ii,$iat) \
                            $ifx(1,$iat) $ify(1,$iat) $ifz(1,$iat)]
        } else {
            ::pwtk::warning "the CRD file '$crdFile' is inconsistent: number of atoms do not match between the images"
        }
    }    
    ATOMIC_POSITIONS $unit($imageIndex) $pos

    # update the "nat" variable
    ::pwtk::pwi::setNAtoms
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::replaceCoor
# SYNOPSIS
proc ::pwtk::pwi::replaceCoor {coorLines {lengthUnit ""}} {
    # PURPOSE
    #   Overwrite the ATOMIC_POSITIONS card with the new atomic 
    #   coordinates as specified by coorLines in such a
    #   way that the old if_pos(:) records are maintained (the fixed
    #   components will remain fixed even if $coorLines does
    #   not have the if_pos(:) fields. This requires that $coorLines
    #   contain the same number of atoms as the current (old)
    #   ATOMIC_POSITIONS card.
    #
    #   BEWARE: works for non-path calculations !!!
    # ARGUMENTS
    #   * coorLines -- atomic coordinates in form: 
    #        |html <pre>atmSym1   x1  y1  z1
    #        |html atmSym2   x2  y2  z2
    #        |html ...</pre>
    #   * lengthUnit -- unit in which atomic coordinates in $coorLines are specified 
    #     (optional, default = {}, which means the length unit used in ATOMIC_POSITIONS card)
    # SOURCE
        
    set atmPos [::pwtk::pwi::coorToAtmPos $coorLines]
    if { $lengthUnit == "" } {
	set lengthUnit [::pwtk::input::cardGetFlags ATOMIC_POSITIONS]
    }
    ATOMIC_POSITIONS $lengthUnit $atmPos
    ::pwtk::pwi::setNAtoms
} 
#******


#****f* ::pwtk::pwi/::pwtk::pwi::fixAtoms
# SYNOPSIS
proc ::pwtk::pwi::fixAtoms {atomList {fixString "0 0 0"}} {
    # PURPOSE
    #   Fix specified atoms by setting if_pos(:) flags to $fixString
    #
    # ARGUMENTS
    # * atomList  -- list of atoms (indices) to be immobilized (list of atoms can also have a 
    #                symbolic compact syntax supported by ::pwtk::parseRangeString)    
    # * fixString -- list of if_pos(:) values (optional, default = {0 0 0})
    #
    # SOURCE
    
    set atmPosList [getAtmPos]
    if { $atmPosList eq {} } {
        # no atoms
        ::pwtk::error "atomic structure is empty: cannot fix atoms [join $atomList {, }]" 1
    }

    # check that indices are in range
    
    set natoms [::pwtk::pwi::getNAtoms]
    set atomList [lsort -integer -unique [::pwtk::parseRangeString $atomList $natoms]]
    foreach index $atomList { ::pwtk::int_in_range1_ $index $natoms }
    
    # parse atmPosList

    set nat     0
    set fi      {}
    set oi      {}
    
    if { [string match -nocase {*first_image*} [lindex $atmPosList 0]] } {
	
        # path calculation
	
	set fi [lindex $atmPosList 0]\n
        foreach line [lrange [split $atmPosList \n] 1 end] {
            if { [string match -nocase *intermediate_image* $line] || [string match -nocase *last_image* $line] } {
                set oi $line\n
	    } elseif { $oi != {} } {
		append oi $line\n		
	    } elseif { [llength $line] == 4 || [llength $line] == 7 } {     
                incr nat
		set atmPos($nat) $line
            }
        }
    } else {

	# normal calculation

        foreach line [split $atmPosList \n] {
            if { [llength $line] == 4 || [llength $line] == 7 } {     
                incr nat
		set atmPos($nat) $line
            }
	}
    }    

    # immobilize atoms
    
    foreach ind $atomList {
	if { $ind > 0 && $ind <= $nat} {
	    set coor [lrange $atmPos($ind) 0 3]
	    set atmPos($ind) [concat $coor $fixString]
	}
    }
    
    # build a new atmPos list

    set atmp {}
    
    if { $fi != {} } {
	set atmp $fi
    }
    
    for {set ia 1} {$ia <= $nat} {incr ia} {
	append atmp $atmPos($ia)\n
    }

    if { $oi != {} } {
	append $atmp $oi
    }

    # load $atmp into the ATOMIC_POSITIONS card

    ::pwtk::input::cardContent ATOMIC_POSITIONS $atmp
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::fixAtomsRange
# SYNOPSIS
proc ::pwtk::pwi::fixAtomsRange {firstAtom lastAtom {fixString "0 0 0"}} {
    # PURPOSE
    #   Fix range of atoms by setting if_pos(:) flags to $fixString
    #
    # ARGUMENTS
    # * firstAtom,lastAtom -- range of atoms (from,to) to be immobilized, lastAtom can be also "end"
    # * fixString          -- list of if_pos(:) values (optional, default = {0 0 0})
    #
    # SOURCE

    # replace "end" with number-of-atoms
    set nat [::pwtk::pwi::getNAtoms]
    set firstAtom [::pwtk::parseIndex1 $firstAtom $nat]
    set lastAtom  [::pwtk::parseIndex1 $lastAtom  $nat]

    fixAtoms $firstAtom-$lastAtom $fixString
}
#******

#****f* ::pwtk::pwi/::pwtk::pwi::fixAtomsLast
# SYNOPSIS
proc ::pwtk::pwi::fixAtomsLast {natoms  {fixString "0 0 0"}} {
    # PURPOSE
    #   Fix the last $natoms atoms by setting if_pos(:) flags to $fixString (default = {0 0 0}).
    #
    # ARGUMENTS
    # * natoms -- number of atoms to fix as specified by $fixString
    # * fixString -- list of 3 if_pos(:) values (optional, default = {0 0 0})
    # SOURCE

    set nat [::pwtk::pwi::getNAtoms]
    ::pwtk::pwi::fixAtomsRange $nat-$natoms+1  $nat  $fixString
}
#******

#****f* ::pwtk::pwi/::pwtk::pwi::fixAtoms1st
# SYNOPSIS
proc ::pwtk::pwi::fixAtoms1st  {natoms {fixString "0 0 0"}} {
    # PURPOSE
    #   Fix the first $natoms atoms by setting if_pos(:) flags to $fixString (default = {0 0 0}).
    #
    # ARGUMENTS
    # * natoms -- number of atoms to fix as specified by $fixString
    # * fixString -- list of 3 if_pos(:) values (optional, default = {0 0 0})
    # SOURCE
    
    ::pwtk::pwi::fixAtomsRange 1 $natoms  $fixString
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::getAtmSymbList
# SYNOPSIS
proc ::pwtk::pwi::getAtmSymbList {} {
    # PURPOSE
    #   Get a sequential list of atomic-symbols from ATOMIC_POSITIONS card (in the same order), i.e.:
    #      AtmSy1
    #      AtmSy2
    #      ...
    # SOURCE

    set save_input [::pwtk::input::get_]

    set result ""
    foreach line [split [::pwtk::input::cardGetContent ATOMIC_POSITIONS] \n] {
        if { [string is space $line] } {
            continue
        } elseif { [string match -nocase *first_image* $line] } { 
	    continue
	} elseif { [string match -nocase *intermediate_image* $line] \
                       || [string match -nocase *last_image* $line] } {
	    return $result
	} else {
	    lappend result [lindex $line 0]
	}
    }

    ::pwtk::input::set_ $save_input
    
    return $result
}
#****


#****f* ::pwtk::pwi/::pwtk::pwi::filterAtomicSpecies
# SYNOPSIS
proc ::pwtk::pwi::filterAtomicSpecies {{atmSymbCmd_ ::pwtk::pwi::getAtmSymbList}} {
    # PURPOSE 
    #   Starting from QE v4.0, the pw.x aborts if unused atomic
    #   species are specified. In order to prevent that, this proc
    #   filters-out unsed species
    #
    # ARGUMENTS
    # * atmSymbCmd_ -- [OPTIONAL] used only internally within the PWTK
    #                  (to know when we are dealing with neb.x, then the atmSymbCmd_ == ::pwtk::nebi::getAtmSymbList)
    #
    # RETURN VALUE
    # * filtered atomic species data in format to be used for ATOMIC_SPECIES
    #
    # SOURCE

    set content [::pwtk::input::cardGetContent ATOMIC_SPECIES]
    set atmSymb [lsort -unique [$atmSymbCmd_]]    
    set result  ""

    foreach line [split $content \n] {
	# skip empty lines
	if { [string is space $line] } { continue }
	
	if { [lindex $line 0] in $atmSymb } {
	    lappend result $line
	}
    }

    return [join $result \n]
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::substituteAtmType
# SYNOPSIS
proc ::pwtk::pwi::substituteAtmType {oldType newType} {
    # PURPOSE 
    #   Substitute a given atom-type in ATOMIC_POSITIONS with a new atom type.
    #
    # ARGUMENTS
    # * oldType -- atom-type to be substituted
    # * newType -- new atomic type
    #
    # EXAMPLE
    #   Substitute all hydrogen atoms (H) with deuterium (D):
    #
    #      ::pwtk::pwi::substituteAtmType H D
    #
    # SOURCE

    set lenUnit [::pwtk::input::cardGetFlags ATOMIC_POSITIONS]
    set atmPos  [::pwtk::purifyCoor [::pwtk::input::cardGetContent ATOMIC_POSITIONS]]

    set new_atmPos ""
    foreach line [split $atmPos \n] {	
	append new_atmPos [regsub -- $oldType $line $newType]\n
    }

    ATOMIC_POSITIONS $lenUnit [::pwtk::purifyCoor $new_atmPos]

    return  $new_atmPos
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::substituteAtom
# SYNOPSIS
proc ::pwtk::pwi::substituteAtom {atomIndex newType} {
    # PURPOSE 
    #   Substitute a specified atom in ATOMIC_POSITIONS with a new
    #   atomic type. The first atom has index 1.
    #
    # ARGUMENTS
    # * atomIndex -- index of the atom to substitute (the first atom has index 1)
    # * newType -- new atomic type
    #
    # SOURCE

    set lenUnit [::pwtk::input::cardGetFlags ATOMIC_POSITIONS]
    set atmPos  [::pwtk::purifyCoor [::pwtk::input::cardGetContent ATOMIC_POSITIONS]]

    set ind 1
    set new_atmPos ""
    foreach line [split $atmPos \n] {
        if { $atomIndex == $ind } {
            append new_atmPos "$newType [lrange $line 1 end]\n"
        } else {
            append new_atmPos $line\n
        }
        incr ind
    }

    ATOMIC_POSITIONS $lenUnit [::pwtk::purifyCoor $new_atmPos]

    return [::pwtk::pwi::getAtmPos]
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::substituteAtoms
# SYNOPSIS
proc ::pwtk::pwi::substituteAtoms {args} {
    # USAGE
    #   ::pwtk::pwi::substituteAtoms index1 newType1  ?index2 newType2?  ...
    # PURPOSE 
    #   Substitute specified atoms in ATOMIC_POSITIONS with new atomic
    #   types.  The first atom has index 1.
    #
    # ARGUMENTS
    # * args -- atom-index & new-atom-type list in the following format:   ind1 newType1  ind2 newType 2  ...
    #
    # SOURCE

    foreach {ind type} [concat {*}$args] {
        print "ind=$ind type=$type"
        ::pwtk::pwi::substituteAtom $ind $type
    }
    return [::pwtk::pwi::getAtmPos]
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::getAllAtomicLabels
# SYNOPSIS
proc ::pwtk::pwi::getAllAtomicLabels {} {
    # PURPOSE
    # Return all atomic labels specified ATOMIC_SPECIES card.
    #
    # SOURCE

    set save_input [::pwtk::input::get_]

    if { [info exists ::pwtk::pwi::all_atomic_species] \
             && $::pwtk::pwi::all_atomic_species != {} } {
        #  we are in the midst of pw.x input creation and the
        # ATOMIC_SPECIES were already filtered; use the
        # ::pwtk::pwi::all_atomic_species instead
        
        set atomic_species $::pwtk::pwi::all_atomic_species
        
    } elseif { [info exists ::pwtk::nebi::all_atomic_species] \
             && $::pwtk::nebi::all_atomic_species != {} } {
        #  we are in the midst of neb.x input creation and the
        # ATOMIC_SPECIES were already filtered; use the
        # ::pwtk::nebi::all_atomic_species instead
        
        set atomic_species $::pwtk::nebi::all_atomic_species
        
    } else {
        
        set atomic_species [::pwtk::input::cardGetContent ATOMIC_SPECIES]
    }
    
    set result {}
    foreach line [split $atomic_species \n] {
        if { [string is space $line] } { continue }
        lappend result [lindex $line 0]
    }

    ::pwtk::input::set_ $save_input
    
    return $result
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::getAtomicLabels
# SYNOPSIS
proc ::pwtk::pwi::getAtomicLabels {} {
    # PURPOSE
    # Return a list of atomic-labels in ATOMIC_SPECIES card.
    #
    # SOURCE

    set save_input [::pwtk::input::get_]
    
    set result {}
    foreach line [split [::pwtk::input::cardGetContent ATOMIC_SPECIES] \n] {
        if { [string is space $line] } { continue }
        lappend result [lindex $line 0]
    }
    
    ::pwtk::input::set_ $save_input
    
    return $result
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::tabulateStructs
# SYNOPSIS
proc ::pwtk::pwi::tabulateStructs {args} {
    #
    # USAGE
    # ::pwtk::pwi::tabulateStructs  ?options?  latexFile  pwiFileList  xcrysdenScriptList
    #
    # OPTIONS
    #   * -xcd 0|1|2
    #   * -reduce 2|1|0
    #   * -ncol  <value>
    #   * -npage <value>
    #
    # PURPOSE
    #    Plot with xcrysden the structures from the supplied list of
    #    pw.x input files ($pwiFileList) and arrange them into a table
    #    in LaTeX document ($latexFile).
    #
    #    To instruct xcrysden how to plot each structure, user has to
    #    provide at least one xcrysden script (i.e., the state-part of
    #    *.xcrysden file). If user supllies more then one xcrysden
    #    script ($xcrysdenScriptList), each structure will be plotted
    #    several times, i.e., once with each suppplied xcrysden script
    #    file.
    #        
    # OPTIONS
    #    * -xcd 0|1|2 -- execute xcrysden (0 = never, 1 = always, 2 = only if the respective picture file does not yet exists)
    #    * -reduce 0|1|2 -- reduce the periodic dimensionality of the structure (i.e. xcrysden's "-r" option)
    #    * -ncol <value> -- arrange snapshots into ncol columns in the LaTeX table
    #    * -npage <value> -- hint of how many pages the LaTeX table should span
    #
    # ARGUMENTS
    #    * latexFile -- name of latex file to tabulate the structure
    #    * pwiFileList -- list of pw.x input files
    #    * xcrysdenScriptList -- list of xcrysden script files
    #
    # SOURCE

    # parse args

    ::pwtk::printTitle TABULATE "tabulation of pw.x input files (::pwtk::pwi::tabulateStructs)"
    
    set options {
	{xcd.arg      1         "do we run xcrysden to make figures"}
	{reduce.arg   3         "reduce the dimensionality of structure"}
	{npage.arg    1         "number of pages the table will span (estimate only)"}
	{ncol.arg    -1         "number of columns (-1 means automatically determined)"}
    }
    array set opt [::cmdline::getoptions args $options [list [lindex [info level 0] 0] options:]]    

    lassign $args latexFile fileList xcrysScriptList
    
    if { $opt(xcd) == 1 } {
	::pwtk::xcd::runScript 1
    } else {
	::pwtk::xcd::runScript 0
    }

    # make structure figures

    pwtk::xcd::scriptHead { scripting::filter::pwscfInput $structureFile $reduce }
    set figList [::pwtk::xcd::makeFigs $fileList $xcrysScriptList ic $opt(reduce)]
    
    # make titles & texts ...
    
    foreach file $fileList {
	set prefix [file rootname [file tail $file]]
	lappend titleList $prefix
	lappend infoList [list  "input structure"]
    }
    
    set textList {}

    # puts all figures into latex longtable and write corresponding LaTeX file
    
    ::pwtk::latex::tabulateFigs $latexFile $figList $titleList $infoList $textList $opt(npage) $opt(ncol)
    ::pwtk::print "LaTeX file written to: $latexFile"
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::abc2celldm
# SYNOPSIS
proc ::pwtk::pwi::abc2celldm {} {
    # PURPOSE
    #   Transform the A,B,C,cosAB,cosAC,cosBC cell specification in
    #   the SYSTEM namelist into the celldm(1)--celldm(6)
    #   specification based on ibrav.
    #
    # BEWARE
    #   If ibrav==0 & CELL_PARAMETERS are specified in angstrom or
    #   bohr units, then celldm(1) is set and CELL_PARAMETERS are
    #   transformed to alat units.
    #
    #   If cell is already specified with celldm(i) nothing is done,
    #   otherwise A,B,C,cosAB,cosAC,cosBC are unset and celldm(i) are
    #   set.
    #
    # REMARK
    #   This routine is based on the abc2celldm subroutine in QE's
    #   Modules/latgen.f90 (if new lattices are introduced to QE, this
    #   cmd must be updated).    
    #
    # SOURCE

    set ibrav [ibrav]
    if { $ibrav == "" } {
        ::pwtk::error "ibrav is not defined" 1
    }

    if { $ibrav == 0 } {
        #
        # free lattice: transform CELL_PARAMETERS to alat & set celldm(1)
        #
        set unit [::pwtk::input::cardGetFlags CELL_PARAMETERS trim]
        set cell [::pwtk::input::cardGetContent CELL_PARAMETERS]
        if { $cell == {} } { ::pwtk::error "CELL_PARAMETERS must be specified for ibrav == 0" 1 }
        if { [llength $cell] != 9 } { ::pwtk::error "expected a 3x3 matrix for CELL_PARAMETERS, but got\n$cell" 1 }
        
        if { ! [string match *alat* $unit] } {
            # angstrom || bohr
            set a [::pwtk::norm3 [lrange $cell 0 2]]
            set scale [expr {1.0/$a}]

            if { $unit eq {} } {
                if { [::pwtk::input::namelistGetVarValue SYSTEM celldm(1)] eq {} \
                         && [::pwtk::pwi::aA] } {
                    # from input_pw.html:
                    #   if neither unit nor lattice parameter are specified, 'bohr'
                    #   is assumed - DEPRECATED, will no longer be allowed
                    set unit bohr
                } else {
                    # plain "CELL_PARAMETERS" implies alat units
                    set alat [alat]            
                }
            }
            
            if { [string match *angstrom* $unit] } {
                set alat [expr {$::pwtk::angs2bohr*$a}]
            } elseif { [string match *bohr* $unit] } {
                set alat $a
            }
            SYSTEM " celldm(1) = $alat, A = , a = "
            CELL_PARAMETERS (alat) [::pwtk::scaleVec $scale $cell]
            return
        }
    }
    
    # store A, B, C... & unset them in the SYSTEM namelist
    foreach var {A B C cosAB cosAC cosBC} {
        set varName [::pwtk::input::namelistGetVarNoCase SYSTEM $var]
        set value   [::pwtk::input::namelistGetVarValue SYSTEM $varName]

        SYSTEM " $varName = "

        if { $var == "A" && $value == {} } {
            # not using A, B, C...
            return
        }

        ::pwtk::ifset value 0.0
        set $var $value

        # $value must be a number (or expression)
        if { ! [::pwtk::is_expr $value] } {
            ::pwtk::error "expected a number for lattice parameter $var, but got \"$value\"" 1
        }
    }

    # check lattice-parameters values
    
    if { $A <= 0.0 } { ::pwtk::error "lattice parameter A must be >= 0.0, but got $A" 1 }
    if { $B <  0.0 } { ::pwtk::error "lattice parameter B must be > 0.0, but got $B" 1 }
    if { $C <  0.0 } { ::pwtk::error "lattice parameter C must be > 0.0, but got $C" 1 }
    if { abs($cosAB) > 1.0 } { ::pwtk::error "lattice parameter cosAB must be in \[-1,1\], but got $cosAB" 1 }
    if { abs($cosAC) > 1.0 } { ::pwtk::error "lattice parameter cosAC must be in \[-1,1\], but got $cosAC" 1 }
    if { abs($cosBC) > 1.0 } { ::pwtk::error "lattice parameter cosBC must be in \[-1,1\], but got $cosBC" 1 }
    
    # load celldm() ...
    
    set celldm(1) [expr $A * $::pwtk::angs2bohr]
    set celldm(2) [expr $B / $A]
    set celldm(3) [expr $C / $A]
    set celldm(4) 0.0
    set celldm(5) 0.0
    set celldm(6) 0.0

    if { $ibrav == 14 } {        
        # ... triclinic lattice
        set celldm(4) $cosBC
        set celldm(5) $cosAC
        set celldm(6) $cosAB
        
    } elseif { $ibrav == -12 || $ibrav == -13 } {
        # ... monoclinic P or base centered lattice, unique axis b     
        set celldm(5) $cosAC
        
    } elseif { abs($ibrav) == 5 || $ibrav == 12 || $ibrav == 13 } {
        # ... trigonal and monoclinic lattices, unique axis c     
        set celldm(4) $cosAB
    }
    
    foreach i [seq 1 6] {
        if { $celldm($i) != 0.0 } { SYSTEM " celldm($i) = $celldm($i) " }
    }
}
#******


# ------------------------------------------------------------------------
#
# internal procs ...
#
# ------------------------------------------------------------------------

proc ::pwtk::pwi::loadDefaults_ {{name CONTROL}} {
    # load some default values, when user has omitted them 

    if { $name == "CONTROL" } {
	namespace eval ::pwtk::input {
	    defaultVarValue_ CONTROL outdir     [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
	    defaultVarValue_ CONTROL wfcdir     [::pwtk::getDir_ QEdir(ESPRESSO_WFCDIR)]
	    defaultVarValue_ CONTROL pseudo_dir [::pwtk::getDir_ QEdir(ESPRESSO_PSEUDO)]
	}
    }
}
