#
# $RCSfile: mpdi.tcl,v $ --
#
#      This file contains the procs for handling the molcularpdos.x input.
#
# Copyright (c) 2017  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: mpdi.tcl,v 1.2 2021/05/03 14:21:08 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::mpdi_fprint {{file {}}} { uplevel ::pwtk::mpdi::fprint $file }
proc ::pwtk::mpdi_clear  {}          { uplevel ::pwtk::mpdi::clear }
proc ::pwtk::mpdi_get    {}          { uplevel ::pwtk::mpdi::get }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::mpdi/::pwtk::mpdi::fprint
# SYNOPSIS
proc ::pwtk::mpdi::fprint {{file {}}} {
# PURPOSE
#   Print the content of molecularpdos.x input data to a file or to stdout if the
#   file was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::mpdi $file
}
#****


#****f* ::pwtk::mpdi/::pwtk::mpdi::get
# SYNOPSIS
proc ::pwtk::mpdi::get {} {
    # DESCRIPTION    
    #   Return the content of the molecularpdos.x input 
    # SOURCE

    loadDefaults_

    # molecularpdos.x uses INPUTMOPDOS namelist, but this name is too long,
    # hence PWTK uses shorter MOPDOS instead, thus we need to substitute the
    # MOPDOS string with INPUTMOPDOS

    return [regsub -- {\&MOPDOS} [::pwtk::input::namelistGet MOPDOS] {\&INPUTMOPDOS}]
}
#******
    

#****f* ::pwtk::mpdi/::pwtk::mpdi::clear
# SYNOPSIS
proc ::pwtk::mpdi::clear {} {
    # DESCRIPTION    
    #   Clear the content of the molecularpdos.x input 
    # SOURCE
    variable input_flow_list
    
    foreach name $input_flow_list {
	::pwtk::input::clear $name
    }
}
#******
    

proc ::pwtk::mpdi::loadDefaults_ {} {
    # load some default values, when user has omitted them 

    namespace eval ::pwtk::input {
	#defaultVarValue_ MOPDOS ngauss  0
	#defaultVarValue_ MOPDOS DeltaE  0.01
	#defaultVarValue_ MOPDOS degauss 0.00734980670008; # 0.1 eV
    }
}


#****f* ::pwtk::mpdi/::pwtk::mpdi::load_fromMPDI
# SYNOPSIS
proc ::pwtk::mpdi::load_fromMPDI {mpdi {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing molecularpdos.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * mpdi -- filename of the molecularpdos.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?
    #
    # SOURCE

    ::pwtk::fileMustExist $mpdi "molecularpdos.x input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current molecularpdos.x input data ...
	::pwtk::input::clear MOPDOS
    }

    # read the namelists & replace INPUTMOPDOS with MOPDOS

    set output [regsub INPUTMOPDOS \
                    [::pwtk::readNamelists $mpdi INPUTMOPDOS] MOPDOS]
                
    # molecularpdos.x must contain an INPUTMOPDOS namelist
    if { $output == "" } {
	::pwtk::error "input file \"$mpdi\" does not appear to be a molecularpdos.x input file" 1
    }
    
    eval $output
    variable input_flow_list
    ::pwtk::input::namelists_ityp2atmSymb_ $input_flow_list
}
#******
