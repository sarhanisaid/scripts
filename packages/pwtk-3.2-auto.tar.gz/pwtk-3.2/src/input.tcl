#
# $RCSfile: input.tcl,v $ --
#
#       This file contains functions used for handling namelists,
#       cards, and "scripts".
#
#       Namelist and cards are input "blocks" used by QE.
#
#       "Scripts" are Tcl scripts used within PWTK scripts. They are
#       used to set a proper state before a given calculation. An
#       example of the "script" is FASTNEB for the fast_neb calculation
#       and difden_segmentSpec for the difden calculation.
#
# Copyright (c) 2009-2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: input.tcl,v 1.12 2021/05/03 14:19:26 tone Exp $ 
#

#------------------------------------------------------------------------
# SHORT-CUTS
#------------------------------------------------------------------------

proc ::pwtk::input_clear {args} { uplevel ::pwtk::input::clear $args }


# ------------------------------------------------------------------------
#
# namelist handling procs
#
# ------------------------------------------------------------------------

#****f* Namelists/::pwtk::input::namelist
# SYNOPSIS
proc ::pwtk::input::namelist {name content} {
    # PURPOSE
    #   Set or update the namelist.
    # ARGUMENTS
    #   * name -- name of the namelist
    #   * content -- content of the namelist in the syntax of fortran namelist (without namelist begin&end markers)
    # SOURCE
    global ::pwtk::input::namelist

    set ::pwtk::input::namelist($name) [string trim $content]
    namelistParse_ $name    
}
#****


#****f* Namelists/::pwtk::input::namelistGet
# SYNOPSIS
proc ::pwtk::input::namelistGet {name} {
    # PURPOSE
    #   Return the namelist.
    # ARGUMENTS
    #   * name -- name of the namelist
    # SOURCE

    clear_
    namelistOut_ $name
    return [get_]
}
#****


#****f* Namelists/::pwtk::input::namelistGetPWTK
# SYNOPSIS
proc ::pwtk::input::namelistGetPWTK {name} {
    # PURPOSE
    #   Return the namelist as a PWTK script.
    #
    #   This routine handles both, namelist and namelist.affix
    #
    # ARGUMENTS
    #   * name -- name of the namelist
    # SOURCE
    variable namelist
    variable card

    if { [info exists namelist($name)] } {

        set result "$name \{\n"
        set vars [namelistVars_ $name]
            
        # get the maximum length of a variable name
        set maxl 0
        foreach var $vars {
            set maxl [expr { [string length $var] > $maxl ? [string length $var] : $maxl }]
        }

        foreach var $vars {
            if { $namelist($name,var=$var) ne {} } {
                append result [format "   %-*s = %s\n" $maxl $var $namelist($name,var=$var)]
            }           
        }

        # check if the namelist has an appix
        set affix {}
        if { [info exists card($name.affixCards)] } {
            set affix [string trimright [cardGetContent $name.affixCards]]            
        }
        if { $affix ne {} } {
            append result "\} \{\n$affix\n"
        }        

        return [append result "\}\n\n"]
    }
    return ""
}
#******


#****f* Namelists/::pwtk::input::namelistPrint
# SYNOPSIS
proc ::pwtk::input::namelistPrint {name} {
    # PURPOSE
    #   Print the namelist
    # ARGUMENTS
    #   * name -- name of the namelist
    # SOURCE

    variable channel    
    puts $channel [::pwtk::input::namelistGet $name]
}
#****


#****f* Namelists/::pwtk::input::namelistClear
# SYNOPSIS
proc ::pwtk::input::namelistClear {args} {
    # USAGE
    #   ::pwtk::input::namelistClear name1 ?name2? ?...?
    # PURPOSE
    #   Clear the content of specified namelists
    # ARGUMENTS
    #   * args -- one or more namelists
    # SOURCE
    
    global ::pwtk::input::namelist

    foreach name $args {
	# clear the content of the namelist
	
	if { [info exists ::pwtk::input::namelist($name)] } {
	    array unset ::pwtk::input::namelist $name,var=*	    
	    unset ::pwtk::input::namelist($name)
	}
        # N.B. if exist, clear also the namelist's affixCards (see:
        # ::pwtk::input::namelist.affix) because without the namelist,
        # the affixCards make no sense
        cardClear $name.affixCards
    }
}
#****


# ------------------------------------------------------------------------
#
# namelist.affix handling procs
#
# ------------------------------------------------------------------------


#****f* Namelists/::pwtk::input::namelist.affix
# SYNOPSIS
proc ::pwtk::input::namelist.affix {name content {affix {}}} {
    # PURPOSE    
    #   Set or update the namelist followed with an optional nameless-card (aka affix)
    # ARGUMENTS
    #   * name -- name of the namelist
    #   * content -- content of the namelist in the syntax of fortran namelist (without namelist begin&end markers)
    #   * affix -- an optional nameless-card (aka affix) that follows the namelist
    # SOURCE
    global ::pwtk::input::namelist

    namelist $name $content
    if { $affix ne {} } {
        ::pwtk::input::card $name.affixCards [string trim $affix]
    }    
}
#****


#****f* Namelists/::pwtk::input::namelist.affixGet
# SYNOPSIS
proc ::pwtk::input::namelist.affixGet {name} {
    # PURPOSE
    #   Return the namelist with its affix (see: ::pwtk::input::namelist.affix)
    # ARGUMENTS
    #   * name -- name of the namelist
    # SOURCE

    clear_
    namelistOut_ $name
    cardOutContent_ $name.affixCards
    return [::pwtk::skipEmptyLines [get_]]\n\n
}
#****


#****f* Namelists/::pwtk::input::namelist.affixGetAffix
# SYNOPSIS
proc ::pwtk::input::namelist.affixGetAffix {name} {
    # PURPOSE
    #   Return the affix part of namelist.affix
    # ARGUMENTS
    #   * name -- name of the namelist
    # SOURCE

    clear_
    cardOutContent_ $name.affixCards
    return [::pwtk::skipEmptyLines [get_]]
}
#****


#****f* Namelists/::pwtk::input::namelist.affixPrint
# SYNOPSIS
proc ::pwtk::input::namelist.affixPrint {name} {
    # PURPOSE
    #   Print the namelist with its affix (see: ::pwtk::input::namelist.affix)
    # ARGUMENTS
    #   * name -- name of the namelist
    # SOURCE

    variable channel    
    puts $channel [::pwtk::input::namelist.affixGet $name]
}
#****


#****f* Namelists/::pwtk::input::namelist.affixPrintAffix
# SYNOPSIS
proc ::pwtk::input::namelist.affixPrintAffix {name} {
    # PURPOSE
    #   Print the affix part of namelist.affix
    # ARGUMENTS
    #   * name -- name of the namelist.afix
    # SOURCE
    variable channel    
    puts $channel [::pwtk::input::namelist.affixGetAffix $name]
}
#****


# ------------------------------------------------------------------------
#
# card handling procs
#
# ------------------------------------------------------------------------


#****a* ::pwtk::input/Cards
# DESCRIPTION   
#   Routines associated with cards.
#******

#****f* Cards/::pwtk::input::card
# SYNOPSIS
proc ::pwtk::input::card {name args} {
    # USAGE
    #   card name ?flags? content
    #
    # PURPOSE
    #   Set the card.
    #
    # ARGUMENTS
    #   * name -- name of the card
    #   * flags -- (optional) strings (flags) present on the same line as the keyword in the input files
    #   * content -- content of the card in the syntax of a given card
    #
    # SOURCE
    global ::pwtk::input::card ::pwtk::input::card_flags ::pwtk::input::card_content

    if { $args == "" || [llength $args] > 2 } {
	::pwtk::error "wrong usage of ::pwtk::input::card, must be:  card ?flags? content\n\nwhile executing [::pwtk::procName] $name $args" 1
    }
    
    if { [llength $args] == 1 } {
	set flags ""
	set content [lindex $args 0]
    } else {
	set flags   [lindex $args 0]
	set content [lindex $args 1]
    }

    set ::pwtk::input::card($name)         exists
    set ::pwtk::input::card_flags($name)   [string trim $flags]
    set ::pwtk::input::card_content($name) [string trim $content]    
}
#****


#****f* Cards/::pwtk::input::card_wo_flags
# SYNOPSIS
proc ::pwtk::input::card_wo_flags {name content} {
    # PURPOSE
    #   Set the card-without-flags.
    # SOURCE
    card $name $content
}
#******


#****f* Cards/::pwtk::input::card_w_flags
# SYNOPSIS
proc ::pwtk::input::card_w_flags {name flags content} {
    # PURPOSE
    #   Set the card-with-madatory-flag(s).
    # SOURCE
    card $name $flags $content
}
#******


#****f* Cards/::pwtk::input::cardFlags
# SYNOPSIS
proc ::pwtk::input::cardFlags {name flags} {
    # PURPOSE
    #   Set the card's flag(s) if and only if the card exists.
    # ARGUMENTS
    #   * name -- name of the card
    #   * flags -- flags of the card (i.e. strings (flags) present on the same line as the keyword in the input files)
    # RETURN VALUE
    # * $flags if $name card exists
    # * empty string otherwise
    # SOURCE
    global ::pwtk::input::card ::pwtk::input::card_flags ::pwtk::input::card_content

    if { [info exists ::pwtk::input::card($name)] } {
	return [set ::pwtk::input::card_flags($name) [string trim $flags]]
    }
    return ""
}
#****


#****f* Cards/::pwtk::input::cardContent
# SYNOPSIS
proc ::pwtk::input::cardContent {name content} {
    # PURPOSE
    #   Set the card's content if and only if the card exists.
    # ARGUMENTS
    #   * name -- name of the card
    #   * content -- content of the card in the syntax of a give card
    # RETURN VALUE
    # * $content if $name card exists
    # * empty string otherwise
    # SOURCE
    global ::pwtk::input::card ::pwtk::input::card_flags ::pwtk::input::card_content

    if { [info exists ::pwtk::input::card($name)] } {
	return [set ::pwtk::input::card_content($name) [string trim $content]]
    }
    return ""
}
#****


#****f* Cards/::pwtk::input::cardPrepend
# SYNOPSIS
proc ::pwtk::input::cardPrepend {name prepend_content} {
    # PURPOSE
    #   Prepend new content to the begining of the existing card content.
    # ARGUMENTS
    #   * name -- name of the card
    #   * prepend_content -- content to prepend to the beginning of existing card content
    # RETURN VALUE
    # * the new content of the $name card
    # SOURCE

    global ::pwtk::input::card ::pwtk::input::card_flags ::pwtk::input::card_content

    if { ! [info exists ::pwtk::input::card($name)] } {
	set ::pwtk::input::card($name)         exists
	set ::pwtk::input::card_flags($name)   ""
    }

    set ::pwtk::input::card_content($name) "[string trim $prepend_content]\n$::pwtk::input::card_content($name)"
}
#****


#****f* Cards/::pwtk::input::cardAppend
# SYNOPSIS
proc ::pwtk::input::cardAppend {name append_content} {
    # PURPOSE
    #   Append new content to the end of the existing card content.
    # ARGUMENTS
    #   * name -- name of the card
    #   * append_content -- content to append to the end of existing card content
    # RETURN VALUE
    # * the new content of the $name card
    # SOURCE

    global ::pwtk::input::card ::pwtk::input::card_flags ::pwtk::input::card_content

    if { ! [info exists ::pwtk::input::card($name)] } {
	set ::pwtk::input::card($name)         exists
	set ::pwtk::input::card_flags($name)   ""
    }

    append ::pwtk::input::card_content($name) "\n[string trim $append_content]"
}
#****


#****f* Cards/::pwtk::input::cardPrint
# SYNOPSIS
proc ::pwtk::input::cardPrint {name} {
    # PURPOSE
    #   Print card to stdout.    
    # ARGUMENTS
    #   * name -- name of the card to print.
    # EXAMPLE
    # How to print the ATOMIC_POSITIONS card:
    #
    #   ::pwtk::input::cardPrint ATOMIC_POSITIONS
    #
    # This will print to stdout something like:
    #
    #   ATOMIC_POSITIONS unit
    #     AtmSymb1  x1 y1 z1
    #     ...
    # SOURCE

    global ::pwtk::input::card ::pwtk::input::card_flags ::pwtk::input::card_content 

    clear_
    cardOut_ $name
    print_
}
#****


#****f* Cards/::pwtk::input::cardGet
# SYNOPSIS
proc ::pwtk::input::cardGet {name} {
    # PURPOSE
    #   Return the card.
    # ARGUMENTS
    #   * name -- name of the card
    # EXAMPLE
    # How to get the whole ATOMIC_POSITIONS card:
    #
    #   set atomicPosCard [::pwtk::input::cardGet ATOMIC_POSITIONS]
    #
    # The "atomicPosCard" now holds the following:
    #
    #   ATOMIC_POSITIONS unit
    #     AtmSymb1  x1 y1 z1
    #     ...
    #
    # SOURCE

    global ::pwtk::input::card ::pwtk::input::card_flags ::pwtk::input::card_content 

    clear_
    cardOut_ $name
    return [get_]
}
#****


#****f* Cards/::pwtk::input::cardGetContent
# SYNOPSIS
proc ::pwtk::input::cardGetContent {name} {
    # PURPOSE
    #   Return only the content of the card without its flags
    # ARGUMENTS
    #   * name -- name of the card
    # SOURCE
    global ::pwtk::input::card ::pwtk::input::card_content 

    clear_
    cardOutContent_ $name    
    return [get_]
}
#****


#****f* Cards/::pwtk::input::cardGetFlags
# SYNOPSIS
proc ::pwtk::input::cardGetFlags {name {trim ""}} {
    # PURPOSE
    #   Return the flags of the card.
    # ARGUMENTS
    #   * name -- name of the card
    #   * trim    -- do we get rid of braces {} or ()
    # SOURCE

    global ::pwtk::input::card ::pwtk::input::card_flags 

    set result ""
    if { [info exists ::pwtk::input::card($name)] && [info exists ::pwtk::input::card_flags($name)] } {
	set result $::pwtk::input::card_flags($name)
    }
    
    if { $trim != "" && $trim != 0 } {	
	return [::pwtk::trimCardFlag $result]
    }
    return $result
}
#****


#****f* Cards/::pwtk::input::cardGetPWTK
# SYNOPSIS
proc ::pwtk::input::cardGetPWTK {name} {
    # PURPOSE
    #   Return the card as a PWTK script.
    #
    # ARGUMENTS
    #   * name -- name of the card
    #
    # SOURCE

    variable card
    variable card_flags
	
    if { [info exists card($name)] } {
        # card's line (keyword + flags)
        set cardline "$name"
        if { [info exists card_flags($name)] && $card_flags($name) ne {} } {
            append cardline " $card_flags($name)"
        }
        # take care of "K_POINTS gamma"
        if { $name eq "K_POINTS" \
                 && [string match *gamma* $card_flags($name)] } {
            return "$cardline\n\n"
        } else {
            return "$cardline \{\n[string trimright [cardGetContent $name]]\n\}\n\n"
        }
    }
    return ""
}
#******


#****f* Cards/::pwtk::input::cardClear
# SYNOPSIS
proc ::pwtk::input::cardClear {args} {
    # USAGE
    #   ::pwtk::input::cardClear name1 ?name2? ?...?
    # PURPOSE
    #   Clear the content of specified cards.
    # ARGUMENTS
    #   * args -- one or more cards
    # SOURCE
    
    global ::pwtk::input::card 

    foreach name $args {
	# clear the content of the card
	if { [info exists ::pwtk::input::card($name)] } {
	    global ::pwtk::input::card_content ::pwtk::input::card_flags
	    unset ::pwtk::input::card($name)
	    set ::pwtk::input::card_content($name) ""
	    set ::pwtk::input::card_flags($name)   ""
	}
    }
}
#****


# ------------------------------------------------------------------------
#
# "script" handling procs
#
# ------------------------------------------------------------------------

#****a* ::pwtk::input/Scripts
# DESCRIPTION   
#   Routines associated with scripts.
#
#   Scripts are data that contain PWTK script snippets. Scripts are
#   used by various PWTK commands as a handy way of altering the
#   state. Scripts are stackable, implying that they can be handled
#   via stack commands (e.g. input_pushpop { ... }) similarly to
#   namelists and cards.
#
#   Example of scripts are ::pwtk::FASTNEB and
#   ::pwtk::difden::segmentSpecialization.
#
#******


#****f* Scripts/::pwtk::input::script
# SYNOPSIS
proc ::pwtk::input::script {name scriptCode} {
    # USAGE
    #   script name scriptCode
    #
    # PURPOSE
    #   Set the "script" named $name.
    #
    # ARGUMENTS
    #   * name   -- name of the "script"
    #   * scriptCode -- the code of the "script" (in the Tcl syntax)
    #
    # SOURCE
    variable script

    return [set script($name) $scriptCode]
}
#****


#****f* Scripts/::pwtk::input::scriptPrepend
# SYNOPSIS
proc ::pwtk::input::scriptPrepend {name prependScript} {
    # PURPOSE
    #   Prepend new content to the begining of the existing script named $name.
    # ARGUMENTS
    #   * name -- name of the script
    #   * prependScript -- content to prepend to the beginning of existing script $name
    # SOURCE
    variable script
    
    ::pwtk::ifexist script($name) {
        return [set script($name) "$prependScript\n$script($name)"]
    } else {
        return [set script($name) "$prependScript"]
    }
}
#****


#****f* Scripts/::pwtk::input::scriptAppend
# SYNOPSIS
proc ::pwtk::input::scriptAppend {name appendScript} {
    # PURPOSE
    #   Append new content to the end of the existing script named $name
    # ARGUMENTS
    #   * name -- name of the script
    #   * appendScript -- content to append to the end of existing script named $name
    # SOURCE

    variable script

    return [append script($name) "\n$appendScript"]
}
#****


#****f* Scripts/::pwtk::input::scriptPrint
# SYNOPSIS
proc ::pwtk::input::scriptPrint {name} {
    # PURPOSE
    #   Print to stdout the $name script 
    # ARGUMENTS
    #   * name -- name of the script to print.
    # SOURCE
    variable script

    ::pwtk::ifexist script($name) {
        print $script($name)
    }
}
#****


#****f* Scripts/::pwtk::input::scriptGet
# SYNOPSIS
proc ::pwtk::input::scriptGet {name} {
    # PURPOSE
    #   Get the $name script.
    # ARGUMENTS
    #   * name -- name of the script to return.
    # RETURN VALUE
    #   The content of the $name script. If the $name script does not
    #   exist, empty string is returned.
    # SOURCE
    variable script

    ::pwtk::ifexist script($name) {
        return $script($name)
    } else {
        return {}
    }
}
#****


#****f* Scripts/::pwtk::input::scriptClear
# SYNOPSIS
proc ::pwtk::input::scriptClear {args} {
    # USAGE
    #   :scriptClear name1 ?name2? ?...?
    # PURPOSE
    #   Clear (unset) the content of the specified scripts.
    # ARGUMENTS
    #   * args -- one or more script names
    # SOURCE
    
    variable script

    foreach name $args {
	# clear the content of the script
	::pwtk::ifexist script($name) {
	    unset script($name)
	}
    }
}
#****



# ------------------------------------------------------------------------
#
# namelist + card + script procs ...
#
# ------------------------------------------------------------------------


#****f* ::pwtk::input/::pwtk::input::clear
# SYNOPSIS
proc ::pwtk::input::clear {args} {
    # USAGE
    #   ::pwtk::input::clear name1 ?name2? ?...?
    # PURPOSE
    #   Clear the content of specified namelists and/or cards
    # ARGUMENTS
    #   * args -- one or more namelists and/or cards
    # SOURCE
    
    foreach name $args {
	::pwtk::input::namelistClear $name
	::pwtk::input::cardClear     $name
	::pwtk::input::cardClear     $name.affixCards
	::pwtk::input::scriptClear   $name
    }
}
#****


#****f* ::pwtk::input/::pwtk::input::print
# SYNOPSIS
proc ::pwtk::input::print {name} {
    # PURPOSE
    #   Print to stdout a given namelist or card if it exists.
    # ARGUMENTS
    # * name -- name of namelist or card
    # SOURCE
    global ::pwtk::input::namelist
    global ::pwtk::input::card
	
    if { [info exists ::pwtk::input::namelist($name)] } {
	#namelistPrint $name
        # t.k. Mon Mar 11 2024 (it's safe to use namelist.affixPrint instead of namelistPrint)
        namelist.affixPrint $name        
    } 
    if { [info exists ::pwtk::input::card($name)] } {
	cardPrint $name
    }
    if { [info exists ::pwtk::input::script($name)] } {
	scriptPrint $name
    }
}    
#****


#****f* ::pwtk::input/::pwtk::input::printAll
# SYNOPSIS
proc ::pwtk::input::printAll {} {
    # PURPOSE
    #   Print to stdout all user-defined namelists and cards.
    # SOURCE

    global ::pwtk::input::namelist ::pwtk::input::card
    
    foreach name [array names ::pwtk::input::namelist] {
	if { ! [regexp , $name] } {
            # t.k. Mon Mar 11 2024 (it's safe to use namelist.affixPrint instead of namelistPrint)
	    namelist.affixPrint $name
	}
    }
    foreach name [array names ::pwtk::input::card] {
	cardPrint $name
    }
    foreach name [array names ::pwtk::input::script] {
	scriptPrint $name
    }
}
#****


# ------------------------------------------------------------------------
#
# other procs
#
# ------------------------------------------------------------------------


#****f* Namelists/::pwtk::input::namelistAtmSymb2Ityp
# SYNOPSIS
proc ::pwtk::input::namelistAtmSymb2Ityp {nmlName varName} {
    # USAGE
    #   ::pwtk::input::namelistAtmSymb2Ityp  namelistName  VarName
    #
    # PURPOSE
    # Transform "ntyp"-type variable by relacing the atomic-label with
    # atomic-index, e.g., "starting_magnetization(Fe)" will be
    # transformed to "starting_magnetization(1)", where 1 is the index
    # of Fe species.
    #
    # multidimension arrays are also handled, e.g.,
    # starting_ns_eigenvalue(5,1,Fe1) is replaced by starting_ns_eigenvalue(5,1,1)
    #
    # Beware that such a transformation should be done only during the
    # input file creation.
    #
    # RETURN VALUE
    # * either: $varName
    # * or:     $arrayName(atomic-index) instead of $arrayName(atomic-label)
    #
    # SOURCE
    
    global ::pwtk::ntyp_variables
    
    if { [info exists ::pwtk::ntyp_variables($nmlName)] \
             && $::pwtk::ntyp_variables($nmlName) } {
        
        # BEWARE:  for arrays: varName == var(index),        
        #          split var(index) to {var index}
        
        lassign [split $varName ()] var index

        if { $index eq "" } {
            # variable is not array
            return $varName
        }

        set usedSpecies [::pwtk::pwi::getAtomicLabels]
        set allSpecies  [::pwtk::pwi::getAllAtomicLabels]

        if { [info exists ::pwtk::ntyp_multidimensions($nmlName)] \
                 && $var in $::pwtk::ntyp_multidimensions($nmlName) } {                     

            # var is a multidimension
            
            set multiL [::pwtk::varvalue ::pwtk::ntyp_multidimensions($nmlName)]
            set dim [lindex $multiL [lsearch -nocase $multiL $var]+1]

            if { ! [string is integer -strict $dim] } {
                ::pwtk::error "::pwtk::ntyp_multidimensions list is malformed, check the respective config/*i.tcl config file" 1
            }
            
            set indL [split $index ,]
            set symb [lindex $indL $dim]
            
            if { $symb in $usedSpecies } {
                set ind [expr [lsearch $usedSpecies $symb] + 1]
                set newi [join [lreplace $indL $dim $dim $ind] ,]
                return ${var}($newi)

            } elseif { $symb in $allSpecies } {
                # "symb" is defined but not currently used, filter it out,
                # i.e., return an empty string
                return ""
                
            } else {
                # "symb" is not defined, signal an error
                ::pwtk::error "atomic species \"$symb\" is not defined in ATOMIC_SPECIES card" 1
            }                
        }        

        set ind [lsearch $usedSpecies $index]

        if { $ind == -1 } {
            if { $index in $allSpecies } {
                # we have variable(AtomicLabel), but the atomic label is
                # not used; filter it out, i.e., return nothing
                return ""
            } else {
                # perhaps we have variable(atomicLabel) and
                # atomicLabel is not even defined; note that Fortran
                # arrays use numeric indices, whereas atomicLabel is a
                # string, hence filter out variable(atomicLabel) if
                # atomicLabel is not a numeric index.
                #
                # BEWARE: Fortran indices can be "1,2" or "-1:5,-3:+4" !
                #
                set parsed [regsub -all {[,:+-]} $index {}]                
                if { ! [string is integer $parsed] } {
                    return ""
                }
            }
        } elseif { $ind > -1 } {
            incr ind
            return $var\($ind\)
        }     
    }
    
    return $varName            
}
#****


#****f* Namelists/::pwtk::input::namelistItyp2AtmSymb
# SYNOPSIS
proc ::pwtk::input::namelistItyp2AtmSymb {nmlName varName} {    
    # PURPOSE
    # This routine is typically used internally by PWTK.
    #
    # Transform "ntyp"-type variable by replacing the atomic-index with
    # atomic-label, e.g., "starting_magnetization(1)" will be
    # transformed to "starting_magnetization(Fe)", where 1 is the index
    # of the Fe species.
    #
    # Beware that such transformation should be only done immediately
    # after "load_from" operation.
    #
    # RETURN VALUE
    # * if $varName is not ntyp-type (multi)dimension, $varName is returned.
    # * otherwise, the transformed $varName (multi)dimension  is returned, e.g.,
    #   Hubbard_occ(H,1,1) instead of Hubbard_occ(H,1,1)    
    #
    # SOURCE
    
    global ::pwtk::ntyp_variables
    global ::pwtk::ntyp_dimensions
    global ::pwtk::ntyp_multidimensions

    set dimL   [::pwtk::varvalue ::pwtk::ntyp_dimensions($nmlName)]
    set multiL [::pwtk::varvalue ::pwtk::ntyp_multidimensions($nmlName)]

    # split var(index) to {var index}
    lassign [split $varName ()] var index

    if { ($dimL eq {} && $multiL eq {}) || $index eq {} } {
        return $varName
    }

    set atomic_labels [::pwtk::pwi::getAllAtomicLabels]
    set ntyp [llength $atomic_labels]
    
    if { $var in $dimL } {
        if { $index > $ntyp } {
            # index is greater than the number of atomic-species; make no transformation
            return $varName
        }
        set atmSymb [lindex $atomic_labels $index-1] 
        return ${var}($atmSymb)
    } elseif { $var in $multiL } {
        set dim [lindex $multiL [lsearch -nocase $multiL $var]+1]
        if { ! [string is integer -strict $dim] } {
            ::pwtk::error "::pwtk::ntyp_multidimensions list is malformed, check the respective config/*i.tcl config file" 1
        }
        set indL [split $index ,]
        set ityp [lindex $indL $dim]
        if { [string is integer -strict $ityp] } {
            if { $ityp > $ntyp } {
                # index is greater than the number of atomic-species; make no transformation
                return $varName
            }
            set symb [lindex $atomic_labels $ityp-1]
            set newi [join [lreplace $indL $dim $dim $symb] ,]
            return ${var}($newi)
        }
    }
    
    return $varName    
}
#****

#****if Internals/::pwtk::input::namelists_ityp2atmSymb_
proc ::pwtk::input::namelists_ityp2atmSymb_ {nmlList} {
    # PURPOSE
    # This routine used internally by PWTK.
    #
    # Try to transform "ntyp"-type arrays for a list of namelists by
    # replacing the atomic-index with atomic-label, e.g.,
    # "starting_magnetization(1)" will be transformed to
    # "starting_magnetization(Fe)", where 1 is the index of the Fe
    # species.
    #
    # Beware that such transformation should be only done immediately
    # after "load_from" operation.
    #
    # SOURCE

    variable namelist
    
    foreach name $nmlList {
        if { ! [info exists ::pwtk::ntyp_dimensions($name)] && ! [info exists ::pwtk::ntyp_multidimensions($name)] } {
            continue
        }
        if { [info exists namelist($name)] } {
            foreach var [namelistVars_ $name] {
                # syvar = array(index) with index replaced with atomic-symbol
                set syvar [::pwtk::input::namelistItyp2AtmSymb $name $var]

                if { $syvar ne $var } {
                    set namelist($name,var=$syvar) $namelist($name,var=$var)
                    unset namelist($name,var=$var)
                }
            }
        }
    }
}
#******


# ------------------------------------------------------------------------
#
# internal procs
#
# ------------------------------------------------------------------------


#****if* Internals/::pwtk::input::appendInput_
# SYNOPSIS
proc ::pwtk::input::appendInput_ {name} {
    # PURPOSE
    #   Append a given namelist or card to variable "input" if the
    #   namelist|card exists. The whole input is build by successive
    #   call to thic proc. This means that the "input" variable is
    #   accumulating data ...
    # ARGUMENTS
    #   * name -- name of namelist or card
    # SOURCE
    
    namelistOut_ $name	
    cardOut_     $name     
}
#****


#****if* Internals/::pwtk::input::fprint_
# SYNOPSIS
proc ::pwtk::input::fprint_ {namespaceName {filename {}}} {
    # DESCRIPTION
    #    Collect and print the input data of a given namespace either to
    #    file or to stdout. Here namespace is related to particular input
    #    data, such as pwi (for pw.x input), ppi (for pp.x input), etc. ...
    # ARGUMENTS
    # * namespaceName -- absolute name of namespace that handles input
    #                    data (examples: ::pwtk::pwi, ::pwtk::phi, ::pwtk::ppi, ::pwtk::pri)
    # * filename      -- name of file to print to the input data (optional,
    #                    default = {}, which means print to stdout)
    # SOURCE
    
    if { $filename == {} } {
	# print to stdout
	puts stdout [namespace eval $namespaceName get]
    } else {
	if { [::pwtk::backup_io] } {
	    ::pwtk::file_backup $filename
	}
	::pwtk::writeFile $filename [namespace eval $namespaceName get]
    }
}
#******



#****if* Internals/::pwtk::input::defaultVarValue_
# SYNOPSIS
proc ::pwtk::input::defaultVarValue_ {namelist var default_value} {    
    # PURPOSE
    #   Set the "default" value of given namespace variable. Actually
    #   its sets the value only if the variables is not yet set.

    set value [::pwtk::input::namelistGetVarValue $namelist $var]
    
    if { $value == "" } {
	switch -nocase -- $var {
	    prefix -
	    outdir - 
	    wfcdir {
                # try the CONTROL namelist (e.g. outdir, prefix, ...)
		set value [::pwtk::input::namelistGetVarValue CONTROL $var]
	    }
	
	    fildyn {
                # query the INPUTPH namelist for the value of fildyn
		set value [::pwtk::input::namelistGetVarValue INPUTPH fildyn]
	    }

            flfrc {
                set value [::pwtk::input::namelistGetVarValue Q2R flfrc]
            }
	}
    }
    
    if { $value != "" } {
	namelist $namelist " $var = $value "
    } elseif { $default_value != "" } {
	namelist $namelist " $var = $default_value "
    }
}
#******


namespace eval ::pwtk::input {

    # PURPOSE
    #   clear the "input" variable
    proc clear_ {} {
	variable input
	if { [info exists input] } {
	    unset input
	}
    }

    # PURPOSE
    #   print the value of the "input" variable
    proc print_ {} {
	variable input 
	variable channel
	if { [info exists input] } {
	    puts $channel $input
	}
    }

    # PURPOSE
    #   return the value of the "input" variable
    proc get_ {} {
	variable input 	
	if { [info exists input] } {
	    return $input
	}
	return ""
    }

    # PURPOSE
    #   set the value of the "input" variable
    proc set_ {value} {
	variable input
        set input $value
	return $input
    }

    # PURPOSE
    #   write an empty line to variable "input"
    proc emptyLine_ {} {
	variable input
	append input "\n"
    }
    
    # PURPOSE
    #   write a card to variable "input"
    proc cardOut_ {name} {
	variable input
	global ::pwtk::input::card ::pwtk::input::card_flags
	
	if { [info exists ::pwtk::input::card($name)] } {
	    # card's line (keywaord + flags)
	    set cardline "$name"
	    if { [info exists ::pwtk::input::card_flags($name)] } {
		append cardline " $::pwtk::input::card_flags($name)"
	    }
	    append input "$cardline\n"

	    # card's content
	    cardOutContent_ $name
	    emptyLine_	    
	}
    }


    # PURPOSE
    #   write a the card's content to variable "input"
    proc cardOutContent_ {name} {
	variable input
	global ::pwtk::input::card ::pwtk::input::card_content

	if { [info exists ::pwtk::input::card($name)] && [info exists ::pwtk::input::card_content($name)]} {

	    set content $::pwtk::input::card_content($name)

	    switch -exact -- $name {
                ATOMIC_SPECIES {
                    append input [::pwtk::ATOMIC_SPECIES_math_parser $content]
                }
		ATOMIC_POSITIONS -
		POSITIONS {
		    # special math-parsing of this card
		    append input [::pwtk::ATOMIC_POSITIONS_math_parser $content]
		}
		CELL_PARAMETERS {
		    # special math-parsing of this card		    
		    append input [::pwtk::CELL_PARAMETERS_math_parser $content]
		}
                INPUTPH.titleLine {
                    # verbatim, i.e., w/o math-parsing
                    append input $content\n
                }
		default {		    
		    # default math-parsing of cards
		    append input [card_math_parser $content]\n
		}
	    }
	}
    }

    # PURPOSE
    #   append a namelist to variable "input"
    proc namelistOut_ {name} {	
	global ::pwtk::input::namelist
	variable input

	# IMPORTANT: the "input" variable should not be cleared, it should be appended !!!  

	if { [info exists ::pwtk::input::namelist($name)] } {

	    append input " &$name\n"
            
	    foreach var [namelistVars_ $name] {

                # print only non-empty variables
                
		if { $::pwtk::input::namelist($name,var=$var) != "" } {

                    # convert all variable of type var(atomic-symbol) to var(atomic-index)
                    # example: starting_magnatization(Fe) --> starting_magnatization(1)
                    
                    set vari [namelistAtmSymb2Ityp $name $var]

                    # PROBLEM:
                    # parhaps ::pwtk::input::namelist($name,var=$vari) exists!                    
                    # what to do in such a case, who should have the preference ?
                    #
                    # SOLUTION: if load_fromXX clears the input data, then
                    # ::pwtk::input::namelist($name,var=$var) does not exist,
                    # otherwise it should have the preference, whereas PWTK scripts
                    # should always use atomic-symbols

                    if { $vari != "" } {
                        set value [::pwtk::input::namelistGetVarValue $name $var]

                        if { $vari ni $var } {
                            # we have variable(atomic-symbol)
                            set variable($vari) $value
                        }
                        # we have variable(ityp)
                        lappend input_ [list $vari $value]
                    }                    
                }
	    }
            
            ::pwtk::ifexist input_ {                
                # check for occurances of variable(atomic-symbol); in such a case
                # use the value of variable(atomic-symbol) instead of variable(ityp),
                # see the above explanation
                foreach elem $input_ {
                    set var [lindex $elem 0]
                    ::pwtk::ifexist variable($var) {
                        set elem [list $var $variable($var)]
                    }
                    lappend input__ $elem
                }
                # due to variable(atomic-symbol) && variable(ityp) there
                # can be duplicates; remove them

                # get maximum length of a variable name
                set maxl 0
                foreach elem $input__ {
                    lassign $elem var
                    if {[string length $var] > $maxl} {
                        set maxl [string length $var]
                    }
                }

                foreach elem [lsort -ascii -unique $input__] {
                    lassign $elem var value
                    append input [format "   %-*s = %s\n" $maxl $var $value]
                }
            }
	    append input " /\n"
	    emptyLine_
	}
    }

    # PURPOSE
    #   return the list of all defined namelist variables
    proc namelistVars_ {name} {
	global ::pwtk::input::namelist
	set vars ""
	foreach elem [lsort [array names ::pwtk::input::namelist $name,var=*]] {
	    lappend vars [lindex [split $elem =] 1] 
	}
	return $vars
    }
}
