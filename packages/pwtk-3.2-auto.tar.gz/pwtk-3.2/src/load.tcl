#
# $RCSfile: load.tcl,v $ --
#
#      This file contains the generic load_from and qe2pwtk commands for loading
#      the input data from input files.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: load.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#

#****f* Programs/::pwtk::load_from
# SYNOPSIS
proc ::pwtk::load_from {program inputFile {clear_existing 1}} {
    # USAGE
    #   load_from PROGRAM inputFile ?clear_existing?
    #
    # PURPOSE 
    #   Load the input data for PROGRAM from the existing input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, 
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * PROGRAM -- the QE executable (e.g. pw.x, cp.x, neb.x)
    # * pwi -- filename of the input file from which to extract the input data
    # * clear_existing -- (optional) should the current input data associated with the PROGRAM be cleared (boolean)
    #
    # EXAMPLE
    #   load_from pw.x scf.in
    #
    # SOURCE

    variable prog2inNN
    variable plugin
    
    if { ! [info exists prog2inNN($program)] && [lsearch -exact $plugin(list) [string tolower $program]] < 0} {
        ::pwtk::error "cannot load the $program input file because $program is neither a supported executable nor plugin" 1
    } 

    if { [info exists prog2inNN($program)] } {
        # executable
        set ns [namespace tail $prog2inNN($program)]
        namespace eval ::pwtk::${ns} load_from[string toupper $ns] $inputFile $clear_existing
    } else {
        # plugin
        set program [string tolower $program]
        namespace eval ::pwtk::${program} load_$program.in $inputFile $clear_existing
    }
}
#******


#****f* Programs/::pwtk::qe2pwtk
# SYNOPSIS
proc ::pwtk::qe2pwtk {args} {
    # USAGE
    #   qe2pwtk ?-p program? inputFile
    #
    # OPTION
    # * -p program ... the name of the QE program or plugin (e.g. -p pw.x, -p environ)
    #
    # ARGUMENT
    # * inputFile -- the QE input file
    #
    # PURPOSE    
    #   Transform a QE input into a PWTK script.
    #
    #   If the QE program is not explicitly specified with the -p
    #   option, PWTK attempts to make a best guess in converting the
    #   QE input into the PWTK script.
    #
    #   In contrast, if the program is explicitly specified, then an
    #   error is thrown if the syntax of the input file does not
    #   match.
    #
    # RETURN VALUE
    # A QE input converted to a PWTK script
    #
    # SOURCE

    variable prog2inNN
    variable plugin

    # parse command-line
    
    set narg 1
    set usage "?-p program? inputFile"
    set options {
        {p.arg {} "the name of the QE program (e.g. pw.x, pp.x...)"}
    }
    parseOpt_

    set inpFile $args
    ::pwtk::fileMustExist $inpFile [string trim "$opt(p) input"]

    # convert QE input to PWTK script
    
    ::pwtk::input::pushpop {
        if { $opt(p) ne {} } {
            # the -p option was specified
            
            set fullList [string tolower [concat [lsort [array names prog2inNN]] [lsort $plugin(list)]]]
            if { [string tolower $opt(p)] ni $fullList } {
                ::pwtk::error "\"$opt(p)\" is a non-supported QE program or plugin, must be one of [join $fullList {, }]" 1
            }

            if { $opt(p) eq "neb.x" } {
                # it's a neb.x input
                if { [catch {::pwtk::readNamelists $inpFile PATH 1}] } {
                    ::pwtk::error "input file \"$inpFile\" does not appear to be a neb.x input file" 1
                }
                return [qe2pwtk_nebi_ $inpFile]
            } else {
                # other input file
                load_from $opt(p) $inpFile

                if { [info exists ::pwtk::prog2inNN($opt(p)) ] } {
                    upvar $::pwtk::prog2inNN($opt(p))::input_flow_list_specs specs
                } else {
                    # plugin
                    upvar ::pwtk::${opt(p)}::input_flow_list_specs specs
                }
            }        
        } else {
            # implicit conversion via best guess
            
            if { ! [catch {::pwtk::readNamelists $inpFile PATH 1}] } {
                # it's a neb.x input
                return [qe2pwtk_nebi_ $inpFile]
            } else {
                # read input for all programs and plugins, except neb.x               
                foreach prog [array names prog2inNN] {
                    if { $prog ne "neb.x" } { lappend ilist $prog2inNN($prog) }
                }
                
                foreach x [concat $ilist $plugin(list)] {
                    set x ::pwtk::[namespace tail $x]

                    append QEnml_flow_list     "[varvalue ${x}::QEnml_flow_list] "
                    append QEcard_flow_list    "[varvalue ${x}::QEcard_flow_list] "
                    append QEcard_closing_list "[varvalue ${x}::QEcard_closing_list] "
                    
                    append namelist_flow_list  "[varvalue ${x}::namelist_flow_list] "
                    append card_flow_list      "[varvalue ${x}::card_flow_list] "
                    
                    append input_flow_list_specs "[varvalue ${x}::input_flow_list_specs] "
                    
                    array set QE2PWTKcard [array get ${x}::QE2PWTKcard]
                }
                ::pwtk::read_QEinput_ $inpFile \
                    $QEnml_flow_list $QEcard_flow_list $QEcard_closing_list \
                    $namelist_flow_list $card_flow_list $input_flow_list_specs \
                    QE2PWTKcard

                # this is a bit complicated, but preserves the order of input_flow_list
                set names {}
                foreach type_name $input_flow_list_specs {
                    lassign $type_name type name
                    if { [lsearch $names $name] < 0 } {
                        lappend names $name
                        lappend specs [list $type $name]
                    }
                }            
            }
        }
        
        foreach elem $specs {
            lassign $elem type name
            switch -glob $type {
                namelist* { append result [::pwtk::input::namelistGetPWTK $name] }
                card*     { append result [::pwtk::input::cardGetPWTK $name] }
            }
        }
    }
    return $result
}
#******


# internal...
proc ::pwtk::qe2pwtk_nebi_ {inpFile} {
    # PURPOSE
    #   qe2pwtk for neb.x input file (it's treated specially)

    ::pwtk::nebi::load_fromNEBI $inpFile

    foreach nml [concat $::pwtk::nebi::namelist_flow_list $::pwtk::pwi::namelist_flow_list] {
        append result [::pwtk::input::namelistGetPWTK $nml]
    }
    # exclude ATOMIC_POSITIONS from the pw.x cards
    set pwi_cards [lsearch -inline -all -not -exact $::pwtk::pwi::card_flow_list ATOMIC_POSITIONS]
    foreach card [concat $pwi_cards $::pwtk::nebi::card_flow_list] {
        append result [::pwtk::input::cardGetPWTK $card]
    }
    return $result
}
