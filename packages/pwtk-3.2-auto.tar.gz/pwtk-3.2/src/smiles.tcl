#
# $RCSfile: smiles.tcl,v $ --
#
#      This file contains commands associated with SMILES, i.e.:
#      https://en.wikipedia.org/wiki/Simplified_molecular-input_line-entry_system
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: smiles.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#

#****a* 5.6. Structural Utilities/smiles
# DESCRIPTION
# A collection of routines associated with SMILES,
# https://en.wikipedia.org/wiki/Simplified_molecular-input_line-entry_system
# 
#******


#****f* smiles/::pwtk::smi2xsf
# SYNOPSIS
proc ::pwtk::smi2xsf {args} {
    # USAGE
    #   smi2image ?-d?  ?-vacuum VACUUM|-box BOX_SPECS?  SMILES  ?OUTPUT_XSF?
    #
    # PURPOSE
    #   Convert SMILES specs to XSF formatted structure data.
    #
    #   A molecular XSF data is created unless the -vacuum or -box
    #   options are specified, in which case a 3D XSF data are created.
    #
    #   If the OUTPUT_XSF argument is given, the XSF data are written
    #   to the OUTPUT_XSF file.
    #
    # OPTIONS
    # Display option:
    # * -d --- display the generated molecular structure with xcrysden
    #
    # Exclusive options:
    # * -vacuum VACUUM --- size of vacuum around the molecule in Å
    #                      (determines the size of the unit cell)
    # * -box BOX_SPECS --- size of the orthogonal box (unit cell), where BOX_SPECS are:
    #
    #       + if BOX_SPECS == A: cubic box (A x A x A),
    #       + if BOX_SPECS == {A C}: tetragonal box (A x A x C),
    #       + if BOX_SPECS == {A B C}: orthorhombic (A x B x C).
    #
    # ARGUMENTS
    # * SMILES     --- molecular SMILES specs
    # * OUTPUT_XSF --- (optional) if given, XSF data are written to OUTPUT_XSF file
    #
    # RETURN VALUE
    # * the XSF formatted data
    #
    # SOURCE

    set nargmin 1
    set nargmax 2
    set usage "?-d?  SMILES  ?OUTPUT_XSF?"
    set options {
        {d  "display the generated image"}
        {vacuum.arg -8.0 "size of vacuum around the molecule in angstroms (the same in each direction)"}
        {box.arg    -1   "size of the box in angstroms used for the CELL_PARAMETERS"}
    }
    parseOpt_
    checkOTypeStrict_ -vacuum $opt(vacuum) double number
    checkOTypeStrict_ -box    $opt(box)    {numberlist double}  "list of numbers"

    lassign $args smiles xsf
    
    # check if both -vacuum & -box were specified
    set lvac [expr {"-vacuum" in $args_}]
    set lbox [expr {"-box" in $args_}]
    if { $lvac + $lbox > 1 } {
        ::pwtk::error "-vacuum & -box exclusive options were specified; please specify only one of them" 1
    }
    
    set coor [smilesToCoor $smiles]
    set nat  [getNAtoms $coor]

    if { $lvac } {
        lassign [boxify $coor $opt(vacuum)] A B C
    } elseif { $lbox } {
        # assume orthorhomic: A B C
        lassign $opt(box) A B C
        if { $B eq {} } {
            # cubic: A A A
            set C [set B $A]
        } elseif { $C eq {} } {
            # tetragonal: A A C
            set C $B
            set B $A
        }
    }

    # XSF
    
    ifempty A {
        set result "MOLECULE"
    } else {
        set result "CRYSTAL\n
PRIMVEC
$A   0.0  0.0
0.0  $B   0.0
0.0  0.0  $C"
    }
    append result "\n\nPRIMCOORD\n$nat 1\n$coor"
    ifnotempty xsf {
        writeFile $xsf $result
    }

    # visualize
    
    if { $opt(d) } {
        ifempty xsf {
            set xsf [::fileutil::tempfile].xsf
            writeFile $xsf $result
        }
        try_exec -i -- xcrysden --xsf $xsf
    }
    
    return $result
}
#******


#****f* smiles/::pwtk::smi2png
# SYNOPSIS
proc ::pwtk::smi2png {args} {
    # USAGE
    #   smi2image ?-d?  SMILES  ?OUTPUT_PNG?
    #
    # PURPOSE
    #   Create a PNG image of molecular skeletal structure from the
    #   SMILES specs.
    #
    # OPTION
    # * -d --- display the generated image (viewer is executed in the background)
    #
    # ARGUMENTS
    # * SMILES     --- molecular SMILES specs
    # * OUTPUT_PNG --- (optional) name of the generated PNG image file
    #
    # RETURN VALUE
    # The filename of the generated PNG image.
    #
    # SOURCE
    set type png
    return [::pwtk::smi2image_]
}
#******


#****f* smiles/::pwtk::smi2svg
# SYNOPSIS
proc ::pwtk::smi2svg {args} {
    # USAGE
    #   smi2image ?-d?  SMILES  ?OUTPUT_SVG?
    #
    # PURPOSE
    #   Create a SVG image of molecular skeletal structure from the
    #   SMILES specs.
    #
    # OPTION
    # * -d --- display the generated image (viewer is executed in the background)
    #
    # ARGUMENTS
    # * SMILES     --- molecular SMILES specs
    # * OUTPUT_SVG --- (optional) name of the generated SVG image file
    #
    # RETURN VALUE
    # The filename of the generated SVG image.
    #
    # SOURCE
    set type svg
    return [::pwtk::smi2image_]
}
#******


# internal ...
proc ::pwtk::smi2image_ {} {
    uplevel 1 {
        set nargmin 1
        set nargmax 2
        set usage "?-d?  SMILES  ?IMAGE_NAME?"
        set options {
            {d  "display the generated image"}
        }
        parseOpt_
        lassign $args smiles image

        ifset image [fileutil::tempfile].$type
        try_exec -ignorestderr -- obabel -:$smiles -O $image -xx -xc1
        if { $opt(d) } {
            display $image &
        }
        return $image
    }
}


#****f* smiles/::pwtk::smi2coor
# SYNOPSIS
proc ::pwtk::smi2coor {smi} { return [::pwtk::smilesToCoor $smi] }
# PURPOSE
# A shortcut to ::pwtk::smilesToCoor.
#******


#****f* smiles/::pwtk::smilesToCoor
# SYNOPSIS
proc ::pwtk::smilesToCoor {smiles} {
    # PURPOSE
    #   Transform molecular SMILES specs into Cartesian coordinates.
    #
    #   For info about SMILES, see:
    #   https://en.wikipedia.org/wiki/Simplified_molecular-input_line-entry_system
    
    # BEWARE
    #   This routine requires the "obabel" program.   
    # ARGUMENT
    # * smiles -- the molecular SMILES specs
    # RETURN VALUE
    #   Cartesian molecular coordinates, e.g.:    
    #      C          1.06626        0.07457        0.00696
    #      H          2.15846        0.07457        0.00696
    #      H          0.70220       -0.59722       -0.77346
    #      H          0.70219        1.08633       -0.18463
    #      H          0.70219       -0.26539        0.97895    
    # SOURCE
    set xyz [fileutil::tempfile].xyz
    try_exec -ignorestderr -- obabel -:$smiles -oxyz -O $xyz --gen3D --best >& /dev/null

    set xyzl [split [string trim [readFile $xyz]] \n]
    catch { file delete $xyz }
    return [join [lrange $xyzl 2 end] \n]
}
#******
