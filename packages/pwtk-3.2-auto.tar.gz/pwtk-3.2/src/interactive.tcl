#
# $RCSfile: interactive.tcl,v $ --
#
#      This file defines a PWTK interactive prompt by redefining
#      ::tclreadline::prompt1 and ::tclreadline::prompt2 routines.
#
# Copyright (c) 2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: interactive.tcl,v 1.3 2015/01/12 17:00:01 kokalj Exp $ 
#

proc ::tclreadline::prompt1 {} {
    global env
    if {[catch {set pwd [pwd]} tmp]} {
        set pwd "unable to get pwd"
    }
    
    if {[info exists env(HOME)]} {
        variable normalized_home
        if {![info exists normalized_home]} {
            set normalized_home [file normalize $env(HOME)]
        }
        if {[string equal -length [string length $normalized_home] $pwd $normalized_home]} {
            set pwd "~[string range $pwd [string length $normalized_home] end]"
        }
    }
    return "\[0;34m$env(USER)@[info hostname]\[0;32m \[$pwd\]\n\[0;31mPWTK-$::pwtk::version %\[0m "
}


proc ::tclreadline::prompt2 {} {
    variable prompt_pwd
    #return [join [lrepeat [string length "PWTK-$::pwtk::version % "] { }] {}]
    return {}
}
