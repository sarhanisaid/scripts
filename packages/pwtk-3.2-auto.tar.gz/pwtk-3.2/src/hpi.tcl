#
# $RCSfile: hpi.tcl,v $ --
#
#      This file contains the procs for handling the hp.x input.
#
# Copyright (c) 2019  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: hpi.tcl,v 1.2 2021/05/03 14:21:08 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::hpi_fprint {{file {}}} { uplevel ::pwtk::hpi::fprint $file }
proc ::pwtk::hpi_clear  {}          { uplevel ::pwtk::hpi::clear }
proc ::pwtk::hpi_get    {}          { uplevel ::pwtk::hpi::get }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::hpi/::pwtk::hpi::fprint
# SYNOPSIS
proc ::pwtk::hpi::fprint {{file {}}} {
# PURPOSE
#   Print the content of hp.x input data to a file or to stdout if the
#   file was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::hpi $file
}
#****


#****f* ::pwtk::hpi/::pwtk::hpi::get
# SYNOPSIS
proc ::pwtk::hpi::get {} {
    # DESCRIPTION    
    #   Return the content of the hp.x input 
    # SOURCE

    loadDefaults_
    
    return [::pwtk::input::namelistGet INPUTHP]
}
#******
    

#****f* ::pwtk::hpi/::pwtk::hpi::clear
# SYNOPSIS
proc ::pwtk::hpi::clear {} {
    # DESCRIPTION    
    #   Clear the content of the hp.x input 
    # SOURCE
    variable input_flow_list
    
    foreach name $input_flow_list {
	::pwtk::input::clear $name
    }
}
#******
    

proc ::pwtk::hpi::loadDefaults_ {} {
    # load some default values, when user has omitted them 

    namespace eval ::pwtk::input {
	defaultVarValue_ INPUTHP outdir  [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
	defaultVarValue_ INPUTHP prefix  ""
    }
}


#****f* ::pwtk::hpi/::pwtk::hpi::load_fromHPI
# SYNOPSIS
proc ::pwtk::hpi::load_fromHPI {hpi {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing hp.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * hpi -- filename of the hp.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?

    #
    # SOURCE
 
    ::pwtk::fileMustExist $hpi "hp.x input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current hp.x input data ...
	::pwtk::input::clear INPUTHP
    }

    # read the namelist

    set output [::pwtk::readNamelists $hpi $::pwtk::hpi::input_flow_list]

    # hp.x must contain an INPUTHP namelist
    if { $output == "" } {
	::pwtk::error "input file \"$hpi\" does not appear to be a hp.x input file" 1
    }

    eval $output
    ::pwtk::input::namelists_ityp2atmSymb_ $::pwtk::hpi::input_flow_list
}
#******
