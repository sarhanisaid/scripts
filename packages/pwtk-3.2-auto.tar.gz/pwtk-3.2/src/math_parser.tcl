#
# $RCSfile: math_parser.tcl,v $ --
#
#      This file contains the implementation of math-parser.
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: math_parser.tcl,v 1.10 2021/05/03 14:16:49 tone Exp $ 
#

#****f* MathParser/::pwtk::is_double
# SYNOPSIS
proc ::pwtk::is_double {expression} {
    # PURPOSE   
    #   Return 1 if the supplied $expression is of double type, 0
    #   otherwise.  Beware that fortran "D" exponential syntax, i.e
    #   1.0d0, is taken care of.
    # SOURCE
    if { [catch {::pwtk::mathParser $expression}] } {
        return 0
    } else {
        return 1
    }
}
#******

#****f* MathParser/::pwtk::is_int
# SYNOPSIS
proc ::pwtk::is_int {expression} {
    # PURPOSE   
    #   Return 1 if the supplied $expression is of int type, 0 otherwise.
    # SOURCE
    if { [catch {set result [expr $expression]}] } {
        return 0
    } else {
        return [string is integer -strict $result]
    }
}
#******

#****f* MathParser/::pwtk::is_true
# SYNOPSIS
proc ::pwtk::is_true {value} {        
    # PURPOSE    
    #   Return 1 if the supplied $value is one of 1, TRUE, T, .TRUE.,
    #   .T., YES, or ON (case insensitive). Return 0 otherwise.
    #
    # SOURCE
    set value [string trim $value .]    
    switch -nocase -- $value {
        true - t - yes - on - 1 {
            return 1
        }
    }
    # perhaps $value is expression
    if { [is_expr $value] } {
        set value [expr $value]
    }
    # positive integer values are considered as true
    if { [string is integer -strict $value] } {
        if { $value > 0 } {
            return 1
        }
    }
    # boolean ?
    if { [string is boolean -strict $value] } {
        if { $value } {
            return 1
        } else {
            return 0
        }
    }
    return 0
}
#******

#****f* MathParser/::pwtk::is_expr
# SYNOPSIS
proc ::pwtk::is_expr {expression} {
    # PURPOSE   
    #   Return 1 if the supplied string is "expression", 0 otherwise.
    #   Beware that fortran "D" exponential syntax, i.e 1.0d0, is
    #   taken care of.
    # SOURCE
    if { [catch {expr [f2c_number $expression]}] } {
        return 0
    } else {
        return 1
    }
}
#******


#****f* MathParser/::pwtk::is_comment
# SYNOPSIS
proc ::pwtk::is_comment {line} {
    # PURPOSE
    #   Check if the input 'line' is a comment (i.e., if its first non-whitespace character is #).
    # RETURN VALUE
    # * 1 or 0
    # SOURCE
    if { [string index [string trim $line] 0] eq "#" } {
        return 1
    } else {
        return 0
    }
}
#******


#****f* MathParser/::pwtk::evalExpr
# SYNOPSIS
proc ::pwtk::evalExpr {expression} {
    # PURPOSE   
    #   Evaluate expression and return its value. For integer
    #   expression, integer value is returned; for real expression,
    #   real value is returned.  Beware that fortran "D" exponential
    #   syntax, i.e 1.0d0, is taken care of.
    # SOURCE
    if { [is_int $expression] } {
        return [expr $expression]
    } elseif { [is_double $expression] } {
        return [mathParser $expression]
    } else {
        return $expression
    }
}
#******


#****f* MathParser/::pwtk::mathParser
# SYNOPSIS
proc ::pwtk::mathParser {expression} {        
    # PURPOSE
    #   Parse a simple math expression and return the value.
    # ARGUMENTS
    #   * expression -- a simple math expression.
    # SOURCE

    variable bohr2angs
    variable angs2bohr
    variable ry2ev
    variable ev2ry

    # force expr to use floating-point (real) numbers by multiplying
    # expression by 1.0
    return [expr 1.0 * [f2c_number $expression]]
}
#******


#****f* MathParser/::pwtk::f2c_number
# SYNOPSIS
proc ::pwtk::f2c_number {expression} {
    # PURPOSE
    #   Real numbers may have Fortran syntax, i.e., they may
    #   contain fortran double precision formatted numbers 1.0d-4;
    #   Reformat this to be Tcl-compatible, i.e., replace D with E.
    # ARGUMENTS
    #   * expression -- a simple math expression.
    # SOURCE
    
    return [string map -nocase {d- e- d+ e+ d0 e0 d1 e1 d2 e2 d3 e3 d4 e4 d5 e5 d6 e6 d7 e7 d8 e8 d9 e9} $expression]
}
#****


#****f* MathParser/::pwtk::queryMathParsing
# SYNOPSIS
proc ::pwtk::queryMathParsing {namelist variable} {
    # PURPOSE
    #   Query if reuqested variable should be math-parsed.
    # ARGUMENTS
    #   * namelist -- name of namelist
    #   * variable --- name of namelist variable
    # SOURCE
    variable mathparse_real_variables
    variable mathparse_int_variables
    variable mathparse_variables

    # the new mathparse_real_variables and mathparse_int_variables
    
    if { [info exists mathparse_real_variables($namelist)] } {
	foreach pattern $mathparse_real_variables($namelist) {
	    if { [string match -nocase $pattern $variable] } {
		return 1
	    }
	}
    }
    if { [info exists mathparse_int_variables($namelist)] } {
	foreach pattern $mathparse_int_variables($namelist) {
	    if { [string match -nocase $pattern $variable] } {
		return 1
	    }
	}
    }

    # the old mathparse_variables
    if { [info exists mathparse_variables($namelist)] } {
	foreach pattern $mathparse_variables($namelist) {
	    if { [string match -nocase $pattern $variable] } {
		return 1
	    }
	}
    }

    return 0
}
#****

#****f* MathParser/::pwtk::vecMathParser
# SYNOPSIS
proc ::pwtk::vecMathParser {vec} {
    # PURPOSE
    #   Math parser for a numeric vector of any dimension.
    # ARGUMENT
    # * vec -- a vector to math-parse
    # RETURN VALUE
    # * math-parsed vector
    # SOURCE
    set result ""
    foreach x $vec {
        if { [is_expr $x] } {
            lappend result [mathParser $x]
        } else {
            lappend result $x
        }
    }
    return $result
}
#******


#****f* MathParser/::pwtk::card_math_parser
# SYNOPSIS
proc ::pwtk::input::card_math_parser {content} {
    # PURPOSE
    #  Generic math parser for cards
    # SOURCE

    set parsedContent ""

    foreach line [split $content \n] {
        # if the first character of the line is "#', it is a comment
        if { [::pwtk::is_comment $line] } {
            set parsedLine [string trim $line]
        } else {        
            set  parsedLine ""
            foreach field $line {	    
                if { [catch {::pwtk::mathParser $field}] } {
                    # not a number (string)
                    append parsedLine "  $field "
                } elseif { [string is integer $field] } {
                    append parsedLine "  $field "
                } else {
                    set parsedNumber [::pwtk::evalExpr $field]
                    #set parsedNumber [::pwtk::mathParser $field]
		
                    if { ! [string is double $parsedNumber] } {
                        # not a floating point number, print as is
                        append parsedLine "  $field "
                    } else {
                        # floating point number
                        append parsedLine "   $parsedNumber "
                        #append parsedLine [format "  %20.16f " $parsedNumber]
                    }
                }	
            }
        }
	append parsedContent ${parsedLine}\n
    }
    if { $parsedContent eq {} } { set parsedContent \n }
    
    return $parsedContent
}
#****

proc ::pwtk::pwi::ATOMIC_POSITIONS_math_parser {content} {
    deprecated "[::pwtk::procName] is deprecated, use ::pwtk::ATOMIC_POSITIONS_math_parser instead"
    return [::pwtk::ATOMIC_POSITIONS_math_parser $content]
}
#****f* MathParser/::pwtk::ATOMIC_POSITIONS_math_parser
# SYNOPSIS
proc ::pwtk::ATOMIC_POSITIONS_math_parser {content} {
    # PURPOSE
    #   Specially supplied math-parser for ATOMIC_POSITIONS card to
    #   yield nicely formated output.  
    #
    #   There can be 4 or 7 columns, but only coordinates (columns
    #   2,3,4) are math-parsed.
    #
    # RETURN VALUE
    #   Nicely formated ATOMIC_POSITIONS card as, e.g.:
    #
    #          atom1 x1 y1 z1 if_pos1(x) if_pos1(y) if_pos1(z)
    #          atom2 x2 y2 z2
    #          ...
    #
    #   If $content correspond to neb.x POSITIONS card, it returns, e.g.:
    #
    #      FIRST_IMAGE
    #      ATOMIC_POSITIONS (unit)
    #          atom1 x1 y1 z1 if_pos1(x) if_pos1(y) if_pos1(z)
    #          atom2 x2 y2 z2
    #          ...
    #      ...    
    # SOURCE

    variable fmt_atmPos
    
    set charge 0
    set parsedContent ""
    foreach line [split [::pwtk::skipEmptyLines $content] \n] {

	# check if we have path-calculation

	set word [lindex $line 0]
	switch -glob -- $word {
            "#" {
                # comment
                append parsedContent [string trim $line]\n
            }
	    first_image* - 
	    intermediate_image* - 
	    last_image* {
		# atomic positions specified using the old pw.x format 
		append parsedContent [string toupper ${line}]\n
		append parsedContent "ATOMIC_POSITIONS [::pwtk::input::cardGetFlags ATOMIC_POSITIONS]\n"
	    }
	    FIRST_IMAGE -
	    INTERMEDIATE_IMAGE - 
	    LAST_IMAGE -
	    ATOMIC_POSITIONS* {
		# atomic positions specified using the new neb.x format 
		append parsedContent ${line}\n
                set charge 0
	    }
            TOTAL_CHARGE {
                # neb.x TOTAL_CHARGE card
                append parsedContent ${line}\n
                set charge 1
            }
	    default {
		set len [llength $line]
                if { ! $charge } {
                    if { $len != 4 && $len != 7 } {
                        ::pwtk::error "wrong number of fields, $len, in ATOMIC_POSITIONS card, must be 4 or 7, while reading ATOMIC_POSITIONS\n$content" 1
                    }

                    lassign $line atmSymb x y z ifx ify ifz
                    set x [::pwtk::mathParser $x]
                    set y [::pwtk::mathParser $y]
                    set z [::pwtk::mathParser $z]
                    
                    if { $len == 7 } {
                        append parsedContent [format $fmt_atmPos(7) $atmSymb $x $y $z $ifx $ify $ifz]
                    } else {
                        append parsedContent [format $fmt_atmPos(4) $atmSymb $x $y $z]
                    }
                } else {
                    append parsedContent $line\n
                }
	    }   		
	}
    } 	    
    return $parsedContent
}
#****


proc ::pwtk::pwi::CELL_PARAMETERS_math_parser {content} {
    deprecated "[::pwtk::procName] is deprecated, use ::pwtk::CELL_PARAMETERS_math_parser instead"
    return [::pwtk::CELL_PARAMETERS_math_parser $content]
}

#****f* MathParser/::pwtk::CELL_PARAMETERS_math_parser
# SYNOPSIS
proc ::pwtk::CELL_PARAMETERS_math_parser {content} {
    # PURPOSE
    #   Specially supplied math-parser for CELL_PARAMETERS card to
    #   yield nicely formated output.
    #
    # RETURN VALUE
    #   Cell parameters in the form:
    #       ax  ay  az
    #       bx  by  bz
    #       cx  cy  cz
    # SOURCE


    set parsedContent ""
    foreach line [split [::pwtk::skipEmptyLines $content] \n] {
	if { [::pwtk::is_comment $line] } {
            append parsedContent [string trim $line]\n
            continue
        } 
	set len [llength $line]
	if { $len != 3 } {
	    ::pwtk::error "wrong number of fields, $len, in CELL_PARAMETERS card, must be 3, while reading CELL_PARAMETERS\n$content"
	}
        lassign $line vx vy vz
	append parsedContent [format "  %20.15f %20.15f %20.15f\n" \
                                  [::pwtk::mathParser $vx] \
                                  [::pwtk::mathParser $vy] \
                                  [::pwtk::mathParser $vz] ]
    }
    
    return $parsedContent
}
#****


#****f* MathParser/::pwtk::ATOMIC_SPECIES_math_parser
# SYNOPSIS
proc ::pwtk::ATOMIC_SPECIES_math_parser {content} {
    # PURPOSE
    #   Specially supplied math-parser for ATOMIC_SPECIES card to
    #   yield nicely formated output.  
    #
    # RETURN VALUE
    #   Nicely formated ATOMIC_SPECIES card.
    #
    # SOURCE

    variable fmt_atmPos
    
    set charge 0
    set result ""

    set species [split [::pwtk::skipEmptyLines $content] \n]

    # get the max length of symb & mass number
    set sl 0
    set ml 0
    foreach line $species {
        if { ! [::pwtk::is_comment $line] } {
            lassign $line symb mass
            if {[string length $symb] > $sl} {
                set sl [string length $symb]
            }
            set mass [evalExpr $mass]
            if {[string length $mass] > $ml} {
                set ml [string length $mass]
            }
        }
    }
    # nicely format
    foreach line $species {
	if { [::pwtk::is_comment $line] } {
            append result [string trim $line]\n
            continue
        }
        if { [llength $line] != 3 } {
            ::pwtk::error "wrong format of the ATOMIC_SPECIES card. Each line must consists of 3 columns, but got:\n\n$content" 1
        }

        lassign $line symb mass ppFile

        if { ! [is_double $mass] } {
            ::pwtk::error "expected a number for atomic mass, but got $mass" 1
        }
        
        append result [format {%-4s%-*s  %-*s  %s} { } $sl $symb $ml [evalExpr $mass] $ppFile]\n
    }
    return $result
}
#****
