#
# $RCSfile: latex.tcl,v $ --
#
#      This file contains a small support for creating LaTeX source
#      files (mainly used by tabulateStructs).
#
# Copyright (c) 2009-2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: latex.tcl,v 1.5 2021/05/01 19:23:20 tone Exp $ 
#

#****n* LaTeX/::pwtk::latex
# DESCRIPTION
#   This namespace contains a few commands for creating LaTeX source
#   files (mainly used by ::pwtk::pwi::tabulateStructs &
#   ::pwtk::pwo::tabulateStructs utilities).
#
#   The main command used by tabulateStructs utilities is ::pwtk::latex::tabulateFigs
#******

namespace eval ::pwtk::latex {

    variable head {
	\documentclass[10pt]{extarticle}
	\usepackage{longtable}
	\usepackage{graphicx} 
	\usepackage{grffile}
	\addtolength{\hoffset}{-3cm}
	\addtolength{\voffset}{-3.5cm}
	\setlength\textwidth{18cm}
	\setlength\textheight{27cm}
	\begin{document}
    }

    variable tail {
	\end{document}
    }

    variable cellOffset 0.02
}


#****f* ::pwtk::latex/::pwtk::latex::landscape
# SYNOPSIS
proc ::pwtk::latex::landscape {} {
    # PURPOSE
    #   Set the landscape paper orientation (default orientation = portrait).
    # SOURCE

    variable head
    # deafult head for landscape orientation
    
    set head {
	\documentclass[10pt,landscape,a4]{extarticle}
	\usepackage{longtable}
	\usepackage{graphicx} 
	\usepackage{grffile}
	\setlength\textheight{18cm}
	\setlength\textwidth{26cm}
	\addtolength{\voffset}{-3cm}
	\addtolength{\hoffset}{-7cm}
	\begin{document}
    }
}
#******


#****f* ::pwtk::latex/::pwtk::latex::head
# SYNOPSIS
proc ::pwtk::latex::head {text} {
    # PURPOSE
    #   Set the LaTeX preamble (aka head).
    # SOURCE

    variable head
    set head $text
}
#******

#****f* ::pwtk::latex/::pwtk::latex::tail
# SYNOPSIS
proc ::pwtk::latex::tail {text} {
    # PURPOSE
    #   Set the LaTeX tail (default tail = \end{document}).
    # SOURCE
    variable tail
    set tail $text
}
#******

# internal...
proc ::pwtk::latex::write_ {text} {   
    variable fid
    set text [uplevel 1 "subst -nocommands -nobackslashes {$text}"]
    puts $fid $text
}

# internal...
proc ::pwtk::latex::make_head {} {
    variable head
    write_ $head
}

# internal...
proc ::pwtk::latex::make_tail {} {
    # PURPOSE
    #   
    # SOURCE
    variable tail
    write_ $tail
}


# internal...
proc ::pwtk::latex::make_longtable {figList titleList infoList textList {npage 1} {ncol -1}} {
    variable cellOffset
 
    set nfig  [llength $figList]
    set nitem [llength [lindex $figList 0]]

    if { $ncol == -1 } {
	set ncol  [tabular $npage $nfig $nitem]
    }

    set width [expr 1.0/$ncol - $cellOffset]

    write_ {
	\begin{longtable}[t]{*{$ncol}{|c|}}
    }

    set ifile 0

    # create LaTeX longtable
    
    set icol 0
    foreach figGroup $figList title $titleList infoGroup $infoList text $textList {
	
	::pwtk::print "Processing figs: $figGroup"
	
	if { $icol == 0 } {
	    write_ {\hline}
	}
	
	write_ {\begin{minipage}[t]{$width\linewidth}}
	if { $title != "" } {
	    write_ {{\tiny\verb^${title}^}\\}
	}	        
	
	foreach fig $figGroup infoText $infoGroup {
	    if { $infoText != {} } {
		set infoText "$infoText\\\\"
	    }
	    write_ {$infoText 
		\includegraphics[width=1.0\textwidth]{$fig}}
	}	
	write_ {
	    \scriptsize
	    $text
	    \end{minipage}
	}  
	
	incr icol
	
	if { $icol < $ncol} {
	    write_ {&}
	} else {
	    write_ {
		\\
		    \hline}
	    set icol 0
	}	    
    }

    if { $icol != 0 } {
        for {set i $icol} {$i < $ncol-1} {incr i} {
            write_ {\begin{minipage}[t]{$width\linewidth}
                \end{minipage}
                &}
        }
        write_ {\begin{minipage}[t]{$width\linewidth}
            \end{minipage}
            \\
                    \hline
        }
    }

    write_ {\end{longtable}}
}
#******

proc ::pwtk::latex::verbatim_ {text} {   
    variable fid
    puts $fid $text
}

#****f* ::pwtk::latex/::pwtk::latex::text
# SYNOPSIS
proc ::pwtk::latex::text {text} {
    # PURPOSE
    #   Add a text to latex file.(this should be used prior to calling
    #   "tabulate").
    # ARGUMENTS
    # * text -- text to add to latex file
    # SOURCE
    
    variable content
    append content [list verbatim_ $text\n]
}
#******


#****f* ::pwtk::latex/::pwtk::latex::tabulateFigs
# SYNOPSIS
proc ::pwtk::latex::tabulateFigs {latexFile figList titleList infoList textList {npage 1} {ncol -1} {composite 0}} {
    # PURPOSE
    #   Tabulate figures into a LaTeX document.
    #
    # ARGUMENTS
    # * latexFile -- name of the resulting LaTeX file
    # * figList -- list of figures to tabulate

    # * titleList -- title for each figure (written above the figure),
    #                e.g., name of the I/O file from where the figure originates

    # * infoList -- info text for each figure (written above the figure),
    #               e.g., type of structure (initial|latest|optimized)

    # * textList -- text for each figure (written below the figure),
    #               e.g., a total energy
    
    # * npage -- (optional) on how many pages to arrange figures
    # * ncol  -- (optional) in how many tabular columns to arrange figures

    # * composite -- (optional) if true, do not write the LaTeX file
    #                but store the generated snippet into memory
    #                (typically used when tabulateFigs is called
    #                multiple times; the last time, tabulateFigs
    #                should be called with composite=false to write
    #                the LaTeX file)
    
    # TODO
    #   {npage 1} {ncol -1} {composite 0} arguments are not elegant, transform into options
    #
    # SOURCE

    
    variable fid
    variable content
    
    if { ! $composite } {
        set fid [open $latexFile w]
    
        make_head
        if { [info exists content] } {
            eval $content
            unset content
        }
        make_longtable $figList $titleList $infoList $textList $npage $ncol
        make_tail

        close $fid
    } else {        
        append content [list make_longtable "$figList" "$titleList" "$infoList" "$textList" $npage $ncol]\n
    }    
}
#******


# internal...
proc ::pwtk::latex::tabular {npage N {m 1}} {
    set n [expr round($N/$npage)]    
    set n [expr $n*$npage < $N ? $n + ($N-$n*$npage) : $n]

    set phi  [expr (1.0+sqrt(5.0))/2.0]
    set ncol [expr round(sqrt($m*$n/$phi))]
    set nrow [expr $n/$ncol < 1 ? 1 : $n/$ncol]

    set ncol [expr $nrow*$ncol < $n ? $ncol+1 : $ncol]
    #set nrow [expr $nrow*$ncol < $n ? $nrow+1 : $nrow]

    return $ncol
}
