 #
# $RCSfile: pwo.tcl,v $ --
#
#      This file contains the procs for handling the pw.x standard
#      output.
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: pwo.tcl,v 1.20 2021/05/07 13:18:12 tone Exp $ 
#


#
# SHORT-CUTS
#
proc ::pwtk::pwo_totene {file {index end}} { uplevel ::pwtk::pwo::totene $file $index }
proc ::pwtk::pwo_totfor {file {index end}} { uplevel ::pwtk::pwo::totfor $file $index } 
proc ::pwtk::pwo_totmag {file {index end}} { uplevel ::pwtk::pwo::totmag $file $index } 
proc ::pwtk::pwo_etot   {file {index end}} { uplevel ::pwtk::pwo::etot   $file $index }
proc ::pwtk::pwo_efermi {file {index end}} { uplevel ::pwtk::pwo::efermi $file $index }
proc ::pwtk::pwo_elumo  {file {index end}} { uplevel ::pwtk::pwo::elumo  $file $index }
proc ::pwtk::pwo_press  {file {index end}} { uplevel ::pwtk::pwo::press  $file $index }
proc ::pwtk::pwo_dipole {file {index end} {unit debye}} { uplevel ::pwtk::pwo::dipole $file $index $unit }

proc ::pwtk::pwo_ibrav {pwo {index end}}         { return [::pwtk::pwo::ibrav $pwo $index] }         
proc ::pwtk::pwo_alat {pwo {index end}}          { return [::pwtk::pwo::alat $pwo $index] }          
proc ::pwtk::pwo_volume {pwo {index end}}        { return [::pwtk::pwo::volume $pwo $index] }        
proc ::pwtk::pwo_nat {pwo {index end}}           { return [::pwtk::pwo::nat $pwo $index] }           
proc ::pwtk::pwo_ntyp {pwo {index end}}          { return [::pwtk::pwo::ntyp $pwo $index] }          
proc ::pwtk::pwo_nelec {pwo {index end}}         { return [::pwtk::pwo::nelec $pwo $index] }         
proc ::pwtk::pwo_nbnd {pwo {index end}}          { return [::pwtk::pwo::nbnd $pwo $index] }          
proc ::pwtk::pwo_ecutwfc {pwo {index end}}       { return [::pwtk::pwo::ecutwfc $pwo $index] }       
proc ::pwtk::pwo_ecutrho {pwo {index end}}       { return [::pwtk::pwo::ecutrho $pwo $index] }       
proc ::pwtk::pwo_conv_thr {pwo {index end}}      { return [::pwtk::pwo::conv_thr $pwo $index] }      
proc ::pwtk::pwo_mixing_beta {pwo {index end}}   { return [::pwtk::pwo::mixing_beta $pwo $index] }   
proc ::pwtk::pwo_etot_conv_thr {pwo {index end}} { return [::pwtk::pwo::etot_conv_thr $pwo $index] } 
proc ::pwtk::pwo_forc_conv_thr {pwo {index end}} { return [::pwtk::pwo::forc_conv_thr $pwo $index] } 
proc ::pwtk::pwo_xc {pwo {index end}}            { return [::pwtk::pwo::xc $pwo $index] }            
proc ::pwtk::pwo_crystal_axes {pwo {index end}}  { return [::pwtk::pwo::crystal_axes $pwo $index] }
proc ::pwtk::pwo_reciprocal_axes {pwo {index end}} {  return [::pwtk::pwo::reciprocal_axes $pwo $index] }


#------------------------------------------------------------------------


#****f* ::pwtk::pwo/::pwtk::pwo::ibrav
# SYNOPSIS
proc ::pwtk::pwo::ibrav {pwo {index end}} {
    # PURPOSE
    #   Get the "ibrav" value from the pw.x output file.
    # ARGUMENTS   
    # * pwo -- pw.x output file
    # * index -- for concatenated pw.x output file, which ibrav to return (first = 0, last = end)
    # SOURCE
    return [::pwtk::grep_field {bravais-lattice index     =} $pwo end $index]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::alat
# SYNOPSIS
proc ::pwtk::pwo::alat {pwo {index end}} {
    # PURPOSE
    #   Get the "alat" value (in bohr) from the pw.x output file.
    # ARGUMENTS
    #   See ::pwtk::pwo::ibrav
    # SOURCE

    #return [::pwtk::grep_field {lattice parameter (alat)  =} $pwo end-1 $index]

    # N.B. it is more "precise" to grep for 'celldm(1)=' than 'lattice parameter (alat)  ='    
    return [::pwtk::grep_field {     celldm(1)=} $pwo 1 $index]
    
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::volume
# SYNOPSIS
proc ::pwtk::pwo::volume {pwo {index end}} {
    # PURPOSE
    #   Get the "volume" value from the pw.x output file.
    # ARGUMENTS
    #   See ::pwtk::pwo::ibrav
    # SOURCE
    return [::pwtk::grep_field {unit-cell volume          =} $pwo end-1 $index]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::nat
# SYNOPSIS
proc ::pwtk::pwo::nat {pwo {index end}} {
    # PURPOSE
    #   Get the "nat" value (number of atoms) from the pw.x output file.
    # ARGUMENTS
    #   See ::pwtk::pwo::ibrav
    # SOURCE
    return [::pwtk::grep_field {number of atoms/cell      =} $pwo end $index]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::ntyp
# SYNOPSIS
proc ::pwtk::pwo::ntyp {pwo {index end}} {
    # PURPOSE
    #   Get the "ntyp" value (number of atomic types) from the pw.x output file.
    # ARGUMENTS
    #   See ::pwtk::pwo::ibrav
    # SOURCE
    return [::pwtk::grep_field {number of atomic types    =} $pwo end $index]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::nelec
# SYNOPSIS
proc ::pwtk::pwo::nelec {pwo {index end}} {
    # PURPOSE
    #   Get the "nelec" value (number of electrons) from the pw.x output file.
    # ARGUMENTS
    #   See ::pwtk::pwo::ibrav
    # SOURCE
    return [::pwtk::grep_field {number of electrons       =} $pwo 4 $index]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::nbnd
# SYNOPSIS
proc ::pwtk::pwo::nbnd {pwo {index end}} {
    # PURPOSE
    #   Get the "nbnd" value (number of Kohn-Sham states) from the pw.x output file.
    # ARGUMENTS
    #   See ::pwtk::pwo::ibrav
    # SOURCE
    return [::pwtk::grep_field {number of Kohn-Sham states=} $pwo end $index]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::ecutwfc
# SYNOPSIS
proc ::pwtk::pwo::ecutwfc {pwo {index end}} {
    # PURPOSE
    #   Get the "ecutwfc" value from the pw.x output file.
    # ARGUMENTS
    #   See ::pwtk::pwo::ibrav
    # SOURCE
    return [::pwtk::grep_field {kinetic-energy cutoff     =} $pwo end-1 $index]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::ecutrho
# SYNOPSIS
proc ::pwtk::pwo::ecutrho {pwo {index end}} {
    # PURPOSE
    #   Get the "ecutrho" value from the pw.x output file.
    # ARGUMENTS
    #   See ::pwtk::pwo::ibrav
    # SOURCE
    return [::pwtk::grep_field {charge density cutoff     =} $pwo end-1 $index]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::conv_thr
# SYNOPSIS
proc ::pwtk::pwo::conv_thr {pwo {index end}} {
    # PURPOSE
    #   Get the "conv_thr" value from the pw.x output file.
    # ARGUMENTS
    #   See ::pwtk::pwo::ibrav
    # SOURCE
    return [::pwtk::grep_field {scf convergence threshold =} $pwo end $index]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::mixing_beta
# SYNOPSIS
proc ::pwtk::pwo::mixing_beta {pwo {index end}} {
    # PURPOSE
    #   Get the "mixing_beta" value from the pw.x output file.
    # ARGUMENTS
    #   See ::pwtk::pwo::ibrav
    # SOURCE
    return [::pwtk::grep_field {mixing beta               =} $pwo end $index]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::etot_conv_thr
# SYNOPSIS
proc ::pwtk::pwo::etot_conv_thr {pwo {index end}} {
    # PURPOSE
    #   Get the "etot_conv_thr" value from the pw.x output file.
    # ARGUMENTS
    #   See ::pwtk::pwo::ibrav
    # SOURCE
    return [::pwtk::grep_field {energy convergence thresh.=} $pwo end $index]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::forc_conv_thr
# SYNOPSIS
proc ::pwtk::pwo::forc_conv_thr {pwo {index end}} {
    # PURPOSE
    #   Get the "forc_conv_thr" value from the pw.x output file.
    # ARGUMENTS
    #   See ::pwtk::pwo::ibrav
    # SOURCE
    return [::pwtk::grep_field {force convergence thresh. =} $pwo end $index]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::xc
# SYNOPSIS
proc ::pwtk::pwo::xc {pwo {index end}} {
    # PURPOSE
    #   Get the exchange-correlation functional name from the pw.x output file.
    # ARGUMENTS
    #   See ::pwtk::pwo::ibrav
    # SOURCE
    return [lrange [::pwtk::grep {Exchange-correlation=} $pwo end] 1 end]
}
#******



#****f* ::pwtk::pwo/::pwtk::pwo::totene
# SYNOPSIS
proc ::pwtk::pwo::totene {file {index end}} {
    # PURPOSE
    #   Extract an index-th converged total-energy from pw.x output;
    #   the converged energy is the one having the "!" as the first
    #   line character. Index can be "end" or digital number (first
    #   energy has an index of 0).
    #
    # ARGUMENTS
    #   * file -- name of the pw.x output file
    #   * index -- which energy (optional), default = end
    # SOURCE

    pwtk::lineread line $file {
	if { [regexp {^!} $line] } {
	    lappend eneList [lindex $line 4]
	}
    }
    if { ! [info exists eneList] } {
	::pwtk::error "no ^! (i.e. total energy) line found in output file: $file"
        set eneList {}
    }
    return [lindex $eneList $index]
}
#****

#****f* ::pwtk::pwo/::pwtk::pwo::etot
# SYNOPSIS
proc ::pwtk::pwo::etot {file {index end}} {
    # PURPOSE
    #   Extract an index-th total-energy from SCF's pw.x output (it greps
    #   the "total energy" string). Index can be "end" or digital
    #   number (first energy has an index of 0).
    #
    # ARGUMENTS
    #   * file -- name of the pw.x output file
    #   * index -- which energy (optional), default = end
    # SOURCE

    pwtk::lineread line $file {
	if { [regexp {^ +total energy} $line] } {
	    lappend eneList [lindex $line 3]
	}
    }
    if { ! [info exists eneList] } {
	::pwtk::error "no \"total energy\" line found in output file: $file"
        set eneList {}
    }
    return [lindex $eneList $index]
}
#****

#****f* ::pwtk::pwo/::pwtk::pwo::scferr
# SYNOPSIS
proc ::pwtk::pwo::scferr {file {index end}} {
    # PURPOSE
    #   Extract the index-th "estimated scf accuracy" from SCF's pw.x
    #   output (i.e., grep the "estimated scf accuracy" string). Index
    #   can be "end" or digital number (first energy has an index of
    #   0).
    #
    # ARGUMENTS
    #   * file -- name of the pw.x output file
    #   * index -- which energy (optional), default = end
    # SOURCE

    pwtk::lineread line $file {
	if { [regexp {^ +estimated scf accuracy} $line] } {
	    lappend errList [lindex $line 4]
	}
    }
    if { ! [info exists errList] } {
	::pwtk::error "no \"estimated scf accuracy\" line found in output file: $file"
        set errList {}
    }
    return [::pwtk::f2c_number [lindex $errList $index]]
}
#****


#****f* ::pwtk::pwo/::pwtk::pwo::toteneLine
# SYNOPSIS
proc ::pwtk::pwo::toteneLine {file {index end}} {
    # PURPOSE
    #   Extract an index-th total-energy line from PW-output. Index can
    #   be "end", or digital number (first energy has an index of 0).
    # ARGUMENTS
    #   * file -- name of the pw.x output file
    #   * index -- which energy-line (optional), default = end
    # SOURCE

    pwtk::lineread line $file {
	if { [regexp {^!} $line] } {
	    lappend eneLineList $line
	}
    }
    if { ! [info exists eneLineList] } {
	::pwtk::error "no ^! (i.e. total energy) line found in output file: $file"
        set eneLineList {}
    }
    return [lindex $eneLineList $index]
}
#****


#****f* ::pwtk::pwo/::pwtk::pwo::totfor
# SYNOPSIS
proc ::pwtk::pwo::totfor {file {index end}} {
    # PURPOSE
    #   Extract the index-th total-force from PW-output. Index can be
    #   "end" or digital number (first total force has an  index of 0).
    # ARGUMENTS
    #   * file -- name of the pw.x output file
    #   * index -- which total force (optional), default = end
    # SOURCE

    pwtk::lineread line $file {
	if { [string match {*Total force*} $line] } {
	    lappend forList [lindex $line 3]
	}
    }
    if { ! [info exists forList] } {
	::pwtk::error "no *Total force* line found in output file: $file"
        set forList {}
    }
    return [lindex $forList $index]
}
#****


#****f* ::pwtk::pwo/::pwtk::pwo::totforLine
# SYNOPSIS
proc ::pwtk::pwo::totforLine {file {index end}} {
    # PURPOSE
    #   Extract the index-th total-force file from PW-output. Index can be
    #   "end" or digital number (first total force has an index of 0).
    # ARGUMENTS
    #   * file -- name of the pw.x output file
    #   * index -- which total force-line (optional), default = end
    # SOURCE

    pwtk::lineread line $file {
	if { [string match {*Total force*} $line] } {
	    lappend forLineList $line
	}
    }
    if { ! [info exists forLineList] } {
	::pwtk::error "no *Total force* line found in output file: $file"
        set forLineList {}
    }
    return [lindex $forLineList $index]
}
#****


#****f* ::pwtk::pwo/::pwtk::pwo::totmag
# SYNOPSIS
proc ::pwtk::pwo::totmag {file {index end}} {
    # PURPOSE
    #   Extract the index-th total-magnetization from PW-output. Index can be
    #   "end" or digital number (first total magnetization has an  index of 0).
    # ARGUMENTS
    #   * file -- name of the pw.x output file
    #   * index -- which total magnetization (optional), default = end
    # SOURCE

    pwtk::lineread line $file {
	if { [string match {*total magnetization*} $line] } {
	    lappend magList [lindex $line 3]
	}
    }
    if { ! [info exists magList] } {
	::pwtk::error "no *total magnetization* line found in output file: $file"
        set magList {}
    }
    return [lindex $magList $index]
}
#****


#****f* ::pwtk::pwo/::pwtk::pwo::press
# SYNOPSIS
proc ::pwtk::pwo::press {file {index end}} {
    # PURPOSE
    #   Extract an index-th pressure from the pw.x output. Index can
    #   be "end" or digital number (first pressure has an index of 0).
    # ARGUMENTS
    #   * file -- name of the pw.x output file
    #   * index -- which pressure (optional), default = end
    # SOURCE

    pwtk::lineread line $file {
	if { [string match {*(kbar)     P=*} $line] } {	    
	    lappend pressList [string trim [lindex $line end] P=]
	}
    }
    if { ! [info exists pressList] } {
	::pwtk::error "no presure found in output file: $file"
        set pressList {}
    }
    return [lindex $pressList $index]
}
#****

#****f* ::pwtk::pwo/::pwtk::pwo::efermi
# SYNOPSIS
proc ::pwtk::pwo::efermi {file {index end}} {
    # PURPOSE
    #   Extract index-th Fermi energy (or the highest occupied level)
    #   from the pw.x output file. Index can be "end" or digital
    #   number (first energy has an index of 0).
    #
    # ARGUMENTS
    #   * file -- name of the pw.x output file
    #   * index -- which energy (optional), default = end
    # SOURCE

    pwtk::lineread line $file {
	if { [regexp {highest occupied level} $line] } {
            
            lappend efList [lindex $line end]
            
	} elseif { [regexp {highest occupied, lowest unoccupied level} $line] } {
            
            lappend efList [lindex $line end-1]
            
        } elseif { [regexp {Fermi energy is} $line] } {
            
            lappend efList [lindex $line end-1]
        }
    }
    
    if { ! [info exists efList] } {
	::pwtk::error "no Fermi energy or highest occupied level line found in output file: $file"
        set efList {}
    }
    return [lindex $efList $index]
}
#****


#****f* ::pwtk::pwo/::pwtk::pwo::elumo
# SYNOPSIS
proc ::pwtk::pwo::elumo {file {index end}} {
    # PURPOSE
    #   Extract index-th lowest unoccupied level from the pw.x output file.
    #   Index can be "end" or digital number (first energy has an index of 0).
    #
    # ARGUMENTS
    #   * file -- name of the pw.x output file
    #   * index -- which energy (optional), default = end
    #
    # RETURN VALUE
    # * if found, value of the lowest unoccupied level
    # * otherwise, empty string
    #
    # SOURCE

    set elList {}
    pwtk::lineread line $file {
	if { [regexp {highest occupied, lowest unoccupied level} $line] } {
            lappend elList [lindex $line end]
        }
    }
    return [lindex $elList $index]
}
#****


# #****f* ::pwtk::pwo/::pwtk::pwo::alat
# # SYNOPSIS
# proc ::pwtk::pwo::alat {file} {    
#     # PURPOSE
#     #   Get the alat value from the pw.x output file.  
#     #
#     #   The proc searches for the "lattice parameter (alat)  =" printout
#     #   line in the initial pw.x printout header.    
#     # ARGUMENTS    
#     #   * file -- name of the pw.x output file 
#     # SOURCE
# 
#     set string_old {*lattice parameter (a_0)   =*}
#     set string_new {*lattice parameter (alat)  =*}
# 
#     pwtk::lineread line $file {
# 
# 	set match_old [string match $string_old $line]
# 	set match_new [string match $string_new $line]
# 
# 	if { $match_old || $match_new } {
# 	    return [lindex $line 4]
# 	}
#     }
#     return 1.0
# }
# #******


#****f* ::pwtk::pwo/::pwtk::pwo::dipole
# SYNOPSIS
proc ::pwtk::pwo::dipole {file {index end} {unit debye}} {
    # PURPOSE
    #   Extract an index-th dipole from pw.x output that is printed
    #   when tefield = .true.; Index can be "end" or digital number
    #   (first reported dipole in the output has an index of 0).   
    # ARGUMENTS
    #   * file -- name of the pw.x output file
    #   * index -- [optional] which dipole (optional), default = end
    #   * unit  -- [optional] unit of reported dipole (debye or au, where au = "Ry au"), default = debye
    #
    # SOURCE

    pwtk::lineread line $file {
	if { [regexp {    Dipole     } $line] } {
	    switch -nocase $unit {
		debye {
		    # report Dipole in Debye units
		    lappend dipList [lindex $line 4]
		}
		default {
		    # report dipole in Ry au units
		    lappend dipList [lindex $line 1]
		}
	    }
	}
    }
    if { ! [info exists dipList] } {
	::pwtk::error "no \"    Dipole     \" string found in output file: $file"
        set dipList {}
    }
    return [lindex $dipList $index]
}
#****


#****f* ::pwtk::pwo/::pwtk::pwo::crystal_axes
# SYNOPSIS
proc ::pwtk::pwo::crystal_axes {pwo {index end}} {
    # PURPOSE
    #   Return the crystal axes from the pw.x output file, taken from the
    #   following record:
    #
    #         crystal axes: (cart. coord. in units of alat)
    #               a(1) = (  -0.500000   0.000000   0.500000 )  
    #               a(2) = (   0.000000   0.500000   0.500000 )  
    #               a(3) = (  -0.500000   0.500000   0.000000 )  
    # ARGUMENTS   
    # * pwo -- pw.x output file
    # * index -- for concatenated pw.x output file, which crystal axes to return (first = 0, last = end)
    #
    # RETURN VALUE
    # * crystal axes in the following form:
    #
    #      a1x a1y a1z
    #      a2x a2y a2z
    #      a3x a3y a3z
    #
    # SOURCE

    ::pwtk::fileMustExist $pwo "pw.x output"

    set result {}
    set fid [open $pwo r]
    while { ! [eof $fid] } {
        gets $fid line
        if { [regexp {^ +crystal axes: \(cart. coord. in units of alat\)} $line] } {
            set v1 [lindex [split [gets $fid] ()] 3]
            set v2 [lindex [split [gets $fid] ()] 3]
            set v3 [lindex [split [gets $fid] ()] 3]
            lappend result $v1\n$v2\n$v3
        }
    }
    close $fid
    return [lindex $result $index]
}
#******


#****f* ::pwtk::pwo/::pwtk::pwo::reciprocal_axes
# SYNOPSIS
proc ::pwtk::pwo::reciprocal_axes {pwo {index end}} {
    # PURPOSE
    #   Return the reciprocal axes from the pw.x output file, taken from the
    #   following record:
    #
    #     reciprocal axes: (cart. coord. in units 2 pi/alat)
    #               b(1) = ( -1.000000 -1.000000  1.000000 )  
    #               b(2) = (  1.000000  1.000000  1.000000 )  
    #               b(3) = ( -1.000000  1.000000 -1.000000 )
    #
    # ARGUMENTS   
    # * pwo -- pw.x output file
    # * index -- for concatenated pw.x output file, which reciprocal axes to return (first = 0, last = end)
    #
    # RETURN VALUE
    # * reciprocal axes in the following form:
    #
    #      b1x b1y b1z
    #      b2x b2y b2z
    #      b3x b3y b3z
    #
    # SOURCE

    ::pwtk::fileMustExist $pwo "pw.x output"

    set result {}
    set fid [open $pwo r]
    while { ! [eof $fid] } {
        gets $fid line
        if { [regexp {^ +reciprocal axes: \(cart. coord. in units 2 pi/alat\)} $line] } {
            set v1 [lindex [split [gets $fid] ()] 3]
            set v2 [lindex [split [gets $fid] ()] 3]
            set v3 [lindex [split [gets $fid] ()] 3]
            lappend result $v1\n$v2\n$v3
        }
    }
    close $fid
    return [lindex $result $index]
}
#******



#****f* ::pwtk::pwo/::pwtk::pwo::job_done
# SYNOPSIS
proc ::pwtk::pwo::job_done {file} {
    # PURPOSE
    #   Check if a given pw.x output-file corresponds to normally
    #   finished job (it searches for "JOB DONE." string). It returns
    #   1 if this string is found, and zero otherwise. Note that this
    #   proc returns 1 even if "Program stopped by user request".
    #
    # ARGUMENTS
    # * file -- name of the pw.x output file 
    # SOURCE

    ::pwtk::deprecated "[::pwtk::procName] is deprecated, use ::pwtk::job_done instead"
    return [::pwtk::job_done $file]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::bfgs_converged
# SYNOPSIS
proc ::pwtk::pwo::bfgs_converged {file} {
    # PURPOSE  
    #   Check if BFGS has converged in a given pw.x output-file. It
    #   searches for "End of BFGS Geometry Optimization" string. It
    #   returns 1 if this string is found, and zero otherwise.
    # ARGUMENTS    
    # * file -- name of pw.x output file    
    # SOURCE

    if { ! [file exists $file] } {
	return 0
    }

    set result 0
    set bfgs_conv 0
    pwtk::lineread line $file {
	if { [string match {*bfgs converged*} $line] } {
	    set bfgs_conv 1
	}
	if { [string match {*End of BFGS Geometry Optimization*} $line] } {
	    set result 1
	}
    }
    return [expr $result && $bfgs_conv]
}
#******


proc ::pwtk::pwo::checkForError {pwoFile {_stopOnError 0}} {
    # BEWARE
    #   This routine is obsolete, use ::pwtk::checkForError instead.

    pwtk::deprecated "::pwtk::pwo::checkForError is OBSOLETE; use ::pwtk::checkForError pw.x ... instead"
    ::pwtk::checkForError $pwoFile pw.x $_stopOnError
}


#****f* ::pwtk::pwo/::pwtk::pwo::tabulateStructs
# SYNOPSIS
proc ::pwtk::pwo::tabulateStructs {args} {
    #
    # USAGE
    # ::pwtk::pwo::tabulateStructs  [options]  latexFile  pwoFileList  xcrysdenScriptList
    #
    # Options are:
    #    -ic
    #    -lc
    #    -ilc
    #    -xcd 0|1|2
    #    -reduce 2|1|0
    #    -ncol  <value>
    #    -npage <value>
    #    -E0  <value>
    #    -E0fmt <value>
    #    -Elabel <value>
    #    -landscape
    #    -composite
    #    -noinfo
    #
    #
    # PURPOSE
    #    Plot with xcrysden the structures from the supplied list of
    #    pw.x output files ($pwoFileList) and arrange them into a table
    #    in LaTeX document ($latexFile).
    #
    #    To instruct xcrysden how to plot each structure, user has to
    #    provide at least one xcrysden script (i.e., the state-part of
    #    *.xcrysden file). If user supllies more then one xcrysden
    #    script ($xcrysdenScriptList), each structure will be plotted
    #    several times, i.e., once with each supplied xcrysden script
    #    file.
    #        
    # OPTIONS
    #    * -ic -- plot only the initial structure from each pw.x output file
    #    * -lc -- plot only the latest structure from each pw.x output file
    #    * -ilc -- plot initial and latest strutcures from each pw.x output file
    #    * -xcd 0|1|2 -- execute xcrysden (0 = never, 1 = always, 2 = only if the respective picture does not yet exist)
    #    * -reduce 0|1|2 -- reduce the periodic dimensionality of the structure (i.e. xcrysden's "-r" option)
    #    * -ncol <value> -- arrange snapshots into ncol columns in the LaTeX table
    #    * -npage <value> -- hint of how many pages the LaTeX table should span
    #    * -E0 <value> -- reference energy; if suplied the the Delta-E = E - E0 will be reported for each structure
    #    * -E0fmt <value> -- format specified for \Delta E printout (default = %.4f)
    #    * -Elabel <value> -- label to appear for the Delta-E in LaTeX table (in LaTeX syntax)
    #    * -landscape -- use landscape paper orientation in the resulting document
    #    * -composite --composite mode:  do not dump the latex file, because tabulateStructs will be called again for this latex file
    #    * -noinfo -- do not print the status info & total energy
    #
    # ARGUMENTS
    #    * latexFile -- name of latex file to tabulate the structure
    #    * pwoFileList -- list of pw.x output files
    #    * xcrysdenScriptList -- list of xcrysden script files
    #
    # SOURCE

    # parse args

    ::pwtk::printTitle TABULATE "tabulation of pw.x output files (::pwtk::pwo::tabulateStructs)"

    set options {
	{ic                     "extract initial structure"}
	{lc                     "extract the latest structure"}
	{ilc                    "extraxt initial and the latest structure"}
	{xcd.arg      1         "do we run xcrysden to make figures"}
	{reduce.arg   3         "reduce the dimensionality of structure"}
	{ncol.arg    -1         "number of columns (-1 means automatically determined)"}
	{npage.arg    1         "number of pages the table will span (estimate only)"}
	{E0.arg       0.0       "reference-energy for \Delta E calculation"}
        {E0fmt.arg    %.4f      "format specified for \Delta E printout (default = %.4f)"}
	{Elabel.arg  {\Delta E} "energy label of for \Delta E calculation"}
	{landscape              "landscape paper orientation"}
        {composite              "composite mode:  do not dump the latex file, because tabulateStructs will be called again for this latex file"}
        {noinfo                 "do not print the status info & total energy"}
    }
    array set opt [::cmdline::getoptions args $options [list [lindex [info level 0] 0] options:]]    

    lassign $args latexFile pwoFileList xcrysScriptList

    ::pwtk::xcd::runScript $opt(xcd)
    
    if { $opt(landscape) } {
	::pwtk::latex::landscape
    }

    # make structure figures

    if { $opt(ilc) } {
	set which ilc
    } elseif { $opt(lc) } {
	set which lc
	set type  latest
    } elseif { $opt(ic) } {
	set which ic
	set type  initial
    } else {
	set which lc
	set type  latest
    }

    switch -exact $which {
	ic - lc {
	    pwtk::xcd::scriptHead "scripting::filter::pwscfOutput -$which \$structureFile \$reduce"
	    set figList [::pwtk::xcd::makeFigs $pwoFileList $xcrysScriptList $which $opt(reduce)]
	    foreach fig $figList {
		if { $opt(noinfo) } {
                    lappend infoList {}
                } else {
                    lappend infoList [list [list $type structure]]
                }
	    }
	}

	ilc {
	    # initial structures

	    pwtk::xcd::scriptHead { 
		scripting::filter::pwscfOutput -ic $structureFile $reduce 
	    }
	    set figList1 [::pwtk::xcd::makeFigs $pwoFileList $xcrysScriptList ic $opt(reduce)]

	    # latest structures

	    pwtk::xcd::scriptHead { 
		scripting::filter::pwscfOutput -lc $structureFile $reduce 
	    }
	    set figList2 [::pwtk::xcd::makeFigs $pwoFileList $xcrysScriptList lc $opt(reduce)]
	    
	    # make a proper figList

	    foreach figG1 $figList1 figG2 $figList2 {
		lappend figList  [concat $figG1 $figG2]
		lappend infoList [ilc_infoText_ "initial structure" $figG1 "latest structure" $figG2]
	    }
	}
    }

    # make titles and calculated energies ...

    foreach file $pwoFileList {

	# title
	set prefix [file rootname [file tail $file]]
	if { $opt(noinfo) } {
            lappend titleList {}
        } else {
            lappend titleList $prefix
        }
	
	# calculate energies

        set Etot [format %.6f [::pwtk::pwo::totene $file end]]

	# is job already converged

	if { [::pwtk::job_done $file] } {
	    set status "Status: job done"
	} else {
	    set status "Status: unfinished"
	}

        if { $opt(E0) != 0.0 } {

	    set deltaE [format $opt(E0fmt) [expr ($Etot - $opt(E0)) * $::pwtk::ry2ev]]

            if { $opt(noinfo) } {
                lappend textList [subst -nocommands -nobackslashes {
                    \ensuremath{$opt(Elabel)}=\ensuremath{$deltaE} eV
                    \vspace{0.5em}
                }]
            } else {
                lappend textList [subst -nocommands -nobackslashes {
                    \ensuremath{E_{\rm tot}}=\ensuremath{$Etot} ryd\\
                        \ensuremath{$opt(Elabel)}=\ensuremath{$deltaE} eV\\
                        {\footnotesize $status}\\
                    }]
            }
	} else {
            if { $opt(noinfo) } {
                lappend textList [subst -nocommands -nobackslashes {
                    \vspace{0.5em}
                }]
            } else {
                lappend textList [subst -nocommands -nobackslashes {
                    \ensuremath{E_{\rm tot}}=\ensuremath{$Etot} ryd\\
                        {\footnotesize $status}\\
                    }]
            }
	}
    }

    # puts all figures into latex longtable and write corresponding LaTeX file

    ::pwtk::latex::tabulateFigs $latexFile $figList $titleList $infoList $textList $opt(npage) $opt(ncol) $opt(composite)
        
    if { ! $opt(composite) } {
        ::pwtk::print "
LaTeX file written to: $latexFile
To compile the generated LaTeX file, execute:   

      pdflatex $latexFile
"
    }
}
#******


#****f* ::pwtk::pwo/::pwtk::pwo::sortFiles
# SYNOPSIS
proc ::pwtk::pwo::sortFiles {args} {    
    # USAGE
    #    ::pwtk::pwo::sortFiles [-by energy|force|totmag|press|dipole|COMMAND] [-increasing|-decreasing]  filePattern  ?filePattern ...?
    #
    # PURPOSE
    #   Return a sorted list of pw.x output files according to the specified criterion.
    #
    # OPTIONS
    # * -by CRITERIA ... by which criterion to sort (possibilities are energy, force, press, dipole, or user supplied COMMAND; defualt = energy);
    #                    COMMAND specified with the -by option must be of the form analogous to ::pwtk::pwo::totene
    # * -increasing  ... sort in increasing order
    # * -decreasing  ... sort in decreasing order
    #
    # The user COMMAND command specified by the -by option must be of the form analogous to ::pwtk::pwo::totene
    #   
    # ARGUMENTS
    # * filePattern ... a glob-style pattern for pw.x output files; it can also be a list of files
    #
    # SOURCE

    set result {}
    foreach pwo_value [eval ::pwtk::pwo::listing $args] {
        lappend result [lindex $pwo_value 0]
    }
    return $result
}
#******


#****f* ::pwtk::pwo/::pwtk::pwo::listingPrint
# SYNOPSIS
proc ::pwtk::pwo::listingPrint {args} {
    # USAGE
    #    ::pwtk::pwo::listingPrint [-by energy|force|totmag|press|dipole|COMMAND] [-increasing|-decreasing]  filePattern  ?filePattern ...?
    #
    # PURPOSE
    #   Print to stdout a sorted listing based on the pw.x output
    #   files, where each reported line consists of the output
    #   filename and the value extracted from the output file via the
    #   -by option, which is the criterion used for sorting.
    #
    # EXAMPLE
    #   The command:
    #
    #      ::pwtk::pwo::listingPrint -by energy -increasing relax.*out
    #
    #   prints to stdout:
    #
    #      relax.rot_X-35_Z-40.out                    -229.09690231
    #      relax.rot_X-35_Z40.out                     -229.09687168
    #      relax.rot_X-35_Z35.out                     -229.09664108
    #      relax.rot_X-35_Z-45.out                    -229.09628525
    #      relax.rot_X-35_Z45.out                     -229.09617450
    #      ....                                       ...
    #
    #   where the numbers correspond to total energies.
    #
    # OPTIONS
    # * -by CRITERIA ... by which criterion to sort (possibilities are energy, force, press, dipole, or user supplied COMMAND; defualt = energy);
    #                    COMMAND specified with the -by option must be of the form analogous to ::pwtk::pwo::totene
    # * -increasing  ... sort in increasing order
    # * -decreasing  ... sort in decreasing order
    #
    # The user COMMAND command specified by the -by option must be of the form analogous to ::pwtk::pwo::totene
    #   
    # ARGUMENTS
    # * filePattern ... a glob-style pattern for pw.x output files; it can also be a list of files
    #
    # SOURCE

    foreach pwo_value [eval ::pwtk::pwo::listing $args] {
        lassign $pwo_value pwo value
        ::pwtk::print [format "%-40s   %s" $pwo $value]
    }
}
#******


#****f* ::pwtk::pwo/::pwtk::pwo::listing
# SYNOPSIS
proc ::pwtk::pwo::listing {args} {
    # USAGE
    #    ::pwtk::pwo::listing [-by energy|force|totmag|press|dipole|COMMAND] [-increasing|-decreasing]  filePattern  ?filePattern ...?
    #
    # PURPOSE
    #   Return a sorted list, where each list element is a pair of
    #   output pw.x filename and the corresponding value extracted
    #   from the output file via the -by option, which is the
    #   criterion used for sorting.
    #
    # EXAMPLE
    #   The command:
    #
    #      ::pwtk::pwo::listing -by energy -increasing relax.*out
    #
    #   returns:
    #
    #      {relax.rot_X-35_Z-40.out -229.09690231} {relax.rot_X-35_Z40.out -229.09687168} {relax.rot_X-35_Z35.out -229.09664108} ...
    #
    #   where the numbers correspond to total energies.
    #
    # OPTIONS
    # * -by CRITERIA ... by which criterion to sort (possibilities are energy, force, press, dipole, or user supplied COMMAND; defualt = energy);
    #                    COMMAND specified with the -by option must be of the form analogous to ::pwtk::pwo::totene
    # * -increasing  ... sort in increasing order
    # * -decreasing  ... sort in decreasing order
    #
    # The user COMMAND command specified by the -by option must be of the form analogous to ::pwtk::pwo::totene
    #   
    # ARGUMENTS
    # * filePattern ... a glob-style pattern for pw.x output files; it can also be a list of files
    #
    # SOURCE

    set options {
        {by.arg      energy  "criteria for sorting, allowed values are energy, force, totmag, press, dipole, or COMMAND"}
	{increasing          "sort in increasing order"}
	{decreasing          "sort in decreasing order"}
    }
    set usage ":   pwtk::pwo::sortFiles \[-by energy|force|press|dipole] \[-increasing|-decreasing] filelist"

    array set opt [::cmdline::getoptions args $options $usage]
    
    set sort increasing
    if { $opt(increasing) && $opt(decreasing) } {
        ::pwtk::error "both -increasing and -decreasing option specified, please use only one" 1
    } elseif { $opt(decreasing) } {
        set sort decreasing
    }    

    switch -glob -- $opt(by) {
        ene* { set cmd ::pwtk::pwo::totene }
        for* { set cmd ::pwtk::pwo::totfor }
        totmag -
        mag* { set cmd ::pwtk::pwo::totmag }
        pre* { set cmd ::pwtk::pwo::press }
        dip* { set cmd ::pwtk::pwo::dipole }
        default {
            if { [info command $opt(by)] eq {} } {
                ::pwtk::error "the \"$opt(by)\" command specified with the -by option does not exist" 1
            }
            set cmd $opt(by)
        }
    }
        
    if { [llength $args] == 1 } {
        set args {*}$args
    }
    set unsorted {}
    # construct and sort the "value pwo" list
    foreach pattern $args {
        foreach pwo [glob -nocomplain $pattern] {
            lappend unsorted [list $pwo [$cmd $pwo]]
        }
    }
    return [lsort -real -index 1 -$sort $unsorted]
}
#****

# ------------------------------------------------------------------------


proc ::pwtk::pwo::ilc_infoText_ {info1 figG1 info2 figG2} {    
    foreach fig $figG1 {
	lappend result $info1
	set info1 {}
    }
    foreach fig $figG2 {
	lappend result $info2
	set info2 {}
    }
    return $result
}
