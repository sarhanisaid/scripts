#
# $RCSfile: dmi.tcl,v $ --
#
#      This file contains the procs for handling the dynmat.x input.
#
# Copyright (c) 2017  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: dmi.tcl,v 1.3 2021/05/03 14:21:08 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::dmi_fprint {{file {}}} { uplevel ::pwtk::dmi::fprint $file }
proc ::pwtk::dmi_clear  {}          { uplevel ::pwtk::dmi::clear }
proc ::pwtk::dmi_get    {}          { uplevel ::pwtk::dmi::get }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::dmi/::pwtk::dmi::fprint
# SYNOPSIS
proc ::pwtk::dmi::fprint {{file {}}} {
# PURPOSE
#   Print the content of dynmat.x input data to a file or to stdout if the
#   file was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::dmi $file
}
#****


#****f* ::pwtk::dmi/::pwtk::dmi::get
# SYNOPSIS
proc ::pwtk::dmi::get {} {
    # DESCRIPTION    
    #   Return the content of the dynmat input 
    # SOURCE

    loadDefaults_

    # dynmat.x uses INPUT namelist, but this name is too generic,
    # hence pwtk uses DYNMAT instead, hence we need to substitute the
    # DYNMAT string with INPUT

    return [regsub -- {\&DYNMAT} [::pwtk::input::namelistGet DYNMAT] {\&INPUT}]
}
#******


#****f* ::pwtk::dmi/::pwtk::dmi::clear
# SYNOPSIS
proc ::pwtk::dmi::clear {} {
    # PURPOSE
    #   Clear the stored matdyn.x input data.
    # SOURCE
    variable input_flow_list
    
    foreach name $input_flow_list {
	::pwtk::input::clear $name
    }
}
#****

proc ::pwtk::dmi::loadDefaults_ {} {
    # load some default values, when user has omitted them 

    namespace eval ::pwtk::input {
        defaultVarValue_ DYNMAT fildyn  ""
    }
}


#****f* ::pwtk::dmi/::pwtk::dmi::load_fromDMI
# SYNOPSIS
proc ::pwtk::dmi::load_fromDMI {dmi {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing dynmat.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * dmi -- filename of the dynmat.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?
    #
    # SOURCE

    ::pwtk::fileMustExist $dmi "dynmat.x input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current dynmat.x input data ...
	::pwtk::input::clear DYNMAT
    }

    # read the namelists & replace INPUT with DYNMAT

    set output [regsub INPUT \
                    [::pwtk::readNamelists $dmi INPUT] DYNMAT]
                
    # dynmat.x must contain an INPUT namelist
    if { $output == "" } {
	::pwtk::error "input file \"$dmi\" does not appear to be a dynmat.x input file" 1
    }
    
    eval $output
    variable input_flow_list
    ::pwtk::input::namelists_ityp2atmSymb_ $input_flow_list
}
#******
