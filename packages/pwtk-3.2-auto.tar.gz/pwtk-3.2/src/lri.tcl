#
# $RCSfile: lri.tcl,v $ --
#
#      This file contains a few "parent" procs for handling the LR
#      inputs (i.e. inputs for turbo_***.x set of programs).
#
# Copyright (c) 2021  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: lri.tcl,v 1.2 2021/05/03 14:21:08 tone Exp $ 
#

proc ::pwtk::lri::loadDefaults_ {} {
    namespace eval ::pwtk::input {
        # load some default values, when user has omitted them
        defaultVarValue_ LR_INPUT prefix  ""
        defaultVarValue_ LR_INPUT outdir [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
        defaultVarValue_ LR_INPUT wfcdir [::pwtk::getDir_ QEdir(ESPRESSO_WFCDIR)]
    }
}

proc ::pwtk::lri::load_from_input_ {prog namelist_flow_list inFile clear_existing} {

    ::pwtk::fileMustExist $inFile "$prog input"

    # check if program is OK
    if { ! [info exists ::pwtk::prog2inNN($prog)] } {
        ::pwtk::error "unsupported program $prog" 1
    }
    upvar $::pwtk::prog2inNN($prog)::input_flow_list flow_list
    
    if { [::pwtk::is_true $clear_existing] } {
	# clear the current ${ns} input data ...
        ::pwtk::input::clear {*}$flow_list
    }

    # read the namelists
    set output [::pwtk::readNamelists $inFile $flow_list]

    # input file must contain at least one namelist 
    if { $output == "" } {
	::pwtk::error "input file \"$inFile\" does not appear to be a $prog input file" 1
    }

    eval $output
    ::pwtk::input::namelists_ityp2atmSymb_ $flow_list
}
#******
    
