#
# $RCSfile: ppi.tcl,v $ --
#
#      This file contains the procs for handling the pp.x input.
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: ppi.tcl,v 1.9 2021/05/03 14:21:08 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::ppi_fprint {{file {}}} { uplevel ::pwtk::ppi::fprint $file }
proc ::pwtk::ppi_clear  {}          { uplevel ::pwtk::ppi::clear }
proc ::pwtk::ppi_get    {}          { uplevel ::pwtk::ppi::get }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------


#****f* ::pwtk::ppi/::pwtk::ppi::fprint
# SYNOPSIS
proc ::pwtk::ppi::fprint {{file {}}} {
# PURPOSE
#   Print the content of pp.x input data to a file or to stdout if the
#   file was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::ppi $file
}
#****


#****f* ::pwtk::ppi/::pwtk::ppi::get
# SYNOPSIS
proc ::pwtk::ppi::get {} {
    # PURPOSE
    #   Return the content of the pp.x input file.
    # SOURCE
    loadDefaults_
    
    set inputpp_ [::pwtk::input::namelistGet INPUTPP]
    set plot_    [::pwtk::input::namelistGet PLOT]

    # INPUTPP namelist must be always present (even if empty)
    if { $inputpp_ == {} } {
	set inputpp_ " &INPUTPP
 /"
    }
    
    return "$inputpp_\n$plot_"
}
#****
    
#****f* ::pwtk::ppi/::pwtk::ppi::clear
# SYNOPSIS
proc ::pwtk::ppi::clear {} {
    # PURPOSE
    #   Clear the content of the pp.x input.
    # SOURCE
    variable input_flow_list
    
    foreach name $input_flow_list {
	::pwtk::input::clear $name
    }
}
#****
    

proc ::pwtk::ppi::loadDefaults_ {} {
    # load some default values, when user has omitted them 

    namespace eval ::pwtk::input {
	defaultVarValue_ INPUTPP outdir  [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
	defaultVarValue_ INPUTPP prefix  ""

	set prefix [::pwtk::input::namelistGetVarValue INPUTPP prefix trim]
	if { $prefix != "" } {
	    defaultVarValue_ INPUTPP filplot '$prefix.pp'
	}
    }
}


#****f* ::pwtk::ppi/::pwtk::ppi::load_fromPPI
# SYNOPSIS
proc ::pwtk::ppi::load_fromPPI {ppi {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing pp.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * ppi -- filename of the pp.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?
    #
    # SOURCE

    ::pwtk::fileMustExist $ppi "pp.x input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current pp.x input data ...
	::pwtk::input::clear INPUTPP PLOT
    }
    
    # read the namelists

    set output [::pwtk::readNamelists $ppi $::pwtk::ppi::input_flow_list]

    # pp.x must contain at least one of the two namelists
    if { $output == "" } {
	::pwtk::error "input file \"$ppi\" does not appear to be a pp.x input file" 1
    }

    eval $output
    variable input_flow_list
    ::pwtk::input::namelists_ityp2atmSymb_ $input_flow_list
}
#******

