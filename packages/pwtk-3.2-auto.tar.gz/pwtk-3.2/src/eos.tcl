#
# $RCSfile: eos.tcl,v $ --
#
#      This file contains the implementation of EOS task.
#
#      EOS = equation-of-state: i.e. automatic determination of the
#      "A" lattice parameter and bulk modulus. For non-cubic systems,
#      only "A" is optimized keeping the cell shape intact, i.e., the
#      ratio between A, B, C is maintained and angles are kept fixed.
#
# Copyright (c) 2009-2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: eos.tcl,v 1.8 2021/05/01 19:23:20 tone Exp $ 
#


#
# SHORT-CUTS
#


#****f* EOS/::pwtk::eos_run
# DESCRIPTION
# See ::pwtk::eos::run
# SOURCE
proc ::pwtk::eos_run {prefix {eosInput ""}} { uplevel [list ::pwtk::eos::run $prefix $eosInput] }
#******


#****f* EOS/::pwtk::eos::EOS
# SYNOPSIS
proc ::pwtk::eos::EOS {content} { 
    # PURPOSE
    # The input data for the EOS calculation are specified with the
    # EOS namelist. This proc is the implementation of the EOS
    # namelist.
    #
    # EOS = equation-of-state. EOS is a workflow for automatic
    # determination of the "A" lattice parameter and bulk modulus. For
    # non-cubic systems, only "A" is optimized keeping the cell shape
    # intact, i.e., the ratio between A, B, C is maintained and angles
    # are kept fixed.
    #
    # BEWARE
    # All distances in the EOS namelist are specified in bohr units!
    #
    # DESCRIPTION
    # A short description of the EOS namelist:
    #
    #    EOS {
    #        mode = auto | range | stepwise
    #        npoints = integer-number
    #    
    #        use_estimator_points = .true. | .false. | yes | no | 1 | 0 | ... # any boolean value accepted by Tcl
    #    
    #        # if mode==auto
    #    
    #        a0 = real-number 
    #        B0  = 'high' | 'medium' | 'small' | real-number (in kbar)
    #        da0 = real-number
    #        scale_min = real-number
    #        scale_max = real-number
    #    
    #        # if mode==range
    #    
    #        amin = real-number (in Bohr units) [REQUIRED]
    #        amax = real-number (in Bohr units) [REQUIRED]
    #        use_stress = true | false (whether to use stress, default=true)
    #    
    #        # if mode==stepwise
    #    
    #        amin = real-number (in Bohr units) [REQUIRED]
    #        da = real-number (in Bohr units)   [REQUIRED]
    #        use_stress = true | false (whether to use stress, default=true)
    #    }
    #
    # REMARK
    # Majority of variables in the EOS namelist are optional because
    # reasonable default values are provided in the config/eos.tcl file.    
    # 
    # Description of the EOS variables:
    
    # * mode -- mode of the lattice parameter search [default=auto]. 
    #           Possibilities are: auto, range, and stepwise
    
    # * npoints -- number of single-point scf calculations
    
    # * use_estimator_points -- whether to use the initial estimator
    #                           points data in the final assessment
    #                           (fitting) of the results
    
    # * use_stress -- whether to use the stress via tstress=.true. in the
    #                 CONTROL namelist (default=true)
    #
    # |html <b>mode == auto</b>: lattice-parameter scanning range is
    # automatically determined; "npoints" SCF calculations is 
    # performed in this range. The following optional variables may be
    # specified:
    
    # * a0 -- initial guess for the lattice parameter (in Bohr, default = celldm(1))
    
    # * B0 -- initial guess for the bulk-modulus (in kbar); used only
    #         when a0 is substantially far from the minimum. Possible
    #         values are: "small", "medium", "high", or numeric value
    #         in kbar units.
    
    # * da0 -- criterion for choosing the 2nd estimator point, a = a0*(1 +/- da0)
    
    # * scale_min, scale_max -- scan the lattice parameter from
    #                           scale_min*a0 to scale_max*a0, where a0
    #                           is the two point estimation of the
    #                           lattice parameter
    #
    # |html <b>mode == range</b>: lattice parameter is scanned in the
    # specified range, as determined by the following two variables:
    
    # * amin, amax -- range to scan the lattice parameter, from "amin"
    #                 to "amax" [REQUIRED]
    #
    # |html <b>mode == stepwise</b>: lattice parameter is scanned in
    # stepwise fashion, starting at amin with increments da:
    
    # * amin -- lower bound of the range to scan the lattice parameters [REQUIRED]
    
    # * da -- increment (in Bohr units) for lattice parameter
    #         scan. This means that npoints SCF calculations will be
    #         performed at amin, amin+da, amin+2*da, ... [REQUIRED]
    #
    # SUMMARY of the EOS namelist:
    #
    # |html <b>mode == auto</b>:
    #
    #    EOS {
    #           mode = auto
    #        npoints = integer-number (OPTIONAL)
    #             a0 = real-value     (OPTIONAL)
    #             B0 = small|medium|high|real-value (OPTIONAL)
    #            da0 = real-value     (OPTIONAL)
    #      scale_min = real-value     (OPTIONAL)
    #      scale_max = real-value     (OPTIONAL)
    #    }    
    #
    # |html <b>mode == range</b>:
    #
    #    EOS {
    #           mode = range
    #        npoints = integer-number (OPTIONAL)
    #           amin = real-value     (REQUIRED)
    #           amax = real-value     (REQUIRED)
    #    }
    #
    # |html <b>mode == stepwise</b>:
    #
    #    EOS {
    #           mode = stepwise
    #        npoints = integer-number (OPTIONAL)
    #           amin = real-value     (REQUIRED)
    #             da = real-value     (REQUIRED)
    #    }
    #
    # SOURCE

    ::pwtk::input::namelist EOS $content 
}
#******


#****if* Internals/::pwtk::eos::parseEOS_
# SYNOPSIS
proc ::pwtk::eos::parseEOS_ {} {
    variable eos
    variable eos_default

    ::pwtk::ifexist eos { unset eos }
    
    # some variables simply need to be defined for EOS to work
    array set eos [array get eos_default]
                  
    # parse the input data for EOS calculation and perform some checks

    foreach var [::pwtk::input::namelistVars_ EOS] {

	set value [::pwtk::input::namelistGetVarValue EOS $var trim]
        
        # allow:  EOS { value = }
        if { $value == "" } {
            continue
        }
        
	switch -exact -- [string tolower $var] {
            restart {
                ::pwtk::deprecated "The use of the \"restart\" variable in the EOS namelist is obsolete. 
Using PWTK's restart mechanism instead." 
                ::pwtk::restart [string trim $value .]
            }
            use_stress {
                set value [string trim $value .]
                if { ! [string is boolean $value] } {
                    ::pwtk::error "wrong value for EOS's use_stress variable, must be boolean, but got $value"
                } else {
		    set eos(use_stress) $value
		}
            }
	    use_estimator_points {
                set value [string trim $value .]
                if { ! [string is boolean $value] } {
                    ::pwtk::error "wrong value for EOS's use_estimator_points variable, must be boolean, but got $value"
                } else {
		    set eos(use_estimator_points) $value
                }
	    }
	    mode {
		if { [regexp (auto|range|stepwise) $value] } {
		    set eos(mode) $value
		} else {
		    ::pwtk::error "wrong mode for EOS calculation: ${value}, must be one of auto, range, or stepwise"
		}
	    }
	    b0 {
		if { [regexp (high|medium|small) $value] } {
		    set eos(B0) $eos(B0_$value)
		} elseif { [::pwtk::is_double $value] } {
                    set value [pwtk::mathParser $value]
		    if { $value < 5 || $value > 5000 } {
			::pwtk::error "B0 value, ${value} kbar, out of acceptable range, must be witin \[5,5000\] kbar"
		    }
		    set eos(B0) $value
		} else {
		    ::pwtk::error "wrong value of B0 for EOS calculation: ${value}, must be one of high, medium, small, or real-number in kbar, but got $value" 1
		}
	    }
	    a0 - scale_min - scale_max - amin - amax - da - da0 {                
		if { [::pwtk::is_double $value] } {
                    set value [pwtk::mathParser $value]
		    set eos($var) $value
		} else {
		    ::pwtk::error "wrong value of $var for EOS calculation: ${value}, must be a real number"
		}
		# additional number checks
		if { [regexp (a0|amin|amax|scale_min) $var] && $value < 0.5 } {
		    ::pwtk::error "increase $var, which is too small, ${value}"
		} elseif { $var == "scale_max" && $value > 2.0 } {
		    ::pwtk::error "scale_max is too big: ${value}, should be lower than 2.0, say, around 1.10"
		}
	    }
	    npoints {
		if { [::pwtk::is_int $value] } {
                    set value [expr $value]
		    if { $value < 4 } {
			::pwtk::error "npoints must be >= 4"
		    }
		    set eos($var) $value
		} else {
		    ::pwtk::error "wrong value of $var for EOS calculation: ${value}, must be an integer number"
		}
	    }
	    default {
		::pwtk::error "wrong EOS's variable name: $var"
	    }
	}
    }
}
#******


#****if* Internals/::pwtk::eos::init_
# SYNOPSIS
proc ::pwtk::eos::init_ {} { 
    # PURPOSE
    #   Initialize the EOS calculation, and perform some checks on
    #   the input variables.
    # SOURCE

    variable eos

    if { ! [info exists eos(mode)] } {
	::pwtk::warning "EOS mode not set, setting it to \"auto\""
	set eos(mode) auto
    }

    set ibrav [::pwtk::pwi::ibrav]
    
    printTitle_ "Search for an optimum A-lattice parameter"
    print_ "  ibrav                =  $ibrav (lattice type: [::pwtk::eos::ibrav2lattice $ibrav])"
    print_ "  mode                 =  $eos(mode)"
    print_ "  number of points     =  $eos(npoints)"   
    print_ "  use estimator points =  $eos(use_estimator_points)"
    print_ "  use stress           =  $eos(use_stress)"
    if { $eos(mode) == "auto" && !$eos(use_stress) } {
        # N.B. ::pwtk::eos::run_auto_ cmd uses hardcoded "tstress = .true."
        print_ "  WARNING: mode == auto and use_stress == false; using stress anyway"
    }
    
    # switch to celldm()
    ::pwtk::pwi::abc2celldm
    
    # which EOS mode ?
    
    switch -- $eos(mode) {
	auto {
	    if { ! [info exists eos(a0)] } {
		set eos(a0) -1.0
	    }
	    if { $eos(a0) < 0.0 } {
		# set the initial a0 to celldm(1) or A from input
		set a0 [::pwtk::pwi::alat]
		if { $a0 > 0.5 } {
		    set eos(a0) $a0
		} else {
		    ::pwtk::error "unreasonable value for the initial lattice parameter a0: $a0" 1
		}
	    }

	    if { $eos(da0) > 0.4 } {
		::pwtk::error "da0 is too big: typical value should be about 10%"
	    }
	    if { $eos(da0) < 0.03 } {
		::pwtk::error "da0 is too small: typical value should be about 10%"
	    }

	    print_ "  initial a0           =  $eos(a0) bohr"
	    print_ "  initial B0           =  $eos(B0) kbar"
	    print_ "  scale_min            =  $eos(scale_min)"
	    print_ "  scale_max            =  $eos(scale_max)"
	}
	range {
	    if { ![info exists eos(amin)] || ![info exists eos(amax)] } {
		::pwtk::error "input parameter \"amin\" or \"amax\" is not defined" 1
	    }
	    if { $eos(amin) > $eos(amax) } {
		::pwtk::error "amin is larger than amax, $eos(amin) and $eos(amax), respectively" 1
	    }
	    print_ "  lattice parameter search-range: \[$eos(amin), $eos(amax)\] bohr"
	}
	stepwise {
	    if { ![info exists eos(amin)] || ![info exists eos(da)] } {
		::pwtk::error "input parameter \"amin\" or \"da\" is not defined" 1
	    }
	    if { $eos(da) > 0.5*$eos(amin) } {
		::pwtk::error "da is too big: typical value should be a few percents of a0"
	    }
	    print_ "  amin                 =  $eos(amin) bohr"
	    print_ "  da                   =  $eos(da) bohr"
	}

	default {
	    ::pwtk::error "wrong EOS mode \"$eos(mode)\", must be one of auto, range, stepwise"
	}
    }    
}
#******


#****f* EOS/::pwtk::eos::run
# SYNOPSIS
proc ::pwtk::eos::run {head {eosInput ""}} {
    # PURPOSE
    #   Run the EOS calculation, i.e., find the optimum "A" lattice parameter.
    #
    #   For non-cubic systems, only "A" is optimized keeping the cell
    #   shape intact, i.e., the ratio between A, B, C is maintained,
    #   and angles are kept fixed.
    #
    # ARGUMENTS
    # * head -- rootname of the input file 
    # * eosInput -- (OPTIONAL) input data in syntax of EOS namelist (see: ::pwtk::eos::EOS)
    #
    # Note that
    #    ::pwtk::eos::run $head $eosInput
    # is equivalent to
    #    EOS $eosInput
    #    ::pwtk::eos::run $head
    #
    # SOURCE

    variable eos

    if { $eosInput != "" } {
        EOS $eosInput
    }

    ::pwtk::input::pushpop {

        parseEOS_
        init_

        # create $head.d directory ...
        
        print_ "  pw.x I/O files will be stored in directory:  ./${head}.d/\n"
        
        if { ! [file isdirectory ${head}.d]} {
            try {
                file mkdir ${head}.d
            } on error err {
                ::pwtk::error "cannot create directory: ${head}.d\n\n$err" 1
            }
        }
        
        run_${eos(mode)}_ [file join $head.d $head]
        findMinimum  [ibrav2lattice [::pwtk::pwi::ibrav]]  [file join $head.d $head]  $eos(datafile)
        
        if { [file exists [file join $head.d $head.RESULTS]] } {
            file rename -force -- [file join $head.d $head.RESULTS] .
        }
    }
}
#******


proc ::pwtk::eos::run_auto_ {head} {
    variable eos
    variable a
    variable V
    variable E

    if { [info exists E] } {
	unset E
	unset V
	unset a
    }

    set a_ini(1)  $eos(a0)
    set da0 [expr {abs($eos(da0))}]

    # calculate the 1st-estimator point 

    ::pwtk::print "Guessing the minimum: performing a two-point calculation.\n
* calculating estimator point \#.1 :  a = [format %8.4f $a_ini(1)] bohr\n"

    set name $head.estimator-1
    CONTROL " tstress = .true. "
    SYSTEM  " celldm(1) = $a_ini(1) "
    runPW $name

    # calc the eos(vol_factor)   
    ::pwtk::eos::vol_factor_ $name.out
    
    set E_ini(1) [::pwtk::pwo::totene $name.out]
    set P_ini(1) [::pwtk::pwo::press  $name.out]    
    set V_ini(1) [::pwtk::pwo::volume $name.out]
    
    ::pwtk::print "* E(tot) = $E_ini(1) ryd
* P      = $P_ini(1) kbar\n"

    set scale    [expr {$P_ini(1) > 0 ? 1.0 + $da0 : 1.0 - $da0}]
    set a_ini(2) [expr {$scale * $a_ini(1)}]

    # iterate until minimum is bracketed

    set NP   2
    set ind1 1
    set done 0
 
    while { ! $done } {
	
	::pwtk::print "* calculating estimator point \#.$NP :  a = [format %8.4f $a_ini($NP)] bohr\n"
    
	set name $head.estimator-$NP
	SYSTEM  " celldm(1) = $a_ini($NP) "
	runPW $name

	set E_ini($NP) [::pwtk::pwo::totene $name.out]
	set P_ini($NP) [::pwtk::pwo::press $name.out]
	set V_ini($NP) [::pwtk::pwo::volume $name.out]

	::pwtk::print "* E(tot) = $E_ini($NP) ryd
* P      = $P_ini($NP) kbar\n"

	# make a two-point V0 estimate

	set V0 [get2pV0_ $V_ini($ind1) $V_ini($NP) $P_ini($ind1) $P_ini($NP)]
	set a0 [getA0fromV0_ $V0]

	if { $P_ini($ind1)*$P_ini($NP) > 0 } {

	    # minimum is NOT bracketed: do another estimator point calculation

	    ::pwtk::print "warning: minimum is not bracketed, calculating another estimator point.\n"

	    # update data for new estimator calculation

	    if { $P_ini($NP) > 0 } {
		set scale [expr {1.0 + 0.5*$eos(da0)}]; # overestimate
	    } else {
		set scale [expr {1.0 - 0.5*$eos(da0)}]; # underestimate
	    }
	    set ind1 $NP
	    incr NP
	    set a_ini($NP) [expr {$scale * $a0}]		
	} else {
	    # minimum is bracketed
	    set done 1
	}
	
	# make a "bad-luck" check ...
	if { ! $done && $NP > 5 } {
	    pwtk::error "failed to guess a0 in 5 steps. Initial a0 must be too far off, retry with a better a0 estimation." 1
	}
    }

    # OK, minimum is bracketed !!!

    set B0 [get2pB0_ $V_ini($ind1) $V_ini($NP) $P_ini($ind1) $P_ini($NP)]

    ::pwtk::print "Two-point estimate:
   two-point estimated lattice parameter :  a  = [format %7.2f $a0] bohr
   two-point estimated of bulk modulus   :  B0 = [format %7.2f $B0] kbar\n"

    # lattice-parameter scan range: [$scale_min*$a0, $scale_max*$a0] 
    
    set amin [expr {$eos(scale_min) * $a0}]
    set amax [expr {$eos(scale_max) * $a0}]
    set da   [expr {($amax - $amin) / double($eos(npoints) - 1)}]

    # use the 4-digit precision as in the pw.x output
    
    set amin [format %.4f $amin]
    set da   [format %.4f $da]
    set amax [expr $amin + ($eos(npoints) - 1)*$da]

    for {set i 1} {$i <= $eos(npoints)} {incr i} {
	set a($i) [expr {$amin + double($i-1)*$da}]
	set V($i) [getV0fromA0_ $a($i)]
    }

    ::pwtk::print "Performing ${eos(npoints)}-points calculation ...
   lattice-parameter range     :  \[[format {%8.4f, %8.4f} $amin $amax]\] bohr
   lattice-parameter increment :   [format %8.4f $da] bohr\n"

    # we already have two (or more) calculated points, let's use them
    # if they are in proper range (unless explicitly requested otherwise)

    if { $eos(use_estimator_points) } {
	for {set j 1} {$j <= $NP} {incr j} {
	    for {set i 1} {$i <= $eos(npoints)} {incr i} {

		set am [expr {$a($i) - $da/2.0}]
		set aM [expr {$a($i) + $da/2.0}]

		if { $a_ini($j) >= $am && $a_ini($j) < $aM } {
		    # accept the initial estimator point
		    set a($i) $a_ini($j)
		    set E($i) $E_ini($j)
		    set V($i) $V_ini($j)		
		}
	    }
	}
    }
	
    # calculate the rest of the points; we don't need pressure (stress) anymore

    CONTROL " tstress = .false. "

    for { set i 1 }  { $i <= $eos(npoints) } { incr i } {
	if { [info exists E($i)] } {
	    ::pwtk::print "One among initial estimator points taken as the ${i}. point.\n"
	} else {
	    ::pwtk::print "Calculating $i. point...\n" 
	    
	    SYSTEM  " celldm(1) = $a($i) "
	    runPW $head.$i
	    
	    set E($i) [::pwtk::pwo::totene $head.$i.out]
	}
	::pwtk::print "* a      = [format %8.4f $a($i)] bohr
* E(tot) = $E($i) ryd\n"
    }

    ::pwtk::eos::printAVE_ $head
}


proc ::pwtk::eos::run_range_ {head} {
    variable eos
    runRange_ $head $eos(amin) $eos(amax)
}


proc ::pwtk::eos::run_stepwise_ {head} {
    variable eos
    runRange_ $head $eos(amin) [expr {$eos(amin) + double($eos(npoints)-1)*$eos(da)}]
}


proc ::pwtk::eos::runRange_ {head amin amax} {
    variable eos
    variable a
    variable V
    variable E

    if { [info exists E] } {
	unset E
	unset V
	unset a
    }

    # use the 4-digit precision as in the pw.x output
    
    set da [format %.4f [expr {($amax - $amin) / double($eos(npoints) - 1)}]]
    set a(1)             [format %.4f $amin]
    set a($eos(npoints)) [format %.4f [expr $amin + ($eos(npoints) - 1)*$da]]

    if { $eos(use_stress) } {
        ::pwtk::print "Checking if the minimum is within the specified range.\n"
    }
    ::pwtk::print "* calculating the 1st point :  a = [format %8.4f $a(1)] bohr\n"
   
    # calc the 1st point

    set name $head.1
    SYSTEM  " celldm(1) = $a(1) "
    if { $eos(use_stress) } {
        CONTROL " tstress = .true. "
    }
    runPW $name

    # calc the eos(vol_factor)   
    ::pwtk::eos::vol_factor_ $name.out

    set E(1) [::pwtk::pwo::totene $name.out]
    set V(1) [getV0fromA0_ $a(1)]
    ::pwtk::print "* E(tot) = $E(1) ryd\n"
    
    if { $eos(use_stress) } {
        set P(1) [::pwtk::pwo::press $name.out]
    
        if { $P(1) < 0.0 } {
            # minimum is outside the range.
            ::pwtk::error "Minimum is not within the specified range!
P(1) < 0 ==> a0 is smaller than $amin bohr" 1
        }
    }
    
    # calc the last point

    ::pwtk::print "* calculating the last point :  a = [format %8.4f $a($eos(npoints))] bohr\n"    
    set name $head.$eos(npoints)
    SYSTEM  " celldm(1) = $a($eos(npoints)) "
    runPW $name
    
    set E($eos(npoints)) [::pwtk::pwo::totene $name.out]
    set V($eos(npoints)) [getV0fromA0_ $a($eos(npoints))]
    ::pwtk::print "* E(tot) = $E($eos(npoints)) ryd\n"
    
    if { $eos(use_stress) } {
        set P($eos(npoints)) [::pwtk::pwo::press $name.out]
        if { $P($eos(npoints)) > 0.0 } {
            # minimum is outside the range.
            ::pwtk::error "Minimum is not within the specified range!
P(last) > 0 ==> a0 is larger than $amax bohr" 1
        }

        ::pwtk::print "Minimum is within the specified range.
   * P(1) = [format %7.2f $P(1)] kbar
   * P($eos(npoints)) = [format %7.2f $P($eos(npoints))] kbar\n"
    }
    
    # calculate the rest of the points

    CONTROL " tstress = .false. "

    ::pwtk::print "Calculating the rest of the points ...\n"
    
    for {set i 2} {$i < $eos(npoints)} {incr i} {
	set a($i) [expr {$a(1) + $da*double($i-1)}]
	set V($i) [getV0fromA0_ $a($i)]
	::pwtk::print "Calculating $i. point... \n"
	
	SYSTEM  " celldm(1) = $a($i) "
	runPW $head.$i	    
	
	set E($i) [::pwtk::pwo::totene $head.$i.out]
	
	::pwtk::print "* a      = [format %8.4f $a($i)] bohr
* E(tot) = $E($i) ryd\n"
    }
    
    ::pwtk::eos::printAVE_ $head
}


proc ::pwtk::eos::printAVE_ {head} {
    # PURPOSE
    #   Print a, V, E to the $head.dat datafile

    variable eos
    variable a
    variable V
    variable E

    ::pwtk::print "Summary of the calculated lattice-parameter data points:

#   a/bohr       V/bohr^3        E(tot)/ryd"

    set ibrav [::pwtk::pwi::ibrav]
    
    set eos(datafile) $head.dat
    set fid [open $eos(datafile) w]
    
    for {set i 1} {$i <= $eos(npoints)} {incr i} {
	# stdout
	::pwtk::print [format "%11.5f   %13.5f   %14.6f" $a($i) $V($i) $E($i)]
	# datafile
	if { abs($ibrav) > 0 && abs($ibrav) < 4 } {
            if { $i == 1 } { puts $fid "#   a/bohr       E(tot)/ryd" }
	    puts $fid [format "%11.5f   %14.6f" $a($i) $E($i)]
	} else {
            if { $i == 1 } { puts $fid "#   V/bohr^3        E(tot)/ryd" }
	    puts $fid [format "%14.5f   %14.6f" $V($i) $E($i)]
	}
    }
    close $fid
    ::pwtk::print "\nData-points written to file:  $eos(datafile)\n"
}


proc ::pwtk::eos::get2pV0_ {V1 V2 P1 P2 {output 1}} {
    # PURPOSE
    #   Make a two-point V0 estimate (i.e. on the basis of two volumes nad pressures)
    variable eos

    set dB0 $eos(dB0)

    set U1  [expr {exp($eos(dB0) * log($V1))}]
    set U2  [expr {exp($eos(dB0) * log($V2))}]
    set ratio [expr {($P1 - $P2) / ( $P1/$U2 - $P2/$U1 )}]

    if { $ratio < 0.0 } {

	# a0 was chosen far away from minimum, make some message to
	# the user, and to a simpler and more secure estimation of a0:

	if { $P1 < 0.0 && $P2 < 0.0 } {

	    # a0 was TOO LARGE ...
	    
	    if { $output} {
		::pwtk::print "warning: two-point Murnaghan estimation of lattice parameter failed.
The initial a0 was too large.\n"
	    }
	    set P $P1
	    set V $V1
	    if { $V2 < $V1 } {
		set P $P2
		set V $V2
	    }
	    set ratio [expr {$eos(B0)/($eos(B0)-$P)}]
	    if { $ratio < 0.5 } {
		::pwtk::print "warning: initial a0 was substantially too large.\n"
	    }
	    set V0 [expr {$V * $eos(B0)/($eos(B0)-$P)}]

	} elseif { $P1 > 0.0 && $P2 > 0.0 } {

	    # a0 was TOO SMALL ...
	    
	    if { $output } {
		::pwtk::print "warning: two-point Murnaghan estimation of lattice parameter failed.
The initial a0 was too small.\n"
	    }
	    set P $P1
	    set V $V1
	    if { $V2 > $V1 } {
		set P $P2
		set V $V2
	    }
	    set V0 [expr {$V * exp(1./$dB0 * log(1.0 + $dB0 * $P / $eos(B0)))}]

	} else {
	    # shouldn't happen
	    ::pwtk::error "weird case... don't know what to do...
   V1=$V1 bohr^3, V2=$V2 bohr^3
   P1=$P1 kbar,   P2=$P2 kbar
   U1=$U1,        U2=$U2
   P1/U2=[expr {$P1/$U2}],   P2/U1=[expr {$P2/$U1}]
   ratio = $ratio" 1
	}
	
	if { $output } {	    
	    set a0 [getA0fromV0_ $V0]
	    ::pwtk::print "poor-man estimate of unit-cell volume :  V0 = [format %8.2f $V0] bohr^3
poor-man estimate of lattice parameter:  a0 = [format %8.2f $a0] bohr"
	    puts ""
	}
    } else {
	# normal-case
	set V0 [expr {exp(1./$dB0 * log($ratio))}]	    
    }
    
    return $V0
}

proc ::pwtk::eos::get2pB0_ {V1 V2 P1 P2} {
    # PURPOSE
    #   Make a two-point Murnaghan B0 estimate (i.e. on the basis of
    #   two volumes and pressures)

    variable eos
    
    set dB0 $eos(dB0)
    set V0   [get2pV0_ $V1 $V2 $P1 $P2 0]
    set B0_1 [expr {$dB0*$P1 / ( exp($dB0 * log($V0/$V1)) - 1.0 )}]
    set B0_2 [expr {$dB0*$P2 / ( exp($dB0 * log($V0/$V2)) - 1.0 )}]
    
    return $B0_1
}   


#****f* EOS/::pwtk::eos::findMinimum
# SYNOPSIS
proc ::pwtk::eos::findMinimum {latticeType head datafile} {
    # PURPOSE    
    # Depending on the latticeType (sc, bcc, fcc, hex, or noncubic),
    # read either a-vs-E (cubic systems) or V-vs-E (noncubic systems)
    # datafile and find optimum a0, E0, and B0 (i.e. lattice
    # parameter, total energy, and bulk modulus). The datafile should
    # consist of two-columns, the first is either the lattice
    # parameter [in bohr] or the cell volume [in bohr^3], the second
    # is the correspponding total energy [in Ryd].
    #
    # Comment lines starting with "#" are allowed in the datafile.
    #
    # This command is used by the EOS workflow.
    #
    # ARGUMENTS
    # * latticeType -- the ev.x Bravais lattice type (sc, bcc, fcc, hex, or noncubic)
    # * head -- prefix for the output files
    # * datafile -- filename of datafile
    #
    # SOURCE

    # read points from datafile

    set ibrav [::pwtk::pwi::ibrav]
    
    set npoints 0
    ::pwtk::lineread line $datafile {	

	if { [llength $line] >= 2 && ![regexp "^ *#" $line] } {	    

	    incr npoints

	    if { $latticeType eq "sc" || $latticeType eq "bcc" || $latticeType eq "fcc" } {

		set a($npoints) [lindex $line 0]
		if { ![string is double $a($npoints)] } {
		    ::pwtk::error "syntax error reading $datafile: expected a real-number for A, but got $a($npoints)" 1
		}
		set V($npoints) [getV0fromA0_ $a($npoints)]

	    } else {

		set V($npoints) [lindex $line 0]
		if { ![string is double $V($npoints)] } {
		    ::pwtk::error "syntax error reading $datafile: expected a real-number for V, but got $V($npoints)" 1		}
		set a($npoints) [getA0fromV0_ $V($npoints)]
		
	    }
            
	    set E($npoints) [lindex $line 1]
	    if { ![string is double $E($npoints)] } {
		::pwtk::error "syntax error reading $datafile: expected a real-number for E, but got $E($npoints)" 1
	    }
	}
    }

    if { $npoints < 3 } {
	::pwtk::error "can't find a minimum for less than three data points" 1
    }
    if { $npoints < 7 } {
	::pwtk::warning "number of data points < 7"
    }

    # map between id & equation-of-state for ev.x

    array set emap {
	1 birch1
	2 birch2
	3 keane
	4 murnaghan
    }
    
    # find the lowest-energy point

    set mini 1
    set E(mini) $E(1)
    for {set i 1} {$i <= $npoints} {incr i} {
	if { $E($i) < $E(mini) } { 
	    set mini $i 
	    set E(mini) $E($i)
	}
    }

    # calculate a0 and B0 for different number of points ...
    # TODO: this should be adopted and symmetric range of points (wrt minimum) determined !

    set done 0
    set first 1
    set last  $npoints
    set ii 1

    while { ! $done } {

	set npoi [expr {$last - $first + 1}]

	# write datafile with $npoi points
	
	set dataf ${head}.$first-$last.dat
	set dat [open $dataf w]	    
	for {set i $first} {$i <= $last} {incr i} {	    
	    if { abs($ibrav) > 0 && abs($ibrav) < 4 } {
		puts $dat " $a($i)   $E($i) "
	    } else {
		puts $dat " $V($i)   $E($i) "
	    }
	}
	close $dat

	# calculate a0, E0, and B0 for the current number of points,
	# $npoi, using all four equation of states supported by ev.x

	for {set eqs 1} {$eqs <= 4} {incr eqs} {
	    
	    set prefix ${head}.$emap($eqs).$first-$last
	    
	    if { [file exists $prefix.ev_out] } {
		file delete -- $prefix.ev_out
	    }

            ::pwtk::writeFile $prefix.ev.in "au\n$latticeType\n$eqs\n$dataf\n$prefix.ev_out"

	    # BEWARE: ev.x seems not to understand the "-in" command line option, use stdin redirection instead
	    ::pwtk::run -serial -ihandle "<" ev.x $prefix.ev.in $prefix.ev.out
	
	    # extract the a0 && E0 && B0
            
	    set out [open $prefix.ev_out r]
	    gets $out line
	    gets $out line
	    close $out
	    set line [regsub -all = $line {}]

	    if { abs($ibrav) > 0 && abs($ibrav) < 4 } {
		# cubic systems
		set a0($npoi,$eqs) [lindex $line 2]
	    } else {
		# for hcp & noncubic ev.x reports V0
		set a0($npoi,$eqs) [getA0fromV0_ [lindex $line 2]]
	    }
	    set B0($npoi,$eqs) [lindex $line 5]
	    set E0($npoi,$eqs) [lindex $line end]
	}

	set im($npoi) $first
	set iM($npoi) $last
	
	# decrease the number of points 

	if { $ii % 2 } {
	    incr last -1
	} else {
	    incr first 
	}
	
	if { ! ($first < $mini && $last > $mini) || $npoi <= 7 } {
	    set done 1
	}

	incr ii
    }  

    # print the result

    set res [open $head.RESULTS w]

    puts $res "
FINAL RESULTS::
---------------

  Lattice type:  $latticeType

  OPTIMISED LATTICE PARAMETER, a0 (in Bohr units)::

  ------------+------------+------------+------------+-----------
   # points   | MURNAGHAN  | BIRCH O(1) | BIRCH O(2) |    KEANE  
  ------------+------------+------------+------------+-----------"
    
    for {set np $npoints} {$np >= $npoi} {incr np -1} {	
	puts $res [format "   %2i: %2i--%-2i |  %8.3f  |  %8.3f  |  %8.3f  |  %8.3f " \
		       $np $im($np) $iM($np) \
		       $a0($np,4) $a0($np,1) $a0($np,2) $a0($np,3)]
    }
    puts $res "  ------------+------------+------------+------------+-----------\n" 


    puts $res "  OPTIMISED Total Energy, E0 (in Ryd units)::

  ------------+------------+------------+------------+-----------
   # points   | MURNAGHAN  | BIRCH O(1) | BIRCH O(2) |    KEANE  
  ------------+------------+------------+------------+-----------"
    
    for {set np $npoints} {$np >= $npoi} {incr np -1} {	
	puts $res [format "   %2i: %2i--%-2i | %10.4f | %10.4f | %10.4f | %10.4f " \
		       $np $im($np) $iM($np) \
		       $E0($np,4) $E0($np,1) $E0($np,2) $E0($np,3)]
    }
    puts $res "  ------------+------------+------------+------------+-----------\n" 


    puts $res "  OPTIMISED Bulk Modulus, B0 (in kbar units)::

  ------------+------------+------------+------------+-----------
   # points   | MURNAGHAN  | BIRCH O(1) | BIRCH O(2) |    KEANE  
  ------------+------------+------------+------------+-----------"
    
    for {set np $npoints} {$np >= $npoi} {incr np -1} {	
	puts $res [format "   %2i: %2i--%-2i |   %5i    |   %5i    |   %5i    |   %5i " \
		       $np $im($np) $iM($np) \
		       $B0($np,4) $B0($np,1) $B0($np,2) $B0($np,3)]
    }
    puts $res "  ------------+------------+------------+------------+-----------\n" 
    close $res

    # print also to stdout

    ::pwtk::print [pwtk::readFile -nonewline $head.RESULTS]
    ::pwtk::print "Result written to file $head.RESULTS\n\n"
}
#******


proc ::pwtk::eos::print_ {message} {    
    ::pwtk::print EOS $message
}


proc ::pwtk::eos::printTitle_ {title} {    
    ::pwtk::printTitle EOS $title
}


proc ::pwtk::eos::vol_factor_ {pwo} {
    # PURPOSE
    #   calculated the eos(vol_factor), which is defined as: V = vol_factor * a^3,    
    #   where V = cell volume, a = alat
    
    variable eos
    set a0 [::pwtk::pwo::alat $pwo]
    set V0 [::pwtk::pwo::volume $pwo]
    set eos(vol_factor) [expr $V0 / $a0**3]
}
    
proc ::pwtk::eos::getA0fromV0_ {V0} {
    # PURPOSE
    #   Get the "A" lattice parameter from the cell volume
    # BEWARE
    #   eos(vol_factor) must be defined !

    variable eos
    return [expr ($V0/$eos(vol_factor))**(1./3.)]
}

proc ::pwtk::eos::getV0fromA0_ {a0} {
    # PURPOSE
    #   Get the cell volume from the "A" lattice parameter
    # BEWARE
    #   eos(vol_factor) must be defined !

    variable eos
    return [expr {$eos(vol_factor)*$a0**3}]
}


#****f* EOS/::pwtk::eos::ibrav2lattice
# SYNOPSIS
proc ::pwtk::eos::ibrav2lattice {ibrav} {
    # PURPOSE    
    #   Map the ibrav value to the ev.x Bravais lattice type.
    #   This command is used by the EOS workflow.
    # RETURN VALUE
    #   Either sc, fcc, bcc, hex, or noncubic.
    # SOURCE

    # account for ibrav = -3
    set ibrav [expr {abs($ibrav)}] 
    
    switch -- $ibrav {
	1  { set lattice sc  }
	2  { set lattice fcc }
	3  { set lattice bcc }
	4  { set lattice hex }
	default {
	    set lattice noncubic
	}
    }
    return $lattice
}
#******

