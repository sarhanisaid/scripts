#
# $RCSfile: sbco.tcl,v $ --
#
#
#      SBCO -- Scanned-Bond Constrained Optimization
#
#      In this file a Scanned-Bond Constrained Optimization workflow
#      is implemented.
#
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: sbco.tcl,v 1.7 2021/05/01 19:23:20 tone Exp $ 
#


#
# SHORT-CUTS
#
proc ::pwtk::sbco_run          {prefix {init_ion_dynamics ""}} { uplevel ::pwtk::sbco::run $prefix $init_ion_dynamics }
proc ::pwtk::sbco_postNeb      {prefix {num_of_images ""}}     { uplevel ::pwtk::sbco::postNeb $prefix $num_of_images }


#****f* ::pwtk::sbco/::pwtk::sbco::SBCO
# SYNOPSIS
proc ::pwtk::sbco::SBCO {content} { 
    # PURPOSE
    #   Specify the specs for the SBCO calculation via the SBCO namelist.
    #
    # ARGUMENTS
    #   * content -- specs of the SBCO namelist (for default values of 
    #
    # The SBCO namelist consists of the following variables:
    #
    #    SBCO {
    #        bond        =  1 2          ... bond betwen atom1 & atom2	 
    #        mass        =  1.0 1.0      ... masses of the atom1 and atom2 (used to determine how
    #                                        to move atom1 and atom2; heavier atom moves less)
    #        nsteps      =  5            ... number of constrained-optimization steps to perform
    #        auto        =  false        ... if true, stop the scan when energy starts decreasing
    #        increment   =  0.1          ... increment for bond length	 
    #        tolerance   =  0.0001       ... tolerance for maintain the bond at prescribed length
    #        unit        =  angstroms    ... unit of increment (angstrom|bohr|alat)
    #        first_opt   =  true         ... fully optimize the 1st SBCO image without any CONSTRAINTS card
    #        post_relax  =  true         ... make a full relaxation without any constraint after the SBCO calculation
    #        post_neb    =  false        ... perform a NEB calculation after the SBCO calculation to verify the TS
    #        CI_scheme   =  auto         ... the CI_scheme used for the sbco_postNeb calculation
    #    }
    #
    # SOURCE
    
    ::pwtk::input::namelist SBCO $content 
}
#******

# Internal...
proc ::pwtk::sbco::parseSBCO_ {} {
    # PURPOSE
    #   Parse the SBCO namelist.
    
    variable sbco
    variable sbco_default

    ::pwtk::ifexist sbco { unset sbco }

    # some variables simply need to be defined for SBCO to work
    array set sbco [array get sbco_default]

    foreach var [::pwtk::input::namelistVars_ SBCO] {
	
	set value [::pwtk::input::namelistGetVarValue SBCO $var trim]
        set var_  [string tolower $var]
        lassign [split $var_ ()] arrname elem
        
	switch -glob -nocase -- $var_ {
            bond(?) {
		if { ! [::pwtk::type::number posint -strict $value] } {
		    ::pwtk::error "extected a positive integer for '$var' but got $value" 1
		}
                set sbco(atom$elem) $value
            }
	    mass(?) {
                if { ! [::pwtk::is_double $value] } {
		    ::pwtk::error "expected a real number for '$var' but got $value" 1
		}
                set sbco(mass$elem) [::pwtk::mathParser $value]
	    }
	    nsteps {
		if { ! [string is integer -strict $value] } {
		    ::pwtk::error "wrong value of nsteps: $value, must be an integer" 1
		}
		if { $value < 2 } {
		    ::pwtk::error "nsteps must be > 1 but got $value" 1
		}
		set sbco(nsteps) $value		    
	    }
	    unit {
		switch -glob -- $value {
		    angs* - bohr - alat {
			set sbco(unit) $value
		    }
		    default {
			::pwtk::error "wrong value of unit: $value, must be one of angstrom, bohr, or alat" 1
		    }
		}
	    }
	    increment {
		if { ! [::pwtk::is_double $value] } {
		    ::pwtk::error "wrong value of increment: $value, must be a real number" 1
		}
		set sbco(increment) [::pwtk::mathParser $value]
	    }
	    tolerance {
		if { ! [::pwtk::is_double $value] } {
		    ::pwtk::error "wrong value of tolerance: $value, must be a real number" 1
		}
		set sbco(tolerance) [::pwtk::mathParser $value]
	    }
	    first_opt -
            auto -
            post_relax -
            post_neb {
                set sbco($var_) [fboolOpt_ $var $value]
            }
	    ci_scheme {
		switch -exact -- $value {
		    manual - auto - "no-CI" {
			set sbco(CI_scheme) $value
		    }
		    default {
			::pwtk::error "wrong value of CI_scheme: $value, must be one of auto, manual, or no-CI" 1
		    }
		}
	    }
	    restart_index {
                :pwtk::deprecated "The use of the \"restart_index\" variable in the SBCO namelist is obsolete. 
Using PWTK's restart mechanism instead."
      		if { ! [string is integer -string $value] } {
		    ::pwtk::error "expected an integer for restart_index, but got: $value" 1
		}
                if { $value > 0 } {
                    ::pwtk::restart on
                }
	    }
	    default {
                if { $value ne {} } {
                    # N.B. if an unknown variable has an empty value, it is
                    # OK because this is the PWTK's way to delete a variable
                    ::pwtk::error "wrong SBCO variable name: $var, must be one of bond, mass, nsteps, unit, increment, tolerance, first_opt, auto, post_neb, or CI_scheme" 1
                }
	    }
	}
    }

    # variables that must exist
    
    foreach elem {nsteps atom1 atom2} {
        if { ! [info exists sbco($elem)] } {
            ::pwtk::error "cannot run the SBCO calculation: sbco($elem) variable was not set" 1
        }
    }

    # check for proper values
    if { $sbco(atom1) == $sbco(atom2) } {
        ::pwtk::error "bond was specified with two identical atom indices" 1
    }
    if { abs($sbco(mass1) + $sbco(mass2)) < 1e-6 } {
        ::pwtk::error "the sum of masses <= zero" 1
    }
}


#****f* ::pwtk::sbco/::pwtk::sbco::run
# SYNOPSIS
proc ::pwtk::sbco::run {head {init_ion_dynamics "bfgs"}} {
    # PURPOSE

    #   Run the SBCO calculation, i.e., a series of pw.x contrained
    #   optimizations with a specified bond step-wise elongated,
    #   optionally followed by a neb.x calculation to verify the
    #   transition-state and activation energy.
    #
    # BEWARE
    #   This method is aplicable only for reactions whose reaction
    #   coordinate is predominantly along a given bond. A serious
    #   caveat of this method is that it may completely miss the
    #   transition state, yielding a considerably underestimated
    #   activation energy. For this reason, a post-NEB calculations
    #   can be performed.
    #
    # ARGUMENTS
    #   * head -- rootname for the I/O files
    #   * init_ion_dynamics -- which ion_dynamics to use for optimizing the 1st SBCO image
    #
    # RETURN VALUE
    # * if post_neb == false, the "E(max) - E(0)" difference in eV
    #                  (aka the estimation of the activation energy)
    # * if post_neb == true, the NEB corrected activation energy, E(neb.TS) - E(0)
    #
    # SOURCE

    variable sbco 

    set head sbco.[::pwtk::trim_prefix sbco $head]

    # initialize & parse SBCO ...
    
    parseSBCO_

    # calculation must be 'relax'
    
    set calculation [::pwtk::input::namelistGetVarValue CONTROL calculation trim]
    if { $calculation ne "relax" } {
        ::pwtk::error "for SBCO, the calculation must be 'relax', but the current value is '$calculation'" 1
    }

    # printout
    
    printTitle_ "Scan Bond Constrained Optimization"    
    print_ "bond (atom1 atom2)         ==  $sbco(atom1) $sbco(atom2)
mass (atom1 atom2)         ==  $sbco(mass1) $sbco(mass2)
number of steps            ==  $sbco(nsteps)
bond increment             ==  $sbco(increment) $sbco(unit)
bond tolerance             ==  $sbco(tolerance) bohr
full opt. of the 1st image ==  $sbco(first_opt)
auto mode                  ==  $sbco(auto)
post-relax calculation     ==  $sbco(post_relax)
post-NEB calculation       ==  $sbco(post_neb)"
    if { $sbco(post_neb) } {
        print_ "post-NEB CI_scheme         ==  $sbco(CI_scheme)"
    }
    ::pwtk::print ""
    
    set nsteps        $sbco(nsteps)
    set ion_dynamics  [::pwtk::input::namelistGetVarValue IONS ion_dynamics trim]
    set pwiAtmPosUnit [::pwtk::pwi::getAtmPosUnit enforce]
    switch $pwiAtmPosUnit {
        alat - bohr - angstrom - crystal {}
        default {
            ::pwtk::error "the '$pwiAtmPosUnit' units not imlpemented" 1
        }
    }
    
    # prepare for *.dat and *.axsf files
    
    set dat_fid [open "$head.dat" w]
    chan configure $dat_fid -buffering line
    puts $dat_fid "#  increment ($sbco(unit))   total energy (Ry)   total energy (eV)   dE (eV)   image-No."
    set xsf [::pwtk::pwi::getXSFPrimVec]\n\n

    #
    # run the SBCO calculations
    #
    set de_ev_max 0.0
    set iMax 0
    
    for {set istep 0} {$istep <= $nsteps} {incr istep} {

	# set I/O filenames
	set input  $head.$istep.in
	set output $head.$istep.out

        ::pwtk::print "step \#.$istep"
        
	if { $istep == 0 && $sbco(first_opt) } {

	    # the initial step is special
	    
	    ::pwtk::print "   initial step will be fully optimized"
	    if { $init_ion_dynamics ne "" } {
		::pwtk::print "   ion_dynamics   = $init_ion_dynamics"		
		IONS "ion_dynamics = [::pwtk::squote $init_ion_dynamics]"
	    } else {
		::pwtk::print "   ion_dynamics   = $ion_dynamics"		
            }            
	} else {
	    # the rest of the steps are the same
            
            if { $ion_dynamics eq "bfgs" || $ion_dynamics eq {} } {
                set ion_dynamics damp
                ::pwtk::print "Warning: ion_dynamics == 'bfgs' is incompatible with CONSTRAINTS, using ion_dynamics == '$ion_dynamics' instead"
            }
	    ::pwtk::print "   ion_dynamics   = ${ion_dynamics}"
            IONS "ion_dynamics = [::pwtk::squote ${ion_dynamics}]"

	    if { $istep > 0 } {
		# load the coordinates for the new SBCO run
		::pwtk::pwi::replaceCoor [getNewCoor_ $pwiAtmPosUnit $old_output] $pwiAtmPosUnit
	    }

	    # make a CONSTRAINTS card
	    
	    CONSTRAINTS "1 $sbco(tolerance)\n'distance' $sbco(atom1) $sbco(atom2)"
	}
        ::pwtk::print "   bond increment = [format %.4f [expr {$istep * $sbco(increment)}]] $sbco(unit)\n"

	# run the pw.x calculation

        ::pwtk::outdir_postfix $head.$istep
	::pwtk::runPW $input $output
        
	# write total energy to stdout and update data files

        writeData_
        
        if { [info exist old_totene] && $sbco(auto) && $totene < $old_totene } {
            ::pwtk::print "Auto SBCO condition is met (energy new < energy old).
   Stopping the SBCO calculation.
      energy new = $totene Ry
      energy old = $old_totene Ry
"
            set nsteps $istep
            incr istep
            break
        }
        
	# save the name of input/output file

	set old_output $output
        set old_totene $totene
    }

    # if post_relax & iMax < nsteps, run the full relaxation
    
    if { $sbco(post_relax) } {
        if { $iMax < $nsteps } {            
            ::pwtk::input::pushpop {
                print_ "Performing post-relax SBCO calculation\n"
                if { $init_ion_dynamics ne "" } {
                    IONS "ion_dynamics = [::pwtk::squote $init_ion_dynamics]"
                }
                ::pwtk::input::clear CONSTRAINTS
                ::pwtk::pwi::ATOMIC_POSITIONS_fromPWO $output
                
                incr nsteps
                set name   relax.[::pwtk::trim_prefix sbco $head].$istep
                set output $name.out
                
                ::pwtk::outdir_postfix $name
                ::pwtk::runPW $name

                # calculate the bond length
                set dist_ [postRelaxDist_ $pwiAtmPosUnit $output]
                writeData_
            }
        } else {
            ::pwtk::infoMsg "Post-relax SBCO calculation skipped because the last image\nhas the highest energy."
        }
    }

    incr nsteps; # account for 0th image
    
    close $dat_fid
    writeFile $head.axsf "ANIMSTEPS $nsteps\n\nCRYSTAL\n\n$xsf"

    # write some final info

    ::pwtk::print "SBCO calculation completed.

SBCO energies written to:    $head.dat
SBCO structures written to:  $head.axsf

Summary:
   Number of the SBCO images: $nsteps
   SBCO data (bond increments & energies):\n"
    ::pwtk::print [::pwtk::readFile $head.dat]

    # if requested, run post-NEB
    
    if { $sbco(post_neb) } {
        return [postNeb $head]
    } else {
        ::pwtk::print "   SBCO image with the highest energy:  $iMax
   * dE(max) = E($iMax) - E(0) = [format %.4f $de_ev_max] eV\n"
        return $de_ev_max
    }
}
#******


# Internal...
proc ::pwtk::sbco::writeData_ {} {
    uplevel 1 {
        set totene    [::pwtk::pwo::totene $output] 
	set totene_ev [expr {$totene * $::pwtk::ry2ev}]
	if { $istep == 0 } {
	    set totene_ref $totene
	}
	set de    [expr {$totene - $totene_ref}]
	set de_ev [expr {$de * $::pwtk::ry2ev}]
        if { $de_ev > $de_ev_max } {
            set de_ev_max $de_ev
            set iMax $istep
        }

	::pwtk::print "Optimization for step \#.$istep completed."
	::pwtk::print "   Total energy = $totene Ryd"
	::pwtk::print "             dE = E - E(0) = [format %.5f $de] Ryd = [format %.4f $de_ev] eV\n"

	# write the data files

        ::pwtk::ifnotexist dist_ {
            set d [expr {double($istep) * $sbco(increment)}]
        } else {
            set d $dist_
        }
	puts $dat_fid [format "  %9.4f     %15.5f     %15.4f     %12.4f     $istep"  $d  $totene  $totene_ev $de_ev]
	append xsf [::pwtk::pwo::getXSFPrimCoor -lc $output [expr {$istep + 1}]]\n
    }
}


#****f* ::pwtk::sbco/::pwtk::sbco::postNeb
# SYNOPSIS
proc ::pwtk::sbco::postNeb {head {n_images -3}} {
    # USAGE
    #   postNeb  head  ?n_images?
    #
    # REMARK
    #   This command is called by ::pwtk::sbco::run if post_neb == true.
    #
    # PURPOSE
    #   Perform the NEB calculation on top of the SBCO calculated data
    #   to locate the transition state (TS).
    #
    #   The NEB calculation is performed if and only if the SBCO was
    #   able to bracket the TS. There should be an intermediate image
    #   with the maximum energy in file $head.dat. This "maximum"
    #   image is taken as a TS guess, the image before the "maximum"
    #   SBCO image is uses as IS, and the image after the SBCO
    #   "maximum" image is used as FS.  The NEB calculation is
    #   performed with $n_images between the so-located first and
    #   last image.
    #
    # ARGUMENTS
    # * head -- rootname for the neb.x I/O files
    # * n_images -- (optional) number of images for the neb.x calculation
    #
    # BEWARE
    #   The PATH's num_of_images is set only if the specified n_images >= 3.
    #
    #   If n_images <= -3 and PATH's num_of_images is not
    #   defined, then PATH's num_of_images is set to abs(n_images).
    #
    # RETURN VALUE
    #   NEB corrected activation energy (measured with respect to the 1st SBCO image).
    #
    # SOURCE

    set head sbco.[::pwtk::trim_prefix sbco $head]

    if { ! [file exists $head.dat] } {
	::pwtk::error "cannot perform SBCO post-NEB calculation, data file $head.dat does not exist" 1
    }
    if { ! [string is integer -strict $n_images] } {
	::pwtk::error "expected an integer number for n_images, but got $n_images" 1
    }
    if { $n_images >= 3 } {        
        PATH " num_of_images = $n_images"        
    } elseif { [::pwtk::input::namelistGetVarValue PATH num_of_images] eq {} && $n_images <= -3 } {
        PATH " num_of_images = [expr abs($n_images)] "
    }

    printTitle_ "Post-NEB SBCO calculation"
	
    # find the image with the maximum energy

    set ind    0
    set uphill 0
    set maxInd 0
    set old_ene_ev 1e10

    foreach line [split [::pwtk::readFile $head.dat] \n] {
	
	if { ! [regexp -- {(^[ \t]*#|^[ \t]*$)} $line] } {
	    # not a comment and not an empty line
	    
	    set ene_ev($ind) [lindex $line 2]
	    	    
	    if { $ind > 0 } {
		if { $uphill && $ene_ev($ind) < $old_ene_ev } {
		    # maximum located
		    set maxInd [expr {$ind - 1}]
		    break
		} elseif { $ene_ev($ind) > $old_ene_ev } {
		    set uphill 1
		}
	    }	    
	    set old_ene_ev $ene_ev($ind)
	    incr ind
	}
    }
    if { $maxInd == 0 } {
	::pwtk::error "cannot perform post-NEB SBCO calculation, maximum not found in '$head.dat'" 1
    }
    set im [expr {$maxInd - 1}]
    set iM [expr {$maxInd + 1}]

    ::pwtk::fileMustExist $head.$im.out
    ::pwtk::fileMustExist $head.$maxInd.out
    ::pwtk::fileMustExist $head.$iM.out
    
    # print some useful informations

    print_ "Image with the maximum energy taken from file: $head.$maxInd.out

The following images will be used as starting points for the NEB calculation:
   * first-image from        : $head.$im.out
   * intermediate-image from : $head.$maxInd.out
   * last-image from         : $head.$iM.out\n"
    
    # extract the images 

    for {set i $im} {$i <= $iM} {incr i} {
        set image($i) [::pwtk::pwo::getAtmPos -k $head.$i.out]
        set unit($i)  [::pwtk::trimCardFlag [lrange [lindex [split [string trim $image($i)] \n] 0] 1 end]]
        set coor($i)  [::pwtk::atmPosToCoor $image($i)]
    }

    # set the NEB input

    variable sbco

    set neb_head post-neb.[::pwtk::trim_prefix sbco $head]

    CONTROL " prefix  = '$neb_head' , calculation = "
    input_clear IONS CONSTRAINTS

    POSITIONS "
FIRST_IMAGE
$image($im)

INTERMEDIATE_IMAGE
ATOMIC_POSITIONS $unit($maxInd)
$coor($maxInd)

LAST_IMAGE
ATOMIC_POSITIONS $unit($iM)
$coor($iM)"

    ::pwtk::ifexist sbco(CI_scheme) {
        PATH " CI_scheme = [::pwtk::squote $sbco(CI_scheme)] "
    }
    set CI_scheme [::pwtk::input::namelistGetVarValue PATH CI_scheme trim]
    ::pwtk::ifset CI_scheme no-CI
    set input  $neb_head.$CI_scheme.in
    set output $neb_head.$CI_scheme.out
    
    # run the NEB calculation

    ::pwtk::outdir_postfix $neb_head
    ::pwtk::runNEB $input $output

    ::pwtk::print "Post-NEB SBCO calculation finished. See the \"$output\" file for details."

    # get the cumulative activation energy
    # (neb.x calculates activation energy with respect to the SBCO image No.$im)

    foreach {var value} [::pwtk::path::energies $neb_head.path] { set $var $value }
    # BEWARE: energies in the path file are in Hartrees
    set Eact_neb [expr $::pwtk::ha2ev*($Emax - $E(1))]

    set Eact_sbco [expr $ene_ev($maxInd) - $ene_ev(0)]
    set Eact_corr [expr $ene_ev($im) + $Eact_neb - $ene_ev(0)]

    ::pwtk::print "
Post-NEB SBCO summary:
   * SBCO image with the highest energy: $maxInd
   * SBCO only activation energy = [format %.4f $Eact_sbco] eV (measured wrt SBCO image No.0)

   * NEB image with the highest energy: $iTS
   * NEB only activation energy  = [format %.4f $Eact_neb] eV (measured wrt SBCO image No.$im)

   * NEB corrected SBCO activation energy = [format %.4f $Eact_corr] eV (measured wrt SBCO image No.0)
"    
    return $Eact_corr
}
#******


# Internal...
proc ::pwtk::sbco::print_ {message} {    
    ::pwtk::print SBCO $message
}


# Internal...
proc ::pwtk::sbco::printTitle_ {title} {    
    ::pwtk::printTitle SBCO $title
}


# Internal...
proc ::pwtk::sbco::getNewCoor_ {pwiAtmPosUnit pwo} {
    variable sbco

    set incr $sbco(increment)
    set alat   [::pwtk::pwi::alat]
    set atmPos [::pwtk::pwo::getAtmPos $pwo]
    set coor   [::pwtk::atmPosToCoor [::pwtk::getAtmPosSegment [list $sbco(atom1) $sbco(atom2)] $atmPos]]
    set coorUnit_ $pwiAtmPosUnit
    
    if { $pwiAtmPosUnit eq "crystal" } {
        # CELL_PARAMETERS & ATOMIC_POSITIONS to bohr units
        set orig_coor $coor
        set vecs [::pwtk::pwi::getPrimVec bohr]
        set coor [::pwtk::coorToCartesian $vecs $coor]
        set coorUnit_ bohr
    }
    
    set at1 [lindex $coor 0];  set coor1 [lrange $coor 1 3]
    set at2 [lindex $coor 4];  set coor2 [lrange $coor 5 7]

    set w1 [expr {$sbco(mass2) / ($sbco(mass1) + $sbco(mass2))}]
    set w2 [expr {1.0 - $w1}]

    if { $sbco(unit) ne $coorUnit_ } {
        # convert increment to 'bohr'
        switch -glob -- $sbco(unit) {
            angs* { set incr [expr $incr * $::pwtk::angs2bohr] }
            alat  { set incr [expr $incr * $alat] }
        }        
        # convert increment from 'bohr' to $coorUnit_
        switch -glob -- [string tolower $coorUnit_] {
            angs* { set incr [expr $incr * $::pwtk::bohr2angs] }
            alat  { set incr [expr $incr / $alat] }
        }
    }    

    set path_ [namespace path]
    namespace path ::math::linearalgebra

    set dir   [unitLengthVector [sub $coor2 $coor1]]
    set coor1 [add $coor1 [scale [expr -($w1 * $incr)] $dir] ]
    set coor2 [add $coor2 [scale [expr  ($w2 * $incr)] $dir] ]

    if { $pwiAtmPosUnit eq "crystal" } {
        # convert coor1 & coor2 back to crystal units
        #                                         |v1x v1y v1z|
        #       [a b c] = [x y z] T^-1, where T = |v2x v2y v2z|
        #                                         |v3x v3y v3z|   

        set Tinv [::pwtk::invert3x3 $vecs]
        set coor1 [matmul $coor1 $Tinv]
        set coor2 [matmul $coor2 $Tinv]
        
        set coor $orig_coor
    }

    namespace path $path_

    # replace at1 & at2 with the new coor
    
    set atmPos [::pwtk::replaceAtom $sbco(atom1) "$at1 $coor1" $atmPos]
    set atmPos [::pwtk::replaceAtom $sbco(atom2) "$at2 $coor2" $atmPos]

    return $atmPos
}


# Internal...
proc ::pwtk::sbco::fboolOpt_ {var value} {
    if { ! [::pwtk::type::number fboolean -strict $value] } {
        uplevel 1 [list ::pwtk::error "expected boolean for \"$var\" but got: $value" 1]
    }
    if { [::pwtk::is_true $value] } {
        return true
    } else {
        return false
    }
}


# Internal...
proc ::pwtk::sbco::postRelaxDist_ {pwiAtmPosUnit pwo} {
    variable sbco

    set alat [::pwtk::pwi::alat]
    set coor [::pwtk::atmPosToCoor [::pwtk::pwo::getAtmPosSegment [list $sbco(atom1) $sbco(atom2)] $pwo]]

    if { $pwiAtmPosUnit eq "crystal" } {
        # coor to $sbco(unit)    
        set vecs [::pwtk::pwi::getPrimVec $sbco(unit)]
        set coor [::pwtk::coorToCartesian $vecs $coor]
    } else {
        # Cartesian
        if { $sbco(unit) ne $pwiAtmPosUnit } {
            # convert coor to 'bohr'
            switch -glob -- $pwiAtmPosUnit {
                angs* { set scale $::pwtk::angs2bohr }
                alat  { set scale $alat }
                default { set scale 1.0 }
            }     
            # convert coor from 'bohr' to $sbco(unit)
            switch -glob -- [string tolower $sbco(unit)] {
                angs* { set scale [expr $scale * $::pwtk::bohr2angs] }
                alat  { set scale [expr $scale / $alat] }
            }
            set coor [::pwtk::scaleCoor $scale $coor]    
        }
    }

    set xyz1 [lrange $coor 1 3]
    set xyz2 [lrange $coor 5 7]

    return [::pwtk::norm3 [::math::linearalgebra::sub $xyz1 $xyz2]]
}
