#
# $RCSfile: supercell.tcl,v $ --
#
#      This file contains commands for generating supercells, i.e.,
#      building pw.x CELL_PARAMETERS & K_POINTS cards based on the
#      unit cell vectors and supercell expansion matrix.
#
# Copyright (c) 2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: supercell.tcl,v 1.0 2023/04/08 13:35 kokalj Exp $ 
#



# CONSIDER:
#   A better recipe for supercell k-mesh:
#   1. sort vectors in ascending order
#   2. take the shortest as the reference (i.e. 1st)
#   3. orthogonalize the 2nd to the 1st
#   4. orthogonalize the 3rd to the 1st & 2nd
#   5. assign k-point based on ortogonalized vectors!

namespace eval ::pwtk:: {
    variable dipcorr

    # default settings for dipole correction (see ::pwtk::dipoleCorr)
    array set dipcorr {
        vac1st   15.0 
        diplayer  2.0
        vac2nd   16.0
    }

    #***internal... 
    proc dipcorrDefault_ {vac1st diplayer vac2nd} {
        # load default dipole-correction settings
        variable dipcorr
        ifset vac1st   $dipcorr(vac1st)
        ifset diplayer $dipcorr(diplayer)
        ifset vac2nd   $dipcorr(vac2nd)
        return "$vac1st $diplayer $vac2nd"
    }
}


#****f* generic_struct_utils/::pwtk::latvec3Dto2D
# SYNOPSIS
proc ::pwtk::latvec3Dto2D {m} {
    # PURPOSE
    #   Transform 3D Bravais lattice vectors into 2D vectors, i.e.:
    #     { {x1 y1 z1} {x2 y2 z2} {x3 y3 z3} }
    #   is transformed to
    #     { {x1 y1} {x2 y2} }
    #
    # ARGUMENTS
    # * m --- 3x3 matrix of Bravais lattice vectors
    # SOURCE

    lassign $m v1 v2
    return [list [lrange $v1 0 1] [lrange $v2 0 1]]
}
#******


#****f* generic_struct_utils/::pwtk::latvec2Dto3D
# SYNOPSIS
proc ::pwtk::latvec2Dto3D {m Z} {
    # PURPOSE
    #   Transform 2D Bravais lattice vectors, i.e., 
    #     { {x1 y1} {x2 y2} }
    #   into 3D vectors
    #     { {x1 y1 0.0} {x2 y2 0.0} {0.0 0.0 $Z} }
    #
    # ARGUMENTS
    # * m --- 2x2 (or 3x3) matrix of Bravais lattice vectors
    # * Z --- Z-size of the 3rd lattice-vector, i.e. {0 0 $Z}
    #
    # RETURN VALUE
    #   A (3x3) matrix in the "{x1 y1 0.0} {x2 y2 0.0} {0.0 0.0 Z}" form.
    #
    # SOURCE

    lassign $m v1 v2
    return [list  [lreplace $v1 2 2 0.0]  [lreplace $v2 2 2 0.0]  [list 0.0 0.0 $Z]]
}
#******


#****f* generic_struct_utils/::pwtk::matricize
# SYNOPSIS
proc ::pwtk::matricize {m} {
    # PURPOSE
    #   Transform a 2x2, 2x3, or 3x3 matrix written in various
    #   representations into the math::linearalgebra representation. A
    #   3x3 matrix in the math::linearalgebra representation is:
    #       {{x1 y1 z1} {x2 y2 z2} {x3 y3 z3}}
    #
    #   For 2D, the routine transforms:
    #      "NxM" into "{N 0} {M 0}"   
    #   or
    #      x1.y1_x2.y2 into "{x1 y1} {x2 y2}"
    #   or
    #      "1 2 3 4" into "{1 2} {3 4}"
    #   
    #   For 3D, the routine tranforms:    
    #     "NxMxL" into "{N 0 0} {0 M 0} {0 0 L}"
    #   or
    #     x1.y1.z1_x2.y2.z2_x3.y3.z3 into "{x1 y1 z1} {x2 y2 z2} {x3 y3 z3}"
    #   or
    #     "1 2 3 4 5 6 7 8 9" into "{1 2 3} {4 5 6} {7 8 9}"
    #
    #   If the matrix is already in the math::linearalgebra representation, e.g.,
    #   {{x1 y1 z1} {x2 y2 z2} {x3 y3 z3}}, it is returned verbatim.
    #
    # BEWARE
    #   Use the x1.y1.z1_x2.y2.z2_x3.y3.z3 form only for integer
    #   matrices because real matrices will be wrongly parsed due to
    #   too many "." characters.
    #
    # RETURN VALUE
    #   Matrix $m in the math::linearalgebra representation, i.e.:
    #     { {m11 m12 m13} {m21 m22 m23} {m31 m32 m33} }
    #
    # SOURCE
    
    if { [string match *x* $m] } {
        lassign [split $m x] a1 a2 a3
        if { $a3 ne {} } {
            return [list "$a1 0.0 0.0"  "0.0 $a2 0.0"  "0.0 0.0 $a3"]
        } else {
            return [list "$a1 0.0"  "0.0 $a2"]
        }
    }

    set len [llength $m]
    if { $len == 1 && [string match *_* $m] } {
        lassign [split $m _] v1 v2 v3
        if { $v3 ne {} } {
            return [list [split $v1 .] [split $v2 .] [split $v3 .]];  # 3x3 matrix
        } else {
            return [list [split $v1 .] [split $v2 .]]; # 2x2 matix
        }
    } elseif { $len == 4 } {
        #return [::math::linearalgebra::from_LA [list 2 2 2 {*}$m]]
        return [list [lrange $m 0 1] [lrange $m 2 3]]
    } elseif { $len == 6 } {
        #return [::math::linearalgebra::from_LA [list 2 2 3 {*}$m]]
        return [list [lrange $m 0 2] [lrange $m 3 5]]
    } elseif { $len == 9 } {
        #return [::math::linearalgebra::from_LA [list 2 3 3 {*}$m]]
        return [list [lrange $m 0 2] [lrange $m 3 5] [lrange $m 6 8]]
    }
    return $m
}
#******


#****f* generic_struct_utils/::pwtk::Kmeshize
# SYNOPSIS
proc ::pwtk::Kmeshize {kmesh {dim 3}} {
    # PURPOSE
    #   Tranform various K-mesh representations into a list of 3
    #   numbers, i.e., {M N K}.
    #
    #   In particular:
    #      MxNxK --> {M N K}
    #      MxN   --> {M N 1}
    #      {M N} --> {M N 1}
    #      M     --> {M 1 1}
    #
    # ARGUMENTS
    # * kmesh --- k-mesh to tranform
    # * dim   --- dimension of k-mesh (either 3, 2, or 1)
    #
    # RETURN VALUE
    # * for dim==3: {M N K}
    # * for dim==2: {M N 1}
    # * for dim==1: {M 1 1}
    #
    # SOURCE
    if { [string match *x* $kmesh] } {
        set kmesh [split $kmesh x]
    }
    if { [llength $kmesh] < $dim } {
        ::pwtk::error "wrong format of k-mesh, must be a list of $dim numbers, but got $kmesh" 1
    }
    lassign $kmesh k1 k2 k3
    if { $dim < 3 } { set k3 1 }
    if { $dim < 2 } { set k2 1 }
    return [list $k1 $k2 $k3]
}
#******


#****f* generic_struct_utils/::pwtk::m2cell
# SYNOPSIS
proc ::pwtk::m2cell {m} {
    # PURPOSE
    #   Tranform a 3x3 matrix into a CELL_PARAMETERS 3x3 form, i.e.:
    #                                              {x1 y1 z1
    #      {{x1 y1 z1} {x2 y2 z2} {x3 y3 z3}}  -->  x2 y2 z2
    #                                               x3 y3 z3}
    # SOURCE
    lassign [matricize $m] v1 v2 v3
    return [concat $v1\n$v2\n$v3]
}
#******


#****f* generic_struct_utils/::pwtk::supercell3D
proc ::pwtk::supercell3D {unitvec supercell {unitKmesh {}}} {
    # USAGE
    #   supercell3D unitvec supercell ?unitKmesh?
    #
    # ARGUMENTS
    # * unitvec --- unitcell lattice vectors (a 3x3 matrix in any form accepted by ::pwtk::matricize), e.g.,
    #              either {{xa ya za} {xb yb zb} {xc yc zc}} or {xa ya za  xb yb zb  xc yc zc} ...
    
    # * supercell --- a 3x3 expansion matrix, in any form accepted by ::pwtk::matricize, i.e., either NxMxL,
    #                x1.y1.z1_x2.y2.z2_x3.y3.z3, {{x1 y1 z1} {x2 y2 z2} {x3 y3 z3}}, or
    #                {x1 y1 z1  x2 y2 z2  x3 y3 z3}
    
    # * unitKmesh --- (optional) K-mesh for the unitcell in the K1xK2xK3 or "K1 K2 K3" form;
    #                if specified, the k-mesh for the supercell is generated.
    #
    # PURPOSE
    #   Generate a supercell vectors from the unitcell Bravais
    #   lattice vectors (unitvec) and the supercell expansion matrix
    #   (supercell), i.e.:
    #
    #      superVecs = supercell x unitvec
    #
    #   If the unitKmesh argument (i.e., a K-mesh of the unitcell) is
    #   specified, a k-mesh for the supercell is generated, which 
    #   is of compatible quality (density) to the "unitKmesh".
    #
    #   Note that the routine is agnostic about the units; arguments are treated as numeric matrices.
    #
    # RETURN VALUE
    #   if unitKmesh NOT specified:
    #      * supercell lattice vectors 
    #   else:
    #      * a list of supercell lattice vectors and supercell k-mesh as [list $superVecs $supeKmesh]
    #
    # SOURCE

    set path_ [namespace path]
    namespace path ::math::linearalgebra
    
    set unitvec   [matricize $unitvec]
    set supercell [matricize $supercell]

    if { [shape $unitvec] ne "3 3" } {
        ::pwtk::error "wrong format of the unit-cell lattice vectors,
got \"$unitvec\" but expected a 3x3 matrix" 1
    }
    if { [shape $supercell] ne "3 3" } {
        ::pwtk::error "wrong format of the supercell expansion matrix,
got \"$supercell\"
but expected a 3x3 matrix in the form of \"{x1 y1 z1} {x2 y2 z2} {x3 y3 z3}\",
x1.y1.z1_x2.y2.z2_x3.y3.z3, or MxNxL" 1
    }
    if { abs([det $unitvec]) < 1e-6 } {
        ::pwtk::error "singular \"unitvec\" matrix $unitvec" 1
    }
    if { abs([det $supercell]) < 1e-6 } {
        ::pwtk::error "singular \"supercell\" matrix $supercell" 1
    }

    # calculate supercell
    
    set supervec [matmul $supercell $unitvec]
    if { abs([det $supervec]) < 1e-6 } {
        ::pwtk::error "generated supercell is singular: $supervec" 1
    }

    if { $unitKmesh eq {} } {
        set result $supervec
    } else {
        set unitKmesh [Kmeshize $unitKmesh 3]
        
        # check that unitKmesh is a number list; a real numbers are allowed for unitKmesh as to have more accurate scaling!
        if { ! [::pwtk::type::numberlist posreal -strict $unitKmesh] } {
            ::pwtk::error "wrong format of the k-mesh, must be \"k1 k2 k3\" but got $unitKmesh" 1
        }

        # calc inverse norm of supercell vectors
        lassign $supervec v1 v2 v3
        lassign [list [expr 1.0/[norm $v1]] [expr 1.0/[norm $v2]] [expr 1.0/[norm $v3]]] in1 in2 in3

        set nkk [::tcl::mathop::* {*}$unitKmesh]        
        set skk [expr double($nkk)/abs([det $supercell])]
        # skk = ik**3 * in1 * in2 * in3, hence:
        set ik [expr ($skk / ($in1*$in2*$in3))**(1.0/3.0)]

        set result [list $supervec [list [expr max(round($ik*$in1),1)] [expr max(round($ik*$in2),1)] [expr max(round($ik*$in3),1)]] ]
    }
    
    namespace path $path_

    return $result
}
#******

    
#****f* generic_struct_utils/::pwtk::supercell2D
proc ::pwtk::supercell2D {unitvec supercell {unitKmesh {}}} {
    # USAGE
    #   supercell2D unitvec supercell ?unitKmesh?
    #
    # ARGUMENTS
    # * unitvec --- unitcell lattice vectors (either a 2x2 or 3x3 matrix in any form accepted by ::pwtk::matricize);
    #              if "unitvec" is a 3x3 matrix, only the "{xa ya} {xb yb}" part is used
    
    # * supercell --- a 2x2 (or 3x3) expansion matrix, in the any form accepted by ::pwtk::matricize, i.e., either NxM,
    #                x1.y1._x2.y2, {{x1 y1} {x2 y2}}, or {x1 y1  x2 y2}; if "supercell" is a 3x3 matrix,
    #                only the "{x1 y1} {x2 y2}" part is used
    
    # * unitKmesh --- (optional) K-mesh for the unitcell in the K1xK2xK3, K1xK2, "K1 K2 K3", or "K1 K2" form;
    #                if specified, the k-mesh for the supercell is generated.
    #
    # PURPOSE
    #   Generate a 2D supercell vectors from the unit-cell Bravais
    #   lattice vectors (unitvec) and the supercell expansion matrix
    #   (supercell), i.e.:
    #
    #      supervec = supercell x unitvec
    #
    #   If the unitKmesh argument (i.e., a K-mesh of the unitcell) is
    #   specified, a k-mesh for the supercell is generated, which
    #   is of compatible quality (density) to the "unitKmesh".
    #
    #   Note that the routine is agnostic about the units; arguments are treated as numeric matrices.
    #
    # RETURN VALUE
    #   if unitKmesh NOT specified:
    #      * supercell lattice vectors
    #   else:
    #      * a list of supercell lattice vectors and supercell k-mesh as [list $supervec $supeKmesh]
    #
    #   The supercell lattice vectors are returned as a 3x3 matrix in the following form:
    #      {{x1 y1 0.0} {x2 y2 0.0} {0.0 0.0 1.0}}
    #
    #   K-mesh is returned in the following form:
    #      "kx  ky  1"    
    #
    # SOURCE

    set path_ [namespace path]
    namespace path ::math::linearalgebra
    
    set unitvec   [latvec2Dto3D [matricize $unitvec] 1.0]
    set supercell [latvec2Dto3D [matricize $supercell] 1.0]

    if { [shape $unitvec] ne "3 3" } {
        ::pwtk::error "wrong format of the 2D unit-cell lattice vectors,
got \"$unitvec\"
but expected a 2x2 (or a 3x3) matrix" 1
    }
    if { [shape $supercell] ne "3 3" } {
        ::pwtk::error "wrong format of the 2D supercell expansion matrix,
got \"$supercell\"
but expected a 2x2 (or 3x3) matrix" 1
    }
    if { abs([det $unitvec]) < 1e-6 } {
        ::pwtk::error "singular \"unitvec\" matrix $unitvec" 1
    }
    if { abs([det $supercell]) < 1e-6 } {
        ::pwtk::error "singular \"supercell\" matrix $supercell" 1
    }

    # calculate supercell
    
    set supervec [matmul $supercell $unitvec]
    if { abs([det $supervec]) < 1e-6 } {
        ::pwtk::error "generated supercell is singular: $supervec" 1
    }

    if { $unitKmesh eq {} } {
        set result $supervec
    } else {
        set unitKmesh [Kmeshize $unitKmesh 2]
        # check that unitKmesh is a number list; a real numbers are allowed for unitKmesh as to have more accurate scaling!
        if { ! [::pwtk::type::numberlist posreal -strict $unitKmesh] } {
            ::pwtk::error "wrong format of the \"unitKmesh\" k-mesh, must be \"k1 k2 ?k3?\" but got $unitKmesh" 1
        }
        lassign $unitKmesh k1 k2
       
        # calc inverse norm of supercell vectors
        lassign $supervec v1 v2
        lassign [list [expr 1.0/[norm $v1]] [expr 1.0/[norm $v2]]] in1 in2

        set nkk [expr $k1*$k2]
        set skk [expr double($nkk)/abs([det $supercell])]
        # skk = ik**2 * in1 * in2, hence:
        set ik [expr sqrt($skk / ($in1*$in2))]

        set result [list $supervec [list [expr max(1,round($ik*$in1))] [expr max(1,round($ik*$in2))] 1] ]
    }
    
    namespace path $path_

    return $result
}
#******


#***internal...
proc ::pwtk::pwi::supercellCommonOpts_ {} {
    uplevel 1 {
        # -unit & -unitvec
        set unit    [string tolower $opt(unit)]
        set unitvec $opt(unitvec)
    
        if { $unitvec eq {} } {
            set unit    [::pwtk::input::cardGetFlags   CELL_PARAMETERS trim]
            set unitvec [::pwtk::input::cardGetContent CELL_PARAMETERS]
            if { [llength $unitvec] != 9 } {
                ::pwtk::error "cannot generate a supercell, unitcell vectors are not (properly) defined;
either set the CELL_PARAMETERS card or s       pecify the unitcell vectors via the -unitvec option" 1
            }
        }
        set unitvec [::pwtk::matricize $unitvec]
        
        # -kshift
        set ku [::pwtk::input::cardGetFlags   K_POINTS trim]
        set kp [::pwtk::input::cardGetContent K_POINTS]
        if { $opt(kshift) eq {} } {
            if { [string match *automatic* $ku] } {            
                set opt(kshift) [lrange $kp 3 end]
            } else {
                set opt(kshift) "1 1 1"
            }
        } elseif { [llength $opt(kshift)] != 3 } {
            ::pwtk::error "wrong value of the -kshift option; got \"$opt(kshift)\"
but expected a list of 3 binary numbers" 1
        }
        
        # transform unitcell vectors to Bohr units
    
        set unitalat [::pwtk::pwi::alat]
        switch -glob -- $unit {
            bohr {}
            alat {
                set unitvec [scale $unitalat $unitvec]
            }
            angs* {
                set unitvec [scale $::pwtk::angs2bohr $unitvec]
            }
            default {
                ::pwtk::error "wrong unit \"$unit\", must be one of alat, angstrom, or bohr" 1
            }
        }
    }
}


#****f* ::pwtk::pwi/::pwtk::pwi::supercell
# SYNOPSIS
proc ::pwtk::pwi::supercell {args} {
    # USAGE
    #   ::pwtk::pwi::supercell  ?-unit alat|angs|bohr?  ?-unitvec UNITVEC?  ?-kshift "S1 S2 S3"?  supercell  ?unitKmesh?
    #
    # PURPOSE
    #   Generate CELL_PARAMETERS and, if requested, K_POINTS for a generic supercell.
    #
    # OPTIONS
    # * -unit UNIT --- the length unit for unitvec (default = bohr, allowed values = alat, angs*, bohr)
    
    # * -unitvec UNITVEC --- the 3D unitcell Bravais lattice vectors in any form accepted by ::pwtk::matricize.
    #                        If not set, the unitcell vectors from the CELL_PARAMETERS card are taken.
    
    # * -kshift "S1 S2 S2" --- a list of k-mesh offsets, e.g., "1 1 1" or "0 0 0" or ...
    #                          (default taken from K_POINTS or "1 1 1" if the K_POINTS card does not exist)
    #
    # ARGUMENTS
    # * supercell --- supercell expansion matrix specified in any form accepted by ::pwtk::matricize
    # * unitKmesh --- (optional) K-mesh for the unitcell in the K1xK2xK3 or "K1 K2 K3" form;
    #                if specified, the k-mesh for the supercell is generated.
    #
    # SOURCE

    set nargmin 1
    set nargmax 2
    set usage "?-unit alat|angs|bohr?  ?-unitvec unitvec?  supercell  ?unitKmesh?"
    set options {
        {unit.arg     bohr  "alat of the 2D (1x1) unit cell"}
        {unitvec.arg  {}    "unitcell Bravais lattice vectors"}
        {kshift.arg   {}    "a list of k-mesh offsets"}
    }
    ::pwtk::parseOpt_    
    ::pwtk::checkOType_ -kshift $opt(kshift) {numberlist binary} "list of binary numbers"

    lassign $args supercell unitKmesh

    set path_ [namespace path]
    namespace path ::math::linearalgebra
    supercellCommonOpts_

    # generate supercell & k-mesh

    if { $unitKmesh eq {} } {
        set supervec [::pwtk::supercell3D $unitvec $supercell]
    } else {
        lassign [::pwtk::supercell3D $unitvec $supercell $unitKmesh] supervec kp
    }
    set kmesh [list {*}$kp {*}$opt(kshift)]
    
    # rescale the supercell vectors so that norm(v1) = 1.0
    lassign $supervec v1
    set alat [norm $v1]
    set supervec [scale [expr 1.0/$alat] $supervec]
    lassign $supervec v1 v2 v3

    set nb [norm $v2]
    set nc [norm $v3]

    # set the pw.x input
    
    SYSTEM "ibrav = 0, celldm(1) = $alat, A = "
    CELL_PARAMETERS (alat) [::pwtk::m2cell $supervec]
    if { $unitKmesh != {} } {
        K_POINTS (automatic) $kmesh
    }

    # print the basic info to stdout

    set sv [::pwtk::matricize $supercell]
    set area [expr abs([det $sv])]
    
    ::pwtk::print ++++ "Auto-generation of the supercell..."
    if { $unitKmesh ne {} } {
        ::pwtk::print "\nUnitcell k-mesh:  [::pwtk::Kmeshize $unitKmesh 3]"
    }
    ::pwtk::print "
Unitcell lattice vectors (in Bohr):

[show $unitvec  %15.10f]
Supercell expansion matrix:  
                             
[show $sv %3.0f]
Supercell:
   alat = [format %10.6f $alat] Bohr = [format %10.6f [expr $alat/$unitalat]] unitcell-alat
   
   Size of vector A  = [format %8.4f 1.0] alat
   Size of vector B  = [format %8.4f $nb] alat
   Size of vector C  = [format %8.4f $nc] alat
   
   Area of supercell = [format %8.4f $area] of the unitcell area
"    
    if { $unitKmesh != {} } {
        ::pwtk::print "The following cell parameters and k-points cards were generated:\n"    
        ::pwtk::input::cardPrint CELL_PARAMETERS
        ::pwtk::input::cardPrint K_POINTS
    } else {
        ::pwtk::print "The following cell parameters were generated:\n"    
        ::pwtk::input::cardPrint CELL_PARAMETERS
    }

    namespace path $path_
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::supercell_slab
# SYNOPSIS
proc ::pwtk::pwi::supercell_slab {args} {
    # USAGE
    #   ::pwtk::pwi::supercell_slab  ?-unit alat|angs|bohr?  ?-unitvec UNITVEC?  ?-kshift "S1 S2 S2"?  ?-slabz THICKNESS_BOHR?  ?-vacuum VACUUM_SPECS?  supercell ?unitKmesh?
    #
    # PURPOSE
    #   Generate CELL_PARAMETERS and, if requested, K_POINTS and
    #   dipole correction for a 2D-slab supercell.
    #
    #   It is assumed that the slab is oriented along the XY plane
    #   and Z is the surface normal direction.
    #
    # OPTIONS
    # * -unit UNIT --- the length unit for unitvec (default = bohr, allowed values = alat, angs*, bohr)
    
    # * -unitvec UNITVEC --- 2D or 3D unitcell Bravais lattice vectors in any form accepted by ::pwtk::matricize.
    #                        If not set, the unitcell vectors from the CELL_PARAMETERS card are used.
    
    # * -kshift "S1 S2 S2"   --- a list of k-mesh offsets, e.g., "1 1 1" or "0 0 0" or ...
    #                            (default taken from K_POINTS; if the K_POINTS card does not exist, the "1 1 1" k-mesh is assumed)
    
    # * -slabz THICKNESS_BOHR --- thickness of the slab along the surface normal Z direction (in Bohr)
    
    # * -vacuum VACUUM_SPECS --- either a single value (default = 16.0)
    #                            or a list of three values as {vac1st diplayer vac2nd};
    #                            either possibility is in the Bohr units
    #    
    # Further explanation of the "-vacuum VACUUM_SPECS" option:
    
    # * if "VACUUM_SPECS" is a single number, e.g., -vacuum 16.0, it
    #   corresponds to the vacuum thickness (in Bohr). In this case, no
    #   dipole correction is activated;
    
    # * if "VACUUM_SPECS" is a list with 3 numbers, e.g., -vacuum
    #   {15.0 2.0 16.0}, it corresponds to "vac1st diplayer vac2nd"
    #   (see ::pwtk::pwi::dipoleCorr). In this case, dipole correction
    #   is activated. If any of vac1st, diplayer, or vac2nd is an
    #   empty string, the corresponding default value is used.
    #
    # ARGUMENTS
    # * supercell --- 2x2 (or 3x3) supercell expansion matrix (in any form accepted by ::pwtk::matricize)
    # * unitKmesh --- (optional) K-mesh for the unitcell in the K1xK2xK3, K1xK2, "K1 K2 K3", or "K1 K2" form;
    #                 if specified, the K_POINTS card for the supercell is generated.
    #
    # SOURCE

    set nargmin 1
    set nargmax 2
    set usage "?-unit alat|angs|bohr?  ?-unitvec unitvec?  ?-kshift \"s1 s2 s2\"?  ?-slabz thicknessBohr?  ?-vacuum vacuum-specsBohr?  supercell  ?unitKmesh?"
    set options {
        {unit.arg     bohr "alat of the 2D (1x1) unit cell"}
        {unitvec.arg  {}   "unitcell Bravais lattice vectors"}
        {kshift.arg   {}   "a list of k-mesh offsets"}
        {slabz.arg    0.0  "slab thickness"}
        {vacuum.arg   {}   "either vacuum thickness or \"vac1st diplayer vac2nd\" list"}
    }
    ::pwtk::parseOpt_
    ::pwtk::checkOType_ -kshift  $opt(kshift)  {numberlist binary}  "list of binary numbers"
    ::pwtk::checkOType_ -slabz   $opt(slabz)   {number nonnegreal}  "non-negative real number"
    ::pwtk::checkOType_ -vacuum  $opt(vacuum)  {numberlist posreal} "list of positive numbers"

    lassign $args supercell unitKmesh

    set path_ [namespace path]
    namespace path ::math::linearalgebra
    supercellCommonOpts_

    # -slabz
    # -vacuum
    if { $opt(vacuum) == {} } {
        set vacuum 16.0
    } else {
        set vlen [llength $opt(vacuum)]
        if { $vlen == 1 } {
            set vacuum $opt(vacuum)
        } elseif { $vlen == 3 } {
            lassign $opt(vacuum) vac1st diplayer vac2nd
        } else {
            ::pwtk::error "wrong value of the -vacuum option; got \"$opt(vacuum)\"
but expected either a single number or a list of 3 nunmbers" 1
        }
    }
        
    # get the size of the C vector in Bohr
    
    ::pwtk::ifexist vacuum {
        # "vacuum" exist only for the case of NO dipole-correction
        # (see above the parsing of the -vacuum option)
        set Z_bohr [expr $opt(slabz) + $vacuum]
    } else {
        # dipole-correction case
        set Z_bohr [dipoleCorr -vac1st $vac1st -diplayer $diplayer -vac2nd $vac2nd $opt(slabz)]
    }

    # generate supercell & k-mesh
    
    if { $unitKmesh eq {} } {
        set supervec [::pwtk::supercell2D $unitvec $supercell]
    } else {
        lassign [::pwtk::supercell2D $unitvec $supercell $unitKmesh] supervec kp
    }
    set kmesh [list {*}$kp {*}$opt(kshift)]
    
    # rescale the supercell vectors so that norm(v1) = 1.0 && add Z-thickness
    lassign $supervec v1
    set alat [norm $v1]    
    set supervec [::pwtk::latvec2Dto3D [scale [expr 1.0/$alat] $supervec] [expr $Z_bohr/$alat]]
    lassign $supervec v1 v2 v3

    set nb    [norm $v2]    
    set nc    [norm $v3]

    # set the pw.x input
    
    SYSTEM "ibrav = 0, celldm(1) = $alat, A = "
    CELL_PARAMETERS (alat) [::pwtk::m2cell $supervec]
    if { $unitKmesh != {} } {
        K_POINTS (automatic) $kmesh
    }

    # print the basic info to stdout

    set sv2D [::pwtk::latvec3Dto2D [::pwtk::matricize $supercell]]
    set sv3D [::pwtk::latvec2Dto3D $sv2D 1.0]    
    set area [expr abs([det $sv3D])]
    
    ::pwtk::print ++++ "Auto-generation of the SLAB supercell..."
    if { $unitKmesh ne {} } {
        ::pwtk::print "\nUnitcell k-mesh:  [::pwtk::Kmeshize $unitKmesh 2]"
    }
    ::pwtk::print "
2D unitcell lattice vectors (in Bohr):

[show [::pwtk::latvec3Dto2D $unitvec] %15.10f]
2D supercell expansion matrix:  
                             
[show $sv2D %3.0f]
Supercell:
   alat = [format %.6f $alat] Bohr = [format %.6f [expr $alat/$unitalat]] unitcell-alat
   
   Size of vector A  = [format %8.4f 1.0] alat
   Size of vector B  = [format %8.4f $nb] alat
   Size of vector C  = [format %8.4f $nc] alat
   
   2D area of supercell = [format %8.4f $area] of the unitcell area
   
   Expected slab thickness = $opt(slabz) Bohr"
    
    ::pwtk::ifexist vacuum {
        ::pwtk::print "   Vacuum thickness        = $vacuum Bohr\n"
    } else {
        ::pwtk::print "   Vacuum thickness        = [join [::pwtk::dipcorrDefault_ $vac1st $diplayer $vac2nd] { + }] Bohr\n"
    }
    if { $unitKmesh != {} } {
        ::pwtk::print "The following cell parameters and k-points cards were generated:\n"    
        ::pwtk::input::cardPrint CELL_PARAMETERS
        ::pwtk::input::cardPrint K_POINTS
    } else {
        ::pwtk::print "The following cell parameters were generated:\n"    
        ::pwtk::input::cardPrint CELL_PARAMETERS
    }
        
    namespace path $path_
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::supercell_fccHKL
# SYNOPSIS
proc ::pwtk::pwi::supercell_fccHKL {args} {
    # USAGE
    #   ::pwtk::pwi::supercell_fccHKL  ?-alat1x1 ALAT?  ?-nk1 NK1?  ?-kshift "S1 S2 S2"?  ?-adsize SIZE_BOHR?  ?-vacuum VACUUM_SPECS?  hkl  supercell  Nlayers
    #
    # PURPOSE
    #   Generate CELL_PARAMETERS and K_POINTS for a supercell of the
    #   fcc(hkl) slab. Set also dipole correction if so requested by
    #   the -vacuum option (see below).
    #
    #   It is assumed that the slab is oriented along the XY plane
    #   and Z is the surface normal direction.
    #
    # BEWARE
    #   All lengths are in Bohr units!
    #
    # OPTIONS
    # * -alat1x1 ALAT   --- "alat" of the 2D (1x1) unitcell in Bohr units (if not specified, current "alat" is used)
    
    # * -nk1 NK1        --- nk1 of (nk1 x nk2) k-mesh of the 1x1-fcc(hkl) unitcell
    #                       (if not specified, nk1 from K_POINTS is used)
    
    # * -kshift "S1 S2 S2"  --- a list of k-mesh offsets, e.g., "1 1 1" or "0 0 0" or ...
    #                           (default taken from K_POINTS or "1 1 1" if K_POINTS card does not exist)
    
    # * -adsize SIZE_BOHR   --- size of the largest-considered adsorbate in Bohr units (default = 0.0)
    
    # * -vacuum VACUUM_SPECS --- either a single value (in Bohr units, default = 16.0 bohr)
    #                            or a list of three values as "vac1st diplayer vac2nd" in Bohr units;
    #                            for the latter, a dipole correction is activated
    #    
    # Further explanation of the -vacuum option:
    #
    # * if "vacuum-specs" is a single number, it corresponds to the vacuum thickness, i.e.:
    #       -vacuum 16.0
    #
    # * if "vacuum-specs" is a list with 3 numbers, it corresponds to
    #   "vac1st diplayer vac2nd" (see ::pwtk::pwi::dipoleCorr), i.e.:
    #       -vacuum {15.0 2.0 16.0}   
    #   In this case dipole correction is switched on. If any of vac1st,
    #   diplayer, or vac2nd is an empty string, the corresponding default value is used.
    #
    # ARGUMENTS
    # * hkl --- Miller indices (allowed values: 111, 100, 110, or any permutation of them)
    # * supercell --- 2x2 (or 3x3) supercell expansion matrix (in any form accepted by ::pwtk::matricize)
    # * Nlayers --- number of layers in the slab
    #
    # In addition to the math::linearalgebra form, the supercell can
    # be specified in the diagonal NxM or in the a1.b1_a2.b2
    # notation. The latter corresponds to the following expansion
    # matrix: {{a1 b1} {a2 b2}}
    #
    # SOURCE

    set narg 3
    set usage "?-alat1x1 value?  ?-nk1 nk1?  ?-kshift {s1 s2 s2}?  ?-adsize size?  ?-vacuum vacuum-specs?  hkl supercell Nlayers"
    set options {
        {alat1x1.arg  {}  "alat of the 2D (1x1) unitcell"}
        {nk1.arg      {}  "nk1 of (nk1 x nk2) k-mesh of the 1x1-fcc(hkl) unitcell"}
        {kshift.arg   {}  "a list of k-mesh offsets"}
        {adsize.arg   0.0 "size of the largest adsorbate to consider"}
        {vacuum.arg   {}  "either vacuum thickness or {vac1st diplayer vac2nd} list"}
    }
    ::pwtk::parseOpt_
    ::pwtk::checkOType_ -alat1x1 $opt(alat1x1) {number posreal} "positive real number"
    ::pwtk::checkOType_ -nk1     $opt(nk1)     {number posint}  "positive integer"
    ::pwtk::checkOType_ -kshift  $opt(kshift)  {numberlist binary} "list of binary numbers"
    ::pwtk::checkOType_ -adsize  $opt(adsize)  {number nonnegreal} "non-negative number"
    ::pwtk::checkOType_ -vacuum  $opt(vacuum)  {numberlist posreal} "list of positive numbers"

    lassign $args hkl supercell Nlayers
    
    # -alat1x1
    if { $opt(alat1x1) eq {} } {
        set opt(alat1x1) [::pwtk::pwi::alat]
        if { $opt(alat1x1) == 0.0 } {
            ::pwtk::error "cannot generate a supercell; alat1x1 is not set" 1
        }
    }
    puts "debug: alat = $opt(alat1x1)"
    
    set ku [::pwtk::input::cardGetFlags   K_POINTS trim]
    set kp [::pwtk::input::cardGetContent K_POINTS]

    # -nk1
    set nk1 $opt(nk1)
    if { $nk1 eq {} } {
        if { [string match *automatic* $ku] } {            
            set nk1 [lindex $kp 0]
        } else {
            set nk1 12
        }
    }
    
    # -kshift
    if { $opt(kshift) eq {} } {
        if { [string match *automatic* $ku] } {            
            set opt(kshift) [lrange $kp 3 end]
        } else {
            set opt(kshift) "1 1 1"
        }
    } elseif { [llength $opt(kshift)] != 3 } {
        ::pwtk::error "wrong value of the -kshift option; got \"$opt(kshift)\"
but expected a list of 3 binary numbers" 1
    }

    # -vacuum
    if { $opt(vacuum) == {} } {
        set vacuum 16.0
    } else {
        set vlen [llength $opt(vacuum)]
        if { $vlen == 1 } {
            set vacuum $opt(vacuum)
        } elseif { $vlen == 3 } {
            lassign $opt(vacuum) vac1st diplayer vac2nd
        } else {
            ::pwtk::error "wrong value of the -vacuum option; got \"$opt(vacuum)\"
but expected either a single number or a list of 3 numbers" 1
        }
    }

    set path_ [namespace path]
    namespace path ::math::linearalgebra

    # fcc bulk lattice parameter
    set a0_ [expr $opt(alat1x1)*sqrt(2)]

    # fcc(HKL) unitcell vectors
    switch -- [string trim [string map {{ } {}} $hkl] ()] {
        111 {
            set unitvec "1.0  0.0
                        -0.5  [expr 0.5*sqrt(3)]"
            set unitKmesh "$nk1 $nk1"
            set d12_bohr  [expr $a0_*sqrt(3)/3.0]
        }
        110 - 101 - 011 {
            set unitvec "1.0  0.0
                         0.0  [expr sqrt(2)]"
            set unitKmesh "$nk1 [expr $nk1/sqrt(2)]"
            set d12_bohr  [expr $a0_*sqrt(2)/4.0]
        }
        100 - 010 - 001 {
            set unitvec "1.0  0.00
                         0.0  1.00"
            set unitKmesh "$nk1 $nk1"
            set d12_bohr  [expr $a0_/2.0]
        }
        default {
            ::pwtk::error "unsupported Miller indices $hkl, must be 111, 110, or 100" 1
        }
    }

    # get the size of C vector in Bohr

    set fullslab_height [expr ($Nlayers-1)*$d12_bohr + $opt(adsize)]; # in Bohr
    
    ::pwtk::ifexist vacuum {
        # "vacuum" variable exist only for the case of NO dipole-correction
        # (see above the parsing of the -vacuum option)
        set Z_bohr [expr $fullslab_height + $vacuum]
    } else {
        # dipole-correction case
        set Z_bohr [dipoleCorr -vac1st $vac1st -diplayer $diplayer -vac2nd $vac2nd  $fullslab_height]
    }

    # generate a supercell
    lassign [::pwtk::supercell2D $unitvec $supercell $unitKmesh] supervec kp

    # get supercell alat (in units of alat1x1)
    lassign $supervec v1
    set alat [norm $v1]
    set alatBohr [expr $alat*$opt(alat1x1)]
    
    # rescale the supercell vectors so that norm(v1) = 1.0 and set Z 
    set supervec [::pwtk::latvec2Dto3D [scale [expr 1.0/$alat] $supervec] [expr $Z_bohr/$alatBohr]]
    lassign $supervec v1 v2 v3
    
    set nb    [norm $v2]
    set nc    [norm $v3]
    set kmesh [list {*}$kp {*}$opt(kshift)]
    
    SYSTEM "ibrav = 0, celldm(1) = [expr $alatBohr], A = "
    CELL_PARAMETERS (alat) [::pwtk::m2cell $supervec]
    K_POINTS (automatic) $kmesh

    # print the basic info to stdout

    set sv2D [::pwtk::latvec3Dto2D [::pwtk::matricize $supercell]]
    set sv3D [::pwtk::latvec2Dto3D $sv2D 1.0]    
    set area [expr abs([det $sv3D])]
    
    ::pwtk::print ++++ "Auto-generation of the fcc($hkl) SLAB supercell..."
    ::pwtk::print "
Number of expected layers in the slab:  $Nlayers
Unitcell k-mesh:  [lmap k [::pwtk::Kmeshize $unitKmesh 2] {expr round($k)}]
    
2D unitcell lattice vectors (in Bohr):

[show [scale $opt(alat1x1) [::pwtk::matricize $unitvec]] %15.10f]
2D supercell expansion matrix:  
                             
[show $sv2D %3.0f]
Supercell:
   alat = [format %.6f $alatBohr] Bohr = [format %.6f $alat] unitcell-alat
   
   Size of vector A  = [format %8.4f 1.0] alat
   Size of vector B  = [format %8.4f $nb] alat
   Size of vector C  = [format %8.4f $nc] alat
   
   2D area of supercell = [format %8.4f $area] of the (1x1)-unitcell area
   
   Expected slab thickness = [format %.4f $fullslab_height] Bohr
   Expected adsorbate size = $opt(adsize) Bohr"
    
    ::pwtk::ifexist vacuum {
        ::pwtk::print "   Vacuum thickness        = $vacuum Bohr\n"
    } else {
        ::pwtk::print "   Vacuum thickness        = [join [::pwtk::dipcorrDefault_ $vac1st $diplayer $vac2nd] { + }] Bohr\n"
    }
    ::pwtk::print "The following cell parameters and k-points cards were generated:\n"
    
    ::pwtk::input::cardPrint CELL_PARAMETERS
    ::pwtk::input::cardPrint K_POINTS

    namespace path $path_
}
#******
