#
# $RCSfile: auto-inputs-doc.tcl,v $ --
#
#      This file contains the documentation for the auto generated
#      commands (see auto-inputs.tcl) associated with QE programs.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: auto-inputs-doc.tcl,v 1.0 2024/00/00 00:00:00 kokalj Exp $ 
#


#****a* Programs/cppp.x input
# DESCRIPTION
#   Handling of the cppp.x input. For further details, see ::pwtk::cpppi.
#******

#****n* cppp.x input/::pwtk::cpppi
# NAME
#   ::pwtk::cpppi
# DESCRIPTION
#   Namespace for handling the cppp.x input.
#******

#****f* ::pwtk::cpppi/::pwtk::cpppi::fprint
# USAGE
#   ::pwtk::cpppi::fprint ?FILE?        
# PURPOSE
#   Print the content of the cppp.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::cpppi/::pwtk::cpppi::get
# USAGE
#   ::pwtk::cpppi::get
# DESCRIPTION    
#   Returns the content of the cppp.x input 
#******

#****f* ::pwtk::cpppi/::pwtk::cpppi::clear
# USAGE
#   ::pwtk::cpppi::clear
# PURPOSE
#   Clear the cppp.x input data.
#******

#****f* ::pwtk::cpppi/::pwtk::cpppi::load_fromCPPPI
# USAGE
#   ::pwtk::cpppi::load_fromCPPPI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing cppp.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the cppp.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runCPPP
# USAGE 
#   runCPPP  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the cppp.x input file from the input data and run the cppp.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the cppp.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the cppp.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the cppp.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/kcw.x input
# DESCRIPTION
#   Handling of the kcw.x input. For further details, see ::pwtk::kcwi.
#******

#****n* kcw.x input/::pwtk::kcwi
# NAME
#   ::pwtk::kcwi
# DESCRIPTION
#   Namespace for handling the kcw.x input.
#******

#****f* ::pwtk::kcwi/::pwtk::kcwi::fprint
# USAGE
#   ::pwtk::kcwi::fprint ?FILE?        
# PURPOSE
#   Print the content of the kcw.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::kcwi/::pwtk::kcwi::get
# USAGE
#   ::pwtk::kcwi::get
# DESCRIPTION    
#   Returns the content of the kcw.x input 
#******

#****f* ::pwtk::kcwi/::pwtk::kcwi::clear
# USAGE
#   ::pwtk::kcwi::clear
# PURPOSE
#   Clear the kcw.x input data.
#******

#****f* ::pwtk::kcwi/::pwtk::kcwi::load_fromKCWI
# USAGE
#   ::pwtk::kcwi::load_fromKCWI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing kcw.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the kcw.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runKCW
# USAGE 
#   runKCW  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the kcw.x input file from the input data and run the kcw.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the kcw.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the kcw.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the kcw.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/postahc.x input
# DESCRIPTION
#   Handling of the postahc.x input. For further details, see ::pwtk::postahci.
#******

#****n* postahc.x input/::pwtk::postahci
# NAME
#   ::pwtk::postahci
# DESCRIPTION
#   Namespace for handling the postahc.x input.
#******

#****f* ::pwtk::postahci/::pwtk::postahci::fprint
# USAGE
#   ::pwtk::postahci::fprint ?FILE?        
# PURPOSE
#   Print the content of the postahc.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::postahci/::pwtk::postahci::get
# USAGE
#   ::pwtk::postahci::get
# DESCRIPTION    
#   Returns the content of the postahc.x input 
#******

#****f* ::pwtk::postahci/::pwtk::postahci::clear
# USAGE
#   ::pwtk::postahci::clear
# PURPOSE
#   Clear the postahc.x input data.
#******

#****f* ::pwtk::postahci/::pwtk::postahci::load_fromPOSTAHCI
# USAGE
#   ::pwtk::postahci::load_fromPOSTAHCI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing postahc.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the postahc.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runPOSTAHC
# USAGE 
#   runPOSTAHC  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the postahc.x input file from the input data and run the postahc.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the postahc.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the postahc.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the postahc.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/band_interpolation.x input
# DESCRIPTION
#   Handling of the band_interpolation.x input. For further details, see ::pwtk::band_inti.
#******

#****n* band_interpolation.x input/::pwtk::band_inti
# NAME
#   ::pwtk::band_inti
# DESCRIPTION
#   Namespace for handling the band_interpolation.x input.
#******

#****f* ::pwtk::band_inti/::pwtk::band_inti::fprint
# USAGE
#   ::pwtk::band_inti::fprint ?FILE?        
# PURPOSE
#   Print the content of the band_interpolation.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::band_inti/::pwtk::band_inti::get
# USAGE
#   ::pwtk::band_inti::get
# DESCRIPTION    
#   Returns the content of the band_interpolation.x input 
#******

#****f* ::pwtk::band_inti/::pwtk::band_inti::clear
# USAGE
#   ::pwtk::band_inti::clear
# PURPOSE
#   Clear the band_interpolation.x input data.
#******

#****f* ::pwtk::band_inti/::pwtk::band_inti::load_fromBAND_INTI
# USAGE
#   ::pwtk::band_inti::load_fromBAND_INTI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing band_interpolation.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the band_interpolation.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runBAND_INTERPOLATION
# USAGE 
#   runBAND_INTERPOLATION  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the band_interpolation.x input file from the input data and run the band_interpolation.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the band_interpolation.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the band_interpolation.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the band_interpolation.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/d3hess.x input
# DESCRIPTION
#   Handling of the d3hess.x input. For further details, see ::pwtk::d3hessi.
#******

#****n* d3hess.x input/::pwtk::d3hessi
# NAME
#   ::pwtk::d3hessi
# DESCRIPTION
#   Namespace for handling the d3hess.x input.
#******

#****f* ::pwtk::d3hessi/::pwtk::d3hessi::fprint
# USAGE
#   ::pwtk::d3hessi::fprint ?FILE?        
# PURPOSE
#   Print the content of the d3hess.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::d3hessi/::pwtk::d3hessi::get
# USAGE
#   ::pwtk::d3hessi::get
# DESCRIPTION    
#   Returns the content of the d3hess.x input 
#******

#****f* ::pwtk::d3hessi/::pwtk::d3hessi::clear
# USAGE
#   ::pwtk::d3hessi::clear
# PURPOSE
#   Clear the d3hess.x input data.
#******

#****f* ::pwtk::d3hessi/::pwtk::d3hessi::load_fromD3HESSI
# USAGE
#   ::pwtk::d3hessi::load_fromD3HESSI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing d3hess.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the d3hess.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runD3HESS
# USAGE 
#   runD3HESS  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the d3hess.x input file from the input data and run the d3hess.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the d3hess.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the d3hess.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the d3hess.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/oscdft_et.x input
# DESCRIPTION
#   Handling of the oscdft_et.x input. For further details, see ::pwtk::oscdft_eti.
#******

#****n* oscdft_et.x input/::pwtk::oscdft_eti
# NAME
#   ::pwtk::oscdft_eti
# DESCRIPTION
#   Namespace for handling the oscdft_et.x input.
#******

#****f* ::pwtk::oscdft_eti/::pwtk::oscdft_eti::fprint
# USAGE
#   ::pwtk::oscdft_eti::fprint ?FILE?        
# PURPOSE
#   Print the content of the oscdft_et.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::oscdft_eti/::pwtk::oscdft_eti::get
# USAGE
#   ::pwtk::oscdft_eti::get
# DESCRIPTION    
#   Returns the content of the oscdft_et.x input 
#******

#****f* ::pwtk::oscdft_eti/::pwtk::oscdft_eti::clear
# USAGE
#   ::pwtk::oscdft_eti::clear
# PURPOSE
#   Clear the oscdft_et.x input data.
#******

#****f* ::pwtk::oscdft_eti/::pwtk::oscdft_eti::load_fromOSCDFT_ETI
# USAGE
#   ::pwtk::oscdft_eti::load_fromOSCDFT_ETI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing oscdft_et.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the oscdft_et.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runOSCDFT_ET
# USAGE 
#   runOSCDFT_ET  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the oscdft_et.x input file from the input data and run the oscdft_et.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the oscdft_et.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the oscdft_et.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the oscdft_et.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/oscdft_pp.x input
# DESCRIPTION
#   Handling of the oscdft_pp.x input. For further details, see ::pwtk::oscdft_ppi.
#******

#****n* oscdft_pp.x input/::pwtk::oscdft_ppi
# NAME
#   ::pwtk::oscdft_ppi
# DESCRIPTION
#   Namespace for handling the oscdft_pp.x input.
#******

#****f* ::pwtk::oscdft_ppi/::pwtk::oscdft_ppi::fprint
# USAGE
#   ::pwtk::oscdft_ppi::fprint ?FILE?        
# PURPOSE
#   Print the content of the oscdft_pp.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::oscdft_ppi/::pwtk::oscdft_ppi::get
# USAGE
#   ::pwtk::oscdft_ppi::get
# DESCRIPTION    
#   Returns the content of the oscdft_pp.x input 
#******

#****f* ::pwtk::oscdft_ppi/::pwtk::oscdft_ppi::clear
# USAGE
#   ::pwtk::oscdft_ppi::clear
# PURPOSE
#   Clear the oscdft_pp.x input data.
#******

#****f* ::pwtk::oscdft_ppi/::pwtk::oscdft_ppi::load_fromOSCDFT_PPI
# USAGE
#   ::pwtk::oscdft_ppi::load_fromOSCDFT_PPI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing oscdft_pp.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the oscdft_pp.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runOSCDFT_PP
# USAGE 
#   runOSCDFT_PP  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the oscdft_pp.x input file from the input data and run the oscdft_pp.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the oscdft_pp.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the oscdft_pp.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the oscdft_pp.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/ppacf.x input
# DESCRIPTION
#   Handling of the ppacf.x input. For further details, see ::pwtk::ppacfi.
#******

#****n* ppacf.x input/::pwtk::ppacfi
# NAME
#   ::pwtk::ppacfi
# DESCRIPTION
#   Namespace for handling the ppacf.x input.
#******

#****f* ::pwtk::ppacfi/::pwtk::ppacfi::fprint
# USAGE
#   ::pwtk::ppacfi::fprint ?FILE?        
# PURPOSE
#   Print the content of the ppacf.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::ppacfi/::pwtk::ppacfi::get
# USAGE
#   ::pwtk::ppacfi::get
# DESCRIPTION    
#   Returns the content of the ppacf.x input 
#******

#****f* ::pwtk::ppacfi/::pwtk::ppacfi::clear
# USAGE
#   ::pwtk::ppacfi::clear
# PURPOSE
#   Clear the ppacf.x input data.
#******

#****f* ::pwtk::ppacfi/::pwtk::ppacfi::load_fromPPACFI
# USAGE
#   ::pwtk::ppacfi::load_fromPPACFI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing ppacf.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the ppacf.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runPPACF
# USAGE 
#   runPPACF  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the ppacf.x input file from the input data and run the ppacf.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the ppacf.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the ppacf.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the ppacf.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/pprism.x input
# DESCRIPTION
#   Handling of the pprism.x input. For further details, see ::pwtk::pprismi.
#******

#****n* pprism.x input/::pwtk::pprismi
# NAME
#   ::pwtk::pprismi
# DESCRIPTION
#   Namespace for handling the pprism.x input.
#******

#****f* ::pwtk::pprismi/::pwtk::pprismi::fprint
# USAGE
#   ::pwtk::pprismi::fprint ?FILE?        
# PURPOSE
#   Print the content of the pprism.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::pprismi/::pwtk::pprismi::get
# USAGE
#   ::pwtk::pprismi::get
# DESCRIPTION    
#   Returns the content of the pprism.x input 
#******

#****f* ::pwtk::pprismi/::pwtk::pprismi::clear
# USAGE
#   ::pwtk::pprismi::clear
# PURPOSE
#   Clear the pprism.x input data.
#******

#****f* ::pwtk::pprismi/::pwtk::pprismi::load_fromPPRISMI
# USAGE
#   ::pwtk::pprismi::load_fromPPRISMI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing pprism.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the pprism.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runPPRISM
# USAGE 
#   runPPRISM  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the pprism.x input file from the input data and run the pprism.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the pprism.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the pprism.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the pprism.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/bgw2pw.x input
# DESCRIPTION
#   Handling of the bgw2pw.x input. For further details, see ::pwtk::bgw2pwi.
#******

#****n* bgw2pw.x input/::pwtk::bgw2pwi
# NAME
#   ::pwtk::bgw2pwi
# DESCRIPTION
#   Namespace for handling the bgw2pw.x input.
#******

#****f* ::pwtk::bgw2pwi/::pwtk::bgw2pwi::fprint
# USAGE
#   ::pwtk::bgw2pwi::fprint ?FILE?        
# PURPOSE
#   Print the content of the bgw2pw.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::bgw2pwi/::pwtk::bgw2pwi::get
# USAGE
#   ::pwtk::bgw2pwi::get
# DESCRIPTION    
#   Returns the content of the bgw2pw.x input 
#******

#****f* ::pwtk::bgw2pwi/::pwtk::bgw2pwi::clear
# USAGE
#   ::pwtk::bgw2pwi::clear
# PURPOSE
#   Clear the bgw2pw.x input data.
#******

#****f* ::pwtk::bgw2pwi/::pwtk::bgw2pwi::load_fromBGW2PWI
# USAGE
#   ::pwtk::bgw2pwi::load_fromBGW2PWI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing bgw2pw.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the bgw2pw.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runBGW2PW
# USAGE 
#   runBGW2PW  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the bgw2pw.x input file from the input data and run the bgw2pw.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the bgw2pw.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the bgw2pw.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the bgw2pw.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/pw2bgw.x input
# DESCRIPTION
#   Handling of the pw2bgw.x input. For further details, see ::pwtk::pw2bgwi.
#******

#****n* pw2bgw.x input/::pwtk::pw2bgwi
# NAME
#   ::pwtk::pw2bgwi
# DESCRIPTION
#   Namespace for handling the pw2bgw.x input.
#******

#****f* ::pwtk::pw2bgwi/::pwtk::pw2bgwi::fprint
# USAGE
#   ::pwtk::pw2bgwi::fprint ?FILE?        
# PURPOSE
#   Print the content of the pw2bgw.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::pw2bgwi/::pwtk::pw2bgwi::get
# USAGE
#   ::pwtk::pw2bgwi::get
# DESCRIPTION    
#   Returns the content of the pw2bgw.x input 
#******

#****f* ::pwtk::pw2bgwi/::pwtk::pw2bgwi::clear
# USAGE
#   ::pwtk::pw2bgwi::clear
# PURPOSE
#   Clear the pw2bgw.x input data.
#******

#****f* ::pwtk::pw2bgwi/::pwtk::pw2bgwi::load_fromPW2BGWI
# USAGE
#   ::pwtk::pw2bgwi::load_fromPW2BGWI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing pw2bgw.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the pw2bgw.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runPW2BGW
# USAGE 
#   runPW2BGW  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the pw2bgw.x input file from the input data and run the pw2bgw.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the pw2bgw.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the pw2bgw.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the pw2bgw.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/pw2gw.x input
# DESCRIPTION
#   Handling of the pw2gw.x input. For further details, see ::pwtk::pw2gwi.
#******

#****n* pw2gw.x input/::pwtk::pw2gwi
# NAME
#   ::pwtk::pw2gwi
# DESCRIPTION
#   Namespace for handling the pw2gw.x input.
#******

#****f* ::pwtk::pw2gwi/::pwtk::pw2gwi::fprint
# USAGE
#   ::pwtk::pw2gwi::fprint ?FILE?        
# PURPOSE
#   Print the content of the pw2gw.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::pw2gwi/::pwtk::pw2gwi::get
# USAGE
#   ::pwtk::pw2gwi::get
# DESCRIPTION    
#   Returns the content of the pw2gw.x input 
#******

#****f* ::pwtk::pw2gwi/::pwtk::pw2gwi::clear
# USAGE
#   ::pwtk::pw2gwi::clear
# PURPOSE
#   Clear the pw2gw.x input data.
#******

#****f* ::pwtk::pw2gwi/::pwtk::pw2gwi::load_fromPW2GWI
# USAGE
#   ::pwtk::pw2gwi::load_fromPW2GWI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing pw2gw.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the pw2gw.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runPW2GW
# USAGE 
#   runPW2GW  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the pw2gw.x input file from the input data and run the pw2gw.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the pw2gw.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the pw2gw.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the pw2gw.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/pw2wannier90.x input
# DESCRIPTION
#   Handling of the pw2wannier90.x input. For further details, see ::pwtk::pw2wan90i.
#******

#****n* pw2wannier90.x input/::pwtk::pw2wan90i
# NAME
#   ::pwtk::pw2wan90i
# DESCRIPTION
#   Namespace for handling the pw2wannier90.x input.
#******

#****f* ::pwtk::pw2wan90i/::pwtk::pw2wan90i::fprint
# USAGE
#   ::pwtk::pw2wan90i::fprint ?FILE?        
# PURPOSE
#   Print the content of the pw2wannier90.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::pw2wan90i/::pwtk::pw2wan90i::get
# USAGE
#   ::pwtk::pw2wan90i::get
# DESCRIPTION    
#   Returns the content of the pw2wannier90.x input 
#******

#****f* ::pwtk::pw2wan90i/::pwtk::pw2wan90i::clear
# USAGE
#   ::pwtk::pw2wan90i::clear
# PURPOSE
#   Clear the pw2wannier90.x input data.
#******

#****f* ::pwtk::pw2wan90i/::pwtk::pw2wan90i::load_fromPW2WAN90I
# USAGE
#   ::pwtk::pw2wan90i::load_fromPW2WAN90I FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing pw2wannier90.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the pw2wannier90.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runPW2WANNIER90
# USAGE 
#   runPW2WANNIER90  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the pw2wannier90.x input file from the input data and run the pw2wannier90.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the pw2wannier90.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the pw2wannier90.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the pw2wannier90.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/pwcond.x input
# DESCRIPTION
#   Handling of the pwcond.x input. For further details, see ::pwtk::pwcondi.
#******

#****n* pwcond.x input/::pwtk::pwcondi
# NAME
#   ::pwtk::pwcondi
# DESCRIPTION
#   Namespace for handling the pwcond.x input.
#******

#****f* ::pwtk::pwcondi/::pwtk::pwcondi::fprint
# USAGE
#   ::pwtk::pwcondi::fprint ?FILE?        
# PURPOSE
#   Print the content of the pwcond.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::pwcondi/::pwtk::pwcondi::get
# USAGE
#   ::pwtk::pwcondi::get
# DESCRIPTION    
#   Returns the content of the pwcond.x input 
#******

#****f* ::pwtk::pwcondi/::pwtk::pwcondi::clear
# USAGE
#   ::pwtk::pwcondi::clear
# PURPOSE
#   Clear the pwcond.x input data.
#******

#****f* ::pwtk::pwcondi/::pwtk::pwcondi::load_fromPWCONDI
# USAGE
#   ::pwtk::pwcondi::load_fromPWCONDI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing pwcond.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the pwcond.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runPWCOND
# USAGE 
#   runPWCOND  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the pwcond.x input file from the input data and run the pwcond.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the pwcond.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the pwcond.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the pwcond.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/all_currents.x input
# DESCRIPTION
#   Handling of the all_currents.x input. For further details, see ::pwtk::all_curri.
#******

#****n* all_currents.x input/::pwtk::all_curri
# NAME
#   ::pwtk::all_curri
# DESCRIPTION
#   Namespace for handling the all_currents.x input.
#******

#****f* ::pwtk::all_curri/::pwtk::all_curri::fprint
# USAGE
#   ::pwtk::all_curri::fprint ?FILE?        
# PURPOSE
#   Print the content of the all_currents.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::all_curri/::pwtk::all_curri::get
# USAGE
#   ::pwtk::all_curri::get
# DESCRIPTION    
#   Returns the content of the all_currents.x input 
#******

#****f* ::pwtk::all_curri/::pwtk::all_curri::clear
# USAGE
#   ::pwtk::all_curri::clear
# PURPOSE
#   Clear the all_currents.x input data.
#******

#****f* ::pwtk::all_curri/::pwtk::all_curri::load_fromALL_CURRI
# USAGE
#   ::pwtk::all_curri::load_fromALL_CURRI FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing all_currents.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the all_currents.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runALL_CURRENTS
# USAGE 
#   runALL_CURRENTS  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the all_currents.x input file from the input data and run the all_currents.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the all_currents.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the all_currents.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the all_currents.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


#****a* Programs/ld1.x input
# DESCRIPTION
#   Handling of the ld1.x input. For further details, see ::pwtk::ld1i.
#******

#****n* ld1.x input/::pwtk::ld1i
# NAME
#   ::pwtk::ld1i
# DESCRIPTION
#   Namespace for handling the ld1.x input.
#******

#****f* ::pwtk::ld1i/::pwtk::ld1i::fprint
# USAGE
#   ::pwtk::ld1i::fprint ?FILE?        
# PURPOSE
#   Print the content of the ld1.x input data to a file or
#   to stdout if the file was not specified.
# ARGUMENTS
#   * FILE -- (optional) filename to print to (default = stdout)
#******

#****f* ::pwtk::ld1i/::pwtk::ld1i::get
# USAGE
#   ::pwtk::ld1i::get
# DESCRIPTION    
#   Returns the content of the ld1.x input 
#******

#****f* ::pwtk::ld1i/::pwtk::ld1i::clear
# USAGE
#   ::pwtk::ld1i::clear
# PURPOSE
#   Clear the ld1.x input data.
#******

#****f* ::pwtk::ld1i/::pwtk::ld1i::load_fromLD1I
# USAGE
#   ::pwtk::ld1i::load_fromLD1I FILE ?CLEAR_EXISTING?
# PURPOSE 
#   Load the input data from the existing ld1.x input file. 
#
#   If clear_existing == 1, then the current input will be cleared, but
#   otherwise the data will be simply added to the existing data.
#
# ARGUMENTS
# * FILE -- the ld1.x input file to load
# * CLEAR_EXISTING -- (optional) if true, clear the current input data
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runLD1
# USAGE 
#   runLD1  ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
#
#   Options are: 
#     -bg
#     -append  
#     -serial 
#     -prefix PREFIX
#     -postfix POSTFIX
#     -exec EXECUTABLE
#     -ihandle VALUE
#
# PURPOSE
#   Construct the ld1.x input file from the input data and run the ld1.x program.
#
# OPTIONS
#   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
#   * -append  --- treat the output file in append mode (default = overwrite)
#   * -serial  --- run the calculation in serial mode (default = parallel)
#   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
#   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
#   * -exec EXECUTABLE    --- explicitly specify the ld1.x executable
#   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
#
# ARGUMENTS
#   * INPUT  -- filename (or headname) to which the ld1.x input date will
#               be saved. The .in (.out) suffix will be added to headname for
#               input (output) filename.
#   * OUTPUT -- (optional) filename to which the ld1.x output will be stored
#   * &      -- (optional) run calculation in background (synonymous with the -bg option)
#******


