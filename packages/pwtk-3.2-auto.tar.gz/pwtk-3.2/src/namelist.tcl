#
# $RCSfile: namelist.tcl,v $ --
#
#      This file contains the procs for the fortran namelist handling.
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: namelist.tcl,v 1.5 2021/05/03 14:19:55 tone Exp $ 
#


#****if* Internals/::pwtk::input::namelistParse_
# SYNOPSIS
proc ::pwtk::input::namelistParse_ {name} {
    # DESCRIPTION
    #   Parses the namelist $name, which is stored in
    #   $pwtk::input::namelist($name), so that the values of the variables
    #   are stored in pwtk::input::namelist($name,var=$var) array.
    # ARGUMENTS
    #   * name -- name of namelist to parse    
    # SIDE EFFECTS
    #   At the end the pwtk::input::namelist($name) variable is cleared.
    #  SOURCE

    global pwtk::input::namelist

    if { [info exists pwtk::input::namelist($name) ] } {
	namelistParseContent__ $name $pwtk::input::namelist($name)

	# clear the content of namelist($name)

	set pwtk::input::namelist($name) ""
    }
}
#****


proc ::pwtk::input::namelistParseContent__ {name content} {
    global pwtk::input::namelist

    if { [catch {array set nml [::fnml::parseContent $name $content]} errMsg] }  {
        if { $::errorCode eq "PARSE_ERROR" } {
            pwtk::error "error parsing namelist $name\n$errMsg"
            return
        } else {
            error $::errorInfo
        }
    }
    
    foreach elem [array names nml] {
        set pwtk::input::namelist($name,var=$elem) $nml($elem)
    }
}

# #****f* ::pwtk::input/::pwtk::input::namelistGetVar
# # SYNOPSIS
# proc ::pwtk::input::namelistGetVar {name varName {trim ""}} {
#     # PURPOSE
#     #   Shortcut for ::pwtk::input::namelistGetVarValue
#     # SOURCE
#     uplevel 1 ::pwtk::input::namelistGetVarValue $name $varName $trim
# }
# #******

#****a* ::pwtk::input/Namelists
# DESCRIPTION   
#   Routines associated with namelists.
#******

#****f* Namelists/::pwtk::input::namelistGetVarNoCase
# SYNOPSIS
proc ::pwtk::input::namelistGetVarNoCase {name varName} {
    # PURPOSE
    #   Get the correct-case name of a variable in the namelist "name".
    #   The search rules are:
    #   1. a case-sensitive search of "varName"
    #   2. a case-insensitive search of "varName"
    #   3. if 1+2 fail, "varName" is returned
    #
    # ARGUMENTS
    # * name -- namelist name
    # * varName -- variable name
    #
    # RETURN VALUE
    #   Either "varName" (case-sensitive) or any other
    #   lowercase/uppercase variant of "varName" if present in the
    #   namelist. If no lowercase/uppercase variant of "varName" is
    #   present in the namelist, a verbatim "varName" is returned.
    #
    # SOURCE
    global pwtk::input::namelist

    # 1. case-sensitive search
    if { [info exists pwtk::input::namelist($name,var=$varName)] } {
        return $varName
    }

    # 2. case-insensitive search
    set vars [regsub -all $name,var= [array names pwtk::input::namelist -glob $name,var=*] {}]
    set ind  [lsearch -nocase $vars $varName]
    if { $ind > -1 } {
        return [lindex $vars $ind]            
    }

    # 3. varName does not exists in the namelist, return "varName" verbatim
    return $varName
}
#******


#****f* Namelists/::pwtk::input::namelistGetVarValue
# SYNOPSIS
proc ::pwtk::input::namelistGetVarValue {name args} {
    # USAGE
    #   ::pwtk::input::namelistGetVarValue name ?-nocase? varName ?trim?
    #
    # PURPOSE
    #   Get a value of a given namelist variable.
    #
    # OPTION
    # * -nocase -- treat "varName" as case-insensitive; the search for a variable is done according to ::pwtk::input::namelistGetVarNoCase
    #
    # ARGUMENTS
    #   * name    -- name of namelist
    #   * varName -- name of variable to query
    #   * trim    -- do we get rid of " or ' quotes (if the "trim" argument is specified, any value except the empty string implies trimming)
    #
    # EXAMPLE    
    #   set my_outdir [::pwtk::input::namelistGetVarValue CONTROL outdir]
    #
    # RETURN VALUE
    #   The value of the namelist "varName" variable or an empty
    #   string if the variable does not exist
    #
    # SOURCE

    global pwtk::input::namelist
    
    if { ! [info exists pwtk::input::namelist($name) ] } { 
	# the $name namelist does not even exist !
	return "" 
    }

    set nocase 0
    if { [lindex $args 0] eq "-nocase" } {
        set nocase 1
        set args [lrange $args 1 end]
    }
    lassign $args varName trim

    if { $nocase } {
        # a nocase search of a variable
        set varName [::pwtk::input::namelistGetVarNoCase $name $varName]        
    }

    if { [info exists pwtk::input::namelist($name,var=$varName)] } {

	set value $pwtk::input::namelist($name,var=$varName)

	# check if the variables should be math-parsed as to evaluate
	# the math-expressions

	if { $value != {} && [::pwtk::queryMathParsing $name $varName] } {
	    
	    # parse only if $value is not yet double
            
	    if { ! [string is double $value] } {
	    	set value [::pwtk::evalExpr $value]
	    }
	} else {
	    set value [trimValue_ $value $trim]
	}
	
	return $value
    }

    return ""
}
#******


#****f* Namelists/::pwtk::input::namelistIfsetVar
# SYNOPSIS
proc ::pwtk::input::namelistIfsetVar {name varName varValue} {
    # PURPOSE
    #   Set a namelist's variable only if it does not exists.    
    # ARGUMENTS
    #   * name     -- name of namelist
    #   * varName  -- name of variable to query
    #   * varValue -- value to set the variable to
    # RETURN
    #   The value of the $varName variable or an empty string if the
    #   $name namelist does not exist

    # SOURCE

    global pwtk::input::namelist

    set result {}
    if { [info exists pwtk::input::namelist($name) ] } {
	if { ! [info exists pwtk::input::namelist($name,var=$varName)] } {
	    set result [set pwtk::input::namelist($name,var=$varName) $varValue]
	}
        set result $pwtk::input::namelist($name,var=$varName)
    }
    return $result
}
#****


proc ::pwtk::input::trimValue_ {value trim} {
    if { $trim != "" } {
	return [::pwtk::unquote $value]
    } else {
	return $value
    }
}


proc ::pwtk::input::namelistSplitVarValue_ {varValue} {
    set ind   [string first = $varValue]
    set var   [string range $varValue 0 [expr {$ind - 1}]]
    set value [string range $varValue [expr {$ind + 1}] end]
    return [list $var $value]
}
