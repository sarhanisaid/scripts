#
# $RCSfile: pbs.tcl,v $ --
#
#      This file contains the implementation for the support for PBS
#      queueing system.
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: pbs.tcl,v 1.3 2021/05/01 19:23:20 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# PUBLIC procs
#
# ------------------------------------------------------------------------

# N.B. the ::pwtk::PBS and pbs_* commands are created dynamically
# by calling the ::pwtk::pbs::init command but they are documented here.

#****f* ::pwtk::pbs/::pwtk::PBS
#
# PURPOSE
# The master command for the PBS batch queuing. It manages the
# submission to PBS.
#
# USAGE
#     PBS { ...script code... }
#     PBS file.pwtk
# or
#     PBS options { ...script code... }
#     PBS options file.pwtk
# or
#     PBS profile ?options? { ...script code... }
#     PBS profile ?options? file.pwtk
#
# DESCRIPTION
# The above "profile" is a user defined profile for PBS, i.e., a set
# of "#PBS" directives, whereas the above "options" are the PBS
# options, specified in the PBS syntax (i.e. they are passed verbatim
# to qsub command).
#
# BEWARE
# Tcl uses different quoting than shell. Therefore, option values
# which contain whitespace are specified differently. For example, the
# equivalence for the shell command:
#
#      qsub -W 'attr_name1 = attr_value1, attr_name2 = attr2_value' ...
#
# in PWTK is: 
# 
#      PBS -W "attr_name1 = attr_value1, attr_name2 = attr2_value" ...
# or
#      PBS -W {attr_name1 = attr_value1, attr_name2 = attr2_value} ...
#
# FURTHER DESCRIPTION
# If "profile" is omitted, the "default" profile is used, which is
# guaranteed to exist because it is defined in the
# |html <a href="../config/pbs.tcl">$PWTK/config/pbs.tcl</a> file.
#
# Here is an example of two user defined profiles, named "parallel" and "long":
#
#     pbs_profile parallel {
#         #!/bin/sh
#         #PBS -q parallel
#         #PBS -l nodes=1
#         #PBS -l ppn=8
#         #PBS -l walltime=6:00:00
#     }
#
#     pbs_profile long {
#         #!/bin/sh
#         #PBS -q long
#         #PBS -l nodes=1
#         #PBS -l ppn=64
#         #PBS -l walltime=24:00:00
#     }
#
# It is a good practice to also define the PWTK specifics (aka
# pwtk_profile) associated with the PBS profiles. For example, for
# the above "long" profile with ppn=64, it would be reasonable to use
# "mpirun -n 64" as a default. This can be achieved with:
#
#    pbs_pwtk_profile long { prefix mpirun -n 64 }
#
# There is also a compact version which defines the PBS profile and
# the associated PWTK profile simultaneously, i.e.:
#
#    pbs_profile long {
#         #!/bin/sh
#         #PBS -q long
#         #PBS -l nodes=1
#         #PBS -l ppn=64
#         #PBS -l walltime=24:00:00
#    } {
#        prefix mpirun -n 64
#    }
#
# Here, the 2nd argument to the 'pbs_profile' command is the PBS
# profile and the last argument is the associated PWTK profile. This
# form is recommended because it avoid typos/mismatches between
# profile and pwtk_profile names.
#
# IMPORTANT
# A typical place where to store PBS profiles for frequent use is in
# the ~/.pwtk/pbs.tcl configuration file (N.B. in the ~/.pwtk/pbs.tcl
# configuration file, the prefix 'pbs_' can be omitted).
#
# FURTHER DESCRIPTION
# The 'pbs_profile' command can be used to define profiles on the
# fly within the PWTK script, e.g.:
#
#   pbs_profile n24 {
#         #!/bin/sh
#         #PBS -l ppn=24
#         #PBS -l walltime=24:00:00
#   } {
#        prefix mpirun -np 24
#   }
#
#   PBS n24 job.pwtk
#
# The final effect of the PBS command is to submit either the script
# code encapsulated inside the PBS { ... } command or the script
# file specified with the PBS command (e.g. PBS file.pwtk) to the
# PBS job scheduling system via the qsub command.
#
#******


#****f* ::pwtk::pbs/::pwtk::pbs_profile
# USAGE
#   ::pwtk::pbs_profile profileName profileSpecs ?pwtkSpecs?
#
# DESCRIPTION
#   Define a PBS "profile" within the PWTK script. See also ::pwtk::PBS.
#
#   Here is an example of how a new PBS profile can be defined and used:
#
#      pbs_profile n24 {
#         #PBS -l ppn=24
#         #PBS -l walltime=6:00:00
#      }
#
#      PBS n24 {
#         load_fromPWI scf.in
#         CONTROL { calculation = 'relax' }
#         IONS {}
#         runPW relax.in
#      }
#
# ARGUMENTS
# * profileName -- name of the profile
# * profileSpecs -- definition of the 'profileName' profile
# * pwtkSpecs -- definition of the PWTK profile to be used when
#                the 'profileName' PBS profile is used
#
# IMPORTANT
# A typical place where to store PBS profiles for frequent use is in
# the ~/.pwtk/pbs.tcl configuration file. Note that in the ~/.pwtk/pbs.tcl
# configuration file, the prefix 'pbs_' can be omitted.
#
# EXAMPLE
#    pbs_profile n24 {
#         #!/bin/sh
#         #PBS -q parallel
#         #PBS -n 24
#         #PBS -W 6:00
#    } {
#       prefix mpirun -np 24
#    }
#******

#****f* ::pwtk::pbs/::pwtk::pbs_profileDefault
# USAGE
#   pbs_profileDefault profileName
# DESCRIPTION
#   Make the 'profileName' profile the default PBS profile.
#******

#****f* ::pwtk::pbs/::pwtk::pbs_pwtk_profile
# USAGE
#   pbs_pwtk_profile profileName pwtkSpecs
# DESCRIPTION
#   Define the PWTK profile named 'profileName' and associate it with
#   the PBS profile of the same name.
#
# EXAMPLE
#   pbs_pwtk_profile n24 {
#      prefix mpirun -n 24
#   }
#******

#****f* ::pwtk::pbs/::pwtk::pbs_pwtk_profileDefault
# USAGE
#   pbs_pwtk_profileDefault profileName
# DESCRIPTION
#   Make the pwtk 'profileName' profile the default PWTK profile for
#   PBS.
#******

#****f* ::pwtk::pbs/::pwtk::pbs_head
# USAGE
#   pbs_head { batch sh-script excerpt }
#
# EXAMPLE
#   pbs_head {
#      echo "Today is `date`"
#      module load qe-7.3
#   }
#
# DESCRIPTION
#   This command sets the "head" part of the PBS batch shell
#   script. In PWTK, the batch shell script is composed of four
#   parts:
#
#        profile   (always exists)
#         |
#        head      (optional)
#         |
#        pwtk      (always exists)
#         |
#        tail      (optional)
#
#   where:
#   * profile -- contains the batch-queue directives (e.g. #SBATCH);
#                it is set with pbs_profile command
#   * head -- contains optional shell commands that are executed
#             prior to executing PWTK, such as "module load ...";
#             it is set with pbs_head command
#   * pwtk -- in this part, the PWTK script is executed;
#             it is set internally by PWTK
#   * tail -- contains optional shell commands that are executed
#             after the PWTK script finishes;
#             it is set with pbs_tail command
#******

#****f* ::pwtk::pbs/::pwtk::pbs_tail
# USAGE
#   pbs_tail { batch sh-script excerpt }
#
# EXAMPLE
#   pbs_tail {
#      # copy the scratch files in WORKDIR to $PWD
#      cp -a $WORKDIR .
#   }
#
# DESCRIPTION
#   This command sets the "tail" part of the PBS batch shell
#   script. In PWTK, the batch shell script is composed of four parts
#   (for description, see ::pwtk::pbs_head).
#******

#****f* ::pwtk::pbs/::pwtk::pbs_clear
# USAGE
#   pbs_clear
# DESCRIPTION
#   Clear the current content of the PBS batch shell script as stored in PWTK.
#******

#****f* ::pwtk::pbs/::pwtk::pbs_fprint
# USAGE
#   pbs_fprint ?FILE?
# PURPOSE
#   Typically used intenally by PWTK.
# DESCRIPTION
#   Print the current content of the PBS batch shell script to FILE
#   or to stdout if FILE was not specified.
#******

#****f* ::pwtk::pbs/::pwtk::pbs_get
# USAGE
#   pbs_get ?profileName?
# PURPOSE
#   Typically used intenally by PWTK.
# DESCRIPTION
#   Return the current content of the PBS batch shell script.
#******


#****if* Internals/::pwtk::pbs::init
# SYNOPSIS
proc ::pwtk::pbs::init {} {
    # PURPOSE
    #    Used intenally by PWTK.
    # DESCRIPTION
    #    Initialization of handling of the PBS batch queuing system.
    # SOURCE

    ::pwtk::queue::init pbs qsub "#PBS"
}
#******


