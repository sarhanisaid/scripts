#
# $RCSfile: run_utils.tcl,v $ --
#
#      This file contains some utility/commodity procs for running
#      calculations, such as relax, vc-relax, restart_fromIO, etc.
#
# Copyright (c) 2014-2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: run_utils.tcl,v 1.5 2021/05/01 19:23:20 tone Exp $ 
#

#****a* 5.3. Run Calculations/5.3.4. Run Utilities
# DESCRIPTION
#   Collection of utility routines, associated with running the calculations.
#
#******
#****a* 5.3.4. Run Utilities/pw.x and cp.x utilities
# DESCRIPTION
#   Collection of utility routines, associated with running the calculations.
#
#******


#****if* Internals/::pwtk::engine_
# SYNOPSIS
proc ::pwtk::engine_ {} {
    # PURPOSE
    #   Parses $engine and sets the $runCmd variable.
    # SOURCE
    uplevel 1 {
        switch -nocase -- $engine {
            pw - pw.x { set runCmd runPW }
            cp - cp.x { set runCmd runCP }
            default {
                ::pwtk::error "wrong engine \"$engine\", must be pw.x or cp.x" 1
            }
        }
    }
}
#******


#****if* Internals/::pwtk::xrelaxArgs_
# SYNOPSIS
proc ::pwtk::xrelaxArgs_ {} {
    # PURPOSE
    #   Parses $head $unit $coor arguments and, if needed, sets ATOMIC_POSITIONS.
    # SOURCE
    uplevel 1 {
        set narg [llength $args]
        if { $narg == 3 } {
            lassign $args head unit coor
            ATOMIC_POSITIONS $unit $coor
        } elseif { $narg == 2 } {
            lassign $args head coor
            ATOMIC_POSITIONS $coor
        } elseif { $narg == 1 } {
            set head $args
        }
    }
}
#******


#****if* Internals/::pwtk::xrelax_
# SYNOPSIS
proc ::pwtk::xrelax_ {type runCmd head} {
    # PURPOSE
    #   Performs $type calculation, where  $type == relax | vc-relax;
    # SIDE EFFECTS
    #   "calculation", "prefix", "outdir_postfix", and "nat" are set.
    # SOURCE
    set head [regsub "^$type\." $head {}]
    
    outdir_postfix $head
    CONTROL " calculation = '$type'
              prefix = '$head' "
    ::pwtk::pwi::setNAtoms
    IONS {}
    if { $type eq "vc-relax" } {
        CELL {}
    }
    ::pwtk::print "Setting calculation = '$type'\n"
    $runCmd $type.$head
    
    return $type.$head.out
}
#******


#****f* pw.x and cp.x utilities/::pwtk::relax
# SYNOPSIS
proc ::pwtk::relax {engine args} {
    # PURPOSE
    #   Perform a 'relax' pw.x or cp.x calculation:    
    #   * engine = pw.x or cp.x (or pw | cp)
    #   * args = head ?unit? ?coor?
    #       
    # USAGE
    #   relax engine head
    #
    #   relax engine head coor
    #
    #   relax engine head unit coor
    #
    # ARGUMENTS
    # * engine -- pw.x or cp.x (or pw or cp)
    # * head -- the rootname for the I/O files (beware that CONTROL's "prefix" and "outdir_postfix" are set to $head)
    # * unit -- (optional) unit for ATOMIC_POSITIONS
    # * coor -- (optional) coordinates for ATOMIC_POSITIONS
    #
    # SIDE EFFECTS
    #   "calculation", "prefix", "outdir_postfix", and "nat" are set
    #   to appropriate values.
    #
    # RETURN VALUE
    #   The name of the output file, i.e., relax.$head.out
    #
    # SOURCE
    
    engine_
    xrelaxArgs_
    return [xrelax_ relax $runCmd $head]
}
#******


#****if* Internals/::pwtk::vc-relaxPrintout_
# SYNOPSIS
proc ::pwtk::vc-relaxPrintout_ {} {
    # PURPOSE
    #   Print a message for a multi-pass 'vc-relax' calculation.
    # SOURCE
    uplevel 1 {
        if { $opt(npass) > 1 } {
            printTitle vc-relax "Making a multiple pass vc-relax calculation"
            print "Number of vc-relax passes: $opt(npass)\n
Running vc-relax pass #.1"   
        }
    }
}
#******


#****if* Internals/::pwtk::vc-relaxSubsequent_
# SYNOPSIS
proc ::pwtk::vc-relaxSubsequent_ {} {
    # PURPOSE    
    #   Perform subsequent (from 2nd on) calculations for a multi-pass
    #   'vc-relax' calculation.
    #
    #   BEWARE: the $opt(npass), $out, and $runCmd variables must be defined!
    #
    # SOURCE
    uplevel 1 {
        # prepare for subsequent calcs        
        if { $opt(npass) > 1 } {
            set head [headname $out .out]
            
            # BEWARE: for subsequent vc-relax calculations, "conv_thr" must
            # be tightened hence set conv_thr = conv_thr*upscale & upscale = 1
            set conv_thr [::pwtk::input::namelistGetVarValue ELECTRONS conv_thr]
            set upscale  [::pwtk::input::namelistGetVarValue IONS upscale]
        
            # set to default pw.x values if not defined
            ifset conv_thr 1e-6
            ifset upscale  100

            input_pushpop {
                restart off
                ELECTRONS " conv_thr = $conv_thr/$upscale "            
                IONS      " upscale = 1.0 "
            
                for {set i 2} {$i <= $opt(npass)} {incr i} {
                    file copy -force -- $head.in $head.pass-[expr $i-1].in
                
                    # make another vc-relax
                    print "Running vc-relax pass #.$i\n"
                
                    ::pwtk::pwi::CELL_PARAMETERS_and_ATOMIC_POSITIONS_fromPWO $head.out
                    $runCmd -append $head
                }
            }
        }
    }
}
#******


#****f* pw.x and cp.x utilities/::pwtk::vc-relax
# SYNOPSIS
proc ::pwtk::vc-relax {engine args} {
    # PURPOSE
    #   Perform a 'vc-relax' pw.x or cp.x calculation:
    #   * engine = pw.x or cp.x (or pw or cp)
    #   * args = ?-npass N? head ?unit? ?coor?
    #
    # USAGE
    #   vc-relax engine ?-npass NUMBER? head
    #
    #   vc-relax engine ?-npass NUMBER? head coor
    #
    #   vc-relax engine ?-npass NUMBER? head unit coor
    #
    # OPTIONS
    # * -npass NUMBER ... number of consecutive vc-relax calculations on a
    #                     given structure
    #
    # ARGUMENTS
    # * engine -- pw.x or cp.x (or pw or cp)    
    # * head -- the rootname for the I/O files (beware that CONTROL's
    #           "prefix" and "outdir_postfix" are set to $head)
    # * unit -- (optional) unit for ATOMIC_POSITIONS
    # * coor -- (optional) coordinates for ATOMIC_POSITIONS
    #
    # RETURN VALUE
    #   The name of the output file, i.e., vc-relax.$head.out
    #
    # SIDE EFFECTS
    #   "calculation", "prefix", "outdir_postfix", and "nat" are set
    #   to appropriate values.
    #
    # SOURCE    

    # check the engine argument
    engine_

    # parse the ?-npass value? option
    set options {
	{npass.arg  1  "number of consecutive vc-relax runs for a given case"}
    }
    set nargmin 1
    set nargmax 3
    set usage "engine ?-npass npass? head ?unit? ?coor?"
    parseOpt_
    checkOTypeStrict_ -npass $opt(npass) {number posint} "positive integer"

    # parse head ?unit? ?coor?    
    xrelaxArgs_
    
    # printout for npass > 1
    vc-relaxPrintout_

    # run the 1st calc
    set out [xrelax_ vc-relax $runCmd $head]

    # run subsequent calcs
    vc-relaxSubsequent_

    return $out
}
#******


#****f* pw.x and cp.x utilities/::pwtk::run_fromXSF
# SYNOPSIS
proc ::pwtk::run_fromXSF {engine args} {
    # USAGE
    #   run_fromXSF engine [options] xsfFile
    #
    # more specifically:
    #
    #   run_fromXSF engine ?-fix_first n?  ?-fix_last n?  ?-fix indexList?  ?-fix_string fixString?  \
    #                      ?-head headName?  ?-noalat?  ?-cell?  xsfFile
    #
    # PURPOSE
    #   Load the atomic positions and, if the -cell option is specified,
    #   also the cell parameters, from the XSF file and make a pw.x or
    #   cp.x calculation, depending on the 'engine' specs, i.e.:    
    #   * engine = pw.x or cp.x (or pw | cp)
    #   * args = [options] xsfFile
    #    
    # OPTIONS
    #   * -fix_first Nfirst -- fix the first Nfirst atoms, i.e., atoms from 1 to Nfirst
    #   * -fix_last Nlast   -- fix the last Nlast atoms, i.e., atoms from N-Nlast+1 to N
    #   * -fix fixList      -- list of atoms to fix (list of atoms should have the
    #                          syntax supported by ::pwtk::parseRangeString)
    #   * -fix_string fixString -- the fix string (default = {0 0 0}) for the
    #                              "fixed" coordinates
    #   * -head headname -- head for the pw.x I/O files, i.e., $head.in,
    #                       $head.out (default = head of the supplied XSF file)
    #   * -noalat -- do not use the coordinates in alat but transform them to angstrom
    #                or bohr units (beware: XSF and QE "alat" may be different); 
    #   * -cell -- load CELL_PARAMETERS from the XSF file
    #              (default = load only atomic coordinates)
    #
    # ARGUMENTS
    # * engine -- pw.x or cp.x (or pw or cp)
    # * xsfFile -- the XSF file from which to load the structure
    #
    # RETURN VALUE
    #   The name of the pw.x output file, i.e., type.head.out, where
    #   type is the value of the CONTROL's "calculation" variable
    #   (scf, relax, mv-relax...) and head is the rootname of either
    #   the xsf-file or the argument of the -head option.
    #
    # SIDE EFFECTS
    #   "prefix", "outdir_postfix", and "nat" are set to appropriate values.
    #
    # SOURCE

    # check the engine argument
    engine_

    # parse options

    set narg 1
    set usage "engine ?-fix_first n?  ?-fix_last n?  ?-fix indexList?  ?-fix_string fixString?  ?-head headName?  ?-noalat?  ?-cell? xsfFile"
    set options {
	{fix_first.arg  {}  "fix the first Nfirst atoms, i.e., atoms from 1 to Nfirst"}
	{fix_last.arg   {}  "fix the last Nlast atoms, i.e., atoms from N-Nlast+1 to N"}
        {fix.arg        {}  "list of atoms to fix"}
        {fix_string.arg {0 0 0} "fix string"}
        {head.arg       {} "head-name for the pw.x|cp.x I/O files"}
        {noalat            "prevent using coordinates in alat units"}
        {cell              "load also CELL_PARAMETERS from the XSF file (default = only coordinates)"}
    }
    parseOpt_
    # N.B. do not check $opt(fix), it will be checked latter on by ::pwtk::parseRangeString
    #checkOType_ -fix_last  $opt(fix)       {numberlist posint}  "list of positive integer numbers"
    checkOType_ -fix_first $opt(fix_first) {number posint}      "positive integer"
    checkOType_ -fix_last  $opt(fix_last)  {number posint}      "positive integer"
    checkOType_ -fix_last  $opt(fix_string) {numberlist binary} "list of binary integers (0|1)"
    
    # load XSF file
    
    set xsfFile $args
    ::pwtk::fileMustExist $xsfFile XSF

    # head-name of I/O files
    
    set head [file tail [::pwtk::headname $xsfFile *xsf*]]
    if { $opt(head) != "" } {
        set head $opt(head)
    }

    # -alat || -noalat ?
    
    set optalat -alat
    if { $opt(noalat) } {
        set optalat -noalat
    }
    
    # load the structure from XSF file
        
    if { $opt(cell) } {
        ::pwtk::print [procName] "Loading CELL_PARAMETERS & ATOMIC_POSITIONS from XSF file: $xsfFile\n"
        ::pwtk::pwi::CELL_PARAMETERS_and_ATOMIC_POSITIONS_fromXSF $optalat $xsfFile
    } else {
        ::pwtk::print [procName] "Loading ATOMIC_POSITIONS from XSF file: $xsfFile\n"
        ::pwtk::pwi::ATOMIC_POSITIONS_fromXSF $optalat $xsfFile
    }

    # fix atoms
        
    if { $opt(fix_first) != {} } {
        ::pwtk::pwi::fixAtoms1st $opt(fix_first) $opt(fix_string)
    }
    if { $opt(fix_last) != {} } {
        ::pwtk::pwi::fixAtomsLast $opt(fix_last) $opt(fix_string)
    }
    if { $opt(fix) != {} } {
        ::pwtk::pwi::fixAtoms $opt(fix) $opt(fix_string)
    }

    # determine the rootname for I/O files
    
    set type [::pwtk::input::namelistGetVarValue CONTROL -nocase calculation trim]
    ::pwtk::ifset type scf        
    set prefix [regsub "^$type\." $head {}]; # scf.|relax.|vc-relax. stripped
    set head $type.$prefix

    # run the calculation

    outdir_postfix $prefix
    CONTROL " prefix = '$prefix' "    
    $runCmd $head
    
    return $head.out
}
#******


#****f* pw.x and cp.x utilities/::pwtk::relax_fromXSF
# SYNOPSIS
proc ::pwtk::relax_fromXSF {engine args} {
    # USAGE    
    #   relax_fromXSF engine [options] xsfFile
    #
    # more specifically:
    #
    #   relax_fromXSF engine ?-fix_first n?  ?-fix_last n?  ?-fix fixIndexList?  ?-fix_string fixString? \
    #                        ?-head headName?  ?-cell? xsfFile
    #
    # PURPOSE
    #   Load the structure from the XSF file and make a pw.x or cp.x
    #   'relax' calculation, depending on the 'engine' specs, i.e.:
    #   * engine = pw.x or cp.x (or pw | cp)
    #   * args = [options] xsfFile
    #
    # OPTIONS
    #   For the description of options, see ::pwtk::run_fromXSF
    #
    # SIDE EFFECTS
    #   "calculation", "prefix", "outdir_postfix", and "nat" are set
    #   to appropriate values.
    #
    # RETURN VALUE
    #   The name of the output file, i.e. relax.$head.out
    #
    # SOURCE

    ::pwtk::print "Setting calculation = 'relax'\n"
    CONTROL " calculation = 'relax' "
    IONS ""
    return [eval run_fromXSF $engine $args]
}
#******

#****f* pw.x and cp.x utilities/::pwtk::vc-relax_fromXSF
# SYNOPSIS
proc ::pwtk::vc-relax_fromXSF {engine args} {
    # USAGE
    #   vc-relax_fromXSF engine [options] xsfFile
    #
    # more specifically:
    # 
    #   vc-relax_fromXSF engine ?-npass npass?  ?-fix_first n?  ?-fix_last n?  ?-fix fixIndexList?  ?-fix_string fixString? \
    #                           ?-head headName?  ?-cell? xsfFile
    #
    # PURPOSE
    #   Load the structure from the XSF file and make a pw.x or cp.x
    #   'vc-relax' calculation, depending on the 'engine' specs, i.e.:
    #   * engine = pw.x or cp.x (or pw | cp)
    #   * args = [options] xsfFile
    #
    # OPTIONS
    # * -npass npass ... number of consecutive 'vc-relax' calculations on a given structure
    #
    # For the description of other options, see ::pwtk::run_fromXSF
    #
    # SIDE EFFECTS    
    #   "calculation", "prefix", "outdir_postfix", and "nat" are set
    #   to appropriate values.
    #
    # RETURN VALUE
    #   The name of the output file, i.e. vc-relax.$head.out
    #
    # SOURCE

    # check the engine argument
    engine_
    
    # strip the "-npass value" specs from $args
    set options {
	{npass.arg  1  "number of consecutive vc-relax runs for a given case"}
    }
    array set opt [::cmdline::getKnownOptions args $options]
    checkOTypeStrict_ -npass $opt(npass) {number posint} "positive integer"

    # printout for npass > 1
    vc-relaxPrintout_

    # run the 1st calc
    ::pwtk::print "Setting calculation = 'vc-relax'\n"
    CONTROL " calculation = 'vc-relax' "
    IONS ""
    CELL ""
    set out [eval run_fromXSF $engine $args]

    # run subsequent calcs
    vc-relaxSubsequent_

    return $out
}
#******


#****f* pw.x and cp.x utilities/::pwtk::run_fromPWO
# SYNOPSIS
proc ::pwtk::run_fromPWO {engine args} {
    # USAGE
    #   run_fromPWO engine [options] pwoFile
    #
    # more specifically:
    #
    #   run_fromPWO engine ?-fix_first n?  ?-fix_last n?  ?-fix indexList?  ?-fix_string fixString? \
    #                      ?-head headName?   ?-cell?  pwoFile
    #
    # PURPOSE
    #   Load the structure from the PWO file and make a pw.x or cp.x
    #   calculation, depending on the 'engine' specs, i.e.:
    #   * engine = pw.x or cp.x (or pw | cp)
    #   * args = [options] pwoFile
    #    
    # OPTIONS
    #   * -fix_first Nfirst -- fix the first Nfirst atoms, i.e., atoms from 1 to Nfirst
    #   * -fix_last Nlast   -- fix the last Nlast atoms, i.e., atoms from N-Nlast+1 to N
    #   * -fix fixList      -- list of atoms to fix (list of atoms should have the
    #                          syntax supported by ::pwtk::parseRangeString)
    #   * -fix_string fixString -- the fix string (default = {0 0 0}) for the
    #                              "fixed" coordinates
    #   * -head headname -- head for the pw.x I/O files, i.e., $head.in,
    #                       $head.out (default = head of the supplied PWO file)
    #   * -cell -- load CELL_PARAMETERS from the PWO file
    #              (default = load only atomic coordinates)
    #
    # ARGUMENTS
    # * engine -- pw.x or cp.x (or pw or cp)
    # * pwoFile -- the PWO file from which to load the structure
    #
    # RETURN VALUE
    #   The name of the pw.x output file, i.e., type.head.out, where
    #   type is the value of the CONTROL's "calculation" variable
    #   (scf, relax, mv-relax...) and head is the rootname of either
    #   the pwo-file or the argument of the -head option.
    #
    # SIDE EFFECTS
    #   "prefix", "outdir_postfix", and "nat" are set to appropriate values.
    #
    # SOURCE

    # check the engine argument
    engine_

    # parse options

    set narg 1
    set usage "engine ?-fix_first n?  ?-fix_last n?  ?-fix indexList?  ?-fix_string fixString?  ?-head headName?  ?-cell? pwoFile"
    set options {
	{fix_first.arg  {}  "fix the first Nfirst atoms, i.e., atoms from 1 to Nfirst"}
	{fix_last.arg   {}  "fix the last Nlast atoms, i.e., atoms from N-Nlast+1 to N"}
        {fix.arg        {}  "list of atoms to fix"}
        {fix_string.arg {0 0 0} "fix string"}
        {head.arg       {} "head-name for the pw.x|cp.x I/O files"}
        {cell              "load also CELL_PARAMETERS from the PWO file (default = only coordinates)"}
    }
    parseOpt_
    checkOType_ -fix_first $opt(fix_first) {number posint}      "positive integer"
    checkOType_ -fix_last  $opt(fix_last)  {number posint}      "positive integer"
    checkOType_ -fix_last  $opt(fix)       {numberlist posint}  "list of positive integer numbers"
    checkOType_ -fix_last  $opt(fix_string) {numberlist binary} "list of binary integers (0|1)"
    
    # load PWO file
    
    set pwoFile $args
    ::pwtk::fileMustExist $pwoFile "pw.x output"

    # head-name of I/O files
    
    set head [file tail [::pwtk::headname $pwoFile .out]]
    if { $opt(head) != "" } {
        set head $opt(head)
    }

    # load the structure from the PWO file
        
    if { $opt(cell) } {
        ::pwtk::print [procName] "Loading CELL_PARAMETERS & ATOMIC_POSITIONS from PWO file: $pwoFile\n"
        ::pwtk::pwi::CELL_PARAMETERS_and_ATOMIC_POSITIONS_fromPWO $optalat $pwoFile
    } else {
        ::pwtk::print [procName] "Loading ATOMIC_POSITIONS from PWO file: $pwoFile\n"
        ::pwtk::pwi::ATOMIC_POSITIONS_fromPWO $pwoFile
    }

    # fix atoms
        
    if { $opt(fix_first) != {} } {
        ::pwtk::pwi::fixAtoms1st $opt(fix_first) $opt(fix_string)
    }
    if { $opt(fix_last) != {} } {
        ::pwtk::pwi::fixAtomsLast $opt(fix_last) $opt(fix_string)
    }
    if { $opt(fix) != {} } {
        ::pwtk::pwi::fixAtoms $opt(fix) $opt(fix_string)
    }

    # determine the rootname for I/O files
    
    set type [::pwtk::input::namelistGetVarValue CONTROL -nocase calculation trim]
    ::pwtk::ifset type scf        
    set prefix [regsub "^$type\." $head {}]; # scf.|relax.|vc-relax. stripped
    set head $type.$prefix

    # run the calculation

    outdir_postfix $prefix
    CONTROL " prefix = '$prefix' "    
    $runCmd $head
    
    return $head.out
}
#******


#****f* pw.x and cp.x utilities/::pwtk::relax_fromPWO
# SYNOPSIS
proc ::pwtk::relax_fromPWO {engine args} {
    # PURPOSE
    #   Load the structure from the PWO (pw.x output) file and make a
    #   pw.x or cp.x 'relax' calculation, depending on the 'engine' specs, i.e.:
    #   * engine = pw.x or cp.x (or pw | cp)
    #   * args = [options] pwoFile
    #
    # USAGE    
    #   relax_fromPWO engine [options] pwoFile
    #
    # more specifically:
    #
    #   relax_fromPWO engine ?-fix_first n?  ?-fix_last n?  ?-fix fixIndexList?  ?-fix_string fixString? \
    #                        ?-head headName?  ?-cell? pwoFile
    #
    # OPTIONS
    #   For the description of options, see ::pwtk::run_fromPWO
    #
    # SIDE EFFECTS
    #   "calculation", "prefix", "outdir_postfix", and "nat" are set
    #   to appropriate values.
    #
    # RETURN VALUE
    #   The name of the output file, i.e. relax.$head.out
    #
    # SOURCE

    ::pwtk::print "Setting calculation = 'relax'\n"
    CONTROL " calculation = 'relax' "
    IONS ""
    return [eval run_fromPWO $engine $args]
}
#******


#****f* pw.x and cp.x utilities/::pwtk::vc-relax_fromPWO
# SYNOPSIS
proc ::pwtk::vc-relax_fromPWO {engine args} {
    # USAGE
    #   vc-relax_fromPWO engine [options] pwoFile
    #
    # more specifically:
    # 
    #   vc-relax_fromPWO engine ?-npass npass?  ?-fix_first n?  ?-fix_last n?  ?-fix fixIndexList?  ?-fix_string fixString? \
    #                           ?-head headName?  ?-cell? pwoFile
    #
    # PURPOSE
    #   Load the structure from the PWO file and make a pw.x or cp.x
    #   'vc-relax' calculation, depending on the 'engine' specs, i.e.:
    #   * engine = pw.x or cp.x (or pw | cp)
    #   * args = [options] pwoFile
    #
    # OPTIONS
    # * -npass npass ... number of consecutive 'vc-relax' calculations on a given structure
    #
    # For the description of other options, see ::pwtk::run_fromPWO
    #
    # SIDE EFFECTS    
    #   "calculation", "prefix", "outdir_postfix", and "nat" are set
    #   to appropriate values.
    #
    # RETURN VALUE
    #   The name of the output file, i.e. vc-relax.$head.out
    #
    # SOURCE

    # check the engine argument
    engine_
    
    # strip the "-npass value" specs from $args
    set options {
	{npass.arg  1  "number of consecutive vc-relax runs for a given case"}
    }
    array set opt [::cmdline::getKnownOptions args $options]
    checkOTypeStrict_ -npass $opt(npass) {number posint} "positive integer"

    # printout for npass > 1
    vc-relaxPrintout_

    # run the 1st calc
    ::pwtk::print "Setting calculation = 'vc-relax'\n"
    CONTROL " calculation = 'vc-relax' "
    IONS ""
    CELL ""
    set out [eval run_fromPWO $engine $args]

    # run subsequent calcs
    vc-relaxSubsequent_

    return $out
}
#******


#****f* pw.x and cp.x utilities/::pwtk::restart_fromIO
# SYNOPSIS
proc ::pwtk::restart_fromIO {engine args} {
    # USAGE
    #    restart_fromIO engine [OPTIONS] HEAD ?FILE.in? ?FILE.out?
    #
    # more specifically:
    # 
    #   restart_fromIO pw.x|cp.x  ?-true_restart 0|1?  ?-clear 0|1?  ?-cell?  HEAD  ?FILE.in?  ?FILE.out?
    #
    # PURPOSE
    #   Restart calculation from the I/O files, where:
    #   * engine = pw.x or cp.x (or pw | cp)
    #   * args = [OPTIONS] HEAD ?FILE.in? ?FILE.out?
    #
    #   This command restarts a calculation from the specified input
    #   and output files, i.e., input data are read from the input
    #   file, whereas CELL_PARAMETERS and ATOMIC_POSITIONS are loaded
    #   from the output file; CELL_PARAMETERS are loaded only if found
    #   in the output file.
    #
    # OPTIONS
    #   * -true_restart 0|1 -- if 1, perform true restart with restart_mode = 'restart'
    #                          (allowed values: 0|1, default = 0).
    #                          If "-true_restart 0" then only the latest cell-parameters
    #                          and atomic positions from the output file are re-used.
    
    #   * -clear 0|1   -- clear the currently defined pw.x input variables, i.e.,
    #                     just use the input variables from the specified input file
    #                     (allowed values: 0|1, default = 1)

    #   * -cell -- use the CELL_PARAMETERS from the pw.x output file;
    #              by default, CELL_PARAMETERS are used from the pw.x
    #              output only for calculation = 'vc-relax', but with
    #              this option, their use is enforced for all
    #              calculations
    #        
    # ARGUMENTS
    # * engine -- pw.x or cp.x (or pw or cp)
    # * HEAD -- rootname for the I/O files
    # * FILE.in -- (optional) input file to restart from (default: HEAD.in)
    # * FILE.out -- (optional) output file to restart from (default: [headname FILE.in].out)
    #
    # SIDE EFFECTS
    #    None. Data loading and calculation is performed within input_pushpop { ... }    
    #
    # RETURN VALUE
    #    The name of the new output file.
    #
    # SOURCE

    # check the engine argument
    engine_

    # parse options
    set nargmin 1
    set nargmax 3
    set usage "engine ?-true_restart 0|1?  ?-clear 0|1?  head  ?file.in?  ?file.out?"
    set options {
	{true_restart.arg  0  "perform true restart with restart_mode = 'restart'"}
	{clear.arg         1  "use just the input variables from the specified input file"}
        {cell                 "enforce the use of CELL_PARAMETERS from the pw.x output file"}
    }
    parseOpt_
    checkOTypeStrict_ -true_restart $opt(true_restart) boolean
    checkOTypeStrict_ -clear        $opt(clear) boolean

    
    # assign head, inp, out
    lassign $args head inp out
    ifset inp $head.in 
    ifset out [::pwtk::headname $inp].out 

    # check if $inp & $out exist; if not try with $type.$inp & $type.$out
    set calc [::pwtk::input::namelistGetVarValue CONTROL -nocase calculation trim]
    if { ! [file exists $inp] && [file exists $calc.$inp] } {
        set head $calc.[regsub "^$calc\." $head {}]
        set inp  $calc.$inp
    }
    if { ! [file exists $out] && [file exists $calc.$out] } { set out $calc.$out }    
    
    # do the job    
    input_pushpop {        
        ::pwtk::print [procName] "Loading input data from $inp"
        switch -nocase -- $engine {
            pw - pw.x { ::pwtk::pwi::load_fromPWI $inp $opt(clear) }
            cp - cp.x { ::pwtk::cpi::load_fromCPI $inp $opt(clear) }
        }
        if { [regexp ^vc- $calc] || $opt(cell) } {
            ::pwtk::print [procName] "Loading CELL_PARAMETERS & ATOMIC_POSITIONS from $out\n"
            ::pwtk::pwi::CELL_PARAMETERS_and_ATOMIC_POSITIONS_fromPWO $out
        } else {
            ::pwtk::print [procName] "Loading ATOMIC_POSITIONS from $out\n"
            ::pwtk::pwi::ATOMIC_POSITIONS_fromPWO $out
        }
        if { $opt(true_restart) } {
            re$runCmd $head
        } else {
            CONTROL " restart_mode = "
            $runCmd -append $head
        }
    }
    return $head.out
}
#******


# ------------------------------------------------------------------------
#
# Obsolete procs
#
# ------------------------------------------------------------------------


#****f* Deprecated/::pwtk::relaxPW
# SYNOPSIS
proc ::pwtk::relaxPW {head unit coor} {
    deprecated "[procName] is deprecated, use \"::pwtk::relax pw.x\" instead"
    return [relax pw.x $head $unit $coor]
}
#******

#****f* Deprecated/::pwtk::vc_relaxPW
# SYNOPSIS
proc ::pwtk::vc_relaxPW {head unit coor} {
    deprecated "[procName] is deprecated, use \"::pwtk::vc-relax pw.x\" instead"
    return [vc-relax pw.x $head $unit $coor]
}
#******

#****f* Deprecated/::pwtk::relaxPW_fromXSF
# SYNOPSIS
proc ::pwtk::relaxPW_fromXSF {args} {
    deprecated "[procName] is deprecated, use \"::pwtk::relax_fromXSF pw.x\" instead"
    return [eval relax_fromXSF pw.x $args]
}
#******

#****f* Deprecated/::pwtk::vc_relaxPW_fromXSF
# SYNOPSIS
proc ::pwtk::vc_relaxPW_fromXSF {args} {
    deprecated "[procName] is deprecated, use \"::pwtk::vc-relax_fromXSF pw.x\" instead"
    return [eval vc-relax_fromXSF pw.x $args]
}
#******

#****f* Deprecated/::pwtk::runPW_fromXSF
# SYNOPSIS
proc ::pwtk::runPW_fromXSF {args} {
    deprecated "[procName] is deprecated, use \"::pwtk::run_fromXSF pw.x\" instead"
    return [eval run_fromXSF pw.x $args]
}
#******
  
#****f* Deprecated/::pwtk::restartPW_fromPWIandPWO
# SYNOPSIS
proc ::pwtk::restartPW_fromPWIandPWO {args} {
    deprecated "[procName] is deprecated, use \"::pwtk::restart_fromIO pw.x\" instead"
    return [eval restart_fromIO pw.x $args]
}
#******
