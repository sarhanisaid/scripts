#
# $RCSfile: speci.tcl,v $ --
#
#      This file contains procs for handling the turbo_spectrum.x input.
#
# Copyright (c) 2021  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: speci.tcl,v 1.1 2021/05/01 19:24:39 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::speci_fprint {{file {}}} { uplevel ::pwtk::speci::fprint $file }
proc ::pwtk::speci_clear  {}          { uplevel ::pwtk::speci::clear }
proc ::pwtk::speci_get    {}          { uplevel ::pwtk::speci::get }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::speci/::pwtk::speci::fprint
# SYNOPSIS
proc ::pwtk::speci::fprint {{file {}}} {
# PURPOSE
#   Print the content of turbo_spectrum.x input data to a file or to stdout if the
#   file was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::speci $file    
}
#****


#****f* ::pwtk::speci/::pwtk::speci::get
# SYNOPSIS
proc ::pwtk::speci::get {} {
    # DESCRIPTION    
    #   Return the content of the turbo_spectrum.x input. 
    # SOURCE
    variable namelist_flow_list
    
    # N.B. turbo_spectrum.x does not have the wfcdir variable, hence
    # ::pwtk::lri::loadDefaults_ is not OK
    namespace eval ::pwtk::input {
        defaultVarValue_ LR_INPUT prefix  ""
        defaultVarValue_ LR_INPUT outdir [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
    }

    foreach nml $namelist_flow_list {
        append inp [::pwtk::input::namelistGet $nml]
    }
   
    return $inp
}
#******
    
#****f* ::pwtk::speci/::pwtk::speci::clear
# SYNOPSIS
proc ::pwtk::speci::clear {} {
    # DESCRIPTION    
    #   Clear the content of the turbo_spectrum.x input. 
    # SOURCE
    variable namelist_flow_list

    foreach name $input_flow_list {
	::pwtk::input::clear $name
    }
}
#******
    
#****f* ::pwtk::speci/::pwtk::speci::load_fromSPECI
# SYNOPSIS
proc ::pwtk::speci::load_fromSPECI {speci {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing turbo_spectrum.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * speci -- filename of the turbo_spectrum.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?

    #
    # SOURCE
    variable namelist_flow_list

    ::pwtk::lri::load_from_input_  turbo_spectrum.x  $namelist_flow_list  $speci  $clear_existing
}
#******
