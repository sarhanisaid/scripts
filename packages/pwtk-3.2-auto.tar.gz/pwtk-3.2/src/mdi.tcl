#
# $RCSfile: mdi.tcl,v $ --
#
#      This file contains the procs for handling the matdyn.x input.
#
# Copyright (c) 2021  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: mdi.tcl,v 1.2 2021/05/03 14:21:08 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::mdi_fprint {{file {}}} { uplevel ::pwtk::mdi::fprint $file }
proc ::pwtk::mdi_get    {}          { uplevel ::pwtk::mdi::get }
proc ::pwtk::mdi_clear  {}          { uplevel ::pwtk::mdi::clear }
proc ::pwtk::mdi_getAffix {}        { uplevel ::pwtk::mdi::getAffix }

# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::mdi/::pwtk::mdi::fprint
# SYNOPSIS
proc ::pwtk::mdi::fprint {{file {}}} {
# PURPOSE
#   Print the content of matdyn.x input data to a file or to stdout if the
#   file was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::mdi $file
}
#****


#****f* ::pwtk::mdi/::pwtk::mdi::get
# SYNOPSIS
proc ::pwtk::mdi::get {} {
    # DESCRIPTION    
    #   Returns the content of the matdyn.x input 
    # SOURCE

    loadDefaults_

    # matdyn.x uses INPUT namelist, but this name is too generic,
    # hence pwtk uses MATDYN instead, hence we need to substitute the
    # MATDYN string with INPUT

    set    input_ [regsub -- {\&MATDYN} [::pwtk::input::namelistGet MATDYN] {\&INPUT}]
    append input_ [::pwtk::input::cardGetContent MATDYN.affixCards]
    
    return [::pwtk::skipEmptyLines $input_]
}
#******
    

#****f* ::pwtk::mdi/::pwtk::mdi::getAffix
# SYNOPSIS
proc ::pwtk::mdi::getAffix {} { 
    # PURPOSE
    #   Return the last part of the matdyn.x input file, that is, the
    #   cards following the MATDYN (or INPUT) namelist.
    # SOURCE
    return [::pwtk::input::cardGetContent MATDYN.affixCards]
}
#****

#****f* ::pwtk::mdi/::pwtk::mdi::clear
# SYNOPSIS
proc ::pwtk::mdi::clear {} {
    # PURPOSE
    #   Clear the stored matdyn.x input data.
    # SOURCE
    variable input_flow_list
    
    foreach name [concat $input_flow_list MATDYN.affixCards] {
	::pwtk::input::clear $name
    }
}
#****


proc ::pwtk::mdi::loadDefaults_ {} {
    # load some default values, when user has omitted them 

    # nothing so var (perhaps add flfrc from q2r.x)
    namespace eval ::pwtk::input {
        defaultVarValue_ MATDYN flfrc  ""
    }
}


#****f* ::pwtk::mdi/::pwtk::mdi::load_fromMDI
# SYNOPSIS
proc ::pwtk::mdi::load_fromMDI {mdi {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from the existing matdyn.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * mdi -- filename of the matdyn.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?
    #
    # SOURCE

    ::pwtk::fileMustExist $mdi "matdyn.x input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current matdyn.x input data ...
	::pwtk::input::clear MATDYN
    }

    set fid [open $mdi r]

    # matdyn.x input file must contain the INPUT namelist

    if { [catch {set nml [::pwtk::readNml $fid INPUT]}] } {
        ::pwtk::error "input file \"$mdi\" does not appear to be a matdyn.x input file" 1
    }
    # replace INPUT with MATDYN
    eval [regsub INPUT $nml MATDYN]
          
    # read the rest of the matdyn.x input file
    while { ! [eof $fid] } {
        ::pwtk::input::cardAppend MATDYN.affixCards [gets $fid]
    }
    close $fid
    variable input_flow_list
    ::pwtk::input::namelists_ityp2atmSymb_ $input_flow_list
}
#******
