# ------------------------------------------------------------------------
# The AUTHOR of the below code (i.e., "gp" command) is:
#
# Alexander Mlynski-Wiese
#
# The code below is taken from: https://wiki.tcl-lang.org/page/gnuplot
# and is used almost verbatim. Changes by T.K. are marginal, i.e., gp
# command was encapsulated into ::gp namespace so that threads work.
#
# The snippet published on https://wiki.tcl-lang.org/page/gnuplot are
# disrtibuted under BSD-type license: https://wiki.tcl-lang.org/license
# ------------------------------------------------------------------------


namespace eval ::gp {
    variable gnuplot
    variable gnuplot_rx

    namespace export gp
    
    #****f* Gnuplot/gp
    # SYNOPSIS
    proc gp { args } {
        # PURPOSE
        #  Start and control gnuplot.
        #
        #  Taken from https://wiki.tcl-lang.org/page/gnuplot and used almost
        #  verbatim (changes by A.K. are marginal)
        #
        # AUTHOR
        #   Alexander Mlynski-Wiese
        #
        # USAGE
        #   gp args
        #
        # DESCRIPTION
        #  Normally, all args are passed to gnuplot.
        #  The following convenience function is applied: if the first argument is a
        #  filename OR if the first argument is the command 'plot', then:
        #  * if filename contains wildcards (*), the youngest matching file is selected
        #  * the selected file is searched for lines containing "#! command":
        #     (1) if such commands are found, these commands are sent to gnuplot;
        #     (2) otherwise, a plot command is sent to gnuplot
        #
        # EXAMPLES
        #
        #    gp filename            \   if filename contains wildcards (*),
        #    gp 'filename'           \      select youngest file matching
        #    gp plot filename        /  if file exists, try to read "#! commands"
        #    gp plot 'filename'     /       from it
        #    gp filename using 3:6  ->  plot 'filename' using 3:6
        #    gp set title 'TEST'
        #    gp replot
        #    gp exit                ->  terminate gnuplot
        #
        # SOURCE

        variable gnuplot
        variable gnuplot_rx

        set cmdline ""

        set argc [llength $args]

        set tryDaq 0
        if { $argc >= 2 && [lindex $args 0] == "plot" } {
            set tryDaq 1
        }

        #-----------------------------------------------------------------
        #  try to interpret arg as a filename
        #-----------------------------------------------------------------
        set filename [string trim [lindex $args $tryDaq] "'"]

        #-----------------------------------------------------------------
        #  convenience: if filename contains '*', look for youngest
        #        file matching pattern
        #-----------------------------------------------------------------
        if { [regexp {\*} $filename] } {
            set dir   [file dirname $filename]
            set mask  [file tail $filename]
            set files [glob -nocomplain -directory $dir -types f $mask]
            if { [llength $files] > 0 } {
                set filename [lindex $files 0]
                set filetime [file mtime $filename]
                foreach fname [lrange $files 1 end] {
                    set mtime [file mtime $fname]
                    if { $mtime > $filetime } {
                        set filename $fname
                        set filetime $mtime
                    }
                }
            }
        }

        #-----------------------------------------------------------------
        #  check if arg is a filename, try to read "#! commands" from file
        #-----------------------------------------------------------------
        if { [file exist $filename] } {
            if { $argc <= 2 } {
                set f [open $filename "r"]
                while { [gets $f line] > -1 } {
                    if { [regexp {^#!\s*(.*)} $line all cmd] } {   ;#
                        append cmdline "$cmd\n"
                    }
                }
                close $f
                regsub -all {\$this} $cmdline $filename cmdline
            }
            if { $cmdline == "" } {
                set cmdline "plot '$filename'"
            }

            #set cmdline "set title '$filename'\n$cmdline"
            set cmdline "$cmdline"
            foreach arg [lrange $args $tryDaq+1 end] { append cmdline "$arg " }
        }

        #-----------------------------------------------------------------
        #  build cmdline from args
        #-----------------------------------------------------------------
        if { $cmdline == "" } {
            foreach arg $args { append cmdline "$arg " }
        }

        #-----------------------------------------------------------------
        #  start gnuplot if not alread running
        #-----------------------------------------------------------------
        if { ! [info exist gnuplot] } {
            # gnuplot writes to stderr!
            set gnuplot [open "|gnuplot 2>@1" r+]

            # how s small configuration can be done
            puts $gnuplot "set grid lt -1 lc '#bbbbbb'\nset style data linespoints"
            
            fconfigure $gnuplot -buffering none
            fileevent  $gnuplot readable {
                #---------------------------------------------------------
                # async. background receive
                #---------------------------------------------------------
                if { [eof $gp::gnuplot] } {
                    catch { close $gp::gnuplot }
                    unset gp::gnuplot
                } else {
                    set rx [gets $gp::gnuplot]
                    if { $gp::gnuplot_rx == "-" } {
                        puts stderr $rx; # 'gp' no longer waiting
                    } else {
                        set gp::gnuplot_rx $rx
                    }
                }
            }
        }

        #-------------------------------------------------------------------
        #  send command to gnuplot
        #-------------------------------------------------------------------
        set gnuplot_rx ""
        puts $gnuplot "$cmdline\n"

        #-------------------------------------------------------------------
        #  wait 150ms if gnuplot writes a response
        #-------------------------------------------------------------------
        after 150 [list append gnuplot_rx ""]
        vwait gnuplot_rx
        set rx $gnuplot_rx
        set gnuplot_rx "-"; # show I'm not waiting any longer!
        return $rx
    }
    #******
}

