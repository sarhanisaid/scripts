#
# $RCSfile: math.tcl,v $ --
#
#      This file contains math routines.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: math.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#

#****f* Math/::pwtk::invert3x3
# SYNOPSIS
proc ::pwtk::invert3x3 {m33} {
    # PURPOSE
    #   Invert a 3x3 matrix.
    # ARGUMENT
    # * m33 ... a 3x3 matrix specified either as a list of 9 numbers,
    #               {1 2 3 4 5 6 7 8 9},
    #           or as a 3x3 list of lists,
    #               {{1 2 3} {4 5 6} {7 8 9}}.
    #
    # RETURN VALUE
    # * Inverted 3x3 matrix in the 3x3 list of lists form, compatible
    #   with the Tcllib ::math::linearalgebra matrix representation.
    #
    # SOURCE

    if { [llength $m33] == 3 } {
        # do nothing
    } elseif { [llength $m33] == 9 } {
        set m33 [list [lrange $m33 0 2] [lrange $m33 3 5] [lrange $m33 6 8]]
    } else {
        ::pwtk::error "$m33 is not a 3x3 matrix" 1
    }
    for {set i 0} {$i<3} {incr i} {
        for {set j 0} {$j<3} {incr j} {
            set m($i,$j) [lindex [lindex $m33 $i] $j]
        }
    }
    
    set mm(0,0) [expr $m(1,1)*$m(2,2) - $m(1,2)*$m(2,1)]
    set mm(0,1) [expr $m(1,2)*$m(2,0) - $m(1,0)*$m(2,2)]
    set mm(0,2) [expr $m(1,0)*$m(2,1) - $m(2,0)*$m(1,1)]
    set mm(1,1) [expr $m(0,0)*$m(2,2) - $m(0,2)*$m(2,0)]
    set mm(1,2) [expr $m(2,0)*$m(0,1) - $m(0,0)*$m(2,1)]
    set mm(2,2) [expr $m(0,0)*$m(1,1) - $m(0,1)*$m(1,0)]
    set mm(1,0) [expr $m(2,1)*$m(0,2) - $m(0,1)*$m(2,2)]
    set mm(2,0) [expr $m(0,1)*$m(1,2) - $m(1,1)*$m(0,2)]
    set mm(2,1) [expr $m(0,2)*$m(1,0) - $m(0,0)*$m(1,2)]

    set det [expr double($m(0,0)*$mm(0,0) + $m(0,1)*$mm(0,1) + $m(0,2)*$mm(0,2))]
    if { $det < 1e-20 } {
        ::pwtk::error "colinear 3x3 matrix" 1
    }

    return [list \
                [list [expr $mm(0,0)/$det] [expr $mm(1,0)/$det] [expr $mm(2,0)/$det]] \
                [list [expr $mm(0,1)/$det] [expr $mm(1,1)/$det] [expr $mm(2,1)/$det]] \
                [list [expr $mm(0,2)/$det] [expr $mm(1,2)/$det] [expr $mm(2,2)/$det]] ]
}
#******


#****f* Math/::pwtk::norm
# SYNOPSIS
proc ::pwtk::norm {v} {
    # PURPOSE
    #   Return the size (norm) of an N-dimensional vector.
    #
    # EXAMPLE
    #      ::pwtk::norm {1.0 2.0 0.0}
    #
    # SOURCE
    set sum 0.0
    foreach c $v {
        set sum [expr $sum + $c*$c]
    }
    return [expr sqrt($sum)]
}
#******


#****f* Math/::pwtk::norm3
# SYNOPSIS
proc ::pwtk::norm3 {v} {
    # PURPOSE
    #   Return the size (norm) of a 3-dimensional vector.
    #
    # EXAMPLE
    #      ::pwtk::norm3 {1.0 2.0 0.0}
    #
    # SOURCE
    if { [llength $v] != 3 } {
        ::pwtk::error "supplied vector \"$v\" is not a 3D vector" 1
    }
    return [norm $v]
}
#******
