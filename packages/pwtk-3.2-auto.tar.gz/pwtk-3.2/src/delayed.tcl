#
# $RCSfile: delayed.tcl,v $ --
#
#      This file contains a simple mechanism for delayed evaluations.
#
# Copyright (c) 2014-2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: delayed.tcl,v 1.1 2015/01/12 17:20:57 kokalj Exp $ 
#

#****f* Delayed Execution/::pwtk::delayed_eval
# SYNOPSIS
proc ::pwtk::delayed_eval {ms args} {
    # USAGE
    #   ::pwtk::delayed_eval ms ARG ?ARG? ...
    #
    # PURPOSE
    #   Evaluate a script after after a time delay of $ms
    #   milliseconds. This command is non-blocking and returns
    #   immediately, but it arranges for a script to be executed $ms
    #   milliseconds later. The script is formed by concatenating the
    #   ARG arguments together.
    #
    # ARGUMENTS
    # * ms -- time delay in milliseconds
    # * args -- arguments concatenated into a script 
    #
    # SOURCE    
    
    variable delayed_eval

    set id [incr delayed_eval(counter)]
    set delayed_eval($id,done) 0

    after $ms "$args; set ::pwtk::delayed_eval($id,done) 1"
}
#******



#****f* Delayed Execution/::pwtk::delayed_eval_finish
# SYNOPSIS
proc ::pwtk::delayed_eval_finish {} {
    # PURPOSE
    #   Wait for all delayed evaluations spawned by
    #   ::pwtk::delayed_eval to finish. This command is blocking.    
    # SOURCE
    variable delayed_eval

    if { ! [info exists delayed_eval(counter)] } {
	return
    }

    for {set i 1} {$i <= $delayed_eval(counter)} {incr i} {
	if { ! $delayed_eval($i,done) } { 
	    print "Waiting for delayed process #.$i to finish ...\n"
	    vwait ::pwtk::delayed_eval($i,done)
	}
    }
}
#******


# Internal...
proc ::pwtk::wait_for_concurrent {} {
    # PURPOSE
    #   Wait for concurrent jobs (bgs, threads, and tpools) to finish
    variable bg
    variable thread

    if { [info exists bg(count)] && $bg(count) > 0 } {
        # wait for all backgrounds to finish
        ::pwtk::bg_wait
    }

    if { [info exists thread(count)] && $thread(count) > 0 } {
        # wait for all threads to finish
        ::pwtk::thread_wait
    }

    foreach tp [info class instances ::pwtk::tpool] {
        # wait for all tpools to finish
        $tp wait
    }
}
