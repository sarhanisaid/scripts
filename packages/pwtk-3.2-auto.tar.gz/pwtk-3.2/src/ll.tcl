#
# $RCSfile: ll.tcl,v $ --
#
#      This file contains the implementation of LL support.
#
#      ll == LoadLeveler batch queuing system.
#
# Copyright (c) 2009-2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: ll.tcl,v 1.3 2021/05/01 19:23:20 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# PUBLIC procs
#
# ------------------------------------------------------------------------


# N.B. the ::pwtk::LL and ll_* commands are created dynamically
# by calling the ::pwtk::ll::init command but they are documented here.


#****f* ::pwtk::ll/::pwtk::LL
# PURPOSE
# The master command for the LL (Load-Leveler) batch queuing. It
# manages the submission to LL.

# USAGE
#     LL { ...script code... }
#     LL file.pwtk
# or
#     LL options { ...script code... }
#     LL options file.pwtk
# or
#     LL profile ?options? { ...script code... }
#     LL profile ?options? file.pwtk
#
# DESCRIPTION
# The above "profile" is a user defined profile for LL, i.e., a set of
# "# @" directives, whereas the above "options" are the LL options
# (i.e. keyword values pairs), specified with the standard Tcl syntax
# of "-option value", i.e.:
#
#    LL -total_tasks 16 -node 2 { import job.pwtk }    (N.B. ...script code... version)
# or
#    LL -total_tasks 16 -node 2 job.pwtk               (N.B. file.pwtk version)
#
# If "profile" is omitted, the "default" profile is used, which is
# guaranteed to exist because it is defined in the
# |html <a href="../config/ll.tcl">$PWTK/config/ll.tcl</a> file.
#
# Here is an example of two user defined profiles, named "parallel" and "long":
#
#    ll_profile parallel {
#        #!/bin/sh
#        # @ job_type         = parallel
#        # @ wall_clock_limit = 6:00:00
#        # @ node             = 1
#        # @ total_tasks      = 8
#        # @ queue
#    }
#
#    ll_profile longpar {
#        #!/bin/sh
#        # @ job_type         = parallel
#        # @ wall_clock_limit = 24:00:00
#        # @ node             = 1
#        # @ total_tasks      = 64
#        # @ queue
#    }
#
# The 'longpar' profile is then requested within the PWTK script as:
#
#    LL longpar {
#         load_fromPWI scf.in
#         CONTROL { calculation = 'relax' }
#         IONS {}
#         runPW relax.in
#   }
#
# which submits the script contained within the LL { ... } command to
# the LL queuing system with the specifics defined by the 'longpar' profile.
#
# IMPORTANT
# A typical place where to store LL profiles for frequent use is in
# the ~/.pwtk/ll.tcl configuration file (N.B. in the ~/.pwtk/ll.tcl
# configuration file, the prefix 'll_' can be omitted).
#
#******

#****f* ::pwtk::ll/::pwtk::ll_profile
# USAGE
#   ::pwtk::ll_profile profileName profileSpecs ?pwtkSpecs?
#
# DESCRIPTION
#   Define a LL (Load-Leveler) "profile" within the PWTK script. See
#   also ::pwtk::LL.
#
#   Here is an example of how a new ll profile can be defined and used:
#
#      ll_profile n24 {
#         #!/bin/sh
#         # @ wall_clock_limit = 24:00:00
#         # @ blocking         = 1
#         # @ total_tasks      = 24
#      }
#
#      LL n24  job.pwtk
#
#   This submits the PWTK file job.pwtk to the LL queuing system with
#   the specifics defined by the 'n24' profile.
#
# ARGUMENTS
# * profileName -- name of the profile
# * profileSpecs -- definition of the 'profileName' profile
# * pwtkSpecs -- definition of the PWTK profile to be used when
#                the 'profileName' LL profile is used
#
# IMPORTANT
# A typical place where to store LL profiles for frequent use is in
# the ~/.pwtk/ll.tcl configuration file. Note that in the ~/.pwtk/ll.tcl
# configuration file, the prefix 'll_' can be omitted.
#
# EXAMPLE
#    ll_profile n24 {
#       #!/bin/sh
#       # @ wall_clock_limit = 24:00:00
#       # @ blocking         = 1
#       # @ total_tasks      = 24
#    } {
#       prefix mpirun -np 24
#    }
#******

#****f* ::pwtk::ll/::pwtk::ll_profileDefault
# USAGE
#   ll_profileDefault profileName
# DESCRIPTION
#   Make the 'profileName' profile the default LL profile.
#******

#****f* ::pwtk::ll/::pwtk::ll_pwtk_profile
# USAGE
#   ll_pwtk_profile profileName pwtkSpecs
# DESCRIPTION
#   Define the PWTK profile named 'profileName' and associate it with
#   the LL profile of the same name.
#
# EXAMPLE
#   ll_pwtk_profile n24 {
#      prefix mpirun -n 24
#   }
#******

#****f* ::pwtk::ll/::pwtk::ll_pwtk_profileDefault
# USAGE
#   ll_pwtk_profileDefault profileName
# DESCRIPTION
#   Make the pwtk 'profileName' profile the default PWTK profile for LL.
#******

#****f* ::pwtk::ll/::pwtk::ll_head
# USAGE
#   ll_head { batch sh-script excerpt }
#
# EXAMPLE
#   ll_head {
#      echo "Today is `date`"
#      module load qe-7.3
#   }
#
# DESCRIPTION
#   This command sets the "head" part of the LL batch shell
#   script. In PWTK, the batch shell script is composed of four
#   parts:
#
#        profile   (always exists)
#         |
#        head      (optional)
#         |
#        pwtk      (always exists)
#         |
#        tail      (optional)
#
#   where:
#   * profile -- contains the batch-queue directives (e.g. # @);
#                it is set with ll_profile command
#   * head -- contains optional shell commands that are executed
#             prior to executing PWTK, such as "module load ...";
#             it is set with ll_head command
#   * pwtk -- in this part, the PWTK script is executed;
#             it is set internally by PWTK
#   * tail -- contains optional shell commands that are executed
#             after the PWTK script finishes;
#             it is set with ll_tail command
#******

#****f* ::pwtk::ll/::pwtk::ll_tail
# USAGE
#   ll_tail { batch sh-script excerpt }
#
# EXAMPLE
#   ll_tail {
#      # copy the scratch files in WORKDIR to $PWD
#      cp -a $WORKDIR .
#   }
#
# DESCRIPTION
#   This command sets the "tail" part of the LL batch shell
#   script. In PWTK, the batch shell script is composed of four parts
#   (for description, see ::pwtk::ll_head).
#******

#****f* ::pwtk::ll/::pwtk::ll_clear
# USAGE
#   ll_clear
# DESCRIPTION
#   Clear the current content of the LL batch shell script as stored in PWTK.
#******

#****f* ::pwtk::ll/::pwtk::ll_fprint
# USAGE
#   ll_fprint ?FILE?
# PURPOSE
#   Typically used intenally by PWTK.
# DESCRIPTION
#   Print the current content of the LL batch shell script to FILE
#   or to stdout if FILE was not specified.
#******

#****f* ::pwtk::ll/::pwtk::ll_get
# USAGE
#   ll_get ?profileName?
# PURPOSE
#   Typically used intenally by PWTK.
# DESCRIPTION
#   Return the current content of the LL batch shell script.
#******


# ------------------------------------------------------------------------    
#
# INTERNAL procs
#
# ------------------------------------------------------------------------


#****if* Internals/::pwtk::ll::init
# SYNOPSIS
proc ::pwtk::ll::init {} {
    # PURPOSE
    #    Used intenally by PWTK.
    # DESCRIPTION
    #    Initialization of the LoadLeveler (ll) batch queuing system.
    # SOURCE
    
    ::pwtk::queue::init ll llsubmit "# @"
}
#******


#****if Internals/::pwtk::ll::parseOptions_
proc ::pwtk::ll::parseOptions_ {profileName args} {
    # PURPOSE
    #   Parse the LoadLeveler (LL) options (aka keywords) stored in
    #   $args, and produce a LL profile by merging them with the
    #   corresponding $profileName LL profile. The result is stored in
    #   the ::pwtk::queue::queue(ll,profile) variable.
    #
    # BEWARE
    #   The implicit assumption of this parser is that the LL job command
    #   file has one keyword per line, i.e.:
    #
    #      # @ keyword1 = value1
    #      # @ keyword2 = value2
    #      # @ keyword3
    #
    # ARGUMENTS
    # * profileName -- name of the LL profile
    # * args -- command-line options of the LL command.
    #
    # SOURCE

    if { $args eq {} } {
        # use the profile verbatim
        set ::pwtk::queue::queue(ll,profile) [::pwtk::trimIndent [::pwtk::varvalue ::pwtk::queue::profile(ll,$profileName)]]\n
    } else {
        # add the command-line options to the $profileName LL profile

        # the LL profile looks like:

        #!/bin/sh
        # @ job_type         = parallel
        # @ wall_clock_limit = 6:00:00
        # @ total_tasks      = 4
        # @ queue

        # parse the profile and store its keywords
        set content [::pwtk::trimIndent [::pwtk::varvalue ::pwtk::queue::profile(ll,$profileName)]]

        set key_list {}
	foreach line [split $content \n] {		    	    
	    if { [regexp {^# *@} $line] } {		
		# it is a "# @" line, get rid of "# @" and parse options ...
                #
                # we assume the following syntax: keyword = value value value value ...
		# hence fields past the = sign are the keyword values

                set keywordValue [string trim [regsub = [regsub {^# *@} $line {}] { }]]
                set keyword [lindex $keywordValue 0]
                set value   [string trim [string range $keywordValue [string length $keyword] end]]
                
		lappend key_list [list $keyword $value]
	    }
	}

        puts "key_list: $key_list"
        
        # add the options specified on the LL command-line; new options
        # are added before the "# @ queue" line
        #
        # assumed syntax of options on the LL command-line: -option1 value1 -option2 value2

        set queue_index [lsearch -glob $key_list "queue *"]

	foreach {option value} $args {
            puts "option=$option value=$value"
	    set keyword [string trimleft $option -]
	    set index   [lsearch -glob $key_list "$keyword *"]

	    if { $index < 0 } {
		# append before the "# @ queue"
                set key_list [linsert $key_list $queue_index [list $keyword $value]]
	    } else {
		# replace the value of the keyword
		set key_list [lreplace $key_list $index $index [list $keyword $value]]
	    }
	}	
    
        # build a LL profile

        set ::pwtk::queue::queue(ll,profile) {}
        set printed 0
        foreach line [split $content \n] {	
            if { [regexp {^# *@} $line] } {                
                # a "# @" line, print options ...                
                if { ! $printed } {
                    # write all the options
                    foreach optionValue $key_list {
                        lassign $optionValue option value
                        set sep [expr {$value ne {} ? "=" : " "}]
                        append ::pwtk::queue::queue(ll,profile) [format "# @ %-20s $sep %s\n" $option $value]
                    }
                    set printed 1
                }
            } else {
                # whatever line ...
                append ::pwtk::queue::queue(ll,profile) $line\n
            }
        }
    }
}
