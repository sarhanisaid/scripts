#
# bands.tcl
#
#      This file contains the implementation of the BANDS workflow for
#      calculating and plotting the spaghetti band-structure
#      plots. The workflow is implelemted with the "::pwtk::bands_run"
#      command.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#


#****f* BANDS/::pwtk::bands_run
# SYNOPSIS
proc ::pwtk::bands_run {args} {
    # PURPOSE
    #   A configurable workflow for calculating and plotting spaghetti
    #   BANDS, and if requested, total DOS alongside spaghetti.
    #
    # USAGE
    #   ::pwtk::bands_run ?SPECIFIC-OPTIONS?  ?PLOTTING-OPTIONS?  HEAD  UNIT  NKTOT  KPATH_SPECS  ?KPATH_SPECS?  ...
    #
    #   where SPECIFIC-OPTIONS are:
    #
    #       -scf
    #       -nscf KGRID
    #       -preserve
    #       -gap
    #       -dos
    #       -intdos
    #       -dd  DOS_SIZE
    #       -e   EFERMI
    #       -emin EMIN
    #       -emax EMAX
    #    
    #  PLOTTING-OPTIONS:
    #
    #       -out   ROOTNAME
    #       -w     WITH
    #       -w_dw  WITH
    #       -dw    DOS_WITH
    #       -dw_dw DOS_WITH
    #       -fc    DOS_FILL_COLOR
    #       -fc_dw DOS_FILL_COLOR
    #       -iw    WITH
    #       -itc   INTDOS_TEXTCOLOR
    #
    #   For other PLOTTING-OPTIONS, see: ::pwtk::plot.
    #   Ignored PLOTTING-OPTIONS: -xt, -mx, -xf, -u
    #
    #   A more detailed description of SPECIFIC-OPTIONS and ARGUMENTS is provided below.
    #
    # DESCRIPTION
    #   A workflow for calculating and plotting the spaghetti band
    #   structure plot, and optionally total DOS alongside
    #   spaghetti. The sequence of calculations is:
    #   
    #      pw.x SCF (optional, requested by -scf)
    #       |
    #       +--> for -gap if needed: pw.x fixed-occupations SCF
    #      (|)                        |
    #       +<---------------------- pw.x fixed-occupations NSCF
    #       |
    #      pw.x NSCF (optional, requested by -nscf KGRID)
    #       |
    #      dos.x (optional, requested by -dos or -intdos)
    #       |
    #      pw.x BANDS
    #       |
    #      bands.x
    #       |
    #      PLOTTING
    #
    # SPECIFIC OPTIONS
    # * -scf --- perform an SCF pw.x calculation (the Fermi energy is taken
    #            from this SCF calculation unless the -nscf or -e option is specified)

    # * -nscf {K1 K2 K3  ?SK1 SK2 SK3?} ---
    #                   perform NSCF pw.x calculation using the provided automatic k-point grid;
    #                   if SK1,SK2,SK3 shifts are omitted, a non-shifted k-mesh is used;
    #                   (the Fermi energy is taken from this NSCF calculation unless the -e option is specified)

    # * -gap       --- report the band gap using the combination of fixed-occupations (N)SCF
    #                  and 'bands' pw.x calculations;
    #                  if the input-data correpond to smearing occupations,
    #                  PWTK additionally performs the fixed-occupations SCF and for -nscf also
    #                  fixed-occupations NSCF pw.x calculations, ensuring that pw.x
    #                  prints the line: "highest occupied, lowest unoccupied level (ev): ....";
    #                  BEWARE: do not apply this option for metals

    # * -preserve  --- preserve the 'outdir'; pw.x 'bands' calculation "corrupts" the outdir, and
    #                  this options requests the 'outdir' to be preserved by using the copy of
    #                  'outdir' for 'bands' calculations

    # * -dos         --- calculate and plot also total DOS using dos.x
    # * -intdos      --- for -dos, plot also integrated DOS; implies -dos
    # * -dd DOS_SIZE --- relative size of the DOS plot (default = 0.25)

    # * -e EFERMI  --- Fermi energy (either a floating-point number or a pw.x output file
    #                  from where the Fermi energy is taken)

    # * -emin EMIN --- (used only for -dos) the minimum-energy with respect to Fermi energy (in eV) to be
    #                  used for dos.x, i.e., Emin of dos.x is set to: Emin = EMIN + Efermi

    # * -emax EMAX --- (used only for -dos) the maximum-energy with respect to Fermi energy (in eV) to be
    #                  used for dos.x, i.e., Emax of dos.x is set to: Emax = EMAX + Efermi

    # PLOTTING OPTIONS:
    # * -out   ROOTNAME  --- rootname for the Gnuplot-script and, for file terminals,
    #                        the output image file (default = the value of the HEAD argument)
    # * -w     WITH      --- Gnuplot's "with" plot specs for the DOS
    #
    # * -w_dw WITH --- Gnuplot's "with" plot specs for spin-down bands (the -w option is used for the spin-up analogue)

    # * -dw DOS_WITH       --- Gnuplot's "with" plot specification for DOS
    # * -dw_dw DOS_WITH    --- Gnuplot's "with" plot specification for spin-down DOS
    # * -fc DOS_FILL_COLOR --- fill color for the DOS filledcurve (e.g. -fc {lt 1} or -fc {fc "cyan"})
    # * -fc_dw DOS_FILL_COLOR --- fill color for the spin-down DOS filledcurve
    # * -iw    WITH      --- Gnuplot's "with" plot specs for the Integrated DOS
    # * -itc   TEXTCOLOR --- textcolor of Integrated DOS label and y2tics
    #
    # For other PLOTTING OPTIONS, see ::pwtk::plot
    #
    # ARGUMENTS
    # * HEAD --- the rootname for files, which will be named as prefix.HEAD.postfix
    
    # * UNIT --- units in which the k-points are specified (tbipa* or crystal*, i.e.,
    #            tpiba_b is here synonymous with tpiba and likewise for crystal_b)

    # * NKTOT --- total number of k-points uniformly distributed along the k-path

    # * KPATH_SPECS --- one or more spaghetti continuous k-path specs. More than one KPATH_SPECS arguments
    #                   are used when the k-path is discontinuous. Each KPATH_SPECS is specified as:
    #
    #          kx(1) ky(1) kz(1) ?label(1)?  ... coordinates and label of the 1st special k-point (label is optional)
    #          kx(2) ky(2) kz(2) ?label(2)?  ... coordinates and label of the 2nd special k-point (label is optional)
    #          ...
    #          kx(n) ky(n) kz(n) ?label(n)?  ... coordinates and label of the Nth special k-point (label is optional)
    #
    # 
    # BEWARE
    #   This workflow performs BANDS pw.x calculation, implying that
    #   an SCF (or *relax) pw.x calculation must be performed prior to
    #   using this workflow, unless the -scf option is specified,
    #   which performs such an SCF calculation.
    #
    # EXAMPLE
    #   # plot a spaghetti band-structure for Si-bulk
    #
    #   load_fromPWI scf.Si-bulk.in
    #
    #   bands_run -scf -t png  Si-bulk  crystal 100 {
    #      0.00     0.500     0.000     L
    #      0.00     0.000     0.000     Γ
    #      0.50     0.500     0.000     X
    #      0.25     0.500    -0.250     W
    #      0.00     0.375    -0.375     K
    #      0.00     0.500     0.000     L
    #   } {
    #      0.00     0.000     0.000     Γ
    #      0.625    0.375     0.000     U
    #   }
    #
    #   # plot DOS alongside BANDS spaghetti plot with the -dos option
    #
    #   DOS { DeltaE = 0.03  bz_sum = 'tetrahedra' }
    #   
    #   bands_run -scf -nscf {8 8 8} -dos -t png  Si-bulk  crystal 100 {
    #      0.00     0.500     0.000     L
    #      0.00     0.000     0.000     Γ
    #      0.50     0.500     0.000     X
    #      0.25     0.500    -0.250     W
    #      0.00     0.375    -0.375     K
    #      0.00     0.500     0.000     L
    #   }
    #
    # RETURN VALUE
    #   Filename of the created spaghetti plot (for file terminals) or
    #   the empty string (for window terminals).
    #
    # SOURCE

    set mode run

    printTitle BANDS_RUN "Running the BANDS workflow"
    print "Workflow options & arguments :  $args\n"
    
    # parse & check

    bandsParseOpts_
    bandsCheckUnit_
    bandsParseKSpecs_
    set n_kpath_specs [llength $args]
    
    if { ! [::pwtk::type::number posint -strict $nktot] } {
        ::pwtk::error "expected positive integer for the total number of k-points (NKTOT), but got \"$nktot\"" 1
    }
    
    # printout
    
    print "Rootname for I/O files:  $head

Requested total number of k-points     :   $nktot
Number of special k-points             :   $nk
Special k-points specified in units    :   $unit
Number of discontinuities in the k-path:   [expr $n_kpath_specs - 1]\n"

    if { $opt(dos) } {
        print "In addition to BANDS, DOS plot was also requested\n"
    }

    # no 'tetrahedra*' & 'from_input' for BANDS
    #
    # N.B. this is very restrictive, but it is safer (if the user wants
    # to plot DOS with tetrahedra, bz_sum = 'tetrahedra' can be used)
    
    set occ [::pwtk::input::namelistGetVarValue SYSTEM -nocase occupations trim]
    if { [regexp {tetrahedra|from_input} $occ] } {
        ::pwtk::error "occupations = '$occ' not compatible with calculation = 'bands'" 1
    }
    
    # calculate
    
    input_pushpop {
        input_clear IONS CELL

        # perform SCF + NSCF calcs & fetch Efermi
        SCF_NSCF_
        Efermi_

        # dos.x

        if { $opt(dos) } {
            dosCalc_
        }
        
        # spin-polarized ?

        set nspin [::pwtk::input::namelistGetVarValue SYSTEM -nocase nspin]
        set spin  [expr { [string is integer $nspin] && $nspin > 1 ? 1 : 0 }]

        # distribute k-points uniformly

        bandsDistributeK_

        # pw.x BANDS

        if { $opt(preserve) } {
            set outdir [outdir_backup bands]
            CONTROL [subst {
                calculation = 'bands'
                outdir = '$outdir'
            }]
        }

        ## N.B. this was moved up
        ## no 'tetrahedra' & 'from_input' for BANDS
        #set occ [::pwtk::input::namelistGetVarValue SYSTEM -nocase occupations trim]
        #if { $occ ne {} && $occ ne "smearing" } {
        #    infoMsg "occupations = '$occ' not compatible with calculation = 'bands';\ndisabling occupations"
        #    SYSTEM " occupations = "
        #    ifexist nbnd { SYSTEM " nbnd = $nbnd " }
        #}

        for {set ip 1} {$ip <= $npath} {incr ip} {
            if { $npath > 1 } {
                set name($ip) $head.$ip
                set part " (part-$ip/$npath)"
            } else {
                set name($ip) $head
                set part {}
            }
            print BANDS "Performing BANDS pw.x calculation$part\n"
            print "K-path specs:\n[join $kpath($ip) \n]\n"

            K_POINTS $unit $kpointCard($ip)
        
            runPW pw.$name($ip).bands

            # bands.x

            print BANDS "Performing bands.x calculation$part\n"
            if { ! $spin } {
                BANDS " filband = '$name($ip).dat' "; # N.B.: gnuplot file will be written to $name($ip).dat.gnu
                set bo($ip) [runBANDS bands.$name($ip)]
            } else {
                BANDS " filband = '$name($ip).up.dat'  spin_component = 1"
                set bo($ip.up) [runBANDS bands.$name($ip).up]
                
                BANDS " filband = '$name($ip).dw.dat'  spin_component = 2"
                set bo($ip.dw) [runBANDS bands.$name($ip).dw]
            }
        }
    }

    # report BANDS refined band gap
    bandsBandGap_
    
    # plot

    return [bandsPlot_]
}
#******


#****f* BANDS/::pwtk::bands_plot
# SYNOPSIS
proc ::pwtk::bands_plot {args} {
    # USAGE
    #   ::pwtk::bands_plot ?OPTIONS?  HEAD  UNIT  NKTOT  KPATH_SPECS  ?KPATH_SPECS?  ...
    #
    # DESCRIPTION
    #   The usage of this command is fully analogous to ::pwtk::bands_run, but
    #   the command skips the calculations and only plots the spaghetti BANDS,
    #   and, if requested, DOS.
    #
    #   This command requires the same QE input data as ::pwtk::bands_run.
    #   Furthermore, the output files produced by ::pwtk::bands_run must exist.
    #
    # BEWARE
    #   The specified KPATH_SPECS must be identical to those used in
    #   preceding ::pwtk::bands_run. Otherwise:
    #   * either the plotted spaghetti BANDS will be wrong
    #   * or the command will abort by complaining about missing files
    #
    # SEE
    #   ::pwtk::bands_run
    #
    # RETURN VALUE
    #   Filename of the created spaghetti plot (for file terminals) or
    #   the empty string (for window terminals).
    #
    # SOURCE

    set mode plot
    
    printTitle BANDS_PLOT "Plotting spaghetti BANDS"
    print "Options & arguments :  $args\n"

    # parse options & arguments
    bandsParseOpts_
    bandsCheckUnit_
    bandsParseKSpecs_

    # parse kpath_specs & distribute k-points uniformly
    bandsDistributeK_
    
    # check that if the corresponding bands.x files exist
    bandsCheckFiles_

    # get Fermi energy
    Efermi_
    
    # plot
    return [bandsPlot_]
}
#******


# internal...
proc ::pwtk::bandsParseOpts_ {} {
    # PURPOSE
    #   Parse command-line options & arguments for bands_run & bands_plot
    
    uplevel 1 {
        ::pwtk::gp::defaultCmdlineOpts_ plot options usage workflow

        ignoredOpts_ {-xt -mx -xf -u} $args
        
        addOpts_ options usage {
            {scf         "perform an SCF calculation prior to the BANDS pw.x calculation"}
            {nscf.arg {} "the k-point grid for the optional NSCF pw.x calculation"}
            {gap         "report band gap using fixed-occupations pw.x calculation"}
            {preserve    "preserve the 'outdir' by using the copy of 'outdir' for 'bands' calculations"}
            {dos         "calculate and plot also total DOS using dos.x"}
            {intdos      "for -dos, plot also integrated DOS"}
            {dd.arg 0.25 "relative size of the DOS plot"}
            {e.arg    {} "Fermi energy (either a floating-point number or a pw.x output file from where the Fermi energy is taken"}
            {emin.arg {} "Emin for dos.x with respect to Fermi energy (in eV)"}
            {emax.arg {} "Emax for dos.x with respect to Fermi energy (in eV)"}

            {w_dw.arg  {} "Gnuplot's \"with\" plot specification for the spin-down bands"}            
            {dw.arg    {} "Gnuplot's \"with\" plot specification for DOS"}
            {dw_dw.arg {} "Gnuplot's \"with\" plot specification for spin-down DOS"}
            {fc.arg    {} "fill color for the DOS filledcurve"}
            {fc_dw.arg {} "fill color for the spin-down DOS filledcurve"}
            {iw.arg    {} "Gnuplot's \"with\" plot specs for the Integrated DO"}
            {itc.arg   {} "textcolor of Integrated-DOS label"}
        } {
            -scf {-nscf KGRID} -gap -preserve -dos -intdos {-dd DOS_SIZE}
            {-e EFERMI} {-emin EMIN} {-emax EMAX}
            {-w_dw WITH_DW}
            {-dw DOS_WITH} {-dw_dw DOS_WITH} {-fc DOS_FILL_COLOR} {-fc_dw DOS_FILL_COLOR}
            {-iw WITH} {-itc TEXTCOLOR}
        }

        # N.B. do not assign a default value for -yl here; it is assigned in ::pwtk::bandsPlot_
        setOpts_ options [subst {
            bm    2
            w     {$::pwtk::gp::gp(bands_with)}
            w_dw  {$::pwtk::gp::gp(bands_with_dw)}
            dw    {$::pwtk::gp::gp(bands_dos_with)}
            dw_dw {$::pwtk::gp::gp(bands_dos_with_dw)}
            fc    {$::pwtk::gp::gp(bands_dos_fill_color)}
            fc_dw {$::pwtk::gp::gp(bands_dos_fill_color_dw)}
            iw    {$::pwtk::gp::gp(intdos_with)}
            itc   {$::pwtk::gp::gp(intdos_text_color)}
        }]

        set nargmin 4
        set nargmax -1
        set usage "[fmtUsage_ $usage]  HEAD  UNIT  NKTOT  KPATH_SPECS  ?KPATH_SPECS?  ..."
        parseOpt_
        
        checkOType_ -nscf $opt(nscf) {numberlist nonnegint} "list of non-negative integer numbers (i.e. automatic k-point grid specs)"
        checkOTypeStrict_ -dd $opt(dd) {number real01} "relative size within 0-1"
        
        if { ! [file exists $opt(e)] && ! [string is double $opt(e)] } {
            ::pwtk::error "expected a real number or a pw.x output file for Fermi energy, but got \"$opt(e)\"" 1
        }
        ::pwtk::gp::checkCmdlineOpts_ opt

        # -intdos implies -dos
        
        if { $opt(intdos) } {
            set opt(dos) 1
        }
        
        # arguments
        
        set args [lassign $args head unit nktot]
        set dos  $head.dos

        if { $opt(out) eq {} } {
            set plotname $head
        } else {
            set plotname [headname $opt(out) .$opt(t)]
        }
        if { $opt(dos) } {
            set plotname spaghetti+dos.$plotname
        } else {
            set plotname spaghetti.$plotname
        }
        print "Rootname for files:    $head
Plotting filenames:    $plotname.POSTFIX\n"
    }
}



# internal...
proc ::pwtk::bandsParseKSpecs_ {} {
    # PURPOSE
    #   Parse K-path specs
    uplevel 1 {
        # parse k-path specs
        
        foreach kpath_specs $args {
            incr npath
            set kpath($npath) [split [::pwtk::skipEmptyLines $kpath_specs] \n]
            ifempty kpath($npath) {
                ::pwtk::error "no k-points specified" 1
            }
            foreach line $kpath($npath) {
                incr nk
                set kpt($nk)   [lrange $line 0 2]
                set label($nk) [lindex $line 3]
                ifset path($npath,1st_k) $nk
                ifset label($nk) K.$nk

                if { [llength $line] < 3 || [llength $line] > 4 } {
                    ::pwtk::error "syntax error in k-point #.$nk specs: must be \"kx ky kz ?label?\", but got \"$line\"" 1
                }
                if { ! [::pwtk::type::numberlist double -strict $kpt($nk)] } {
                    ::pwtk::error "syntax error in k-point #.$nk coordinates: expected three floating-point numbers, but got \"$kpt($nk)\" 1" 1
                }
            }
            set path($npath,last_k) $nk
        }
    }
}

# internal...
proc ::pwtk::bandsDistributeK_ {} {
    # PURPOSE
    #   Distribute k-points uniformly along the path
    
    uplevel 1 {
        # distribute k-points uniformly

        if { $unit eq "crystal_b" } {
            #  get a usable pw.x output file to get the reciprocal lattice vectors
            if { $opt(scf) } {
                set out pw.$head.scf.out
            } elseif { $opt(nscf) ne {} } {
                set out pw.$head.nscf.out
            } elseif { [file exists opt(e)] } {
                set out $opt(e)
            }
            
            if { ! [info exists out] } {
                set out [::pwtk::dryrunPW]
            }
            fileMustExist $out "pw.x output file"
            
            # transform k-points to Cartesian coordinates
            set rv  [::pwtk::matricize [::pwtk::pwo::reciprocal_axes $out]]
            for {set ik 1} {$ik <= $nk} {incr ik} {
                set kcart($ik) [::math::linearalgebra::matmul $kpt($ik) $rv]
            }
        } else {
            array set kcart [array get kpt]
        }

        # calculate distances

        set len 0.0
        for {set ik 1} {$ik < $nk} {incr ik} {
            set dist($ik) [::pwtk::norm [::math::linearalgebra::sub $kcart($ik) $kcart([expr $ik+1])]]
            set len [expr $len + $dist($ik)]
        }

        # construct the content of the K_POINTS card(s)

        for {set ip 1} {$ip <= $npath} {incr ip} {
            
            set kpointCard($ip) [expr $path($ip,last_k) - $path($ip,1st_k) + 1]\n
            
            for {set ik $path($ip,1st_k)} {$ik < $path($ip,last_k)} {incr ik} {
                append kpointCard($ip) "$kpt($ik)   [expr round($nktot * $dist($ik)/$len)]\n"
            }
            append kpointCard($ip) "$kpt($ik)   0"
        }
    }
}


# internal...
proc ::pwtk::bandsPlot_ {} {
    uplevel 1 {
        if { $opt(dos) } {
            print PLOT "Plotting the spaghetti band structure with DOS\n"
        } else {
            print PLOT "Plotting the spaghetti band structure\n"
        }
        set gp [::pwtk::gp::plot new -s $opt(s) $plotname.$opt(t)]

        # DOS filledcurves are used only if one of -scf -nscf -e was specified

        if { !$opt(scf) && $opt(nscf) eq {} && $opt(e) eq {} } {
            # Efermi is unspecified
            ifset opt(yl) "Energy (eV)"
        } else {
            ifset opt(yl) "{\{/${::pwtk::gp::gp(font)}-Italic E\} − \{/${::pwtk::gp::gp(font)}-Italic E\}_F (eV)}"
            set dos_fill 1
        }
        
        # do we plot DOS ?
        
        if { $opt(dos) } {
            $gp add "
set multiplot

set origin 0.0,0.0
set size   1-$opt(dd),1.0
"
        }

        # SPAGHETTI
        
        set x0   0.0
        set xgap [expr 0.02*$len]

        set xtics "("
        set plot {}
        for {set ip 1} {$ip <= $npath} {incr ip} {
            set bout [expr { $spin ? "$bo($ip.up)" : "$bo($ip)" }]
            set xoff($ip) $x0

            for {set ik $path($ip,1st_k)} {$ik <= $path($ip,last_k)} {incr ik} {
                set d_ik [expr $ik - $path($ip,1st_k)]
                set xik  [::pwtk::grep_field {  high-symmetry point:} $bout end $d_ik]
                if { $xik eq {} } {
                    ::pwtk::error "cannot grep #.$ik high-symmetry K-point from $bout;
most likely [procName] was called with incompatible KPATH_SPECS" 1
                }
                set xx   [expr $x0 + $xik]
                append xtics "'$label($ik)'  $xx, "
            }
            set x0 [expr $xx + $xgap]

            if { ! $spin } {
                append plot " '$name($ip).dat.gnu' u (\$1+$xoff($ip)):(\$2-Efermi) w $opt(w),"
            } else {
                append plot " '$name($ip).up.dat.gnu' u (\$1+$xoff($ip)):(\$2-Efermi) w $opt(w),"
                append plot " '$name($ip).dw.dat.gnu' u (\$1+$xoff($ip)):(\$2-Efermi) w $opt(w_dw),"
            }
        }
        set plot [string trimright $plot ,]
        append xtics ")"

        $gp cmdlineOpts opt
        $gp options [list xrange \[0:$xx\]  ylabel {offset 0.5}  xtics $xtics  grid {xtics lt -1 lw 1}]
        $gp unset xlabel mxtics
        ifempty opt(key) { $gp unset key }
        if { $opt(dos) } {
            $gp set rmargin 1
            if { $opt(y2l) ne {} } { $gp unset y2label }
        }
        if { $opt(intdos) } {
            $gp set tmargin 2
        }
        $gp add "Efermi = $Efermi"
        $gp plot $plot
        
        # DOS

        if { $opt(dos) } {
            $gp unset xtics ylabel
            $gp options "
origin 1-$opt(dd),0.0
size $opt(dd),1.0
"
            
            $gp options "
format.y ''
lmargin 0
rmargin 7
"
            ifempty opt(xr) {
                $gp unset xrange
            } else {
                $gp set xrange [rangequote $opt(xr)]
            }
            ifempty opt(xl) {
                $gp set xlabel 'DOS'
            } else {
                $gp set xlabel [squote $opt(xl)]
            }
            ifempty opt(y2l) {
                $gp set y2label "[squote $opt(yl)] offset -1"
            } else {
                $gp set y2label "[squote $opt(y2l)] offset -1"
            }
            ifnotempty opt(yr) {
                $gp set y2range [rangequote $opt(yr)]
            } else {
                $gp set yrange  [rangequote GPVAL_Y_MIN:GPVAL_Y_MAX]
                $gp set y2range [rangequote GPVAL_Y_MIN:GPVAL_Y_MAX]
            }
            ifnotempty opt(yt) {
                $gp set y2tics $opt(yt)
            } else {
                $gp set ytics  autofreq
                $gp set y2tics autofreq
            }
            ifnotempty opt(my) { $gp set my2tics $opt(my) }
            ifnotempty opt(rm) {
                $gp set rmargin $opt(rm)
            } else {
                $gp set rmargin 7
            }

            # if Efermi was specified, use filledcurve
            set plot {}
            ifexist dos_fill {
                set plot "'$head.dos' u (\$1-Efermi <= 0.0 ? \$2 : 0/0):(\$1-Efermi) w filledcurve x1=0.0 $opt(fc), "
            }
            append plot "'$head.dos' u 2:(\$1-Efermi) w $opt(dw)"            
            
            if { $spin } {
                ifexist dos_fill {
                    append plot ", '$head.dos' u (\$1-Efermi <= 0.0 ? -\$3 : 0/0):(\$1-Efermi) w filledcurve x1=0.0 $opt(fc_dw)"
                }
                append plot ", '$head.dos' u (-\$3):(\$1-Efermi) w $opt(dw_dw)"                
            }
            
            if { $opt(intdos) } {
                # Integrated DOS
                ifnotempty opt(x2t) {
                    $gp set x2tics "textcolor $opt(itc)"
                    $gp set x2tics $opt(x2t)
                }
                ifempty opt(x2l) { $gp set x2label "'Int DOS (e)' textcolor $opt(itc)" }
                append plot ", '$dos' u (\$[expr 3+$spin]):(\$1-Efermi) axes x2y1 w $opt(iw)"
            }

            $gp plot $plot
        }     

        ::pwtk::gp::execDisplay_ $gp opt
    }
}



# internal...
proc ::pwtk::bandsCheckFiles_ {} {
    # PURPOSE
    #   1. Check that needed bands.x files exists.
    #   2. Assign bands.x output files to "bo" array
    #
    # BEWARE
    #   This proc should be compatible with the bands.x computational
    #   part of run_bands, i.e., naming of files
    
    uplevel 1 {
        # spin-polarized ?

        if { $opt(scf) && [grep magnetic pw.$head.scf.out] ne {} } {
            set nspin 2        
        } elseif { $opt(nscf) ne {} && [grep magnetic pw.$head.nscf.out] ne {} } {
            set nspin 2
        } elseif { [file exists $opt(e)] && [grep magnetic $opt(e)] ne {} } {
            set nspin 2
        } else {
            set nspin [::pwtk::input::namelistGetVarValue SYSTEM -nocase nspin]
        }
        set spin  [expr { [string is integer $nspin] && $nspin > 1 ? 1 : 0 }]

        # loop over k-paths and check for bands.x files

        for {set ip 1} {$ip <= $npath} {incr ip} {
            if { $npath > 1 } {
                set name($ip) $head.$ip
            } else {
                set name($ip) $head
            }
            if { ! $spin } {
                set bo($ip) bands.$name($ip).out
                fileMustExist $bo($ip)           "bands.x output file"
                fileMustExist $name($ip).dat.gnu "bands.x data file"
            } else {
                foreach s {up dw} {
                    set bo($ip.$s) bands.$name($ip).$s.out
                    fileMustExist $bo($ip.$s)        "bands.x output file"
                    fileMustExist $name($ip).$s.dat.gnu "bands.x data file"
                }
            }
        }
    }
}


# internal...
proc ::pwtk::bandsCheckUnit_ {} {
    uplevel 1 {
        switch -glob -- $unit {
            tpiba*   { set unit tbipa_b }
            crystal* { set unit crystal_b }
            default {
                ::pwtk::error "wrong unit for k-points, must be tpiba* or crystal*, but got '$unit'" 1
            }
        }
    }
}


# internal...
proc ::pwtk::bandsBandGap_ {} {
    uplevel 1 {
        if { $gap_ok } {
            set type [expr { $opt(nscf) eq {} ? "SCF" : "NSCF" }]            
            print BAND_GAP "Estimating band gap from $type and BANDS pw.x calculations\n"

            if { $Ehomo > $Elumo } {
                print "Band gap estimation from $type and BANDS pw.x calculations skipped because 
in the pw.x '$pwo_gap' output file:\n\n   lowest unoccupied level > highest occupied level\n"     
            } else {
                # bands.x datafiles:
                # nspin == 1:  $name($ip).dat.gnu
                # nspin == 2:  $name($ip).up.dat.gnu & $name($ip).dw.dat.gnu

                set data {}
                for {set ip 1} {$ip <= $npath} {incr ip} {
                    if { $spin } {
                        append data [readFile $name($ip).up.dat.gnu]\n[readFile $name($ip).dw.dat.gnu]\n
                    } else {
                        append data [readFile $name($ip).dat.gnu]
                    }
                }

                print "Band Gap (from $pwo_gap):
- highest occupied level (eV) :     $Ehomo
- lowest unoccupied level (eV):     $Elumo
- band gap (eV)               :     [format %.4f $gap]

Checking if BANDS give better highest occupied & lowest unoccupied levels..."

                set refined 0
                foreach {x E} $data {
                    if { $E > $Ehomo && $E < $Elumo } {
                        #print "- band energy $E is within SCF highest occupied ($Ehomo eV) & lowest unoccupied ($Elumo eV) levels;"

                        set dE_homo [expr $E - $Ehomo]
                        set dE_lumo [expr $Elumo - $E]
                        if { $dE_homo < $dE_lumo } {
                            print "- new highest occupied level  = $E eV"
                            set Ehomo $E
                            set refined 1
                        } else {
                            print "- new lowest unoccupied level = $E eV"
                            set Elumo $E
                            set refined 1
                        }
                    }
                }

                if { $refined } {
                    set gap [expr $Elumo - $Ehomo]
                    print "
BANDS refined Band Gap:
- highest occupied level (eV) :    $Ehomo
- lowest unoccupied level (eV):    $Elumo
- band gap (eV)               :    [format %.4f $gap]

N.B. please check the BANDS spaghetti plot if BANDS derived highest occupied
     and lower unoccupied levels were correctly assigned\n"

                } else {
                    print "(BANDS provide no refinement)\n"
                }
            }
        }
    }
}
