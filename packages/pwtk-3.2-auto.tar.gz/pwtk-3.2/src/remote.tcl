#
# $RCSfile: remote.tcl,v $ --
#
#      This file contains the machinery for remote execution of
#      scripts/calculations.
#
# Copyright (c) 2014-2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: remote.tcl,v 1.3 2021/05/03 14:20:36 tone Exp $ 
#

#****a* 5.3.5. Background and Remote and Delayed Execution/Remote Execution
# DESCRIPTION
#   Collection of commands for remote execution of jobs.
#
#   N.B.: The remote execution is not meant to be run on HPC
#   supercomputers, where PWTK batch-queuing should be used instead.
#
#******

#****if* Internals/::pwtk::remote_exec
# SYNOPSIS
proc ::pwtk::remote_exec {args} {
    # PURPOSE
    #   Prints a message that ::pwtk::remote_exec is no longer
    #   available because it was superseded by ::pwtk::remote.
    warning "[procName] is no longer available. Use ::pwtk::remote instead"
    abort 
}
#******


#****f* Remote Execution/::pwtk::remote
# SYNOPSIS
proc ::pwtk::remote {args} {
    # USAGE    
    #   remote  ?OPTIONS?  USER@HOST  SCRIPT_CODE
    # or    
    #   remote  ?OPTIONS?  USER@HOST  SCRIPT_FILE
    #
    # where OPTIONS are:
    #     -fg
    #     -rdir  DIRECTORY
    #     -rpwtk FILE
    #    
    # ARGUMENTS
    # * USER@HOST   ... either user@hostname.domain.name, hostname.domain.name, or hostname    
    # * SCRIPT_CODE ... the PWTK script code to run on the remote host
    # * SCRIPT_FILE ... the PWTK script file to run on the remote host
    #
    # PURPOSE
    #   Run on the remote host either the script code contained in the
    #   'SCRIPT_CODE' argument or the script file specified by the
    #   'SCRIPT_FILE' argument. PWTK checks if the last argument is a
    #   file; if so, it consider it as a script-file, otherwise it
    #   considers the last arguments as a script-code.
    #
    #   The connection and file transfer to a remote host is managed
    #   via ssh and rsync. A user must be able to connect to the
    #   remote host without password (e.g., the ~/.ssh/id_rsa.pub key
    #   must be included in the ~/.ssh/authorized_keys file on the
    #   remote host).
    #
    #   The configuration of the PWTK remote execution is specified in
    #   the $PWTK/config/remote.tcl file and the user can tune it with
    #   the ~/.pwtk/remote.tcl file.
    #
    # OPTIONS
    # * -fg              ... run the 'remote' in a blocking mode (aka foreground, default = background), i.e.,
    #                        with this option, 'remote' waits for script to finish on the remote host
    
    # * -rdir  DIRECTORY ... absolute pathname of the directory on the remote host where to run the script
    #                        (default = mirror of the current local directory on the remote host)
    
    # * -rpwtk FILE      ... pathname of the PWTK launcher on the remote host
    #                        (needed if pwtk is not on $PATH on the remote host)
    
    # * -id ID           ... ID number (this option is used internally by PWTK's tpool)
    
    # * -fid FID         ... kind of File-ID used for assembling the filename of the script
    #                        (this option is used internally by PWTK's tpool)
    
    # * -np              ... do not use the propagate mechanism (used internally by PWTK;
    #                        default = use propagate, see: ::pwtk::propagate)
    
    # * -direct          ... used internally by PWTK for "pwtk --remote=user@host";
    #                        use the script file directly without any "dressing" (implies -np)
    #
    # BEWARE
    #   ::pwtk::remote is useful for Beowulf-type clusters without
    #   batch-queuing. On HPC supercomputers, consider using the
    #   PWTK batch-queuing instead (see section:
    #   |html <a href="../documentation_tcl22E20UserInterface2F22E820Batch20Queuing20Support.html">2.8 Batch Queuing Support</a>).
    #
    # EXAMPLE
    #    # run a script code on a remote host:
    #
    #    remote -rpwtk ~/prog/q-e/pwtk/pwtk -rdir ~/calc/QE/myProject user@remotehost {
    #       import common.pwtk
    #       runPW relax.Cu111-1x1-4L.in
    #    }
    #
    #    # run the script file 'calculate.pwtk' on a remote host:
    #
    #    remote user@remotehost calculate.pwtk
    #     
    #
    # DESCRIPTION    
    #   In the default "background" mode, PWTK submits the script to a
    #   remote host and returns immediately for further processing,
    #   i.e., the command is non-blocking. To wait for "background"
    #   remote process(es), use the ::pwtk::remote_wait command.
    #
    #   In the "foreground" mode (the -fg option), PWTK waits for
    #   the calculation to finish, i.e., the command is blocking.
    #
    #   By default, ::pwtk::remote runs the script on the remote host
    #   in the directory, which is a mirror of the current local
    #   directory. For example, if the current working directory on
    #   the local host is ~/path/to/project, then the calculation will
    #   be run on ~/path/to/project directory on the remote host
    #   (remote file-system); note that the value of $HOME on remote
    #   and local hosts can differ.
    #
    #   To request that the calculation on the remote host should run
    #   in an arbitary directory, use the "-rdir DIRECTORY" option.
    #
    # BEWARE
    #   The I/O files produced by remote calculations will not be
    #   copied to the current local directory (the only exception is
    #   the remote PWTK log file). It is the responsability of the
    #   user to copy the I/O files back to the local host.
    #
    # RETURN VALUE
    # * for foreground mode: an empty string
    # * for background mode: ID of the remote background process
    #   (PWTK assigns a unique ID to each background remote process)
    #
    # SOURCE

    variable remote_index
    variable remote

    # parse the options

    set options {
	{fg             "run the calculation in the foreground mode (default = background)"}
	{rdir.arg  {}   "directory on the remote host where calculation will be run (default = mirror of the current local directory but on the remote host)"}
	{rpwtk.arg pwtk "full pathname of the PWTK launcher on the remote host (default = pwtk)"}
	{id.arg    {}   "ID of this remote job, supplied by the caller"}
	{fid.arg   {}   "File-ID used for assembling the filename of the script"}
	{np             "do not use the propagate mechanism (default = use propagate)"}
        {direct         "use the script file is used directly (implies -np)"}
    }
    set narg 2
    set usage "?-f?  ?-fg?  ?-rdir DIRECTORY?  ?-rpwtk FILE?  ?-id ID?  ?-fid ID?  ?-np?  ?-direct?  user@host script"
    ::pwtk::parseOpt_
    
    # assign the last two arguments
    
    lassign $args user_at_host lastarg

    # get the hostname

    set host     [rhost_ $user_at_host]
    set hostonly [rhostonly_ $user_at_host]

    # get the remote directory
    
    #set rdir [::fileutil::relative $::env(HOME) [pwd]]
    set rdir [::fileutil::stripPath $::env(HOME) [pwd]]
    if { $opt(rdir) ne {} } {
        set rdir $opt(rdir)
    }
    set pdir [expr { [file pathtype $rdir] eq "relative" ? "~/$rdir" : $rdir }] ; # used for printing only

    # index

    if { $opt(id) ne {} } {
        set index $opt(id)
        set jobtxt " for job-$index"
    } else {
        set index [incr remote_index($hostonly)]
        set jobtxt ""
    }
    
    # findex

    if { $opt(fid) ne {} } {
        set findex $opt(fid)
    } else {
        set findex $index
    }    
    
    # lastarg (aka script)

    if { $opt(direct) } {
        fileMustExist $lastarg "PWTK script"       
        set scriptName $lastarg
        set scriptLog  [file rootname $lastarg].log
        set opt(np) 1
    } else {
        if { [file exists $lastarg] } {
            # the last argument is a file
            set scriptHead [file rootname $lastarg].
            set scriptCode [readFile $lastarg]
        } else {
            # the last argument is a script code
            set scriptCode $lastarg
            if { [set scriptHead [file tail [file rootname [info script]]]] ne {} } {
                append scriptHead .
            }
        }
        set scriptName $hostonly.${scriptHead}$findex.pwtk
        set scriptLog  $hostonly.${scriptHead}$findex.log
    }
    
    # make a script
    
    if { ! $opt(np) } {
        set scriptCode [::pwtk::propagate_dump]\n$scriptCode
    }
    if { ! $opt(direct) } {
        writeFile $scriptName $scriptCode
    }

    # printout
    
    print REMOTE "Running a script$jobtxt remotely on $user_at_host"
    print "
remote directory     :   $pdir
remote PWTK script   :   $scriptName
remote PWTK log file :   $scriptLog
"

    # check if the remote host is alive and user can connect to it

    #if { ! [host_is_up $user_at_host] } {
    #    ::pwtk::error "cannot communicate with '$host'\n\n$::errorInfo" 1
    #}
    if { ! [can_connect $user_at_host] } {
        ::pwtk::error "cannot connect to '$user_at_host'" 1
    }
            
    # create the remote directory and rsync the script there

    print "$remote(rsync)  $scriptName  $user_at_host:$rdir/\n"
    rmkdir $user_at_host $rdir
    rsync $scriptName $user_at_host:$rdir/$scriptName
    rsync_imports_ $user_at_host
    
    # check if $opt(rpwtk) is executable
    if { [rtclsh $user_at_host "puts \[auto_execok $opt(rpwtk)]"] eq {} } {
        ::pwtk::error "the specified PWTK executable '$opt(rpwtk)' either is not executable or does not exist" 1
    }
    
    # remote-exec the PWTK script

    print "Running remotely on $user_at_host:$rdir/
$opt(rpwtk) $scriptName > $scriptLog 2>&1\n"

    set pid [::pwtk::rexec_bg $user_at_host "cd $rdir; $remote(nohup) $opt(rpwtk) $scriptName > $scriptLog 2>&1 & echo \$!"]
    print "Remote PID = $pid ($scriptName)\n"; # N.B. do not use PID: as not to clash with the PWTK header PID: line

    # background or foreground ?
    
    if { $opt(fg) } {
        print "Waiting for the remote process $pid to finish...\n"
        remote_pidwait $user_at_host $pid
        
        print "\n$remote(rsync)  $user_at_host:$rdir/$scriptLog  .\n"
        rsync $user_at_host:$rdir/$scriptLog .
        return ""
    } else {
        # store the info about this background remote job

        set id [incr remote(ID)]
        
        array set remote [subst {
            ident,$id                      $hostonly,$index
            ID,$hostonly,$index            $id
            PID,$hostonly,$index           $pid
            user_at_host,$hostonly,$index  $user_at_host
            script,$hostonly,$index        $scriptName
            log,$hostonly,$index           $scriptLog
            rdir,$hostonly,$index          $rdir
            rpwtk,$hostonly,$index         $opt(rpwtk)
        }]
        return $id
    }
}
#******


#****f* Remote Execution/::pwtk::remote_id
# SYNOPSIS
proc ::pwtk::remote_id {} {
    # PURPOSE
    #   Return the ID of the last background remote job or an empty
    #   string if there are/were no remote background jobs.
    #
    # SOURCE
    variable remote
    ifexist remote(ID) {
        return $remote(ID)
    } else {
        return ""
    }
}
#******


#****f* Remote Execution/::pwtk::remote_ids
# SYNOPSIS
proc ::pwtk::remote_ids {} {
    # PURPOSE
    #   Return the IDs of all existing remote background jobs.
    #
    #   A background remote job is considered existing if it was submitted by
    #   the ::pwtk::remote command and was not yet waited for with
    #   the ::pwtk::remote_wait or ::pwtk::remote_pidwait command, which
    #   removes it job from the list of existing background remote jobs.
    #
    # SOURCE

    variable remote
    if { ! [info exists remote(ID)] } {
        # there are no background remote jobs
        return
    }
    set ids ""
    for {set id 1} {$id <= $remote(ID)} {incr id} {
        if { [info exists remote(ident,$id)] } {
            lappend ids $id
        }
    }
    return $ids
}
#******

#****f* Remote Execution/::pwtk::remote_get
# SYNOPSIS
proc ::pwtk::remote_get {key {id ""}} {
    # PURPOSE
    #   Get the requested info of the background remote process.
    #
    # ARGUMENTS
    # * key -- a "key" for the info to query, possibilities are ID, PID,
    #          user_at_host, script, log, rdir, and rpwtk
    
    # * id -- (optional, default = 'id' of the last remote job) ID of the remote
    #         background process (PWTK assigns a unique ID to each background
    #         remote process)
    #
    # If the 'id' argument is omitted, the requested 'key' of the last
    # submitted background remote job is returned.
    #
    # SOURCE
    
    variable remote

    if { $id eq "" && [info exists remote(ID)] } {
        set id $remote(ID)
    }
    if { [info exists remote(ident,$id)] } {
        set ident $remote(ident,$id)
        if { [info exists remote($key,$ident)] } {
            return $remote($key,$ident)
        } else {
            set keys [join [regsub -all ,$ident [array names remote *,$ident] {}] {, }]
            ::pwtk::error "wrong key '$key', must be one of $keys"
            ::error {} "from ..."
        }
    }
    return ""    
}
#******


#****f* Remote Execution/::pwtk::remote_wait
# SYNOPSIS
proc ::pwtk::remote_wait {args} {
    # PURPOSE
    #   Wait for all the specified remote processes to finish.
    #
    # USAGE
    #   remote_wait ?options?
    #
    # EXAMPLES
    #   remote_wait
    #   remote_wait -all
    #   remote_wait -ids   LIST-OF-IDS
    #   remote_wait -hosts LIST-OF-HOSTS
    #   remote_wait -pattern PATTERN
    #   remote_wait -pids  LIST-OF-PIDS    
    # 
    # OPTIONS
    # * -all                  ...  wait for all remote processes to finish (default)
    # * -pids LIST-OF-IDS     ...  wait for the remote processes specified with IDs to finish
    #                              (PWTK assigns a unique ID to each background remote process)
    # * -pids LIST-OF-PIDS    ...  wait for the remote processes specified with PIDs to finish
    # * -hosts LIST-OF-HOSTS  ...  wait for remote processes that run at specified hosts to finish
    # * -pattern PATTERN      ...  wait for remote processes that match the pattern to finish
    #
    # If ::pwtk::remote_wait is called without options, it defaults to
    # -all, i.e., the command waits for all the remote background
    # processes to finish.
    #
    # Info about the PATTERN:
    # * PATTERN is a glob-style pattern.
    # * The remote processes are stored with 'hostname,index' keys.
    # * To specify all remote processes on a given host (say myhost), use: myhost,*
    # * To specify all remote processes with index=1, use: *,1
    # * To specify all remote processes with indices 1, 2, and 3, use: {*,[123]}
    #
    # SOURCE
    
    variable remote

    if { ! [info exists remote(ID)] } {
        # nothing to wait for; there are no remote background processes
        return
    }

    # default is -all
    
    ifset args -all
    
    # process options

    set options {
	{all            "wait for all remote processes to finish"}
        {ids.arg     {} "wait for remote processes specified with IDs to finish"}
        {pids.arg    {} "wait for remote processes specified with PIDs to finish"}
	{hosts.arg   {} "wait for remote processes at specified hosts to finish"}
        {pattern.arg {} "wait for remote processes that match the pattern to finish"}
    }

    set narg 0
    set usage "?-all?  ?-ids LIST-OF-IDS?  ?-pids LIST-OF-PIDS?  ?-hosts LIST-OF-HOSTS?  ?-pattern PATTERN?"
    ::pwtk::parseOpt_
    ::pwtk::checkOType_ -pids $opt(pids) {numberlist nonnegint} "list of positive integers"
    
    #set usage "Usage: ::pwtk::remote_wait \[options\]\n\nOptions are:"
    #array set opt [::cmdline::getoptions args $options $usage]
    #if { [llength $args] != 0 } {
    #    ::pwtk::error [::cmdline::usage $options $usage]
    #    ::error {} "from..."
    #}
    #::pwtk::checkOType_ -pids $opt(pids) {numberlist nonnegint} "list of positive integers"
        
    set pid_names ""
    set all_pid_names [array names remote PID,*]

    # -ids LIST-OF-IDS
    foreach id $opt(ids) {
        ifexist remote(ident,$id) {
            lappend pid_names PID,$remote(ident,$id)
        }
    }
    
    # -pids LIST-OF-PIDS
    foreach pid $opt(pids) {
        foreach pid_name $all_pid_names {
            if { $remote($pid_name) == $pid } {
                lappend pid_names $pid_name
                # N.B. do not use 'break' here -- it may happen we
                # have the same PID on different hosts (unlikely but
                # potentially possible)
            }
        }
    }

    # -pattern PATTERN
    if { $opt(pattern) ne "" } {
        append pid_names " [array names remote PID,$opt(pattern)]"
    }

    # -hosts LIST-OF-HOSTS
    if { $opt(hosts) ne "" } {
        foreach host $opt(hosts) {
            append pid_names " [array names remote PID,[rhostonly_ $host],*]"
        }
    }

    # -all
    if { $opt(all) } {
        set pid_names $all_pid_names
    }

    # gets idents & pids...
    lassign {} idents pids
    foreach ident [lmap pid_name  [::pwtk::lunique $pid_names]  {regsub PID, $pid_name {}}] {
        set id $remote(ID,$ident)
        if { [info exists remote(ident,$id)] } {
            lappend idents $ident
            lappend pids   $remote(PID,$ident)
        }
    }

    # wait for PIDs to finish

    if { $pids ne {} } {
        print "Waiting for remote processes with PIDS $pids to finish...\n"
    }
    foreach ident $idents {
        remote_pidwait $remote(user_at_host,$ident) $remote(PID,$ident)
        set id $remote(ID,$ident)
        unset remote(ident,$id)
        ifnotexist first { puts ""; set first 1 }
        print "$remote(rsync)  $remote(user_at_host,$ident):$remote(rdir,$ident)/$remote(log,$ident)  ."
        rsync $remote(user_at_host,$ident):$remote(rdir,$ident)/$remote(log,$ident) .
    }
    if { $pids ne {} } { puts "" }
}
#******


#****f* Remote Execution/::pwtk::remote_pidwait
# SYNOPSIS
proc ::pwtk::remote_pidwait {user_at_host PID} {
    # PURPOSE
    #   Wait for the process, running on the remote host with PID, to finish.
    #
    # ARGUMENTS
    # * user_at_host ... either user@hostname.domainname, hostname.domainname, or hostname    
    # * PID ... PID of the remote process to wait for
    #
    # SOURCE
    variable remote

    set host [rhost_ $user_at_host]
    
    # check if host is alive and user can connect to it
    while { ! [can_connect $user_at_host] } {
        incr attempts
        print "from [procName]: host '$host' is down (attempt #$attempts)"
        
        after $remote(time_interval_ms)
        
        if { $remote(max_attempts) > 0 && $attempts > $remote(max_attempts) } {
            ::pwtk::error "failed to connect to $host in $attempts attempts" 1
        }
    }

    # wait while remote PID is alive
    while { [remote_pidexists $user_at_host $PID] } {
        after $remote(time_interval_ms)
    }
}
#******


#****a* Remote Execution/Remote auxiliaries
# DESCRIPTION
#   Some useful commands for remote execution.
#******


#****f* Remote auxiliaries/::pwtk::remote_pidexists
# SYNOPSIS
proc ::pwtk::remote_pidexists {user_at_host PID} {
    # PURPOSE
    #   Returns 1 if the remote PID process exists, otherwise 0.
    # ARGUMENT
    # * PID -- remote process ID
    # SOURCE
    if { [catch {::pwtk::rexec -i $user_at_host [list ps -p $PID -o pid=]} res] } {
        return 0
    } elseif { $PID in $res } {
        return 1
    } else {
        return 0
    }
}
#******


#****f* Remote auxiliaries/::pwtk::host_is_up
# SYNOPSIS
proc ::pwtk::host_is_up {user_at_host} {
    # PURPOSE
    #   Check with the 'ping' program if the remote host is up. If the
    #   'ping' program is missing, ::pwtk::can_connect is used instead.
    #
    # ARGUMENT
    # * user_at_host -- name of the remote host (can be in the form of user@host)
    #
    # RETURN VALUE
    # * 1 ... if the host is up
    # * 0 ... if the host is down
    #
    # SOURCE

    if { [getExecutable ping] ne {} } {
        set host [resolve_ssh_alias $user_at_host]
        if { [catch {exec ping -c 1 $host}] } {
            return 0
        } else {
            return 1
        }
    } else {
        pwtk::warning "ping program not found, using ssh instead"
        return [can_connect $user_at_host]
    }
}
#******


#****f* Remote auxiliaries/::pwtk::can_connect
# SYNOPSIS
proc ::pwtk::can_connect {user_at_host} {
    # PURPOSE
    #   Check if user can connect to 'user_at_host'.
    #
    # ARGUMENT
    # * user_at_host ... a host specs where to connect (either user@hostname.domainname,
    #                    hostname.domainname, or hostname)
    #
    # RETURN VALUE
    # * 1 ... if user can connect to 'user_at_host'
    # * 0 ... otherwise
    #
    # SOURCE    

    if { [catch {exec -ignorestderr {*}$::pwtk::remote(rsh) {*}$::pwtk::remote(rsh_alive_opts) $user_at_host exit}] } {
        return 0
    } else {
        return 1
    }
}
#******


#****f* Remote auxiliaries/::pwtk::rcp
# SYNOPSIS
proc ::pwtk::rcp {from to} {
    # PURPOSE
    #   Remote copy (aka scp or rcp).
    #
    #   The executable and its options for remote copying are defined by
    #   the remote(rcp) variable in $PWTK/config/remote.tcl or ~/.pwtk/remote.tcl.
    #
    # EXAMPLES
    #   ::pwtk::rcp  user@host:from  to
    #   ::pwtk::rcp  from  user@host:to
    #
    # SOURCE
    variable remote
    try_exec -ignorestderr -- {*}$remote(rcp) $from $to
}
#******


#****f* Remote auxiliaries/::pwtk::rsync
# SYNOPSIS
proc ::pwtk::rsync {from to} {
    # PURPOSE
    #   Rsync between local and remote hosts.
    #
    #   The executable and its options for rsyncing are defined by the
    #   remote(rsync) variable in $PWTK/config/remote.tcl or ~/.pwtk/remote.tcl.
    #
    # EXAMPLES
    #   ::pwtk::rsync  user@host:from  to
    #   ::pwtk::rcync  from  user@host:to
    #
    # SOURCE
    variable remote
    try_exec -ignorestderr -- {*}$remote(rsync) $from $to
}
#******


#****f* Remote auxiliaries/::pwtk::rexec
# SYNOPSIS
proc ::pwtk::rexec {args} {
    # USAGE
    #   ::pwtk::rexec ?-e|-i? user_at_host command
    # 
    # PURPOSE
    #   Execute the command in the foreground on the remote host.
    #
    #   The executable for the remote shell (default = ssh) is defined by the remote(rsh)
    #   variable in $PWTK/config/remote.tcl or ~/.pwtk/remote.tcl.
    #
    # OPTIONS
    # * -e ... throw an error if error occurs
    # * -i ... ignore error(s)
    #
    # ARGUMENTS
    # * user_at_host ... a host specs where to execute a command
    #                    (either user@hostname.domainname, hostname.domainname, or hostname)
    # * command ... command to execute on remore host
    #
    # SOURCE
    variable remote

    set narg 2
    set usage "?-e|-i? user_at_host command"
    set options {
        {e "throw an error explicitly if error occurs"}
        {i "ignore errors"}
    }
    parseOpt_
    lassign $args user_at_host command    
    set flag {}
    if { $opt(e) } { set flag -e }
    if { $opt(i) } { set flag -i }; # -i has preference
    
    return [try_exec -ignorestderr {*}$flag -- {*}$remote(rsh) $user_at_host $command]
}
#******


#****f* Remote auxiliaries/::pwtk::rexec_bg
# SYNOPSIS
proc ::pwtk::rexec_bg {user_at_host command} {
    # PURPOSE
    #   Execute the command in the background on the remote host. The
    #   command returns immediately for further processing.
    #
    #   The executable for the remote shell (default = ssh) and its
    #   options for the background remote execution are defined by the
    #   remote(rsh) and remote(rsh_bg_opts) variables, respectively,
    #   in $PWTK/config/remote.tcl or ~/.pwtk/remote.tcl.
    #
    # ARGUMENTS
    # * user_at_host ... a host specs where to execute a command
    #                    (either user@hostname.domainname, hostname.domainname, or hostname)
    # * command ... command to execute on remore host
    #
    # SOURCE
    
    variable remote
    return [try_exec -ignorestderr -- {*}$remote(rsh) {*}$remote(rsh_bg_opts) $user_at_host $command]
}
#******


#****f* Remote auxiliaries/::pwtk::rmkdir
# SYNOPSIS
proc ::pwtk::rmkdir {host dir} {
    # PURPOSE
    #   Create a directory on the remote host (rmdir = remote mkdir)
    #
    # ARGUMENTS
    # * host -- remote host
    # * dir -- directory to create on the remote host
    #
    # SOURCE

    set result [rtclsh $host "if { \[catch {file mkdir $dir} info] } { puts \"ERROR: \$info\" }"]

    if { [string match ERROR* $result] } {
	::pwtk::error "cannot create the '$dir' directory on the remote host '$host'\n\n$result" 1
    }
}
#******


#****f* Remote auxiliaries/::pwtk::rtclsh
# SYNOPSIS
proc ::pwtk::rtclsh {host scriptCode} {
    # PURPOSE
    #   Execute a tclsh script on the remote host.
    #
    # ARGUMENTS
    # * host -- remote host
    # * scriptCode -- Tcl script-code to execute on the remote host
    #
    # SOURCE
    try {
        ::ssh::connect $host
        ::ssh::rexec $host $scriptCode result
        ::ssh::disconnect $host
    } on error err {
        ::pwtk::error "cannot execute a script on the remote host $host\n\n$err\n$result" 1
    }
    return $result
}
#******


#****f* Remote auxiliaries/::pwtk::resolve_ssh_alias
# SYNOPSIS
proc ::pwtk::resolve_ssh_alias {hostAlias} {
    # PURPOSE
    #   Resolve a ssh alias and return the hostname, i.e.,
    #   map from the ssh alias to the hostname.
    # SOURCE
    set output [try_exec -e -ignorestderr -- ssh -G $hostAlias]
    set index  [lsearch -exact -nocase $output hostname]
    if { $index > -1 } {
        return [lindex $output $index+1]
    }
    # just in case (if hostAlias==user_at_host, return host)
    return [lindex [split $hostAlias @] end]
}
#******


#***internal...
proc ::pwtk::ruser_ {user_at_host} {
    # PURPOSE
    #   Return 'user' from 'user_at_host'.
    if {[regexp {(.*)@(.*)} $user_at_host m12 m1 m2]} {
        return $m1
    }
    return ""    
}

#***internal...
proc ::pwtk::rhost_ {user_at_host} {
    # PURPOSE
    #   Return 'host' from 'user_at_host'.
    if {[regexp {(.*)@(.*)} $user_at_host m12 m1 m2]} {
        return $m2
    }
    return $user_at_host    
}

#***internal...
proc ::pwtk::rhostonly_ {user_at_host} {
    # PURPOSE
    #   Return 'hostonly' from 'user_at_host'; hostonly is the host without a domain-name.
    return [lindex [split [::pwtk::rhost_ $user_at_host] .] 0]
}

#***internal...
proc ::pwtk::rsync_imports_ {user_at_host} {
    # PURPOSE
    #   rsync all imported files to user@host
    variable import
    variable remote
    
    ifexist import {
        print "rsyncing imported files: "
        foreach {dir file} $import {
            if { [file pathtype $dir] eq "relative" } { 
                # N.B $dir is relative to $HOME (see: pwtk::import)
                set file [file join [::fileutil::relative [pwd] [file join $::env(HOME) $dir]] $file]
            } else {
                set file [file join $dir $file]
            }
            print "   $remote(rsync)  $file  $user_at_host:$dir/"
            
            rmkdir $user_at_host $dir
            rsync $file $user_at_host:$dir/
        }
        puts ""
    }
}
