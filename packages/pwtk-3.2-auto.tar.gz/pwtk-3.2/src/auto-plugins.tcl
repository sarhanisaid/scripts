#
# $RCSfile: auto-plugins.tcl,v $ --
#
#      This file contains the auto support for QE plugins.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: auto-plugins.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#

::pwtk::definePlugin oscdft -oscdft oscdft.in pw.x {
    { namelist OSCDFT {} }
    { card_wo_flags TARGET_OCCUPATION_NUMBERS {} }
    { card_wo_flags GAMMA_VAL {} }
} {} {} {}


::pwtk::definePlugin artn -partn artn.in pw.x {
    { namelist ARTN_PARAMETERS {} }
} {ARTN_PARAMETERS { lrestart = .true. }} {ARTN_PARAMETERS { lrestart = }} {}

# N.B. artn requires SYSTEM { nosym = .true. }; IONS { ion_dynamics = 'fire' }
#      this is temporarily activated via ::pwtk::prerun
::pwtk::prerun_plugin_ artn pw.x {
    if { [::pwtk::artn::artn] } {
        infoMsg "temporarily setting SYSTEM { nosym = .true. } and IONS { ion_dynamics = 'fire' } for ARTN"
        SYSTEM { nosym = .true. }; IONS { ion_dynamics = 'fire' }
    }
}

# copy artn.out to artn.$output after the pw.x calculation, where $output == pw.x output file
::pwtk::postrun_plugin_ artn pw.x {
    if { [::pwtk::artn::artn] && [file exists artn.out] } {
        # copy the artn.out file only if is is new
        set tref [clock seconds]
        set tout [file mtime artn.out]
        if { $tref - $tout < 10*[time2s -real ${::pwtk::time_interval_ms}ms] } {
            ::pwtk::print "Making a backup copy of artn.out to artn.$output\n"
            file copy -force artn.out artn.$output
        }
    }
}
