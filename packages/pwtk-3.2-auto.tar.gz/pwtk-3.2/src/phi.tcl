#
# $RCSfile: phi.tcl,v $ --
#
#      This file contains the procs for handling the ph.x input.
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: phi.tcl,v 1.10 2021/05/03 14:21:08 tone Exp $ 
#

# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::phi_fprint {{file {}}} { uplevel ::pwtk::phi::fprint $file }
proc ::pwtk::phi_get   {} { uplevel ::pwtk::phi::get }
proc ::pwtk::phi_clear {} { uplevel ::pwtk::phi::clear }
proc ::pwtk::phi_getTitle {} { uplevel ::pwtk::phi::getTitle }
proc ::pwtk::phi_getAffix {} { uplevel ::pwtk::phi::getAffix }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::phi/::pwtk::phi::fprint
# SYNOPSIS
proc ::pwtk::phi::fprint {{file {}}} {
    # PURPOSE
    #   Print the content of ph.x input data to a file or to stdout if the
    #   file was not specified.
    # ARGUMENTS
    #   * file -- [optional] filename to print to (default = stdout)
    # SOURCE
    
    ::pwtk::input::fprint_ ::pwtk::phi $file
}
#****

#****f* ::pwtk::phi/::pwtk::phi::get
# SYNOPSIS
proc ::pwtk::phi::get {} {
    # PURPOSE
    #   Return the content of the ph.x input 
    # SOURCE
    
    loadDefaults_
    
    set    input_ [::pwtk::input::cardGetContent INPUTPH.titleLine]
    append input_ [::pwtk::input::namelist.affixGet INPUTPH]
    
    return [::pwtk::skipEmptyLines $input_]
}
#****


proc ::pwtk::phi::loadDefaults_ {} {
    # load some default values, when user has omitted them 

    namespace eval ::pwtk::input {
	defaultVarValue_ INPUTPH outdir  [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
	defaultVarValue_ INPUTPH prefix  ""
    }
}


#****f* ::pwtk::phi/::pwtk::phi::getTitle
# SYNOPSIS
proc ::pwtk::phi::getTitle {} { 
    # PURPOSE
    #   Return the title of the ph.x input 
    # SOURCE
    return [::pwtk::input::cardGetContent INPUTPH.titleLine]
}
#****


#****f* ::pwtk::phi/::pwtk::phi::getAffix
# SYNOPSIS
proc ::pwtk::phi::getAffix {} { 
    # PURPOSE
    #   Return the last part of the ph.x input file, that is, the
    #   cards following the INPUTPH namelist.
    # SOURCE
    #return [::pwtk::input::cardGetContent INPUTPH.affixCards]
    return [::pwtk::input::namelist.affixGetAffix INPUTPH]
}
#****

#****if* Internals/::pwtk::phi::input_
# USAGE
#   There are three possible forms:
#
#     1. input_ titleLine INPUTPHnamelist affixCards
#     2. input_ INPUTPHnamelist affixCards
#     3. input_ INPUTPHnamelist 
# 
# DESCRIPTION
#   The actual implementation of INPUTPH command.  Set either (1) the
#   whole ph.x input, or (2) only the INPUTPH and the cards that
#   follow the namelist, or (3) solely the INPUTPH namelist, depending
#   on the number of supplied arguments.
#
# SOURCE 
proc ::pwtk::phi::input_ {args} {
    
    set nargs [llength $args] 
    
    if { $nargs == 3} {
        
        ::pwtk::input::card INPUTPH.titleLine [lindex $args 0]
	::pwtk::input::namelist.affix INPUTPH {*}[lrange $args 1 2]
        
    } elseif { $nargs == 2 || $nargs == 1 } {
        
	::pwtk::input::namelist.affix INPUTPH {*}$args
        
    } else {
	# wrong usage:
	::pwtk::error "wrong usage of INPUTPH command. Must be one of the following form:\n\n   1. input_ titleLine INPUTPHnamelist affixCards\n\n   2. input_ INPUTPHnamelist affixCards\n\n   3. input_ INPUTPHnamelist\n\nbut got:\n[list INPUTPH $args]" 1
    }
}

#******


#****f* ::pwtk::phi/::pwtk::phi::clear
# SYNOPSIS
proc ::pwtk::phi::clear {} {
# PURPOSE
#   Clear the stored ph.x input data.
# SOURCE
    ::pwtk::input::clear INPUTPH.titleLine INPUTPH
}
#****


#****f* ::pwtk::phi/::pwtk::phi::load_fromPHI
# SYNOPSIS
proc ::pwtk::phi::load_fromPHI {phi {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing ph.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * phi -- filename of the ph.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?
    #
    # SOURCE

    ::pwtk::fileMustExist $phi "ph.x input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current ph.x input data ...
	::pwtk::phi::clear
    }
    
    set fid [open $phi r]

    # check if the first line is the title line
    set line    [::pwtk::getNonEmptyLine $fid]
    set word1st [::pwtk::firstWord $line]
    
    if { [string match -nocase &INPUTPH $word1st] } {
        # it's an INPUTPH namelist, rewind $fid
        seek $fid 0 start
    } else {
        ::pwtk::input::card INPUTPH.titleLine $line
    }

    # ph.x input file must contain the INPUTPH namelist

    if { [catch {set res [::pwtk::readNml_w_affix $fid INPUTPH {} {} {} 1]}] } {
        ::pwtk::error "input file \"$phi\" does not appear to be a ph.x input file" 1
    }
    close $fid

    eval $res

    variable input_flow_list
    ::pwtk::input::namelists_ityp2atmSymb_ $input_flow_list    
}
#******
