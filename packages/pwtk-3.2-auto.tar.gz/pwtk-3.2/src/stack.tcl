#
# $RCSfile: stack.tcl,v $ --
#
#      This file contains the implementation of the input-data
#      stacking mechanism.
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: stack.tcl,v 1.6 2021/05/01 19:23:20 tone Exp $ 
#


# ------------------------------------------------------------------------
# SHORT-CUTS
# ------------------------------------------------------------------------
proc ::pwtk::input_pushpop {script} { uplevel [list ::pwtk::input::pushpop $script] }
proc ::pwtk::input_push {} { uplevel ::pwtk::input::push }
proc ::pwtk::input_pop  {} { uplevel ::pwtk::input::pop  }
proc ::pwtk::input_peek {} { uplevel ::pwtk::input::peek }
proc ::pwtk::input_load_state {peekData} { uplevel [list ::pwtk::input::load_state $peekData] }
proc ::pwtk::input_stack_level {} { uplevel ::pwtk::input::stack_level }

#****a* ::pwtk::input/Stacking
# DESCRIPTION   
#   Routines for input data stacking.
#
#   In PWTK script, only the input_pushpop { ... } command is usually used.
#******

#****f* Stacking/::pwtk::input::pushpop
# SYNOPSIS
proc ::pwtk::input::pushpop {script} {
    # PURPOSE
    #   This is a convenience proc. It is equivalent to:
    #
    #      ::pwtk::input::push
    #      ... script ...
    #      ::pwtk::input::pop
    #
    #   but due to the usage of curly braces {}, it assures that
    #   ::pwtk::input::pop is not forgotten because forgotten closing
    #   curly-brace results in a Tcl error, while forgotten
    #   ::pwtk::input::pop does not.
    #
    #  Furthermore, it properly handles specialties, such as the
    #  "return" call, i.e., one can do something like:
    #
    #     input_pushpop {
    #       ...
    #       if { $condition } {
    #          return
    #       }
    #     }
    #
    #  and this will not break the stack-level because the stack will
    #  be poped upon the execution of the "return" call.
    #
    # SOURCE
    ::pwtk::input::push
    set code [catch {uplevel 1 $script} result]
    ::pwtk::input::pop

    return -code $code $result
}
#****

#****f* Stacking/::pwtk::input::push
# SYNOPSIS
proc ::pwtk::input::push {} {
    # PURPOSE    
    #   The "push" proc for the input data & state stack. The push/pop
    #   meschanism for the input data is similar to OpenGL
    #   glPush()/glPop(). It works as follows:
    #
    #      ... set some default input data (#1) ...
    #
    #      ::pwtk::input::push
    #         ... modify input data ...
    #         ... do some calculations with it ...
    #      ::pwtk::input::pop
    #
    #      ... here the input data is the same as those labeled (#1) above
    #
    #   The following data are handled by the stacking mechanism (for
    #   further details, see the source code):
    
    #   * input data (i.e. Namelists, Cards, Scripts)

    #   * run options (prefix, serial_prefix, postfix, serial_postfix, input_handle),
    #     i.e., options handled by the ::pwtk::RUNopt array
    #     (see the source code)

    #   * QE directories (bin_dir, outdir, outdir_prefix, outdir_potfix,
    #     wfcdir, wfcdir_prefix, wfcdir_potfix), i.e., directories handled
    #     by the ::pwtk::QEdir array

    #   * QE programs as set by ::pwtk::pw, ::pwtk::pp, etc.,
    #     i.e., QE executable handled by the ::pwtk::QEprog array

    #   * PWTK state status (stopOnError, restart, environ, bin_query, remedy, prerun,
    #     postrun, treatrun, backup_io), i.e., state status as handled
    #     by the ::pwtk::state array
    #
    # BEWARE
    #   In PWTK scripts, use the ::pwtk::input::pushpop command instead of the
    #   ::pwtk::input::push & ::pwtk::input::pop pair.
    #
    # SOURCE

    variable stack 
    variable stackLevel

    incr stackLevel
    lappend stack [list \
		       ::pwtk::input::namelist     [array get ::pwtk::input::namelist] \
		       ::pwtk::input::card         [array get ::pwtk::input::card] \
		       ::pwtk::input::card_flags   [array get ::pwtk::input::card_flags] \
		       ::pwtk::input::card_content [array get ::pwtk::input::card_content] \
		       ::pwtk::input::script       [array get ::pwtk::input::script] \
                       ::pwtk::RUNopt              [array get ::pwtk::RUNopt] \
                       ::pwtk::QEdir               [array get ::pwtk::QEdir] \
                       ::pwtk::QEprog              [array get ::pwtk::QEprog] \
                       ::pwtk::state               [array get ::pwtk::state] \
                       \
                       ::pwtk::queue::profile      [array get ::pwtk::queue::profile] \
                       ::pwtk::queue::pwtk_profile [array get ::pwtk::queue::pwtk_profile] \
                       ::pwtk::queue::queue        [concat [array get ::pwtk::queue::queue *,head] [array get ::pwtk::queue::queue *,tail]] \
                      ]
}
#******


#****f* Stacking/::pwtk::input::pop
# SYNOPSIS
proc ::pwtk::input::pop {} {
    # PURPOSE    
    #   The "pop" proc for the input data & state stack. 
    #
    # SEE ALSO 
    #   For more explanation see ::pwtk::input::push
    #
    # SOURCE

    variable stack 
    variable stackLevel

    if { ! [info exists stackLevel] || $stackLevel < 1 } {
	pwtk::error "cannot pop an empty stack"
    }

    incr stackLevel -1

    set data [lindex $stack end]
    set stack [lrange $stack 0 end-1]

    load_state $data
}
#******


#****f* Stacking/::pwtk::input::load_state
# SYNOPSIS
proc ::pwtk::input::load_state {peekData} {
    # PURPOSE    
    #   Load the input data state & state that was saved by ::pwtk::input::peek.
    #
    # ARGUMENT
    # * peekData -- input data & state, saved with the ::pwtk::input::peek
    #
    # SOURCE
    foreach {arr arrData} $peekData {
	upvar #0 $arr arrVar
	if { [info exists arrVar] } { 
	    unset arrVar 
	}
	if { $arrData != "" } {	
	    array set arrVar $arrData
	}
    }
}
#******


#****f* Stacking/::pwtk::input::stack_level
# SYNOPSIS
proc ::pwtk::input::stack_level {} {
    # PURPOSE    
    #   Return the current level of input data & state stack.
    #
    # SEE ALSO 
    #   For more explanation see ::pwtk::input::push
    #
    # SOURCE
    variable stackLevel
    if { ! [info exists stackLevel] } {
	set stackLevel 0
    }
    return $stackLevel
}
#******


#****f* Stacking/::pwtk::input::peek
# SYNOPSIS
proc ::pwtk::input::peek {} {
    # PURPOSE    

    #   The "peek" proc for the input data & state. It returns the
    #   current input data & state as a list of the following format:
    #
    #      array1 array1Data array2 array2Data
    #
    #   where arrayData is in the form to be used by "array set"
    #   command, e.g.:
    #
    #      array set array1 $array1Data
    #
    # SEE ALSO 
    #   For more explanation about the input data & state stack
    #   meschanism, see ::pwtk::input::push
    #    
    # SOURCE
    variable stack

    # use 'pushpop' to get the current input data & state
    #
    # N.B. without pushpop, the input data & state of the previous
    # stackLevel would be returned
    
    pushpop {
        return [lindex $stack end]
    }
}
#******
