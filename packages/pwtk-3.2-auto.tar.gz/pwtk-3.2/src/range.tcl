#
# $RCSfile: range.tcl,v $ --
#
#      This file contains the ::pwtk::parseRangeString routine for
#      parsing the range-strings, which can have the form, e.g.: 1,2,5-10,21- 
#
# Copyright (c) 2021  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: range.tcl,v 1.1 2021/05/01 19:24:39 tone Exp $ 
#

#****f* Sequences/::pwtk::expandSequence
# SYNOPSIS
proc ::pwtk::expandSequence {seq {increment 1}} {
    # PURPOSE
    #   Expands the sequence string "from-to" to explicit range of integer numbers.
    #
    #   Allowed values for sequence strings are "from-to" or "from - to".
    #   If $seq does not represents a sequence, it can have a non-integer value.
    #
    # EXAMPLE
    #
    #   expandSequence 1-5     ... returns 1 2 3 4 5
    #
    #   expandSequence {1 - 5} ... returns 1 2 3 4 5
    #
    #   expandSequence 5-1 2   ... returns 5 3 1
    #
    #   expandSequence 6       ... returns 6
    #
    #   expandSequence 1*      ... returns 1*
    #
    #   expandSequence dummy   ... returns dummy
    #
    # ARGUMENTS    
    # * seq -- sequence string to expand
    # * increment -- [optional, default = 1] the increment step
    #
    # SOURCE

    set n12 [split $seq -]

    if { [llength $n12] == 2 } {
        set first [string trim [lindex $n12 0]]
        set last  [string trim [lindex $n12 end]]
        
        if { ! [string is integer -strict $first] || ! [string is integer -strict $last] } {
            pwtk::error "wrong range \"$seq\", must be N1-N2, where N1 and N2 are integers" 1
        }
        if { $first > $last } {
            return [seq $first -$increment $last]
        } else {
            return [seq $first $increment $last]
        }
    }    
    return $seq
}
#******


#****f* Sequences/::pwtk::parseRangeString
# SYNOPSIS
proc ::pwtk::parseRangeString {rangeString lastIndex} {
    # PURPOSE
    #   Evaulate the range-string and expand it into explicit list of
    #   indices. The ranges can be specified as follows (note that
    #   commas are optional):
    #
    #      1, 2, 5, 6 -- this expands to 1 2 5 6    
    #      1, 4-8, 11 -- this expands to 1 4 5 6 7 8 11
    #      -5         -- this expands to 1 2 3 4 5
    #      5-         -- this expands to 5 6 7 ... lastIndex
    #      5-end      -- this expands to 5 6 7 ... lastIndex
    #      5-last     -- this expands to 5 6 7 ... lastIndex 
    #      all        -- this expands to 1 2 3 ... lastIndex
    #      begin-last -- this expands to 1 3 4 ... lastIndex
    #      first-last -- this expands to 1 3 4 ... lastIndex
    #
    # ARGUMENTS    
    # * rangeString -- rangeString to parse (i.e. expands)
    # * lastIndex   -- the largest index (used for "all" and "number-" forms)
    #
    # SOURCE

    if { $rangeString eq {} } { return {} }
    set rangeString [normalizeRangeString_ $rangeString]

    if { [string match "all" [string trim $rangeString '\"]] } {
	set rangeString "1-"
    }    
    # replace "end" and "last" with $lastIndex
    set rangeString [regsub -all {(end|last)} $rangeString $lastIndex]
    set rangeString [regsub -all {(begin|first|1st)} $rangeString 1]

    foreach item $rangeString {
	# check for syntax correctness, possible values: 
	#                                digit, digit-digit, digit-, -digit
	if { ! [regexp {^[0-9]+-?[0-9]*$} $item] && ! [regexp {^-?[0-9]*$} $item] } {
	    ::pwtk::error "syntax error in range specification: $rangeString" 1
	}
        
	append range "[expandSequenceString_ $item $lastIndex] "
    }
    
    return [string trim $range]
}
#******

#****f* Sequences/::pwtk::parseRangeStringNotIn
# SYNOPSIS
proc ::pwtk::parseRangeStringNotIn {rangeString lastIndex} {
    # PURPOSE
    #   Return the indices not included in [::pwtk::parseRangeString $rangeString $lastIndex].
    #
    # ARGUMENTS
    # * rangeString -- rangeString to parse (i.e. expands)
    # * lastIndex   -- the largest index (used for "all" and "number-" forms)
    #
    # SOURCE

    set ran [::pwtk::parseRangeString $rangeString $lastIndex]

    set result {}
    for {set i 1} {$i <= $lastIndex} {incr i} {
        if { $i ni $ran } {
            lappend result $i
        }
    }
    return $result
}
#******


#****f* Sequences/::pwtk::parseIndex1
# SYNOPSIS
proc ::pwtk::parseIndex1 {index lastIndex} {
    # PURPOSE
    #   Tranform symbolic index to numeric index. The first index has
    #   the value of 1 (hence the prefix 1 in the name), i.e.:
    #
    #     begin, first, 1st       --> 1
    #     begin+N, first+N, 1st+N --> 1+N
    #     end, last               --> $lastIndex
    #     end-N, last-N,          --> $lastIndex-N
    #
    #   First index can have symbolic values of:
    #     first, begin, 1st
    #   Last index can have symbolic values of:
    #     end, last
    #
    #   If index is given as math expression, it is evaluated.
    #   For example:
    #     parseIndex1 end-1 3    
    #   returns 2.
    #
    # ARGUMENTS
    # * index -- index to parse
    # * lastIndex -- the greatest value an index can have (used to transform 'end' to a number)
    #
    # SOURCE
    set ind [regsub -nocase {(^begin|^first|^1st)} $index 1]
    set ind [regsub -nocase {(^end|^last)} $ind $lastIndex]
    try {
        set index [expr $ind]
    } on error err {
        set index $ind
    }
    #
    if { ! [string is integer -strict $index] } {
        uplevel 1 [list ::pwtk::error "expected integer for index, but got $index" 1]
    }
    return $index
}
#******

#****f* Sequences/::pwtk::doubleSeq
# SYNOPSIS
proc ::pwtk::doubleSeq {from to nsteps {fmt %s}} {
    # USAGE
    #   ::pwtk::doubleSeq from to nsteps ?format?
    # PURPOSE
    #   Return an equispaced sequence of 'nsteps' double (real) numbers in the [from,to] range.
    # ARGUMENTS
    # * from   --- the from value
    # * to     --- the to value
    # * nsteps --- number of numbers to generate
    # * format --- (optional) format of the numbers in C syntax (e.g. %15.10f)
    #
    # SOURCE
    set d [expr (($to) - ($from)) / double($nsteps - 1)]
    if { $nsteps <= 0.0 } { return $from }
    for {set i 0} {$i < $nsteps} {incr i} {        
        lappend result [format $fmt [expr $from + double($i)*$d]]
    }
    return $result
}
#******


#****f* Sequences/::pwtk::intSeq
# SYNOPSIS
proc ::pwtk::intSeq {from to nsteps} {
    # USAGE
    #   ::pwtk::intSeq from to nsteps
    # PURPOSE
    #   Return an as equispaced as possible sequence of 'nsteps' integer numbers in the [from,to] range.
    # ARGUMENTS
    # * from   --- the from value
    # * to     --- the to value
    # * nsteps --- number of integers to generate
    #
    # SOURCE
    set d [expr double($to - $from) / double($nsteps - 1)]
    if { $nsteps <= 0 } { return [expr round($from)] }
    for {set i 0} {$i < $nsteps} {incr i} {
        lappend result [expr round($from + $i*$d)]
    }
    return $result
}
#******


# ------------------------------------------------------------------------
#
# INTERNAL PROCS
#
#------------------------------------------------------------------------

proc ::pwtk::normalizeRangeString_ {str} {
    # replace commas with whitespace
    set str [regsub -all , $str { }]

    # strip whitespace from range syntax, e.g., transform  "8 - 4" to "8-4"
    return [regsub -all {[ \t]+-[ \t]+} $str -]
}


proc ::pwtk::expandSequenceString_ {item endIndex} {
    set l     [split $item -]
    set len   [llength $l]    
    set first [lindex $l 0]
    set last  [lindex $l end]    
    set result ""

    if { $len == 1 } {
	return $item

    } elseif { $len == 2 } {
	if { $first == "" } {
	    # syntax: -4, which means 1-4
	    for {set i 1} {$i <= $last} {incr i} {
		lappend result $i
	    }
	} elseif { $last == "" } {
	    # syntax: 5-, which means 5-end
	    for {set i $first} {$i<=$endIndex} {incr i} {
		lappend result $i
	    }
	} else {	    
	    for {set i $first} {$i <= $last} {incr i} {
		lappend result $i
	    }
	}
	return $result	
    } else {
	pwtk::error "malformed range string \"$item\"" 1
    }
    
    return ""
}
