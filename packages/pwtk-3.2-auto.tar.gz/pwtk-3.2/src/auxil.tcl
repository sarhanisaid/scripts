#
# $RCSfile: auxil.tcl,v $ --
#
#      This file contains the auxiliary procs.
#
# Copyright (c) 2009-2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: auxil.tcl,v 1.13 2021/05/07 13:21:31 tone Exp $ 
#

#*** internal...
proc ::pwtk::seq_flen_ {first increment} {

    set l1st 0
    set linc 0

    if { ! [string is integer $first] } {
        set l1st [string length [lindex [split $first .] end]]
    }
    if { ! [string is integer $increment] } {
        set linc [string length [lindex [split $increment .] end]]
    }

    return [expr $l1st > $linc ? $l1st : $linc]
}

#****f* Sequences/::pwtk::seq
# SYNOPSIS 
proc ::pwtk::seq {args} {
    # DESCRIPTION
    #   Analogous to Unix seq command. It returns a range of numbers.
    #
    # USAGE
    #    ::pwtk::seq last
    #
    #    ::pwtk::seq first last
    #
    #    ::pwtk::seq first increment last
    #
    # SOURCE
    set nargs [llength $args]
    if { $nargs < 1 || $nargs > 3 } {
        pwtk::error "wrong # args: must be one of\n   seq last\n   seq first last\n   seq first increment last\n\nbut got [concat seq $args]" 1
    }

    set first 1
    set increment 1
    set last [lindex $args end]
    
    if { $nargs >= 2 } {
        set first [lindex $args 0]
        
        if { $nargs == 3 } {
            set increment [lindex $args 1]
        }
    }
    if { $increment == 0 } {
        pwtk::warning "invalid zero increment value; setting increment to 1"
        set increment 1
    }
    
    set len [seq_flen_ $first $increment]    
    set result {}
    while { [expr {$increment > 0 ? $first <= $last : $first >= $last}] } {
        if { $len == 0 } {
            lappend result $first
        } else {
            lappend result [format %.${len}f $first]
        }
        set first [format %.${len}f [expr $first + $increment]]
    }

    return $result
}
#******

#*** internal...
proc ::pwtk::stderr_msg_ {label msg} {
    if { [info level] > 2 } {
	set prefixMsg "from [procName -3]:\n"
    } else {
	set prefixMsg "from top-level:\n"
    }

    set rule  [string repeat - 72]
    set space [format %[string length $label]s { }]
    
    foreach line [split [string trim "${prefixMsg}\n$msg"] \n] {
        if { ! [info exist message] } {
            append message "\n$rule\n${label}: $line\n"
        } else {
            append message "${space}  $line\n"
        }
    }
    append message "$rule\n"
    puts stderr $message
    flush stderr
}


#****f* Evals-Execs-Errors/::pwtk::error
# SYNOPSIS 
proc ::pwtk::error {msg {exit_status 0}} {
    # DESCRIPTION
    #   Print the error message and raise an error if exit_status >= 0.
    # ARGUMENTS
    #   * msg -- error message to print to stderr
    #   * exit_status -- if exit_status > 0, PWTK either exists or raises
    #                    an error in interactive-mode or in catch-status
    # SOURCE
    global debug
    variable catch_error

    stderr_msg_ ERROR $msg
    
    if { $exit_status } {
        if { ([info exists debug] && $debug) || $::tcl_interactive || $catch_error } {
            ::error ""
        } else {
            puts stderr "Aborting ..."
            exit $exit_status
        }
    }
}
#******


#****f* Evals-Execs-Errors/::pwtk::warning
# SYNOPSIS 
proc ::pwtk::warning {msg} {
    # DESCRIPTION
    #   Print the warning message.
    # ARGUMENTS
    #   * msg -- warning message to print to stderr
    # SOURCE

    stderr_msg_ WARNING $msg
}
#******


#****f* Messaging/::pwtk::infoMsg
# SYNOPSIS 
proc ::pwtk::infoMsg {msg} {
    # DESCRIPTION
    #   Print the info message.
    # ARGUMENTS
    #   * msg -- info message to print to stdout
    # SOURCE
    set i 0
    foreach line [split $msg \n] {
	if { ! $i } {
	    ::pwtk::print "INFO: $line"
	} else {
	    ::pwtk::print "      $line"
	}
	incr i
    }
    puts ""
}
#******

#****f* Evals-Execs-Errors/::pwtk::abort
# SYNOPSIS 
proc ::pwtk::abort {{msg {}}} {
    # DESCRIPTION
    #   Like a C abort() function. Prints the message and aborts the application.
    # ARGUMENTS
    #   * msg -- (optional) message to print to stderr
    # SOURCE

    if { $msg != {} } {
        foreach line [split $msg \n] {
            incr i
            if { $i == 1 } {
                puts stderr  "ABORT: $line"
            } else {
                puts stderr  "       $line"
            }
        }
    }
    puts stderr "ABORT statement executed in [procName -2]"
    exit
}
#******


#****f* FileUtilities/::pwtk::headname
# SYNOPSIS
proc ::pwtk::headname {filename {extensions {.in .inp}}} {
    # ARGUMENTS
    #   * filename  -- name of file
    #   * extension -- list of cropping extensions (optional, default = {.in .inp})
    # PURPOSE
    #   Return the filename croped by the suffix if the suffix
    #   matches one of the specified extensions. For example:
    #
    #      ::pwtk::headname myInput.in {.inp .in}
    #
    #   would return myInput.
    #
    # SOURCE

    set file_ext [file extension $filename]
    foreach ext $extensions {
	if { [string match -nocase $ext $file_ext] } {
	    return [file rootname $filename]
	}
    }
    return $filename
}
#******


#****f* FileUtilities/::pwtk::trim_prefix
# SYNOPSIS
proc ::pwtk::trim_prefix {prefixes filename} {
    # ARGUMENTS
    #   * prefixes -- list of prefixes to trim
    #   * filename -- name of file
    # PURPOSE
    #   Return the filename left-trimmed for the prefix. For example:
    #
    #      ::pwtk::trim_prefix {relax scf} relax.file.in
    #      ::pwtk::trim_prefix {relax scf} scf.file.in
    #
    #   returns:
    #
    #      file.in
    #      file.in
    #
    # SOURCE
    foreach prefix $prefixes {
        set prefix [string trimright $prefix .]
        lappend rexp "^$prefix\."
    }
    return [regsub [join $rexp |] $filename {}]
}
#******


#****f* FileUtilities/::pwtk::trim_postfix
# SYNOPSIS
proc ::pwtk::trim_postfix {postfixes filename} {
    # ARGUMENTS
    #   * postfixes -- list of postfixes to trim
    #   * filename -- name of file
    # PURPOSE
    #   Return the filename left-trimmed for the postfix. For example:
    #
    #      ::pwtk::trim_postfix {relax.in scf.in} file.scf.in
    #      ::pwtk::trim_postfix {relax.in scf.in} file.relax.in
    #
    #   returns:
    #
    #      file
    #      file
    #
    # SOURCE
    foreach postfix $postfixes {
        set postfix [string trimleft $postfix .]
        lappend rexp "\.$postfix$"
    }
    return [regsub [join $rexp |] $filename {}]
}
#******


#****f* FileUtilities/::pwtk::file_backup
# SYNOPSIS 
proc ::pwtk::file_backup {filename {postfix bck}} {
    # PURPOSE
    #   Backup the file or directory if it exists. Specifying a
    #   non-existent file (directory) is not considered an error.
    #
    #   Specifying a non-existent file is not considered an error.
    #
    # ARGUMENTS
    # * filename -- name of a file or directory

    # * postfix -- (optional, default = bck) postfix for the backup copy, i.e.,
    #              the backup is named '$filename.${postfix}$i', where $i is an
    #              empty string or an integer (chosen such that
    #              '$filename.${postfix}$i' does not pre-exists)
    #
    # RETURN VALUE
    #   The name of the backup file (or empty string if the filename does not exist).
    #
    # SOURCE
    if { [file exists $filename] } {
	set i ""	
	while { [file exists ${filename}.${postfix}$i] } {
	    if { $i eq "" } { set i 0 }
	    incr i
	}
	file copy -- $filename $filename.${postfix}$i
        return $filename.${postfix}$i
    }
    return {}
}
#******


#****f* FileUtilities/::pwtk::lineread
# SYNOPSIS
proc ::pwtk::lineread {var file script} {
    # PURPOSE
    #   Read entire file line-by-line and at each line execute a
    #   supplied script (script is executed at the level of the call).
    #
    # ARGUMENTS
    # * var    -- name of variable where the content of line will be stored
    # * file   -- name of file to read
    # * script -- script to execute when line is read 
    #
    # CREDITS
    #   Based on fileutils::foreachLine from tcllib (almost verbatim).
    # SOURCE
    upvar $var line

    set fid    [open $file r]
    set code   0
    set result {}

    while { ! [eof $fid] } {
	gets $fid line
	set code [catch {uplevel 1 $script} result]
	if {($code != 0) && ($code != 4)} { 
	    break 
	}
    }
    close $fid

    if { ($code == 0) || ($code == 3) || ($code == 4) } {
        return $result
    }
    if { $code == 1 } {
        global errorCode errorInfo
        return \
	    -code      $code      \
	    -errorcode $errorCode \
	    -errorinfo $errorInfo \
	    $result
    }
    return -code $code $result
}
#******


#****f* FileUtilities/::pwtk::grep
# SYNOPSIS
proc ::pwtk::grep {pattern file {index ""}} {
    # PURPOSE    
    #   A simple grep command (but without options). Lines that
    #   matches the pattern are returned as the Tcl list. If index
    #   argument is specified only the index-th match (list element)
    #   is returned.
    #
    # ARGUMENTS    
    # * pattern -- pattern to grep for [pattern matching is that of
    #              Tcl's "string match" command]
    # * file    -- file to grep
    # * index   -- [optional] which match to return;
    #              its meaning/syntax is the same as for Tcl's lindex command;
    #              1 = first match; end = last match
    #
    # RETURN VALUE
    # * lines that matches the pattern in the form of Tcl list
    # * if 'index' argument is specified, only the index-th element of
    #   the resulting list is returned
    #
    # SOURCE

    set result ""

    pwtk::lineread line $file {
	if { [string match *$pattern* $line] } {
	    lappend result $line
	}
    }
    if { $index != "" } {
	set result [lindex $result $index]
    }

    return $result
}
#******



#****f* FileUtilities/::pwtk::egrep
# SYNOPSIS
proc ::pwtk::egrep {pattern file {index ""}} {
    # PURPOSE    
    #   A simple egrep command (but without options). Lines that
    #   matches the pattern are returned as the Tcl list. If index
    #   argument is specified only the index-th match (list element)
    #   is returned.
    #
    # ARGUMENTS    
    # * pattern -- pattern to grep for [pattern matching is that of
    #              Tcl's "regexp" command]
    # * file    -- file to grep
    # * index   -- [optional] which match to return;
    #              its meaning/syntax is the same as for Tcl's lindex command;
    #              0 = first match; end = last match
    #
    # RETURN VALUE
    # * lines that matches the pattern in the form of Tcl list
    # * if 'index' argument is specified, only the index-th element of
    #   the resulting list is returned
    #
    # SOURCE

    set result ""

    pwtk::lineread line $file {
	if { [regexp $pattern $line] } {
	    lappend result $line 
	}
    }
    
    if { $index != "" } {
	set result [lindex $result $index]
    }
    
    return $result
}
#******



#****f* FileUtilities/::pwtk::grep_field
# SYNOPSIS
proc ::pwtk::grep_field {pattern file which_field {index ""}} {
    # PURPOSE    
    #   A "field-segmented" version of ::pwtk::grep command. It returns
    #   only a specified field from the lines that matches the
    #   pattern.
    #
    # ARGUMENTS    
    # * pattern     -- pattern to grep for [pattern matching is that of
    #                  Tcl's "string match" command]
    # * file        -- file to grep
    
    # * which_field -- which field from the grepped line to return;
    #                  its meaning/syntax is the same as for the Tcl
    #                  'lindex' command; 0 = first field; end = last
    #                  field

    # * index -- [optional] which match to return; its meaning/syntax
    #            is the same as for the Tcl 'lindex' command; 0 =
    #            first match; end = last match
    #
    # SOURCE
    set result ""

    pwtk::lineread line $file {
	if { [string match *$pattern* $line] } {
	    lappend result [lindex $line $which_field]
	}
    }

    if { $index != "" } {
	set result [lindex $result $index]
    }

    return $result
}
#******



#****f* FileUtilities/::pwtk::egrep_field
# SYNOPSIS
proc ::pwtk::egrep_field {pattern file which_field {index ""}} {
    # PURPOSE    
    #   A "field-segmented" version of ::pwtk::egrep command. It returns
    #   only a specified field from the lines that matches the
    #   pattern.
    #
    # ARGUMENTS    
    # * pattern -- pattern to grep for (pattern matching is that of
    #              Tcl's "regexp" command)
    
    # * file -- file to grep
    
    # * which_field -- which field from the grepped line to return;
    #                  its meaning/syntax is that of the Tcl 'lindex'
    #                  command, i.e, 0 = first field; end = last field
    
    # * index -- [optional] which match to return; its meaning/syntax
    #            is the same as for the Tcl lindex command; 0 = first
    #            match; end = last match
    #
    # SOURCE

    set result ""

    pwtk::lineread line $file {
	if { [regexp $pattern $line] } {
	    lappend result [lindex $line $which_field]
	}
    }

    if { $index != "" } {
	set result [lindex $result $index]
    }

    return $result
}
#******


#****f* TextUtilities/::pwtk::cut
# SYNOPSIS
proc ::pwtk::cut {text {N {}} {M {}}} {
    # USAGE
    #   cut text ?N? ?M?
    #
    # EXAMPLES
    #   cut $text 13
    #   cut $text 5 end
    #   cut $text 3 9
    #
    # PURPOSE
    #   Similar to Unix 'cut' command but takes a text string as the   argument, i.e:
    #
    #   cut $text N   ... cut each line in the text to make it at most N characters long
    #   cut $text N M ... cut each line in the text from N'th to M'th (included) character
    #                     (the 1st character has index 1)
    #
    #
    # ARGUMENTS
    # * text ... text to cut
    # * N ... either maximum line length (if 'M' not given) or the index of the starting character if M is given
    # * M ... the index of the last character
    #
    # if $N < 0 || $N == {} || $N == "end", no cutting is performed (i.e. verbatim text is returned).
    #
    # SOURCE

    if { ! [::pwtk::type::number integer $N] && $N ne "end" } {
        ::pwtk::error "expected integer  or 'end' but got: $N\nwhile executing [procName] $N $M" 1
    }
    if { ! [::pwtk::type::number integer $M] && $M ne "end" } {
        ::pwtk::error "expected integer or 'end' but got: $M\nwhile executing [procName] $N $M" 1
    }
    if { $N < 0 || $N eq {} || $N eq "end" } {
        return $text
    }
    if { $M ne {} } {
        set start $N-1
        if { $M ne "end" } { set end $M-1 } else { set end end }
    } else {
        set start 0
        set end   $N-1
    }

    set result {}
    foreach line [split $text \n] {
        append result [string range $line $start $end]\n
    }
    return $result
}
#******


#****f* Variables/::pwtk::varvalue
# SYNOPSIS 
proc ::pwtk::varvalue {varname} {
    # PURPOSE
    #   Return the value of a variable or an empty string if the variable does not exist.
    # ARGUMENTS
    #   * varname -- name of the variable
    # SOURCE

    upvar $varname var

    if { [info exists var] } {
	return $var
    } else {
	return ""
    }
}
#******


#****if* Internals/::pwtk::test
# SYNOPSIS
proc ::pwtk::test {cmd {expectedResult ""} {expectedError ""}} {
    # PURPOSE
    #   A command for testing scripts and commands, used by tests in
    #   tests/*test. It produces a nice and readable output.
    # ARGUMENTS
    # * expectedResult -- (optional) the result of the test will be compared against $expectedResult
    # * expectedError  -- (optional) the error text of the test will be compared against $expectedError
    # SOURCE
    variable catch_error

    set expectedResultPr [testProcessResult_ $expectedResult]
    set expectedErrorPr  [testProcessResult_ $expectedError]

    set result {}
    set resultErr {}
    set error  {}
    set pass N/A

    puts "
===============================================================Testing==
SCRIPT:
$cmd
"
    set tmp [file join [::fileutil::tempdir] error.[pid]]
    # delete the error file, if it exists
    file delete $tmp

    set catch_error 1
    try {
        if { $expectedError ne {} } {
            ::pwtk::redirect_stderr_to $tmp { set result [uplevel $cmd] }
        } else {
            set result [uplevel $cmd]
        }
    } on error err {
        if { [info commands ::tcl::orig_puts] ne {} } {
            # BEWARE: error occurred while evaluation script in
            # ::pwtk::redirect_stderr_to, revert "puts" to default Tcl puts
            # (see ::pwtk::redirect_stderr_to)
            rename ::puts {}
            rename ::tcl::orig_puts ::puts
        }
        if { $expectedError ne {} } {
            set resultErr [testProcessResult_ [readFile $tmp]]
        }
        ifnotempty err { set error "\n\nCODING_ERROR: $err" }        
    }
    set catch_error 0

    set result [testProcessResult_ $result]

    if { $expectedResult ne {} } {
        set pass [expr { $result == $expectedResultPr ? 1 : 0 } ]
    }
    if { $expectedError ne {} } {
        if { $resultErr eq {} && [file exists $tmp] } {
            # for checking stderr message
            set resultErr [testProcessResult_ [readFile $tmp]]
        }
        set passErr [expr { [filterQEerror_ $resultErr] == [filterQEerror_ $expectedErrorPr] ? 1 : 0 } ]
        if { ! $passErr } {
            set pass 0
        }
        if { $expectedResult eq {} } {
            set pass $passErr
        }
    }
    ifnotempty result {
        puts "RESULT:\n$result"
    }
    if { $pass != 1 && $expectedResult ne {} } {
        puts "EXPECTED RESULT:\n$expectedResultPr"
    }
    if { [file exists $tmp] && [file size $tmp] > 0} {
        puts "RESULTING STDERR:\n$resultErr"
    }
    if { $pass != 1 && $expectedError ne {} } {
        puts "EXPECTED ERROR:\n$expectedErrorPr"
    }
    puts "
PASSED: $pass$error
========================================================================
"
}
#******


# internal...
proc ::pwtk::testProcessResult_ {text} {
    # PURPOSE 
    #   Skip all empty and "downloading" lines in $text; "downloading"
    #   lines are lines that look-like: "Downloading ... from http..."
    #   (these line are due to downloading of pseudopotentials)

    set newText "" ; # $text might be an empty string
    set nl      ""
    foreach line [split $text \n] {
	if { ! [regexp {^[ \t]*$} $line] && ! [regexp {Downloading.* from http.*} $line] } {
	    append newText ${nl}[string trim $line]
	    set nl "\n"
	}
    }
    return $newText
}


#****f* TextUtilities/::pwtk::skipEmptyLines
# SYNOPSIS 
proc ::pwtk::skipEmptyLines {text} {
    # PURPOSE 
    #   Skip all empty-lines in $text.
    # SOURCE
    set newText "" ; # $text might be an empty string
    set nl      ""
    #foreach line [split [string trim $text] \n] {} t.k. Mon Mar 11 2024
    foreach line [split $text \n] {
	if { ! [regexp {^[ \t]*$} $line]  } {
	    append newText ${nl}${line}
	    set nl "\n"
	}
    }
    return $newText
}
#******

#****f* TextUtilities/::pwtk::trimIndent
# SYNOPSIS 
proc ::pwtk::trimIndent {text} {
    # PURPOSE 
    #   Trim indent for each line in the text. Empty lines at the
    #   beginning and end of the text are also trimmed.
    # SOURCE
    set p [set nl {}]
    foreach line [split [string trim $text] \n] {
        append p ${nl}[string trim $line]
        set nl \n
    }
    return $p
}
#******

#****if* Internals/::pwtk::trimCardFlag
# SYNOPSIS 
proc ::pwtk::trimCardFlag {flag} {
    # PURPOSE
    #   Trim from the card's flag the () and/or {} characters.
    # SOURCE
    return [string trim $flag "\{\}\(\){ }"]
}
#******


#****f* Messaging/::pwtk::print
# SYNOPSIS 
proc ::pwtk::print {args} {
    # DESCRIPTION
    #   Print a properly indented message to stdout.
    #
    # USAGE
    #    ::pwtk::print ?-nonewline? message
    #
    #    ::pwtk::print ?-nonewline? label message
    #
    #  SOURCE

    fprint stdout {*}$args
}
#****


#****f* Messaging/::pwtk::fprint
# SYNOPSIS 
proc ::pwtk::fprint {channel args} {
    # DESCRIPTION
    #   Print a properly indented message to a channel.
    #
    # USAGE
    #    ::pwtk::fprint channel ?-nonewline? message
    #
    #    ::pwtk::fprint channel ?-nonewline? label message
    #
    #  SOURCE
    
    set arg_ $args
    set opt {}
    if { [lindex $args 0] eq "-nonewline" } {
        set opt -nonewline
        set args [lrange $args 1 end]
    }

    if { [llength $args] == 1} {
        set label " "
    } elseif { [llength $args] == 2} {
	set label "[lindex $args 0]|"
    } else {
	error "expecting [procName] channel ?-nonewline? ?label? message, but got:
[procName] $channel $arg_" 1        
    }
    
    set message [lindex $args end]
    if { $message eq {} } {
        puts {*}$opt $channel ""
    } else {
        foreach line [split $message \n] {
            if { [string trim $line] == "" } {
                puts {*}$opt $channel ""
            } else {
                puts {*}$opt $channel [format "%5s %s" $label $line]
            }	    
        }
    }
    flush $channel
}
#****   


#****f* Messaging/::pwtk::printTitle
# SYNOPSIS 
proc ::pwtk::printTitle {label {title ""}} {
    # DESCRIPTION
    #   Print a nice section-title to stdout.
    #
    # USAGE
    #    ::pwtk::printTitle title
    #
    #    ::pwtk::printTitle label title
    #
    #  SOURCE

    set s |
    if { $title == {} } {
        set title $label
        set label {}
        set s {}
    }
    
    puts ""
    puts [format "%-5s %s" ${label}$s ======================================================================]
    foreach line [split $title \n] {        
        puts [format "%-5s %s" ${label}$s "*** $line"]
    }
    puts [format "%-5s %s" ${label}$s ======================================================================]
    puts ""
    flush stdout
}
#****


#****if* Internals/::pwtk::debug
# SYNOPSIS 
proc ::pwtk::debug {channel {msg ""}} {
    # USAGE
    #   debug ?channel? $msg
    #
    # DESCRIPTION
    #   Print a debug message  to a channel (only when ::debug variable exists and is true).
    #
    # ARGUMENTS
    # * channel -- (optional, default = stderr) channel to prints to
    # * msg -- message to print
    #
    global debug

    if { $msg == "" } {
        set msg $channel
        set channel stderr
    }
    if { [info exists debug] && $debug } {
	puts $channel "\nDEBUG:  $msg\n"
        flush $channel
    }
}
#****


#****if* Internals/::pwtk::nmlL2regexp
# SYNOPSIS 
proc ::pwtk::nmlL2regexp {nml_list} {
    # DESCRIPTION
    #   Transform list-of-namelists into a regexp for parsing the input, i.e.
    #   {INPUTPP PLOT} is tranformed into (^&INPUTPP|^&PLOT)
    #
    #   If $nml_list eq {}, empty string is returned
    #
    # SOURCE
    foreach nml $nml_list {
        lappend reL &[string trimleft $nml &]    
    }
    ifexist reL {
        return "(^[join $reL |^])"
    } else {
        return ""
    }
}
#******

#****if* Internals/::pwtk::cardL2regexp
# SYNOPSIS 
proc ::pwtk::cardL2regexp {card_list} {
    # DESCRIPTION
    #   Transform list-of-cards into a regexp for parsing the input, i.e.
    #   {CARD1 CARD2} is tranformed into (^CARD1|^CARD2)
    #
    #   If $card_list eq {}, empty string is returned
    #
    # SOURCE
    if { [string trim $card_list] ne {} } {
        return "(^[join $card_list |^])"
    } else {
        return ""
    }
}
#******


#****f* FileUtilities/::pwtk::cat
# SYNOPSIS 
proc ::pwtk::cat {args} {
    #  USAGE
    #    ::pwtk::cat file1 ?file2? ?...?
    #
    #  DESCRIPTION    
    #    Concatenate files and print on the standard output.  It's
    #    like a Unix cat command but accepts no options.
    #
    #  SOURCE
    foreach f $args {
        fileMustExist $f
        puts [readFile $f]
    }
}
#********


#****f* FileUtilities/::pwtk::skiplines
# SYNOPSIS
proc ::pwtk::skiplines {channelId nlines} {
    # PURPOSE
    #   Skip the specified number of lines in the opened file (channelId).
    #
    # ARGUMENTS
    # * channelId -- channel identifier of the opened file
    # * nlines -- number of lines to skip
    #
    # SOURCE

    for {set i 0} {$i < $nlines} {incr i} {
        gets $channelId
    }
}
#******


#****f* FileUtilities/::pwtk::readFile
# SYNOPSIS 
proc ::pwtk::readFile {args} {
    #  USAGE
    #    ::pwtk::readFile ?-nonewline? filename
    #
    #  DESCRIPTION
    #    Read a file and return its content. If the -nonewline
    #    switch is specified then the last character of the file is
    #    discarded if it is a newline.
    #
    # RETURN VALUE
    #   The content of the file.
    #
    #  SOURCE

    set filename [lindex $args end]
    ::pwtk::fileMustExist $filename
    set fID [open $filename r]

    if { [llength $args] == 1 } {
        set opt {}
    } elseif { [llength $args] == 2 && [lindex $args 0] == "-nonewline" } {
        set opt -nonewline
    } else {
        ::pwtk::error "wrong usage: must be \"readFile ?-nonewline? filename\", but got: $args" 1
    }
    set output [eval read $opt $fID]
    close $fID

    return $output
}
#********


#****f* FileUtilities/::pwtk::writeFile
# SYNOPSIS
proc ::pwtk::writeFile {filename content {flag w}} {
    #  DESCRIPTION
    #
    #    Write a content to a file. By default, file is written in the
    #    overwrite mode. To append content to the end of an existing
    #    file, use the "a" mode.
    #
    #  ARGUMENTS
    #  * filename  -- name of the file to be written
    #  * content   -- content to be writtento a file
    #  * flag      -- (optional) access flag for the Tcl "open" command, i.e., w, w+, a, a+
    #
    #  EXAMPLE
    #    ::pwtk::writeFile test.txt {This is a test.txt file} 
    #  SOURCE 
    set   fID  [open $filename $flag]
    puts  $fID $content
    flush $fID
    close $fID
}
#********


#****f* FileUtilities/::pwtk::fileMustExist
# SYNOPSIS
proc ::pwtk::fileMustExist {file {fileType {}}} {
    # PURPOSE
    #   Check if the file exists and if it does not, drop an error
    #   message and abort the execution.
    #
    # ARGUMENTS    
    # * file -- file to check its existence
    # * fileType -- type of file (e.g. XSF, PWO, ...) to include in the error message.
    #
    # SOURCE
    if { $fileType ne {} } {
        append fileType " "
    }        
    if { ! [file exists $file] } {
        uplevel 1 [list ::pwtk::error "${fileType}file \"$file\" does not exist" 1]
    }
}    
#******


#****f* Messaging/::pwtk::deprecated
# SYNOPSIS
proc ::pwtk::deprecated {msg} {
    #  DESCRIPTION
    #     Routine used to print messages/warning of deprecated features.
    #  SOURCE    
    set i 0
    foreach line [split $msg \n] {
	if { ! $i } {
	    ::pwtk::print "\nDEPRECATED: $line"
            set i 1
	} else {
	    ::pwtk::print "            $line"
	}
    }
    puts ""
}
#********


#****f* Variables/::pwtk::ifset
# SYNOPSIS
proc ::pwtk::ifset {name value} {
    # USAGE
    #   ::pwtk::ifset varName value
    #   ::pwtk::ifset arrayName {element value ?element value? ...}
    #
    # DESCRIPTION
    #   If 'name' is a variable:
    #   * set a variable $name only if does not exist or has an empty value.
    #
    #   If 'name' is an array:
    #   * set a given array element only if does not exist or has an empty value.
    #
    # BEWARE
    # ::pwtk::ifset will assign array elements only if the array 'name' already exists.
    #
    # ARGUMENTS
    # * name  -- name of the variable or array (aka varName or arrayName)
    # * value -- either a value to set the variable to or "element value" pairs for an array
    #
    # RETURN VALUE
    # * if 'name' is a variable, the value of the variable.
    # * if 'name' is an array, an empty string.
    #
    # SOURCE
    upvar $name var

    if { [array exists var] } {
        if { [llength $value] % 2 } {
            ::error "element-value list must have an even number of elements"
        }
        foreach {e v} $value {
            if { ! [info exists var($e)] || $var($e) eq {} } {
                set var($e) $v
            }
        }
        return {}        
    } else {
        if { [info exists var] && $var ne {} } {
            return $var
        } else {
            return [set var $value]
        }
    }
}
#******


#****f* Conditionals/::pwtk::ifexist
# SYNOPSIS
proc ::pwtk::ifexist {varName script args} {
    # USAGE
    #   ifexist varName script ?else script2?
    # PURPOSE
    #   Execute the $script only if the variable $varName exists.
    #
    # EXAMPLE
    #   ifexist varName {
    #      puts "variable varName exists"
    #   } else {
    #      puts "variable varName does not exist"
    #   }
    # SOURCE    
    upvar $varName var

    set narg [llength $args]
    if { $narg > 0 } {
        if { [lindex $args 0] != "else" } {
            ::error "invalid command name [lindex $args 0]"
        } elseif { [llength $args] != 2 } {            
            ::error "wrong # args: should be \"if exists varName script ?else script?\""
        }
    }
    set result {}
    set code 0
    if { [info exists var] } {
        set code [catch {uplevel 1 $script} result]
    } elseif { $narg == 2 } {
        set code [catch {uplevel 1 [lindex $args end]} result]
    }
    return -code $code $result
}
#******


#****f* Conditionals/::pwtk::ifnotexist
# SYNOPSIS
proc ::pwtk::ifnotexist {varName script args} {
    # USAGE
    #   ifnotexist varName script ?else script2?
    # PURPOSE
    #   Execute the $script only if the variable $varName does not exist.
    # SOURCE    
    upvar $varName var

    set narg [llength $args]
    if { $narg > 0 } {
        if { [lindex $args 0] != "else" } {
            ::error "invalid command name [lindex $args 0]"
        } elseif { $narg != 2 } {
            ::error "wrong # args: should be \"if exists varName script ?else script?\""
        }
    }
    set result {}
    set code 0
    if { ! [info exists var] } {
        set code [catch {uplevel 1 $script} result]
    } elseif { $narg == 2} {
        set code [catch {uplevel 1 [lindex $args end]} result]
    }
    return -code $code $result
}
#******


#****f* Conditionals/::pwtk::ifnotempty
# SYNOPSIS
proc ::pwtk::ifnotempty {varName script args} {
    # USAGE
    #   ifnotempty varName script ?else script2?
    # PURPOSE
    #   Execute the $script only if the variable $varName exists and is not empty.
    # SOURCE    
    upvar $varName var

    set narg [llength $args]
    if { $narg > 0 } {
        if { [lindex $args 0] != "else" } {
            ::error "invalid command name [lindex $args 0]"
        } elseif { $narg != 2 } {
            ::error "wrong # args: should be \"if exists varName script ?else script?\""
        }
    }
    set result {}
    set code 0
    if { [info exists var] && $var != {} } {
        set code [catch {uplevel 1 $script} result]
    } elseif { $narg == 2} {
        set code [catch {uplevel 1 [lindex $args end]} result]
    }
    return -code $code $result
}
#******


#****f* Conditionals/::pwtk::ifempty
# SYNOPSIS
proc ::pwtk::ifempty {varName script args} {
    # USAGE
    #   ifempty varName script ?else script2?
    # PURPOSE
    #   Execute the $script only if the variable $varName is empty or does not exist.
    # SOURCE    
    upvar $varName var

    set narg [llength $args]
    if { $narg > 0 } {
        if { [lindex $args 0] != "else" } {
            ::error "invalid command name [lindex $args 0]"
        } elseif { [llength $args] != 2 } {            
            ::error "wrong # args: should be \"if exists varName script ?else script?\""
        }
    }
    set result {}
    set code 0
    if { ! [info exists var] || $var == {} } {
        set code [catch {uplevel 1 $script} result]
    } elseif { $narg == 2} {
        set code [catch {uplevel 1 [lindex $args end]} result]
    }
    return -code $code $result
}
#******


#****f* Messaging/::pwtk::procName
# SYNOPSIS
proc ::pwtk::procName {{level -1}} {
    # DESCRIPTION    
    #   If level == -1, returns the name of the calling proc or
    #   "top-level" if called from the top level. If level == -2,
    #   return the name of the calling proc of the calling proc, i.e.,
    #   the name of the proc two-levels back. If level == -N, returns
    #   the name of the proc N-levels back.
    #
    #   Typically used internally by PWTK.
    #
    # ARGUMENTS
    # * level -- [optional, default = -1] how many levels back to report the name of the proc.
    #
    # SOURCE
    if { [info level] > abs($level) } {
	return [lindex [info level $level] 0]
    } else {
	return "top-level"
    }
}
#******



#****f* Evals-Execs-Errors/::pwtk::catch_error
# SYNOPSIS
proc ::pwtk::catch_error {script {errorScript {}}} {
    # DESCRIPTION    
    #   Execute a supplied $script and if an error occurs and
    #   $errorScript != {}, execute the $errorScript.
    #
    #   This proc is similar yet different than the Tcl's "try"
    #   command. For example, the "::pwtk::error errMsg 1" calls the
    #   "exit" command and if ::pwtk::error is called within the
    #   catch_error, then "error" is called instead of "exit".
    #
    # ARGUMENTS
    # * script -- script to execute in the "catch_error" mode
    # * errorScript -- [optional] script to execute if an error occurs
    #                  during the $script evaluation
    #
    # SOURCE
    variable catch_error

    set catch_error 1
    set code [catch {uplevel 1 $script}]
    if { $code == 1 } {
        if { $errorScript != {} } {
            uplevel $errorScript
        }
    }
    set catch_error 0
    if { $code != 1 } {
        return -code $code $code
    } else {
        return $code
    }
}
#******

#****f* Evals-Execs-Errors/::pwtk::eval_in_dir
# SYNOPSIS
proc ::pwtk::eval_in_dir {dir script} {
    # PURPOSE
    #   Evaluate a script in directory $dir. If $dir does not exist,
    #   it is created. This command is equivalent to:
    #
    #       set here [pwd]
    #       file mkdir $dir
    #       cd $dir
    #       eval $script
    #       cd $here
    #
    # ARGUMENTS
    # * dir -- directory where to evaluate the script (if $dir is an empty string, ./ is assumed)
    # * script -- script to evaluate
    #
    # RETURN VALUE
    #   The return value of the last command in the script.
    #
    # SOURCE

    set here [pwd]
    ifset dir .
    try {
        file mkdir $dir
        cd $dir
        if { $dir ne "." } {
            pwtk::print "from [procName]:\nCWD changed to [pwd]\n"
        }
    } on error err {
        ::pwtk::error "cannot create directory: $dir\n\n$err" 1
    }
    set code [catch {uplevel 1 $script} result]
    cd $here
    if { $dir ne "." } {
        pwtk::print "from [procName]:\nCWD reverted to [pwd]\n"
    }
    
    return -code $code $result
}
#******

#****f* Processes/::pwtk::pid_exists
# SYNOPSIS
proc ::pwtk::pid_exists {pid} {
    # PURPOSE
    #   Returns 1 if the PID process exists, otherwise 0.
    # ARGUMENT
    # * pid -- process ID
    # SOURCE    
    if { [catch {exec ps -p $pid -o pid=} res] } {
        return 0
    } elseif { $pid in $res } {
        return 1
    } else {
        return 0
    }
}
#******

#****f* Processes/::pwtk::pid_wait
# SYNOPSIS
proc ::pwtk::pid_wait {PID} {
    # PURPOSE
    #   Wait for the PID process to finish. This command blocks until
    #   the PID process is completed.
    #
    # ARGUMENT
    # * PID ... process ID
    #
    # SOURCE
    variable time_interval_ms

    while { [pid_exists $PID] } {	
        after $time_interval_ms
    }
}
#******


##****f* Quoting/::pwtk::lquote
## SYNOPSIS
#proc ::pwtk::lquote {str} {
#    # PURPOSE   
#    #   "lquote" (aka list-quote) quotes a non-empty string with
#    #   single quotes.
#    #
#    #   If the string contains more than one word, it is returned as a
#    #   single-list element, i.e.: {'This is my sentence'}
#    #
#    # RETURN VALUE
#    # * for one-word string, e.g.: 'word'
#    # * for multi-word string, e.g.: {'more words'}
#    # SOURCE
#    if { $str ne {} } {
#        return [list '[unquote $str]']
#    } else {
#        return $str
#    }
#}
##******


#****f* Quoting/::pwtk::rangequote
# SYNOPSIS
proc ::pwtk::rangequote {str} {
    # PURPOSE   
    #   Quote a non-empty string with square brackets, i.e., transform
    #   xmin:xmax to [xmin:xmax].
    #
    # RETURN VALUE
    # * string quoted with square brackets as [string]
    #
    # SOURCE
    if { $str ne {} } {
        return \[[string trim $str {[]}]\]
    } else {
        return $str
    }
}
#******


#****f* Quoting/::pwtk::squote
# SYNOPSIS
proc ::pwtk::squote {str} {
    # PURPOSE   
    #   Quote a non-empty string with the single quotes.
    #
    # RETURN VALUE
    # * $str quoted with single-quotes, i.e., '$str'
    # SOURCE
    if { $str ne {} } {
        return '[unquote $str]'
    } else {
        return $str
    }
}
#******


#****f* Quoting/::pwtk::dquote
# SYNOPSIS
proc ::pwtk::dquote {str} {
    # PURPOSE   
    #   Quotes a non-empty string with the double quotes.
    #
    # RETURN VALUE
    # * $str quoted with double-quotes, i.e., "$str"
    # SOURCE
    if { $str ne {} } {
        return \"[unquote $str]\"
    } else {
        return $str
    }
}
#******


#****f* Quoting/::pwtk::unquote
# SYNOPSIS
proc ::pwtk::unquote {str} {
    # PURPOSE   
    #   Unquote a string, i.e., both single and double quotes are trimmed.
    #
    # RETURN VALUE
    #   Unquoted string.
    # SOURCE
    return [string trim $str '\"]
}
#******


#****f* 5.3.6. Run Auxiliaries/::pwtk::getExecutable
# SYNOPSIS
proc ::pwtk::getExecutable {args} {
    # PURPOSE    
    #   Find an executable program from the list of programs/files and
    #   return the first one that is executable. 
    #
    #   This is similar but simpler than ::pwtk::findExecutable. While
    #   ::pwtk::findExecutable is meant to find the QE executables,
    #   ::pwtk::getExecutable is used to find other (generic)
    #   executables. The usage of the two commands is different
    #   because ::pwtk::getExecutable examines a list of programs,
    #   while ::pwtk::findExecutable examines a single program.
    #
    # ARGUMENTS
    # * args -- list of possible programs/files to probe for
    #           executable status
    #
    # RETURN VALUE
    #   Full path of the executable or an empty string if the
    #   requested executable is not found.
    #
    # SOURCE

    if { [llength $args] == 1 } {
        set args [concat {*}$args]
    }
    foreach exe $args {
        set result [auto_execok $exe]
        if { $result != {} } {
            return $result
        }
    }
    return ""
}
#******


#****f* 5.3.1. Run Programs (plain way)/::pwtk::try_exec
# SYNOPSIS
proc ::pwtk::try_exec {args} {
    # USAGE
    #   try_exec ?-e|-i? ?-p? ?EXEC_OPTIONS? ?--? arg1 ?arg2? ?arg3 ...?
    #
    # PURPOSE    
    #   Execute an executable via the "exec" command and prints an
    #   informative error message if the execution fails.
    #
    #   If "::pwtk::try_exec" is called with the -e option, then an
    #   error is thrown if "exec" returns an error.
    #
    # OPTION
    # * -e ... throw an error if "exec" returns abnormally
    # * -i ... ignore errors and proceed
    # * -p ... print ignored errors if -i is given
    # * EXEC_OPTIONS ... options accepted by Tcl exec command (i.e. -ignorestderr & -keepnewline)
    # * -- ... end of options (this must be used if the executable name starts with -)
    #
    # ARGUMENTS
    # * args -- executable with command line arguments to execute with "exec"
    #
    # SOURCE

    set nargmin 1
    set nargmax -1
    set options {
        {e "throw an error if 'exec' returns abnormally"}
        {i "ignore errors"}
        {p "print ignored errors"}
    }
    set usage "?-e|-i? ?--? arg1 ?arg2? ?...?"
    parseKnownOpt_

    try {
        return [uplevel 1 exec $args]
    } on error err {
        if { $opt(i) } {
            # ignore the error but print the warning
            if { $opt(p) } {
                ::pwtk::warning "an error occurred while running \"$args\":\n\n$err\n\nIgnoring the error as requested."
            }
            return $err
        }
        uplevel 1 [list ::pwtk::error "error executing:  \"exec $args\"\n\n$err"]
        if { $opt(e) } {
            uplevel 1 ::error {} "from..."; # throw an error
        }
    }
}
#******

#proc ::pwtk::try_exec {args} {
#    # USAGE
#    #   try_exec ?-e|-i? ?--? arg1 ?arg2? ?arg3 ...?
#    #
#    # PURPOSE    
#    #   Execute an executable via the "exec" command and prints an
#    #   informative error message if the execution fails.
#    #
#    #   If "::pwtk::try_exec" is called with the -e option, then an
#    #   error is thrown if "exec" returns an error.
#    #
#    # OPTION
#    # * -e ... throw an error if "exec" returns abnormally
#    # * -i ... ignore errors and proceed
#    # * -- ... end of options (this must be used if the executable name starts with -)
#    #
#    # ARGUMENTS
#    # * args -- executable with command line arguments to execute with "exec"
#    #
#    # SOURCE
#
#    set nargmin 1
#    set nargmax -1
#    set options {
#        {e "throw an error if 'exec' returns abnormally"}
#        {i "ignore errors"}
#    }
#    set usage "?-e|-i? ?--? arg1 ?arg2? ?...?"
#    parseOpt_
#
#    try {
#        return [uplevel 1 [list eval exec $args]]
#    } on error err {
#        if { $opt(i) } {
#            # ignore the error
#            return $err
#        }
#        uplevel 1 [list ::pwtk::error "error executing \"$args\"\n\n$err"]
#        if { $opt(e) } {
#            uplevel 1 ::error {} "from..."; # throw an error
#        }
#    }
#}


#****if* Internals/::pwtk::int_in_range1_
# SYNOPSIS
proc ::pwtk::int_in_range1_ {index lastIndex} {
    # PURPOSE
    #   Check that index is integer and is in [1,lastIndex] range.
    #   
    # SOURCE
    if { ! [string is integer -strict $index] } {
        uplevel 1 [list ::pwtk::error "expected integer for index, but got $index" 1]
    }
    if { $index < 1 || $index > $lastIndex } {
        uplevel 1 [list ::pwtk::error "index $index is out of range, must be within \[1,$lastIndex]" 1]
    }
    return $index
}
#******


#****if* Internals/::pwtk::intlist_in_range1_
# SYNOPSIS
proc ::pwtk::intlist_in_range1_ {indexList lastIndex} {
    # PURPOSE
    #   Check that indices in the list are integers and within the [1,lastIndex] range.
    #
    # SOURCE
    foreach int $indexList {
        ::pwtk::int_in_range1_ $int $lastIndex
    }
    return $indexList
}
#******


#****if* Internals/::pwtk::lunique
# SYNOPSIS
proc ::pwtk::lunique {list} {
    # PURPOSE
    #   Remove duplicate elements from the list, while preserving the order or elements.
    #
    #   Taken from https://wiki.tcl-lang.org/page/Unique+Element+List
    #   (author: Wolf-Dieter Busch)
    #
    # SOURCE
    set new {}
    foreach e $list {
        if {$e ni $new} {
            lappend new $e
        }
    }
    return $new
}
#******


#****f* TextUtilities/::pwtk::trimText
# SYNOPSIS
proc ::pwtk::trimText {text} {
    # PURPOSE
    #   Trim lines for whitespaces and skip leading and trailing
    #   empty lines.
    # SOURCE
    set text [string trim $text]
    set result [lmap line [split $text \n] {string trim $line}]    
    return [join $result \n]    
}
#******

#****f* TextUtilities/::pwtk::trimAllLines
# SYNOPSIS
proc ::pwtk::trimAllLines {text} {
    # PURPOSE
    #   Trim all lines for whitespaces and skip all empty lines.
    # SOURCE
    set text [string trim $text]
    set result {}
    foreach line [split [string trim $text] \n] {
        set line [string trim $line]
        if { $line ne {} } {
            append result $line\n
        }
    }
    return [string trim $result]    
}
#******


#****if* Internals/::pwtk::normalizeSOpt
# SYNOPSIS
proc ::pwtk::normalizeSOpt {optval} {
    # PURPOSE
    #   Tranform short option -oVALUE to -o VALUE
    #   (SOpt stands for short option).
    # ARGUMENT
    # * optval -- option-value pair
    # SOURCE
    
    if { ! [regexp -- ^-- $optval] && [regexp -- ^- $optval] } {
        if { [string length $optval] > 2 } {
            # -oVALUE to -o VALUE
            set optval "[string range $optval 0 1] [string range $optval 2 end]"
        }
    }
    return $optval
}
#******


#****if* Internals/::pwtk::expandSOpts
# SYNOPSIS
proc ::pwtk::expandSOpts {string} {
    # PURPOSE
    #   Tranform all short options of type "-oVALUE" to "-o VALUE" in
    #   an arbitrary string (SOpts stands for short options).
    # ARGUMENT
    # * string -- and arbitrary string (can be multi-line)
    # SOURCE

    set result [set nl {}]
    foreach line [split [string trim $string] \n] {
        append result $nl
        foreach f $line {
            if { [llength $f] > 1 } {
                set f [list [normalizeSOpt $f]]
            }
            append result "[normalizeSOpt $f] "
        }
        set nl \n
    }
    return $result
}
#******

#****if* Internals/::pwtk::dummy
# PURPOSE
#   Do nothing - dummy proc.
# SOURCE
proc ::pwtk::dummy {args} {}
#******


#****f* Lists/::pwtk::lequal
# SYNOPSIS
proc ::pwtk::lequal {l1 l2} {
    #  PURPOSE
    #   Check if the l1 and l2 lists are equal; if equal return 1, otherwise 0.
    #  ARGUMENTS
    #  * l1  -- the 1st list
    #  * l2  -- the 2nd list
    #  RETURN VALUE
    #    1 or 0, depending on the equality of lists l1 and l2.
    # SOURCE
    if { [llength $l1] != [llength $l2] } { return 0 }
    foreach e1 $l1 e2 $l2 {
	if { ! [string equal $e1 $e2] } { return 0 }
    }
    return 1
}
#******
