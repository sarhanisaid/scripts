#
# $RCSfile: pdos.tcl,v $ --
#
#      This file contains routines for processing the projwfc.x
#      generated PDOSes.
#
# Copyright (c) 2023-2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: pdos.tcl,v 1.3 2023/01/172 11:22:07 kokalj Exp $ 
#


#****f* PDOS/::pwtk::pdos_run
# SYNOPSIS
proc ::pwtk::pdos_run {args} {
    # USAGE
    #   ::pwtk::pdos_run  ?SPECIFIC-OPTIONS?  ?OPTIONS?  HEAD
    #
    #   where SPECIFIC-OPTIONS are:
    #
    #       -scf
    #       -nscf KGRID
    #       -e    EFERMI
    #       -emin EMIN
    #       -emax EMAX
    #
    # SPECIFIC OPTIONS
    # * -scf   --- perform an SCF pw.x calculation (the Fermi energy is taken
    #              from this SCF calculation unless the -nscf or -e option is specified)
    
    # * -nscf {K1 K2 K3  ?SK1 SK2 SK3?} ---
    #                   perform NSCF pw.x calculation using the provided automatic k-point grid;
    #                   if SK1,SK2,SK3 shifts are omitted, a non-shifted k-mesh is used;
    #                   (the Fermi energy is taken from this NSCF calculation unless the -e option is specified)

    # * -e EFERMI  --- Fermi energy (either a floating-point number or a pw.x output file
    #                  from where the Fermi energy is taken)
    
    # * -emin EMIN --- the minimum-energy (with respect to Fermi energy in eV) to be
    #                  used for projwfc.x, i.e., Emin of projwfc.x is set to: Emin = EMIN + Efermi

    # * -emax EMAX --- the maximum-energy (with respect to Fermi energy in eV) to be
    #                  used for projwfc.x, i.e., Emax of projwfc.x is set to: Emax = EMAX + Efermi
        
    #
    # OPTIONS
    #   See ::pwtk::pdos_multiplot
    #
    # ARGUMENTS
    # * HEAD -- the rootname for files, which will be named as prefix.$HEAD.postfix
    #
    # DESCRIPTION
    #   Run a workflow of calculations to calculate and plot the
    #   projected DOS. The sequence of jobs is:
    #
    #      pw.x SCF (optional, requested by -scf)
    #       |
    #       |
    #      pw.x NSCF (optional, requested by -nscf)
    #       |
    #       |
    #      projwfc.x
    #       |
    #       |
    #      PLOTTING
    #
    # BEWARE
    #   If the -scf option is omitted, an SCF (or *RELAX) calculation
    #   must be performed prior to using this workflow. Optionally,
    #   the PROJWFC namelist could also be predefined.
    #
    # EXAMPLE
    #   load_fromPWI scf.$head.in
    #
    #   PROJWFC { ngauss  = 0 degauss = 0.01 DeltaE = 0.05 }
    #   pdos_run -scf -nscf {8 8 8} -emin -10 -emax 4 -t png  $head
    #
    # RETURN VALUE
    #   Filenames of the created LDOS and PDOS plots (for file
    #   terminals) or the empty string (for window terminals).
    #
    # SOURCE

    printTitle PDOS_RUN "Running the PDOS workflow"
    print "Workflow options & arguments :  $args"

    addOpts_ options usage {
        {scf          "perform SCF calculation"}
        {nscf.arg {}  "perform NSCF calculation using provided KGRID"}
        {e.arg    {}  "Fermi energy (either a floating-point number or a pw.x output file from where the Fermi energy is taken)"}
        {emin.arg {}  "Emin for projwfc.x with respect to Fermi energy (in eV)"}
        {emax.arg {}  "Emax for projwfc.x with respect to Fermi energy (in eV)"}
    } {
        -scf {-nscf KGRID} {-e EFERMI} {-emin EMIN} {-emin EMAX}
    }

    set nargmin 1
    set nargmax -1
    set usage "[fmtUsage_ $usage]  ?SPECIFIC-OPTIONS?  ?OPTIONS?  HEAD"
    deprecatedOpts_ { {-k -nscf} } args; # N.B. -k was replace by -nscf
    parseKnownOpt_
    
    checkOType_ -nscf $opt(nscf) {numberlist nonnegint}  "list of non-negative integer numbers (i.e. automatic k-point grid specs)"
    checkOType_ -emin $opt(emin) double number
    checkOType_ -emin $opt(emax) double number

    set head [lindex $args end]
    
    print "Rootname for files:  $head\n"
    
    input_pushpop {
        input_clear IONS CELL

        # SCF + NSCF calcs & fetch Efermi
        SCF_NSCF_
        Efermi_

        # projwfc.x
        print PROJWFC "Performing projwfc.x calculation\n"
        PROJWFC " filpdos = '$head' "
        EminEmax_ $opt(emin) $opt(emax) $Efermi PROJWFC
        runPROJWFC projwfc.$head
    }

    print PLOTTING "Plotting all LDOSes and PDOSes ...\n"

    set ldos_ [ldos_fullplot -e $pwo -o landscape {*}$args]
    set pdos_ [pdos_fullplot -e $pwo -o landscape {*}$args]

    if { $ldos_ ne {} } {
        print PDOS_RUN "All LDOSes were plotted to :  $ldos_
All PDOSes were plotted to :  $pdos_\n"
    }

    return [concat $ldos_ $pdos_]
}
#******


#****f* PDOS/::pwtk::ldos_fullplot
# SYNOPSIS
proc ::pwtk::ldos_fullplot {args} {
    # USAGE
    #    ::pwtk::ldos_fullplot  ?-out ROOTNAME?  ?OPTIONS?  FILPLOT
    #
    # PURPOSE
    #   Plot the LDOS(es) of each atom into a separate plot of a multiplot.
    #
    # OPTIONS
    #   * -out ROOTNAME ---  rootname for the Gnuplot-script and, for file terminals,
    #                        the output image file (default = the value of the FILPLOT argument)   
    #
    #   For other options, see ::pwtk::ldos_multiplot
    #
    # ARGUMENT
    # * FILPLOT --- the rootname of projwfc.x 'filplot' files, i.e. FILPLOT.pdos_atm#*(*)_wfc#*(*)
    #
    # SOURCE

    addOpts_ options usage [subst {
        {out.arg  {}          "rootname for the Gnuplot-script and image file"}
        {t.arg    $::pwtk::gp::gp(workflow.terminal)   "terminal for the plot"}
    }] {
        {-out ROOTNAME} {-t TERMINAL}
    }
    set nargmin 1
    set nargmax -1
    set usage "[fmtUsage_ $usage]  ?OPTIONS?  FILPLOT"
    parseKnownOpt_

    set filplot [lindex $args end]
    set args [lrange $args 0 end-1]

    if { $opt(out) eq {} } {
        set plotname $filplot
    } else {
        set plotname [headname $opt(out) .$opt(t)]
    }
    set plotname $plotname.fullLDOS

    print "LDOS_FULLPLOT:\nrootname for plotting files:                $plotname"

    # construct a list of lists of LDOS plots
    
    set nat 0
    foreach f [pdos_atm_files -f $filplot] {
        # extract atom.# (iat) and angular momentum (l) from the filename
        regexp {pdos_atm#(\d+)\(\w+\)_wfc#\d+\((\w)\)} $f matchVar iat l
        lappend l1($iat,$l) $f
        if { $iat > $nat} { set nat $iat }
    }
    for {set iat 1} {$iat <= $nat} {incr iat} {
        foreach l {s p d f g h} {
            if { [info exist l1($iat,$l)] } {
                foreach x $l1($iat,$l) {
                    lappend l2($iat) $x
                }
            }
        }
        ifnotempty l2($iat) { lappend ll $l2($iat) }
    }
    ldos_multiplot {*}$args -t $opt(t) $ll $plotname
}
#******


#****f* PDOS/::pwtk::pdos_fullplot
# SYNOPSIS
proc ::pwtk::pdos_fullplot {args} {
    # USAGE
    #    ::pwtk::pdos_fullplot  ?-out ROOTNAME?  ?OPTIONS?  FILPLOT
    #
    # PURPOSE
    #   Plot the PDOS(es) of each pdos_atm file into a separate plot of a multiplot.
    #
    # OPTIONS
    #   * -out ROOTNAME ---  rootname for the Gnuplot-script and, for file terminals,
    #                        the output image file (default = the value of the FILPLOT argument)   
    #
    #   For other options, see ::pwtk::pdos_multiplot
    #
    # ARGUMENT
    # * FILPLOT --- the rootname of projwfc.x 'filplot' files, i.e. FILPLOT.pdos_atm#*(*)_wfc#*(*)
    #
    # SOURCE

    addOpts_ options usage [subst {
        {out.arg  {}   "rootname for the Gnuplot-script and image file"}
        {t.arg    $::pwtk::gp::gp(workflow.terminal)   "terminal for the plot"}
    }] {
        {-out ROOTNAME} {-t TERMINAL}
    }
    set nargmin 1
    set nargmax -1
    set usage "[fmtUsage_ $usage]  ?OPTIONS?  FILPLOT"
    parseKnownOpt_

    set filplot [lindex $args end]
    set args [lrange $args 0 end-1]

    if { $opt(out) eq {} } {
        set plotname $filplot
    } else {
        set plotname [headname $opt(out) .$opt(t)]
    }
    set plotname $plotname.fullPDOS

    print "PDOS_FULLPLOT:\nrootname for plotting files:                $plotname"
    
    # construct a list of lists of LDOS plots
    
    set nat 0
    foreach f [pdos_atm_files -f $filplot] {
        # extract atom.# (iat) and angular momentum (l) from the filename
        regexp {pdos_atm#(\d+)\(\w+\)_wfc#\d+\((\w)\)} $f matchVar iat l
        lappend l1($iat,$l) $f
        if { $iat > $nat} { set nat $iat }
    }
    for {set iat 1} {$iat <= $nat} {incr iat} {
        foreach l {s p d f g h} {
            ifnotempty l1($iat,$l) {
                foreach x $l1($iat,$l) {
                    switch -exact $l {
                        s {
                            lappend ll [list $x s]
                        }
                        p {
                            lappend ll [list $x pz  $x px  $x py]
                        }
                        d {
                            lappend ll [list $x dz2  $x dzx  $x dzy  $x dx2y2  $x dzy]
                        }
                        default {
                            ::pwtk::warning "angular momentum beyond d not supported"
                        }
                    }
                }
            }
        }
    }
    
    pdos_multiplot {*}$args -t $opt(t) $ll $plotname
}
#******


#****f* PDOS/::pwtk::pdos_atm_files
# SYNOPSIS
proc ::pwtk::pdos_atm_files {args} {
    # USAGE
    #    ::pwtk::pdos_atm_files ?-f PATTERN?  ?-n PATTERN?  ?-s PATTERN?  ?-w PATTERN?  ?-l PATTERN?
    #
    # DESCRIPTION
    #   Return a list of projwfc.x filpdos pdos_atm files that matches
    #   the supplied (glob) patterns. The name of these files are:
    #
    #      "filpdos".pdos_atm#N(S)_wfc#M(l)
    #
    #   where N = atom number, S = atom symbol, M = wfc number, l = orbital angular momentum (s,p,d,f).
    #
    #   Note that options are cumulative, implying that the full glob
    #   pattern is assembled by their combination.
    #
    #   All the options are optional (default value for each option is
    #   "*" that means anything).
    #
    # OPTIONS
    # * -f PATTERN --- glob pattern for the 'filpdos' head (note that the assembled glob pattern is PATTERN.pdos_atm#*(*)_wfc#*(*)
    # * -n PATTERN --- list of atom numbers (glob * and ? patterns and ranges using \"from-to\" syntax are supported)
    # * -s PATTERN --- list of atom symbols (glob * and ? patterns are supported)
    # * -w PATTERN --- list of wfc numbers  (glob * and ? patterns and ranges using \"from-to\" syntax are supported)
    # * -l PATTERN --- list of orbital angular momentum s, p, d... (glob * and ? patterns are supported)
    #
    # |html <b>EXAMPLE</b>
    #
    #    set pdosFiles [::pwtk::pdos_atm_files -n 1-6]
    #
    # This will return all pdos_atm files for atoms 1, 2, 3, 4, 5, 6
    # in the current working directory.
    #
    # SOURCE

    set narg -1; # no narg checking (allow flexible use)
    set usage "?-f PATTERN?  ?-n PATTERN?  ?-s PATTERN?  ?-w PATTERN?  ?-l PATTERN?"
    set options {
        {f.arg  * "glob pattern for the 'filpdos' head"}
        {n.arg  * "list of atom numbers (glob * and ? patterns and ranges using \"from-to\" syntax are supported)"}
        {s.arg  * "list of atom symbols (glob * and ? patterns are supported)"}
        {w.arg  * "list of wfc number (glob * and ? patterns and ranges using \"from-to\" syntax are supported)"}
        {l.arg  * "list of orbital angular momentum s, p, d... (glob * and ? patterns are supported)"}
    }
    parseOpt_

    if { $opt(n) != "*" } {
        set opt(n) \{[join [::pwtk::expandSequence $opt(n)] ,]\}
    }
    if { $opt(s) != "*" } {
        set opt(s) \{[join $opt(s) ,]\}
    }
    if { $opt(w) != "*" } {
        set opt(w) \{[join [::pwtk::expandSequence $opt(w)] ,]\}
    }
    if { $opt(l) != "*" } {
        set opt(l) \{[join $opt(l) ,]\}
    }

    set glob $opt(f).pdos_atm#${opt(n)}($opt(s))_wfc#${opt(w)}($opt(l))
    ::pwtk::print "glob pattern for selecting pdos_atm files:  $glob\n"
    
    return [lsort [glob -nocomplain $glob]]
}
#******



#****f* PDOS/::pwtk::sumldos
# SYNOPSIS
proc ::pwtk::sumldos {args} {
    # USAGE
    #   ::pwtk::sumldos ?-f PATTERN?  ?-n PATTERN?  ?-s PATTERN?  ?-w PATTERN?  ?-l PATTERN?  FILEOUT
    #
    # DESCRIPTION
    #   Sum LDOSes for projwfc.x filpdos pdos_atm files that matches
    #   the supplied glob patterns. LDOSes are summed using the QE
    #   sumpdos.x program.
    #
    # OPTIONS
    #   For description of options, see ::pwtk::pdos_atm_files
    #
    # ARGUMENTS
    # * FILEOUT -- name of the output file where to write the summed LDOS
    #
    # RETURN VALUE
    #   The value of the "fileout" argument.
    #
    # SOURCE
    
    # the number of arguments must be odd when implcit options (-?,
    # -help, --) are stripped from $args
    
    if { ! ([llength [trimImplicitOpts_ $args]] % 2) } {
        ::pwtk::error "wrong number of arguments, must be:\n 
[procName] ?-f PATTERN?  ?-n PATTERN?  ?-s PATTERN?  ?-w PATTERN?  ?-l PATTERN?  fileout" 1
    }
    
    ::pwtk::print LDOS "Summing LDOSes..."

    set pdosFiles [::pwtk::pdos_atm_files {*}$args]
    set fileout   [lindex $args end]
    return [::pwtk::sumldosFiles $pdosFiles $fileout]
}
#******


#****f* PDOS/::pwtk::sumldosFiles
# SYNOPSIS
proc ::pwtk::sumldosFiles {pdosFiles fileout} {
    # DESCRIPTION
    #   Sum LDOSes from $pdosFiles and write the result to $fileout
    #   file. LDOSes are summed using the QE sumpdos.x program.
    #
    # ARGUMENTS
    # * pdosFiles -- explicit list of projwfc.x filpdos pdos_atm files
    # * fileout   -- name of the output file where to write the summed LDOS
    #
    # RETURN VALUE
    #   The value of the "fileout" argument.
    #
    # SOURCE
    
    foreach f $pdosFiles {
        ::pwtk::fileMustExist $f "projwfc.x pdos_atm"
    }

    try {
        eval execute -ignorestderr sumpdos.x $pdosFiles > $fileout
    } on error err {
        ::pwtk::error "an error occurred while running sumpdos.x\n\n$err" 1 
    }
    ::pwtk::print "\nSummed LDOS written to :   $fileout\n"
    return $fileout
}
#******



#****f* PDOS/::pwtk::sumpdos
# SYNOPSIS
proc ::pwtk::sumpdos {args} {
    # USAGE
    #   ::pwtk::sumpdos ?-f PATTERN?  ?-n PATTERN?  ?-s PATTERN?  ?-w PATTERN?  ?-l PATTERN?  FILEOUT
    #
    # DESCRIPTION
    #   Sum PDOSes for projwfc.x filpdos pdos_atm files that matches
    #   the supplied glob patterns.
    # 
    #   BEWARE that PDOSes are summed separately for each component,
    #   hence only compatible pdos_atm files can be summed, i.e., s with s,
    #   p with p, and d with d, where s,p,d are angular momenta. Otherwise,
    #   an error occurs.
    #
    # OPTIONS
    #   For description of options, see ::pwtk::pdos_atm_files
    #
    # ARGUMENTS
    # * FILEOUT -- name of the output file where to write the summed PDOSes
    #
    # RETURN VALUE
    #   The value of the "fileout" argument.
    #
    # SOURCE


    # the number of arguments must be odd when implcit options (-?,
    # -help, --) are stripped from $args    
    
    if { ! ([llength [trimImplicitOpts_ $args]] % 2) } {
        ::pwtk::error "wrong number of arguments, must be:\n 
[procName] ?-f PATTERN?  ?-n PATTERN?  ?-s PATTERN?  ?-w PATTERN?  ?-l PATTERN?  fileout" 1
    }
    
    ::pwtk::print PDOS "Summing PDOSes..."

    set pdosFiles [::pwtk::pdos_atm_files {*}$args]
    set fileout   [lindex $args end]    
    return [::pwtk::sumpdosFiles $pdosFiles $fileout]
}
#******


#****f* PDOS/::pwtk::sumpdosFiles
# SYNOPSIS
proc ::pwtk::sumpdosFiles {pdosFiles fileout} {
    # DESCRIPTION
    #   Sum PDOSes from $pdosFiles and write the result to the $fileout file.
    # 
    #   BEWARE that PDOSes are summed separately for each component,
    #   hence only compatible pdos_atm files can be summed, i.e., s with s,
    #   p with p, and d with d, where s,p,d are angular momenta. Otherwise,
    #   an error occurs.
    #
    # ARGUMENTS
    # * pdosFiles -- explicit list of projwfc.x filpdos pdos_atm files
    # * fileout   -- name of the output file where to write the summed PDOSes
    #
    # RETURN VALUE
    #   The value of the "fileout" argument.
    #
    # SOURCE

    ::pwtk::print "Summing PDOSes (all components separately) from files:"
    foreach f $pdosFiles {
        ::pwtk::print "   $f"
    }
    ::pwtk::print " "

    set outID [open $fileout w]
    
    set kresolved 0    
    set n_ik_E 8; # the length of "[ik] E" fields (ik field is optional)
    set nspin 1
    set last -1

    foreach f $pdosFiles {
        ::pwtk::fileMustExist $f "projwfc.x pdos_atm"
        set fid($f) [open $f r]

        # read the 1st line from all the files
        
        gets $fid($f) line($f)
        set len [llength $line($f)]

        # kresolved mode?
        
        if { [lindex $line($f) 1] == "ik" } {
            set kresolved 1
            set n_ik_E 14; # 8 + 5 + 1
        }

        # spin-polarized?
        if { [lindex $line($f) 3+$kresolved] == "ldosup(E)" || [lindex $line($f) 3+$kresolved] == "pdosup(E)" } {
            set nspin 2
        }

        # check that all the files have the same number of fields
        
        if { $last < 0 } {
            set last $len
            puts $outID $line($f)
        } elseif { $len != $last } {
            ::pwtk::error "pdos_atm files $pdosFiles do not contain the same number of fields; cannot sum orbital contributions" 1
        }
        set last $len
    }
    # due to "#" and "(eV)"  fields, $len == nfields+2, 
    incr len -2

    if { $kresolved } {
        ::pwtk::print "PDOSes are k-resolved"
    }
    if { $nspin > 1 } {
        ::pwtk::print "PDOSes are spin-polarized"
    }
        
    set eof 0
    while { ! $eof } {
        for {set i 1} {$i < $len} {incr i} {
            set pdos($i) 0.0
        }
        foreach f $pdosFiles {
            set ik_E [read $fid($f) $n_ik_E]
            if { [eof $fid($f)] } {
                set eof 1
                break
            }
            for {set i 1} {$i < $len} {incr i} {
                if { [catch {set pdos($i) [expr $pdos($i) + [read $fid($f) 11]]} err] } {
                    ::pwtk::error "error reading file $f\n$err" 1
                }
            }
            # read EOL 
            read $fid($f) 1
        }
        if { ! $eof } {
            puts -nonewline $outID [format %${n_ik_E}s $ik_E]
            for {set i 1} {$i < $len} {incr i} {
                puts -nonewline $outID [format %11.3E $pdos($i)]            
            }
            puts $outID ""
        }
    }
    
    # close the files
    foreach f $pdosFiles {
        close $fid($f)
    }
    close $outID

    ::pwtk::print "Summed PDOS written to :   $fileout\n"
    return $fileout
}
#******


#****if* Internals/::pwtk::pdos_spin
# SYNOPSIS
proc ::pwtk::pdos_spin {pdosFile} {
    # DESCRIPTION
    #    Query if $pdosFile corresponds to spin-polarized case.
    #
    # RETURN VALUE
    # 1 -- if spin-polarized
    # 0 -- otherwise
    #
    # SOURCE
    
    ::pwtk::fileMustExist $pdosFile PDOS
    
    set fid [open $pdosFile r]
    gets $fid line
    close $fid

    # format of projwfc.x pdos_atm header:
    #
    #   # [ik] E   (eV) ldosup(E) ldosdw(E) ...
    #   1 [k]  2+k 3+k  4+k       5+k
    #
    # format sumpdos.x header:
    #
    #   # [ik] E   (eV) pdosup(E) pdosdw(E) ...
    #   1 [k]  2+k 3+k  4+k       5+k
    
    set spin 0
    set kresolved 0
    if { [lindex $line 1] == "ik" } {
        set kresolved 1
    }
    if { [lindex $line 3+$kresolved] == "ldosup(E)" || [lindex $line 3+$kresolved] == "pdosup(E)" } {
        set spin 1
    }
    return $spin
}
#******


#****if* Internals/::pwtk::pdos_kresolved
# SYNOPSIS
proc ::pwtk::pdos_kresolved {pdosFile} {
    # DESCRIPTION
    #    Query if $pdosFile is k-resolved
    #
    # RETURN VALUE
    # 1 -- if k-resolved
    # 0 -- otherwise
    #
    # SOURCE
    
    ::pwtk::fileMustExist $pdosFile PDOS
    
    set fid [open $pdosFile r]
    gets $fid line
    close $fid
    
    set kresolved 0
    if { [lindex $line 1] == "ik" } {
        set kresolved 1
    }
    return $kresolved
}
#******


#****f* PDOS/::pwtk::orbitalGroup
# SYNOPSIS
proc ::pwtk::orbitalGroup {name combination} {
    # DESCRIPTION
    #   Define new combinations of orbitals to be use for PDOS plots.
    #
    # ARGUMENTS
    # * name -- name of the new orbital-combination
    # * combination -- combination of orbitals
    #
    # EXAMPLE
    #   orbitalGroup t2g {dxy + dxz + dyz}
    #
    # SOURCE
    variable orbitalGroup

    set name [normalize_orbital_expr_ $name]
    
    if { [info exists orbitalGroup($name)] } {
        print "Overwriting the definition of the \"$name\" group orbital
   current value :   $name = $orbitalGroup($name)
       new value :   $name = $combinatioin
"
    }
    set orbitalGroup($name) $combination
}
#******


#****f* PDOS/::pwtk::ldos_multiplot
# SYNOPSIS
proc ::pwtk::ldos_multiplot {args} {
    # USAGE
    #   ::pwtk::ldos_multiplot  ?SPECIFIC-OPTIONS?  ?PLOTTING-OPTIONS?  PDOSFILE_LLIST  ?HEAD?
    #
    #   where SPECIFIC-OPTIONS are:
    #
    #       -e  E_FERMI|PWO_FILE
    #       -o  ORIENT
    #       -nx NX
    #       -np NP
    #
    #   For PLOTTING-OPTIONS, see: ::pwtk::plot.
    #   Ignored PLOTTING-OPTIONS: -u
    #
    #   A more detailed description of SPECIFIC-OPTIONS and ARGUMENTS is provided below.
    #
    # DESCRIPTION
    #   Visualize specified LDOSes as a "multiplot" with aid of Gnuplot.
    #
    # SPECIFIC OPTIONS
    # * -e EFERMI  --- Fermi energy (either a floating-point number or a pw.x output file from where to grep the Fermi energy)
    # * -o ORIENT  --- page orientation for EPS (default = portrait); if -s is specified, this option is ignored
    # * -nx NUMBER --- number of plots per row
    # * -np NUMBER --- number of plots per page
    #
    # PLOTTING OPTIONS
    #   See ::pwtk::plot
    #
    # ARGUMENTS
    # * PDOSFILE_LLIST -- list of lists of projwfc.x PDOS files (or their sum generated with ::pwtk::sumldos)
    # * HEAD -- (optional, default = multiplot-X, X = integer) rootname for the generated plot files: $HEAD.gp and, for file terminals, $HEAD.EXT, where EXT = image type
    #
    # The structure of the PDOSFILE_LLIST list-of-lists is the following:
    # 
    #      set PDOSFILE_LLIST {
    #          {pdosFile1 pdosFile2}
    #          {pdosFileX pdosFileY pdosFileZ}
    #          pdosFileW
    #      }
    #
    # For each list element in PDOSFILE_LLIST, a plot is generated. Hence,
    # the number of generated plots is [llength $PDOSFILE_LLIST]. For the
    # above example, three LDOS plots are created. The 1st plot
    # displays the LDOSes for pdosFile1 and pdosFile2, the 2nd plot
    # displays the LDOSes for pdosFileX, pdosFileY, and pdosFileZ, etc.
    #
    # RETURN VALUE
    #   Filename of the created image (for file terminals) or
    #   the empty string (for window terminals).
    #
    # SOURCE

    set xdos LDOS
    set mode multi
    printTitle $xdos "Multiplot $xdos plotting"        
    print "Options & arguments :  $args\n"

    # parse command-line options & initialize plotting

    set arguments "PDOSFILE_LLIST  ?HEAD?"
    xdosParseOpts_initPlot_

    #
    # make an LDOS plot for each list element in $pdosLL
    #
    
    set ith 0
    set ipage 1
    foreach pdosL $pdosLL {
        set plot {}

        #
        # filledcurves
        #
        if { $dos_fill } {
            set lt 1
            foreach pdos $pdosL {
                set kres [pdos_kresolved $pdos]
                set spin [pdos_spin $pdos]
                set Ei   [expr 1 + $kres]
                set Yi   [expr 2 + $kres]
                append plot "     '$pdos' u (\$$Ei-Efermi):(\$$Ei-Efermi <= 0.0 ? \$$Yi : 0/0) not w filledcurve y1=0.0 lt $lt, \\\n"
                
                if { $spin } {
                    set Yi [expr 3 + $kres]
                    append plot "     '$pdos' u (\$$Ei-Efermi):(\$$Ei-Efermi <= 0.0 ? -\$$Yi : 0/0) not w filledcurve y1=0.0 lt $lt, \\\n"
                }
                incr lt
            }
            append plot "    \\\n"
        }

        #
        # lines
        #
        set lt 1
        foreach pdos $pdosL {
            set kres [pdos_kresolved $pdos]
            set spin [pdos_spin $pdos]
            set Ei   [expr 1 + $kres]
            set Yi   [expr 2 + $kres]
            if { $lt > 1 } {
                append plot ", \\\n"
            }
            append plot "     '$pdos' u (\$$Ei-Efermi):(\$$Yi) t '$pdos' w l lt $lt lw 2"            
            if { $spin } {
                set Yi [expr 3 + $kres]
                append plot ", \\
     '$pdos' u (\$$Ei-Efermi):(-\$$Yi) not w l lt $lt lw 2"
            }
            incr lt
        }
        $gp plot $plot
    }

    return [::pwtk::gp::execDisplay_ $gp opt]
}
#******


#****f* PDOS/::pwtk::pdos_multiplot
# SYNOPSIS
proc ::pwtk::pdos_multiplot {args} {
    # USAGE
    #   ::pwtk::pdos_multiplot  ?SPECIFIC-OPTIONS?  ?PLOTTING-OPTIONS?  PDOSFILE_ORBITAL_LLIST  ?HEAD?
    #
    #   where SPECIFIC-OPTIONS are:
    #
    #       -e  E_FERMI|PWO_FILE
    #       -o  ORIENT
    #       -nx NX
    #       -np NP
    #
    #   For PLOTTING-OPTIONS, see: ::pwtk::plot.
    #   Ignored PLOTTING-OPTIONS: -u
    #
    #   A more detailed description of SPECIFIC-OPTIONS and ARGUMENTS is provided below.
    #
    # DESCRIPTION
    #   Visualize specified PDOS components as a "multiplot" with aid of Gnuplot.
    #
    # SPECIFIC OPTIONS
    # * -e EFERMI  --- Fermi energy (either a floating-point number or a pw.x output file from where to grep the Fermi energy)
    # * -o ORIENT  --- page orientation for EPS (default = portrait); if -s is specified, this option is ignored
    # * -nx NUMBER --- number of plots per row
    # * -np NUMBER --- number of plots per page
    #
    # PLOTTING OPTIONS
    #   See ::pwtk::plot
    #
    # ARGUMENTS
    # * PDOSFILE_ORBITAL_LLIST -- list of lists of projwfc.x PDOS files and
    #                             the corresponding orbital-expressions (see below)
    # * HEAD -- (optional, default = multiplot-X, X = integer) rootname for the generated plot files: $HEAD.gp and, for file terminals, $HEAD.EXT, where EXT = image type
    #
    # The structure of the PDOSFILE_ORBITAL_LLIST list-of-lists is the following:
    #
    #    set PDOSFILE_ORBITAL_LLIST {
    #          { pdosFile1 orbitalExpression1
    #            pdosFile2 orbitalExpression2
    #            ...       ...
    #          }
    #          {
    #            pdosFileX orbitalExpressionX
    #            ...       ...
    #          }
    #          ...
    #    }
    #
    # |html <b>EXAMPLE</b>
    #
    #    set PDOSFILE_ORBITAL_LLIST {
    #        {
    #            pdosFile1 {pz + px - 2*pz}
    #            pdosFile2 {dxy + dxz + dyz - dx2-y2 - dz2}
    #        }
    #        {
    #            pdosFileX px
    #            pdosFileX py
    #            pdosFileX pz
    #         }
    #         {
    #            pdosFileW {px + py + pz}
    #         }
    #    }
    #    ::pwtk::pdos_multiplot $PDOSFILE_ORBITAL_LLIST pdos-example
    #
    # For each list element in $PDOSFILE_ORBITAL_LLIST, a plot is generated. Hence,
    # the number of generated plots is [llength $PDOSFILE_ORBITAL_LLIST]. For the
    # above example, three PDOS plots are created. The 1st plot
    # displays the PDOSes for pdosFile1 and pdosFile2, the 2nd plot
    # displays the PDOSes for pdosFileX, pdosFileY, and pdosFileZ, etc.
    #
    # |html <b>THE SYNTAX OF ORBITAL EXPRESSIONS</b>
    #
    # Orbital expressions are simple mathematical expressions
    # |html involving <b>orbital labels</b>, defined in the ::pwtk::obitalIndex
    # array (i.e. ldos, s, px,py,pz, dxy,dxz,dxy,dx2y2,dz2), where
    # ldos stands for the sum of all components present in the PDOS
    # file. Here is an example of the orbital expression: 
    #
    #    s + 0.5*(px + py)
    #
    # |html In addition to orbital labels, also <b>group-orbitals</b>
    # can be used as defined in the ::pwtk::obitalGroup array. New
    # group-orbitals can be defined with the ::pwtk::orbitalGroup
    # command.    
    #
    # Note that options are optional and any number of them can be specified.
    #    
    # RETURN VALUE
    #   Filename(s) of the created image(s) (for file terminals) or
    #   the empty string (for window terminals).
    #
    # SOURCE

    set xdos PDOS
    set mode multi
    printTitle $xdos "Multiplot $xdos plotting"
    print "Options & arguments :  $args\n"

    # parse command-line options & initialize plotting
    set arguments "PDOSFILE_ORBITAL_LLIST  ?HEAD?"
    xdosParseOpts_initPlot_

    #
    # make a PDOS plot for each list element in $pdosLL
    #
    
    set ith 0
    set ipage 1
    foreach pdosL $pdosLL {
        set plot {}

        #
        # filledcurves
        #
        if { $dos_fill } {
            set lt 1
            foreach {pdos orbExpr} $pdosL {
                set kres [pdos_kresolved $pdos]
                set spin [pdos_spin $pdos]
                set Ei   [expr 1 + $kres]
                set using [gp_using_ $kres $spin $orbExpr up_i_]

                append plot "     '$pdos' u (\$$Ei-Efermi):(\$$Ei-Efermi <= 0.0 ? $using : 0/0) not w filledcurve y1=0.0 lt $lt, \\\n"
            
                if { $spin } {
                    set using [gp_using_ $kres $spin $orbExpr dw_i_]
                    append plot "     '$pdos' u (\$$Ei-Efermi):(\$$Ei-Efermi <= 0.0 ? -1*($using) : 0/0) not w filledcurve y1=0.0 lt $lt, \\\n"
                } 
                incr lt
            }
            append plot "    \\\n"
        }

        #
        # lines
        #   
        set lt 1
        foreach {pdos orbExpr} $pdosL {
            set kres [pdos_kresolved $pdos]
            set spin [pdos_spin $pdos]
            set Ei   [expr 1 + $kres]
            set using [gp_using_ $kres $spin $orbExpr up_i_]
            set orb   [regsub -all { +} $orbExpr {}]; # condensed orbital expression
            if { $lt > 1 } {
                append plot ", \\\n"
            }
            set title "$orb ($pdos)"
            append plot "     '$pdos' u (\$$Ei-Efermi):($using) t '$title' w l lt $lt lw 2"
            
            if { $spin } {
                set using [gp_using_ $kres $spin $orbExpr dw_i_]
                append plot ", \\
     '$pdos' u (\$$Ei-Efermi):(-1*($using)) not w l lt $lt lw 2"
            }
            incr lt
        }
        $gp plot $plot
    }

    return [::pwtk::gp::execDisplay_ $gp opt]
}
#******


#****f* PDOS/::pwtk::pdos_plot
# SYNOPSIS
proc ::pwtk::pdos_plot {args} {
    # USAGE
    #   ::pwtk::pdos_plot  ?SPECIFIC-OPTIONS?  ?PLOTTING-OPTIONS?  PDOSFILE_ORBITAL_LIST  ?HEAD?
    #
    #   where SPECIFIC-OPTIONS are:
    #
    #       -e  E_FERMI|PWO_FILE
    #       -o  ORIENT
    #
    #   For PLOTTING-OPTIONS, see: ::pwtk::plot.
    #   Ignored PLOTTING-OPTIONS: -u
    #
    #   A more detailed description of SPECIFIC-OPTIONS and ARGUMENTS is provided below.
    #
    # DESCRIPTION
    #   Visualize the specified PDOS components as a "single-plot" with aid of Gnuplot.
    #
    # SPECIFIC OPTIONS
    #   See ::pwtk::pdos_multiplot
    #
    # PLOTTING OPTIONS
    #   See ::pwtk::plot
    #
    # ARGUMENTS
    # * PDOSFILE_ORBITAL_LIST -- list of projwfc.x PDOS files and the corresponding 
    #                            orbital-expressions (see below)
    # * HEAD -- (optional, default = plot-X, X = integer)) rootname for the generated plot files: $HEAD.gp and, for file terminals, $HEAD.EXT, where EXT = image type
    #
    # The structure of the PDOSFILE_ORBITAL_LIST list is the following:
    #
    #    set PDOSFILE_ORBITAL_LIST {
    #           pdosFile1 orbitalExpression1
    #           pdosFile2 orbitalExpression2
    #           pdosFile3 orbitalExpression3
    #           ...       ...
    #    }
    #
    # EXAMPLE    
    #    set PDOSFILE_ORBITAL_LIST {
    #           pdosFile1 {px + py - 2*pz}
    #           pdosFile2 {dxy + dxz + dyz - dx2-y2 - dz2}
    #           pdosFile3 px
    #    }
    #    ::pwtk::pdos_plot $PDOSFILE_ORBITAL_LIST pdos-example
    #
    # EXPLANATION
    # With the above example, each "file orbitalExpression" pair in
    # $PDOSFILE_ORBITAL_LIST is plotted, implying that three PDOSes
    # are plotted: the first corresponds to px+py-2*pz orbital
    # combination, the second to specified combination of d orbitals,
    # and the third to the px orbital.
    #
    # |html <b>THE SYNTAX OF ORBITAL EXPRESSIONS</b>
    #
    # Orbital expressions are simple mathematical expressions
    # |html involving <b>orbital labels</b>, defined in the ::pwtk::obitalIndex
    # array (i.e. ldos, s, px,py,pz, dxy,dxz,dxy,dx2y2,dz2), where
    # ldos stands for the sum of all components present in the PDOS
    # file.
    #
    # |html In addition to orbital labels, also <b>group-orbitals</b>
    # can be used as defined in the ::pwtk::obitalGroup array. New
    # group-orbitals can be defined with the ::pwtk::orbitalGroup
    # command.    
    #
    # RETURN VALUE
    #   Filename of the created image (for file terminals) or
    #   the empty string (for window terminals).
    #
    # SOURCE

    set xdos PDOS
    set mode single
    printTitle "$xdos plotting"        
    print "Options & arguments :  $args\n"
    
    # parse command-line options & initialize plotting
    set arguments "PDOSFILE_ORBITAL_LIST  ?HEAD?"
    xdosParseOpts_initPlot_
    
    # make a PDOS plot for each list element in $pdosLL    
    
    #
    # filledcurves
    #
    if { $dos_fill } {
        set lt 1
        foreach {pdos orbExpr} $pdosLL {
            set kres [pdos_kresolved $pdos]
            set spin [pdos_spin $pdos]
            set Ei   [expr 1 + $kres]     
            set using [gp_using_ $kres $spin $orbExpr up_i_]
            
            append plot "     '$pdos' u (\$$Ei-Efermi):(\$$Ei-Efermi <= 0.0 ? $using : 0/0) not w filledcurve y1=0.0 lt $lt, \\\n"

            if { $spin } {
                set using [gp_using_ $kres $spin $orbExpr dw_i_]
                append plot "     '$pdos' u (\$$Ei-Efermi):(\$$Ei-Efermi <= 0.0 ? -1*($using) : 0/0) not w filledcurve y1=0.0 lt $lt, \\\n"
            }
            incr lt
        }
        append plot "    \\\n"
    }

    #
    # lines
    #   
    set lt 1
    foreach {pdos orbExpr} $pdosLL {
        set kres [pdos_kresolved $pdos]
        set spin [pdos_spin $pdos]
        set Ei   [expr 1 + $kres]
        set using [gp_using_ $kres $spin $orbExpr up_i_]
        set orb   [regsub -all { +} $orbExpr {}]; # condensed orbital expression
        if { $lt > 1 } {
            append plot ", \\\n"
        }
        set title "$orb ($pdos)"
        append plot "     '$pdos' u (\$$Ei-Efermi):($using) t '$title' w l lt $lt lw 2"
            
        if { $spin } {
            set using [gp_using_ $kres $spin $orbExpr dw_i_]
            append plot ", \\
     '$pdos' u (\$$Ei-Efermi):(-1*($using)) not w l lt $lt lw 2"
        }
        incr lt
    }
    $gp plot $plot

    return [::pwtk::gp::execDisplay_ $gp opt]
}
#******


#****f* PDOS/::pwtk::ldos_plot
# SYNOPSIS
proc ::pwtk::ldos_plot {args} {
    # USAGE
    #   ::pwtk::ldos_plot  ?SPECIFIC-OPTIONS?  ?PLOTTING-OPTIONS?  PDOSFILE_LIST  ?HEAD?
    #
    #   where SPECIFIC-OPTIONS are:
    #
    #       -e  E_FERMI|PWO_FILE
    #       -o  ORIENT
    #
    #   For PLOTTING-OPTIONS, see: ::pwtk::plot.
    #   Ignored PLOTTING-OPTIONS: -u
    #
    #   A more detailed description of SPECIFIC-OPTIONS and ARGUMENTS is provided below.
    #
    # DESCRIPTION
    #   Visualize the specified LDOSes as a "single-plot" with aid of Gnuplot.
    #
    # SPECIFIC OPTIONS
    #   See ::pwtk::ldos_multiplot
    #
    # PLOTTING OPTIONS
    #   See ::pwtk::plot
    #
    # ARGUMENTS
    # * PDOSFILE_LIST -- list of projwfc.x PDOS files (or their sum generated with ::pwtk::sumldos)
    # * HEAD -- (optional, default = plot-X, X = integer) rootname for the generated plot files: $HEAD.gp and, for file terminals, $HEAD.EXT, where EXT = image type
    #
    # The PDOSFILE_LIST is a plain list consisting of PDOS files, i.e.:
    # 
    #      set PDOSFILE_LIST {
    #          pdosFile1 pdosFile2 pdosFile3 ...
    #      }
    #
    # For each file in the list, the LDOS will be plotted in a "single-plot".
    #
    # RETURN VALUE
    #   Filename of the created image (for file terminals) or
    #   the empty string (for window terminals).
    #
    # SOURCE

    set xdos LDOS
    set mode single
    printTitle "$xdos plotting"
    print "Options & arguments :  $args\n"
    
    # parse command-line options & initialize plotting
    set arguments "PDOSFILE_LIST  ?HEAD?"
    xdosParseOpts_initPlot_
    
    # make an LDOS plot for file in $pdosLL

    #
    # filledcurves
    #
    if { $dos_fill } {
        set lt 1
        foreach pdos $pdosLL {
            set kres [pdos_kresolved $pdos]
            set spin [pdos_spin $pdos]
            set Ei   [expr 1 + $kres]        
            set Yi   [expr 2 + $kres]
            append plot "     '$pdos' u (\$$Ei-Efermi):(\$$Ei-Efermi <= 0.0 ? \$$Yi : 0/0) not w filledcurve y1=0.0 lt $lt, \\\n"            
            if { $spin } {
                set Yi [expr 3 + $kres]
                append plot "     '$pdos' u (\$$Ei-Efermi):(\$$Ei-Efermi <= 0.0 ? -\$$Yi : 0/0) not w filledcurve y1=0.0 lt $lt, \\\n"
            }
            incr lt
        }
        append plot "    \\\n"
    }

    #
    # lines
    #
    set lt 1
    foreach pdos $pdosLL {
        set kres [pdos_kresolved $pdos]
        set spin [pdos_spin $pdos]
        set Ei   [expr 1 + $kres]
        set Yi   [expr 2 + $kres]
        if { $lt > 1 } {
            append plot ", \\\n"
        }
        append plot "     '$pdos' u (\$$Ei-Efermi):(\$$Yi) t '$pdos' w l lt $lt lw 2"            
        if { $spin } {
            set Yi [expr 3 + $kres]
            append plot ", \\
     '$pdos' u (\$$Ei-Efermi):(-\$$Yi) not w l lt $lt lw 2"
        }
        incr lt
    }
    $gp plot $plot
    
    return [::pwtk::gp::execDisplay_ $gp opt]
}
#******



# internal...
proc ::pwtk::xdosParseOpts_initPlot_ {} {
    # PURPOSE
    #   Parse command-line options & initialize plotting.
    
    uplevel 1 {
        #
        # parse options & arguments
        #

        ::pwtk::gp::defaultCmdlineOpts_ plot options usage workflow

        ignoredOpts_ -u $args
        
        addOpts_ options usage {
            {e.arg  {}   "Fermi energy (either a floating-point number or a pw.x output file from where to grep the Fermi energy"}
            {o.arg  {}   "paper orientation (portrait, landscape)"}
            {nx.arg -1   "number of plots per row"}
            {np.arg -1   "number of plots per page"}
        } {
            {-e EFERMI} {-o ORIENT} {-nx NX} {-np NP}
        }
        
        setOpts_ options [subst {
            rm  1
            tm  0.9
            bm  3.1
            xl  {\{/${::pwtk::gp::gp(font)}-Italic E\} − \{/${::pwtk::gp::gp(font)}-Italic E\}_F (eV)}
            yl  {$xdos}
            xr  :
            yr  :
        }]

        if { $mode eq "single" } {
            deleteOpts_ options usage -nx -np
        }
        set nargmin 1
        set nargmax 2
        set usage "[fmtUsage_ $usage]  $arguments"
        parseOpt_
        ::pwtk::gp::checkCmdlineOpts_ opt
        
        #if { [llength $args] != 2 } {
        #    ::pwtk::error "wrong # args: should be \"${xdos}_multiplot ?OPTIONS?  $arguments\"" 1
        #}
        
        set pdosLL [lindex $args 0]
        set head   [lindex $args 1]
        set npdos  [llength $pdosLL]

        if { $head eq {} } {
            set type [expr { $mode eq "single" ? "plot" : "multiplot" }]
            set id [incr ::pwtk::gp::${type}_id]
            set head ${type}-$id
        }
        if { $mode == "single" } {
            set npdos 1
        } else {
            checkOTypeStrict_ -nx  $opt(nx) integer
            checkOTypeStrict_ -np  $opt(np) integer
        }
        
        set spin [pdos_spin [lindex [lindex $pdosLL 0] 0]]; # OK for LDOS & PDOS
        set spinOpt [expr { $spin ? "-spin" : "" }]

        # -e 
        if { [file exists $opt(e)] } {
            # pwoFile
            set einfo "Fermi energy was taken from the \"$opt(e)\" file\n"
            set opt(e) [::pwtk::pwo::efermi $opt(e)]
            set dos_fill 1
            if { ! [string is double -strict $opt(e)] } {
                ::pwtk::warning "failed to get the Fermi energy (or highest occupied level) from the '$opt(e) file"
                set einfo {}
                set opt(xl)  {Energy (eV)}
                set opt(e)   0.0
                set dos_fill 0
            }
        } else {
            # number or empty string ?
            checkOType_ -e $opt(e) double "number or an existing pw.x output file"
            set einfo "Fermi energy was specified on the command line\n"
            set dos_fill 1
            ifempty opt(e)  {
                set einfo   {}
                set opt(xl) {Energy (eV)}
                set opt(e)  0.0
                set dos_fill 0
            }
        }

        # -yf
        if { $opt(yf) eq {} } {
            if { $xdos == "LDOS" } {
                set opt(yf) %2.0f
            } else {
                set opt(yf) %3.1f
            }
        }
        
        # -lm
        if { $opt(lm) eq {} } {
            if { $xdos == "LDOS" } {                
                set opt(lm) 6
            } else {
                set opt(lm) 7
            }
        }

        # -t (TODO: using 'term' is OK, but take care of default value for term)
        set term [::pwtk::gp::gp2pwtk [::pwtk::gp::term_usable $opt(t)]]

        # -o
        # -s 
        # orient
        set orient [::pwtk::gp::orient $opt(t) $opt(s) $opt(o)]        

        #
        # create Gnuplot object
        #
        
        if { $mode eq "single" } {
            # ::pwtk::gp::plot options: -o -fs -s -t -p 
            set gp [::pwtk::gp::plot new -o $opt(o) -s $opt(s) {*}$spinOpt $head.$term]
            set fsize $::pwtk::gp::gp(fontSize)
        } else {
            set gp [::pwtk::gp::multiplot new -o $opt(o) -s $opt(s) {*}$spinOpt auto $npdos $opt(np) $opt(nx) $head.$term]
            array set mp [::pwtk::gp::multiplot_array $npdos $opt(np) $opt(nx) $orient $spin]; # needed for printout
            set fsize $mp(fsize)
        }

        # fine-tuning configuration
        set ypad [xlabel_yoffset_ $opt(t)]

        if { $xdos == "LDOS" } {
            set reverse {Left reverse}
            set size [expr round(0.9*$fsize)]
        } else {
            set reverse {Left reverse}
            set size [expr round(0.85*$fsize)]
        }            
        set font $::pwtk::gp::gp(font),$size

        # set Gnuplot options        
        $gp cmdlineOpts opt
        $gp options "
xlabel {offset 0,$ypad}
ylabel {offset 0.5}
key    {top left $reverse samplen 1 noenhanced font '$font'}
"
        $gp add "Efermi = $opt(e)"

        
        #
        # printout
        #
        
        set multiInfo ""
        if { $mode eq "multi" } {
            set multiInfo "
Number of plots: $npdos
Number of pages: $mp(pp)
Maximum number of plots per page: [expr $mp(nx)*$mp(ny)]
Average number of plots per page: $mp(np)
Plots will be arranged in $mp(nx) x $mp(ny) matrix layout
Plots will be output to: [string toupper $term]
"
        }
        set fermi_ [expr { $einfo eq {} ? "Fermi energy not set" : "${einfo}Fermi energy = $opt(e) eV" }]
        print "Basic $xdos plotting info:
$multiInfo
$fermi_
plot xrange  = \[$opt(xr)\]
plot yrange  = \[$opt(yr)\]
"
        print "The following ${xdos}es will be ploted:\n"
        
        if { $mode == "multi" } {
            set ind 1
            foreach pdosL $pdosLL {
                if { $xdos == "PDOS" } {
                    # check that # of elements is even
                    if { [llength $pdosL]%2 } {
                        ::pwtk::error "wrong format of \"pdosFile orbitalExpression\" specs in PDOSFILE_ORBITAL_LLIST\nfor PDOS #.$ind. Number of list elements must be even, but got:\n$pdosL" 1
                    }
                    print "* $xdos [format %5s [format #.%d: $ind]]"
                    foreach {fil orbExpr} $pdosL {
                        fileMustExist $fil PDOS
                        set kres [pdos_kresolved $fil]
                        set spin [pdos_spin $fil]
                        print "    file: $fil  \[k-resolved = $kres, spin-pol = $spin\]"
                        print "          - parsed orbital-expression: [normalize_orbital_expr_ $orbExpr]"
                        if { $spin } {
                            print "          - used column(s) for pdosup: [gp_using_ $kres $spin $orbExpr up_i_]"
                            print "          - used column(s) for pdosdw: [gp_using_ $kres $spin $orbExpr dw_i_]"
                        } else {
                            print "          - used column(s): [gp_using_ $kres $spin $orbExpr up_i_]"
                        }
                    }
                } else {
                    foreach pdos $pdosL {
                        fileMustExist $pdos PDOS
                    }
                    print "$xdos [format %5s [format #.%d: $ind]]   [join $pdosL]"
                }
                incr ind
            }
            print " "
        } else {
            # single-plot
            set ind 1
            if { $xdos == "LDOS" } {
                foreach pdos $pdosLL {
                    print "$xdos [format %5s [format #.%d: $ind]]   $pdos"
                    incr ind
                }
                print " "
            } else {
                # check that # of elements is even
                if { [llength $pdosLL]%2 } {
                    ::pwtk::error "wrong format of \"pdosFile orbitalExpression\" specs in PDOSFILE_ORBITAL_LIST\n. Number of list elements must be even, but got:\n$pdosL" 1
                }
                foreach {fil orbExpr} $pdosLL {
                    fileMustExist $fil PDOS
                    set kres [pdos_kresolved $fil]
                    set spin [pdos_spin $fil]
                    print "   file: $fil  \[k-resolved = $kres, spin-pol = $spin\]"
                    print "         - parsed orbital-expression: [normalize_orbital_expr_ $orbExpr]"
                    if { $spin } {
                        print "         - used column(s) for pdosup: [gp_using_ $kres $spin $orbExpr up_i_]"
                        print "         - used column(s) for pdosdw: [gp_using_ $kres $spin $orbExpr dw_i_]"
                    } else {
                        print "         - used column(s): [gp_using_ $kres $spin $orbExpr up_i_]"
                    }
                    print " "
                    incr ind
                }
            }
        }
    }    
}



# ------------------------------------------------------------------------
#
# from here on, only internal procs...
#
# ------------------------------------------------------------------------


#------------------------------------------------------------------------
# INFO for ::pwtk::up_i_ & ::pwtk::dw_i_
#
# Format of no-spin pdos_atm files:
#
# E (eV) ldos(E) pdos1(E) pdos2(E) ...
# 1      2       3        4
#
# pdos(i) = kresolved + 2 + i
#
# Format of spin-pol pdos_atm files
#
# E (eV) ldosup(E) ldosdn(E) pdos1up(E) pdos1dn(E) pdos2up(E) pdos2dn(E) ...
# 1      2         3         4          5          6          7
#
# pdosup(i) = kresolved + 3 + 2*i -1
# pdosdn(i) = kreselved + 3 + 2*i
#
# Format of k-resolved: +1 field !
#
# ik E (eV) ...
# 1  2 ...
#------------------------------------------------------------------------

#*** internal...
proc ::pwtk::up_i_ {kresolved spin orbIndex} {
    # PURPOSE
    #   Returns the field-index of orbIndex spin-up projection in projwfc.x pdos_atm file.
    #
    # ARGUMENTS    
    # ARGUMENTS    
    # * kresolved = 0 (not k-resolved)
    #               1 (k-resolved)
    #
    # * spin      = 0 (unpolarized, aka nspin = 1)
    #               1 (polarized, aka nspin=2)
    #
    # * orbIndex  --- sequential index of orbital according to projwfc.x
    #                 (see: ::pwtk::orbitalIndex)

    if { $spin } {
        return [expr $kresolved + 3 + 2*$orbIndex - 1]
    } else {
        return [expr $kresolved + 2 + $orbIndex]
    }
}

#*** internal...
proc ::pwtk::dw_i_ {kresolved spin orbIndex} {
    # PURPOSE
    #   Returns the field-index of orbIndex spin-dn projection in projwfc.x pdos_atm file.
    #   For spin-unpolarized, gives the same result as ::pwtk::up_i_.
    #
    # ARGUMENTS    
    # * kresolved = 0 (not k-resolved)
    #               1 (k-resolved)
    #
    # * spin      = 0 (unpolarized, aka nspin = 1)
    #               1 (polarized, aka nspin=2)
    #
    # * orbIndex  --- sequential index of orbital according to projwfc.x
    #                 (see: ::pwtk::orbitalIndex)

    if { $spin } {
        return [expr $kresolved + 3 + 2*$orbIndex]
    } else {
        return [expr $kresolved + 2 + $orbIndex]
    }
}

#*** internal...
proc ::pwtk::normalize_orbital_expr_ {orbExpr} {
    # PURPOSE
    #   Returns a "normalized" orbital-expression
    
    # trim _ ^ { } characters and replace dx2-y2 with dx2y2
    set orbExpr [regsub -all dx2\-y2 [regsub -all {[_^\{\}]} $orbExpr {}] dx2y2]

    # add spaces around +, -, /, *, (, )
    set orbExpr [regsub -all {[\+\-\*\/\(\)]} $orbExpr { \0 }]
    # just one space around +, -, /, *
    return [string trim [regsub -all { +} $orbExpr { }]]
}

#*** internal...
proc ::pwtk::gp_using_ {kresolved spin orbExpr sCmd} {
    # PURPOSE
    #   Transforms orbital-expression into the "using" expression for the Gnuplot.
    #
    # ARGUMENTS
    # * kresolved --- aka [pdos_kresolved]
    # * spin      --- aka [pdos_spin]
    # * orbExpr   --- orbital-expression
    # * sCmd      --- up_i_ or dw_i_
    variable orbitalIndex
    variable orbitalGroup
    
    set orbExpr [normalize_orbital_expr_ $orbExpr]

    foreach c $orbExpr {
        if { [string is double -strict $c] } {
            # $c is a number?
            append using $c
        } elseif { [regexp {[\+\-\*\/\(\)]} $c] } {
            # $c is a primitive + - * / operator or parenthesis
            append using $c
        } elseif { [info exists orbitalGroup($c)] } {
            # $c is a defined group-of-orbitals, such as Eg & T2g
            append using [gp_using_ $kresolved $spin $orbitalGroup($c) $sCmd]            
        } elseif { [info exists orbitalIndex($c)] } {
            # $c is an orbital label
            append using "\$[$sCmd $kresolved $spin $orbitalIndex($c)]"
        } else {
            ::pwtk::error "unsupported character or unknown orbital \"$c\", must be one of [join [array names orbitalIndex] ,]" 1
        }
    }
    return $using
}


# internal...
proc ::pwtk::xlabel_yoffset_ {term} {
    # PURPOSE
    #   For *dos.tcl, xlabel is slightly shifted vertically
    set term [::pwtk::gp::term_usable $term]
    if { [::pwtk::gp::pwtk2gp $term] in $::pwtk::gp::gp(win.terminals) } {
        # win.terminals
        set ypad 0.5
    } else {
        # file.terminals || txt.terminals
        set ypad 0.25
    }
}
