#
# $RCSfile: lsf.tcl,v $ --
#
#      This file contains the implementation for the support for LSF
#      queueing system.
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: lsf.tcl,v 1.3 2021/05/01 19:23:20 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# PUBLIC procs
#
# ------------------------------------------------------------------------

# N.B. the ::pwtk::LSF and lsf_* commands are created dynamically
# by calling the ::pwtk::lsf::init command but they are documented here.

#****f* ::pwtk::lsf/::pwtk::LSF
#
# PURPOSE
# The master command for the LSF batch queuing. It manages the
# submission to LSF.
#
# USAGE
#     LSF { ...script code... }
#     LSF file.pwtk
# or
#     LSF options { ...script code... }
#     LSF options file.pwtk
# or
#     LSF profile ?options? { ...script code... }
#     LSF profile ?options? file.pwtk
#
# DESCRIPTION
# The above "profile" is a user defined profile for LSF, i.e., a set
# of "#BSUB" directives, whereas the above "options" are the LSF
# options, specified with the standard Tcl syntax of "-option value",
# i.e.:
#
#     -option1 value1  -option2  -option3 value3
# 
# Here is an example of the usage of the LSF command:
#
#    LSF -n 16 -W 24:00 { import job.pwtk }    (N.B. ...script code... version)
# or
#    LSF -n 16 -W 24:00 job.pwtk               (N.B. file.pwtk version)
#
# If "profile" is omitted, the "default" profile is used, which is
# guaranteed to exist because it is defined in the
# |html <a href="../config/lsf.tcl">$PWTK/config/lsf.tcl</a> file.
#
# Here is an example of two user defined profiles, named "parallel" and "long":
#
#     lsf_profile parallel {
#         #!/bin/sh
#         #BSUB -q parallel
#         #BSUB -n 8
#         #BSUB -W 6:00
#     }
#
#     lsf_profile long {
#         #!/bin/sh
#         #BSUB -q long
#         #BSUB -n 64
#         #BSUB -W 24:00
#     }
#

# It is a good practice to also define the PWTK specifics (aka
# pwtk_profile) associated with the LSF profiles. For example, for
# the above "long" profile with -n 64, it would be reasonable to use
# "mpirun -n 64" as a default. This can be achieved with:
#
#    lsf_pwtk_profile long { prefix mpirun -n 64 }
#
# There is also a compact version which defines the LSF profile and
# the associated PWTK profile simultaneously, i.e.:
#
#    lsf_profile long {
#         #!/bin/sh
#         #BSUB -q long
#         #BSUB -n 64
#         #BSUB -W 24:00
#    } {
#        prefix mpirun -n 64
#    }
#
# Here, the 2nd argument to the 'lsf_profile' command is the LSF
# profile and the last argument is the associated PWTK profile. This
# form is recommended because it avoid typos/mismatches between
# profile and pwtk_profile names.
#
# IMPORTANT
# A typical place where to store LSF profiles for frequent use is in
# the ~/.pwtk/lsf.tcl configuration file (N.B. in the ~/.pwtk/lsf.tcl
# configuration file, the prefix 'lsf_' can be omitted).
#
# FURTHER DESCRIPTION
# The 'lsf_profile' command can be used to define profiles on the
# fly within the PWTK script, e.g.:
#
#   lsf_profile n24 {
#         #!/bin/sh
#         #BSUB -n 24
#         #BSUB -W 12:00
#   } {
#        prefix mpirun -np 24
#   }
#
#   LSF n24 job.pwtk
#
# The final effect of the LSF command is to submit either the script
# code encapsulated inside the LSF { ... } command or the script
# file specified with the LSF command (e.g. LSF file.pwtk) to the
# LSF job scheduling system via the bsub command.
#
#******


#****f* ::pwtk::lsf/::pwtk::lsf_profile
# USAGE
#   ::pwtk::lsf_profile profileName profileSpecs ?pwtkSpecs?
#
# DESCRIPTION
#   Define a LSF "profile" within the PWTK script. See also ::pwtk::LSF.
#
#   Here is an example of how a new lsf profile can be defined and used:
#
#      lsf_profile n24 {
#         #!/bin/sh
#         #BSUB -q parallel
#         #BSUB -n 24
#         #BSUB -W 6:00
#      }
#
#      LSF n24 {
#         load_fromPWI scf.in
#         CONTROL { calculation = 'relax' }
#         IONS {}
#         runPW relax.in
#      }
#
# ARGUMENTS
# * profileName -- name of the profile
# * profileSpecs -- definition of the 'profileName' profile
# * pwtkSpecs -- definition of the PWTK profile to be used when
#                the 'profileName' LSF profile is used
#
# IMPORTANT
# A typical place where to store LSF profiles for frequent use is in
# the ~/.pwtk/lsf.tcl configuration file. Note that in the ~/.pwtk/lsf.tcl
# configuration file, the prefix 'lsf_' can be omitted.
#
# EXAMPLE
#    lsf_profile n24 {
#         #!/bin/sh
#         #BSUB -q parallel
#         #BSUB -n 24
#         #BSUB -W 6:00
#    } {
#       prefix mpirun -np 24
#    }
#******

#****f* ::pwtk::lsf/::pwtk::lsf_profileDefault
# USAGE
#   lsf_profileDefault profileName
# DESCRIPTION
#   Make the 'profileName' profile the default LSF profile.
#******

#****f* ::pwtk::lsf/::pwtk::lsf_pwtk_profile
# USAGE
#   lsf_pwtk_profile profileName pwtkSpecs
# DESCRIPTION
#   Define the PWTK profile named 'profileName' and associate it with
#   the LSF profile of the same name.
#
# EXAMPLE
#   lsf_pwtk_profile n24 {
#      prefix mpirun -n 24
#   }
#******

#****f* ::pwtk::lsf/::pwtk::lsf_pwtk_profileDefault
# USAGE
#   lsf_pwtk_profileDefault profileName
# DESCRIPTION
#   Make the pwtk 'profileName' profile the default PWTK profile for
#   LSF.
#******

#****f* ::pwtk::lsf/::pwtk::lsf_head
# USAGE
#   lsf_head { batch sh-script excerpt }
#
# EXAMPLE
#   lsf_head {
#      echo "Today is `date`"
#      module load qe-7.3
#   }
#
# DESCRIPTION
#   This command sets the "head" part of the LSF batch shell
#   script. In PWTK, the batch shell script is composed of four
#   parts:
#
#        profile   (always exists)
#         |
#        head      (optional)
#         |
#        pwtk      (always exists)
#         |
#        tail      (optional)
#
#   where:
#   * profile -- contains the batch-queue directives (e.g. #SBATCH);
#                it is set with lsf_profile command
#   * head -- contains optional shell commands that are executed
#             prior to executing PWTK, such as "module load ...";
#             it is set with lsf_head command
#   * pwtk -- in this part, the PWTK script is executed;
#             it is set internally by PWTK
#   * tail -- contains optional shell commands that are executed
#             after the PWTK script finishes;
#             it is set with lsf_tail command
#******

#****f* ::pwtk::lsf/::pwtk::lsf_tail
# USAGE
#   lsf_tail { batch sh-script excerpt }
#
# EXAMPLE
#   lsf_tail {
#      # copy the scratch files in WORKDIR to $PWD
#      cp -a $WORKDIR .
#   }
#
# DESCRIPTION
#   This command sets the "tail" part of the LSF batch shell
#   script. In PWTK, the batch shell script is composed of four parts
#   (for description, see ::pwtk::lsf_head).
#******

#****f* ::pwtk::lsf/::pwtk::lsf_clear
# USAGE
#   lsf_clear
# DESCRIPTION
#   Clear the current content of the LSF batch shell script as stored in PWTK.
#******

#****f* ::pwtk::lsf/::pwtk::lsf_fprint
# USAGE
#   lsf_fprint ?FILE?
# PURPOSE
#   Typically used intenally by PWTK.
# DESCRIPTION
#   Print the current content of the LSF batch shell script to FILE
#   or to stdout if FILE was not specified.
#******

#****f* ::pwtk::lsf/::pwtk::lsf_get
# USAGE
#   lsf_get ?profileName?
# PURPOSE
#   Typically used intenally by PWTK.
# DESCRIPTION
#   Return the current content of the LSF batch shell script.
#******


#****if* Internals/::pwtk::lsf::init
# SYNOPSIS
proc ::pwtk::lsf::init {} {
    # PURPOSE
    #    Used intenally by PWTK.
    # DESCRIPTION
    #    Initialization of handling of the LSF batch queuing system.
    # SOURCE

    ::pwtk::queue::init lsf bsub "#BSUB"
    optionParser none
}
#******


#****f* ::pwtk::lsf/::pwtk::lsf::optionParser
proc ::pwtk::lsf::optionParser {parser} {
    # USAGE
    #   ::pwtk::lsf::optionParser none
    # or
    #   ::pwtk::lsf::optionParser parse
    #
    # DESCRIPTION
    #   How to parse options specified on the LSF command-line. Possibilities are:
    #   * none -- do not parse options, but add them verbatim as the command-line options of the 'bsub' command
    #   * parse -- parse options and incorporate them into the Lsf batch script file
    #
    # SOURCE

    ::pwtk::queue::optionParser lsf $parser
}
#******


#****if Internals/::pwtk::lsf::addOptionsToCmdLine_
proc ::pwtk::lsf::addOptionsToCmdLine_ {profileName args} {
    # PURPOSE
    #   This routine has the same purpose as
    #   ::pwtk::lsf::addOptionsToBatchScript_ but instead of
    #   incorporating Lsf options specified on the LSF command
    #   line, contained in $args, into a batch script, it delegates
    #   them to the 'sbatch' command as the command-line
    #   options. Hence, this routine performs the following two tasks:   
    #   1. create the profile part of the batch script from the 'profileName' profile
    #   2. arranges for sbatch command to be called as: bsub {*}$args FILE
    #
    # ARGUMENTS
    # * profileName -- name of the LSF profile
    # * args -- command-line options specified on the LSF command line.
    #
    # SOURCE

    set ::pwtk::queue::queue(lsf,profile) [::pwtk::trimIndent [::pwtk::varvalue ::pwtk::queue::profile(lsf,$profileName)]]\n
    set ::pwtk::queue::queue(lsf,submitOpts) $args    
}
#******


#****if Internals/::pwtk::lsf::addOptionsToBatchScript_
proc ::pwtk::lsf::addOptionsToBatchScript_ {profileName args} {
    # PURPOSE
    #   Parse the LSF options stored in $args, and produce a LSF
    #   profile by merging them with the corresponding $profileName LSF
    #   profile. The result is stored in the
    #   ::pwtk::queue::queue(lsf,profile) variable.
    #
    # BEWARE
    #   The implicit assumption of this parser is that the LSF job script
    #   has one option per #BSUB line, i.e.:
    #
    #     #BSUB -q parallel
    #     #BSUB -n 8
    #     #BSUB -W 6:00
    #
    # ARGUMENTS
    # * profileName -- name of the LSF profile
    # * args -- command-line options of the LSF command.
    # SOURCE

    if { $args eq {} } {
        # use the profile verbatim
        set ::pwtk::queue::queue(lsf,profile) [::pwtk::trimIndent [::pwtk::varvalue ::pwtk::queue::profile(lsf,$profileName)]]\n
    } else {
        # add the command-line options to the lsf $profileName profile

        # the LSF profile looks like:
        #!/bin/sh
        #BSUB -q parallel
        #BSUB -n 8
        #BSUB -W 6:00
        #BSUB -x
    
        # parse the profile and store its options
        set content [::pwtk::trimIndent [::pwtk::varvalue ::pwtk::queue::profile(lsf,$profileName)]]

	set opt_list {}
	foreach line [split $content \n] {		    
	    if { [regexp {^#BSUB} $line] } {                
		# it is a #BSUB line, we assume one option per #BSUB line, i.e.:
                #   #BSUB -option "value value value"
                #
                # get rid of "#BSUB" and store options
                set line [string trim [regsub {^#BSUB} $line {}]]

                set option [lindex $line 0]
                set value  [string trim [string range $line [string length $option] end]]
                lappend opt_list [list $option $value]
            }
        }
        
        # add the options specified on the LSF command-line; new options
        # are added at the end
        #
        # for the options on the LSF command line, a standard Tcl
        # option syntax is assumed, i.e.: -option1 value1 -option2 -option3 value3

        # new
        while { $args ne {} } {
            lassign $args option value
            set index [lsearch -glob $opt_list "$option *"]            
            if { [regexp -- {^-} $value] } {
                # $value is the next option, hence $option is a valueless option
                set value {}
                set args [lrange $args 1 end]
            } else {
                set args [lrange $args 2 end]
            }
            if { $index < 0 } {
		# append to the end
		lappend opt_list [list $option $value]
	    } else {
		# replace the option's value
		set opt_list [lreplace $opt_list $index $index [list $option $value]]
	    }
        }
        # old
	#foreach {option value} $args {
	#    set index [lsearch -glob $opt_list "$option *"]
	#    
	#    if { $index < 0 } {
	#	# append to the end
	#	lappend opt_list [list $option $value]
	#    } else {
	#	# replace the value of the option
	#	set opt_list [lreplace $opt_list $index $index [list $option $value]]
	#    }
	#}
    }

    # build an LSF profile

    set ::pwtk::queue::queue(lsf,profile) {}
    set printed 0
    foreach line [split $content \n] {	
	if { [regexp {^#BSUB} $line] } {	    
	    # a #BSUB line, print options ...
	    if { ! $printed } {
		# write all the options
		foreach optionValue $opt_list {
                    lassign $optionValue option value
		    append ::pwtk::queue::queue(lsf,profile) [format "#BSUB %-6s %s\n" $option $value]
		}
		set printed 1
	    }
	} else {
	    # whatever line ...
	    append ::pwtk::queue::queue(lsf,profile) $line\n
	}
    }
}
