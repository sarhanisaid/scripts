#
# $RCSfile: eelsi.tcl,v $ --
#
#      This file contains procs for handling the turbo_eels.x input.
#
# Copyright (c) 2021  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: eelsi.tcl,v 1.1 2021/05/01 19:24:39 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::eelsi_fprint {{file {}}} { uplevel ::pwtk::eelsi::fprint $file }
proc ::pwtk::eelsi_clear  {}          { uplevel ::pwtk::eelsi::clear }
proc ::pwtk::eelsi_get    {}          { uplevel ::pwtk::eelsi::get }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::eelsi/::pwtk::eelsi::fprint
# SYNOPSIS
proc ::pwtk::eelsi::fprint {{file {}}} {
# PURPOSE
#   Print the content of turbo_eels.x input data to a file or to stdout if the
#   file was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::eelsi $file
}
#****


#****f* ::pwtk::eelsi/::pwtk::eelsi::get
# SYNOPSIS
proc ::pwtk::eelsi::get {} {
    # DESCRIPTION    
    #   Return the content of the turbo_eels.x input 
    # SOURCE
    variable namelist_flow_list
    
    ::pwtk::lri::loadDefaults_

    foreach nml $namelist_flow_list {
        append inp [::pwtk::input::namelistGet $nml]
    }
   
    return $inp
}
#******
    
#****f* ::pwtk::eelsi/::pwtk::eelsi::clear
# SYNOPSIS
proc ::pwtk::eelsi::clear {} {
    # DESCRIPTION    
    #   Clear the content of the turbo_eels.x input 
    # SOURCE
    variable input_flow_list

    foreach nml $input_flow_list {
        ::pwtk::input::clear $name
    }
}
#******
    
#****f* ::pwtk::eelsi/::pwtk::eelsi::load_fromEELSI
# SYNOPSIS
proc ::pwtk::eelsi::load_fromEELSI {eelsi {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing turbo_eels.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * eelsi -- filename of the turbo_eels.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?

    #
    # SOURCE
    variable namelist_flow_list

    ::pwtk::lri::load_from_input_  turbo_eels.x  $namelist_flow_list  $eelsi  $clear_existing
}
#******
