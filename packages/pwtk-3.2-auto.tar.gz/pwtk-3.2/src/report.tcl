#
# $RCSfile: report.tcl,v $ --
#
#      This file contains the "report" ensemble command for reporting
#      various useful info.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: report.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#

#****a* 5. API/5.0 Querying Useful Info
# DESCRIPTION
#   PWTK has hundreds of different commands. To help user navigating
#   among them, PWTK provides a useful interactive 'report' command.
#
#   The usage of 'report' is:
#
#       report WHAT ?arg? ?arg? ...
#
#   To get the help about 'report' itself, type 'report' in the PWTK
#   interactive prompt (%), i.e.:
#
#     % report
#
#     Possible items to query with report are:
#     
#       report structure ?EXECUTABLE? ?EXECUTABLE? ...
#              report structure of inputs for specified QE executables as
#              used by PWTK (if no executable is specified, input structures
#              of all supported QE executables are reported)
#     
#       report exceptions
#              report all PWTK naming exceptions (e.g., in PWTK, some cards
#              and namelists have different names than in QE)
#     
#       report programs
#              report all QE executables supported by PWTK and their
#              associated runCmd commands and input namespaces
#     
#       report plugins
#              report all QE plugins (e.g. environ, oscdft...) supported by PWTK
#     
#       report commands PATTERN
#              report all PWTK commands that matches PATTERN, where PATTERN
#              is either a QE executable, PWTK namespace, or pattern
#     
#       report exported PATTERN
#              report all PWTK exported commands (i.e. commands that can be
#              used without the ::pwtk prefix) that matches PATTERN, where
#              PATTERN is either a QE executable, PWTK namespace, or pattern
#
#       report cmd COMMAND
#              report if the COMMAND command exists and can be used without
#              the namespace qualifiers (e.g. without the ::pwtk prefix)
#
# |html <b>REMARK</b>
#
#   It is not required to type the whole subcommand of report, but
#   only a unique substring, e.g., 'report exp' is equivalent to
#   'report exported'.
#
# |html <b>EXAMPLE</b>
#
#   To get the help about exported commands associated with the pw.x
#   executable, type:
#
#     % report exported pw.x
#     
#     * pw.x run command:
#     runPW   (or runXX pw.x)
#     
#     * pw.x rerun command:
#     rerunPW   (or rerunXX pw.x)
#     
#     * pw.x input commands:
#     ADDITIONAL_K_POINTS ATOMIC_FORCES ATOMIC_POSITIONS
#     ATOMIC_POSITIONS_fromPWO ATOMIC_POSITIONS_fromXSF ATOMIC_SPECIES
#     ATOMIC_VELOCITIES CELL CELL_PARAMETERS
#     CELL_PARAMETERS_and_ATOMIC_POSITIONS_fromPWO
#     CELL_PARAMETERS_and_ATOMIC_POSITIONS_fromXSF
#     CELL_PARAMETERS_fromPWO CELL_PARAMETERS_fromXSF CONSTRAINTS
#     CONTROL ELECTRONS FCP HUBBARD IONS K_POINTS OCCUPATIONS RISM
#     SOLVENTS SYSTEM deleteAtoms deleteAtoms1st deleteAtomsLast
#     deleteAtomsRange fixAtoms fixAtoms1st fixAtomsLast fixAtomsRange
#     insertAtoms load_fromPWI pwi_clear pwi_fprint pwi_get
#     pwi_visualize replaceCoor substituteAtmType substituteAtom
#     substituteAtoms
#     
#     * pw.x output commands:
#     pwo_alat pwo_conv_thr pwo_dipole pwo_ecutrho pwo_ecutwfc
#     pwo_efermi pwo_etot pwo_etot_conv_thr pwo_forc_conv_thr
#     pwo_ibrav pwo_mixing_beta pwo_nat pwo_nbnd pwo_nelec pwo_ntyp
#     pwo_press pwo_totene pwo_totfor pwo_totmag pwo_volume pwo_xc
#                  
#******

#****f* 5.0 Querying Useful Info/::pwtk::report
# SYNOPSIS
proc ::pwtk::report {args} {
    # USAGE
    #   report WHAT ?arg? ?arg? ...
    # 
    # DESCRIPTION
    #   ::pwtk::report is an ensemble command meant to be used in the
    #   PWTK interactive prompt for querying useful info about PWTK
    #   and QE. Choose among:
    #
    #      report structure ?EXECUTABLE? ?EXECUTABLE? ...
    #      report exceptions
    #      report programs
    #      report plugins
    #      report commands PATTERN
    #      report exported PATTERN
    #      report cmd COMMAND
    #
    #   For further info, type 'report' in the PWTK interactive prompt.
    #
    # SOURCE
    if { $args eq {} } {
        puts "
Possible items to query with report are:

  [@ green]report structure [@ grey it]?EXECUTABLE? ?EXECUTABLE? ...[@]
         report structure of inputs for specified QE executables as
         used by PWTK (if no executable is specified, input structures
         of all supported QE executables are reported)

  [@ green]report exceptions[@]
         report all PWTK naming exceptions (e.g., in PWTK, some cards
         and namelists have different names than in QE)

  [@ green]report programs[@]
         report all QE executables supported by PWTK and their
         associated runCmd commands and input namespaces

  [@ green]report plugins[@]
         report all QE plugins (e.g. environ, oscdft...) supported by PWTK

  [@ green]report commands [@ it grey]PATTERN[@]
         report all PWTK commands that matches [@ it grey]PATTERN[@], where [@ it grey]PATTERN[@]
         is either a QE executable, PWTK namespace, or pattern

  [@ green]report exported [@ it grey]PATTERN[@]
         report all PWTK exported commands (i.e. commands that can be
         used without the ::pwtk prefix) that matches [@ it grey]PATTERN[@], where
         [@ it grey]PATTERN[@] is either a QE executable, PWTK namespace, or pattern

  [@ green]report cmd [@ it grey]COMMAND[@]
         report if the [@ it grey]COMMAND[@] command is exported and can be used
         without the namespace qualifiers (e.g. without the ::pwtk prefix)

"
    } else {
        ::pwtk::report_ {*}$args
    }
}
#******


#****f* Internals/::pwtk::report_
# DESCRIPTION
#   The implementation of the 'report' command, implemented as a
#   namespace ensemble.
#
# SOURCE
namespace eval ::pwtk::report_ {
    namespace export structure exceptions programs plugins commands exported cmd
    namespace ensemble create -prefixes true

    proc structure {args} {
        return [::pwtk::input_structure_ {*}$args]
    }
    proc exceptions {} {
        return [::pwtk::input_exceptions_]
    }
    proc programs {} {
        return [::pwtk::supported_programs_]
    }
    proc plugins {} {
        return [::pwtk::supported_plugins_]
    }
    proc commands {pattern} {
        return [::pwtk::commands_ $pattern]
    }
    proc exported {pattern} {
        return [::pwtk::commands_ $pattern 1]
    }
    proc cmd {cmd} {
        return [::pwtk::cmd_ $cmd]
    }
}
#******


proc ::pwtk::input_structure_ {args} {
    variable prog2inNN
    variable plugin
    
    if { $args eq {} } {
        set args [concat [lsort -ascii [array names prog2inNN]] [lsort -ascii $plugin(list)]]
    }
    
    set prog_inNN [array get prog2inNN]
    set narg [llength $args]

    foreach prog_or_inNN $args {
        set plug 0
        set inNN [namespace tail $prog_or_inNN]
        set prog $prog_or_inNN
    
        if { [info exists prog2inNN($prog)] } {
            # is prog_or_inNN a program ?
            set inNN [namespace tail $prog2inNN($prog)]
        } else {
            # is prog_or_inNN an input namespace ?
            set ind  [lsearch -exact $prog_inNN ::pwtk::$inNN]
            set prog [lindex $prog_inNN $ind-1]
            if { $ind < 0 } {
                # is prog_or_inNN a plugin ?
                set prog [string toupper [lsearch -inline -exact $plugin(list) $prog_or_inNN]]
                if { $prog eq {} } {
                    # not even a plugin
                    continue
                }
                set plug 1
            }
        }

        if { [namespace exists ::pwtk::$inNN] && [info exists ::pwtk::${inNN}::input_flow_list] } {
            upvar ::pwtk::${inNN}::input_flow_list ifl
        }
        if { $narg > 1 } {
            if { ! $plug } {
                append result "[@ blue]* input structure for the $prog program:[@]\n"
            } else {
                append result "[@ blue]* input structure for the $prog plugin:[@]\n"
            }
        }
        foreach block [varvalue ifl] {
            append result $block\n
        }
        if { $narg > 1 } { append result \n }
    }    
    return [string trim [varvalue result]]
}



proc ::pwtk::input_exceptions_ {} {
    variable QE2PWTKname
    variable prog2inNN

    set fmt " %-15s %-10s %-35s %-17s"
    # get all executables
    set result "-------------------------------------------------------------------------------
[format $fmt executable type QE-name PWTK-name]
-------------------------------------------------------------------------------\n"
   
    foreach prog [lsort [array names prog2inNN]] {
        set i 0
        foreach type {namelist card} {
            foreach elem [array names QE2PWTKname $prog,*$type,*] {
                incr i
                set p [expr { $i == 1 ? $prog : "" }]
                lassign [split $elem ,] p_ Type QEname
                if { [string match *card* $Type] && [llength $QEname] > 1 } {
                    set Type supercard
                }
                append result [format $fmt $p $Type [join $QEname /] [list $QE2PWTKname($elem)]]\n
            }
        }
        if { $i > 0 } {
            append result \n
        }
    }
    return "[string trim $result]
-------------------------------------------------------------------------------
# remark: {} implies that the corresponding QE supercard does not exist in PWTK"

}

proc ::pwtk::supported_programs_ {} {
    variable prog2inNN
    variable prog2runCmd
    
    set fmt " %-22s %-21s %-13s %-20s"   
    set result "-------------------------------------------------------------------------------
[format $fmt executable runCmd rerunCmd {input namespace}]
-------------------------------------------------------------------------------\n"

    set runCmd {}; # remove-this
    foreach prog [lsort [array names prog2inNN]] {
        set rerunCmd {}
        catch {set runCmd [namespace tail $prog2runCmd($prog)]}
        if { $runCmd ne {} && [info procs re$runCmd] ne {} } {
            set rerunCmd re$runCmd
        }
        append result [format $fmt $prog $runCmd $rerunCmd $prog2inNN($prog)]\n
    }
    return "[string trim $result]
-------------------------------------------------------------------------------"
}

proc ::pwtk::commands_ {pattern {e {}}} {    
    variable prog2inNN
    variable prog2runCmd

    # ARGUMENTS:
    # * pattern can be:
    #   - namespace
    #   - input namespace
    #   - executable
    #   - pattern
    # * e ... if not {}, only exported commands will be reported

    if { [info exists prog2inNN($pattern)] } {
        set prog $pattern
        set pattern $prog2inNN($prog)
    }

    # strip possible ::pwtk:: from $pattern
    set pattern  [regsub {^(::pwtk::|pwtk::)} $pattern {}]
    
    if { [namespace exists ::pwtk::$pattern] } {        
        set NN $pattern; # namespace 
        if { [string index $pattern end] eq "i" } {            
            set inNN $pattern; # input namespace
            ifnotexist prog {
                set prog_inNN [array get prog2inNN]
                set ind [lsearch -exact $prog_inNN ::pwtk::$inNN]
                set prog [lindex $prog_inNN $ind-1]
            }
        }
        set typ [string range $pattern 0 [string length $pattern]-2]
        if { [namespace exists ::pwtk::${typ}o] && "${typ}o" ne $NN } {
            set outNN ${typ}o; # output namespace 
        }
    } 

    ifset prog {}; # just in case
    set result {}

    ifexist prog {
        set rc [exported__ [varvalue prog2runCmd($prog)] $e]
        set rx [exported__ ::pwtk::runXX $e]
        ifnotempty rc {
            append result "[@ blue]* $prog run command:[@]\n  $rc   [@ grey](or[@] $rx $prog[@ grey])[@]\n\n"

            set rct [namespace tail $rc]
            if { [getProcs_ ::pwtk::re$rct] ne {} } {
                set rerc [exported__ ::pwtk::re$rct  $e]
                set rerx [exported__ ::pwtk::rerunXX $e]        
                append result "[@ blue]* $prog rerun command:[@]\n  $rerc   [@ grey](or[@] $rerx $prog[@ grey])[@]\n\n"
            }
        }
    }
    ifexist inNN {
        if { $e eq {} } {
            set ic [lsearch -all -not -inline [concat \
                                                   [exported__ [getProcs_ ::pwtk::${inNN}_*]  $e] \
                                                   [exported__ [getProcs_ ::pwtk::${inNN}::*] $e]] *_]
        } else {
            # exported input commands
            # N.B. make a merge of all defined commands and names from
            # 'input_flow_list' because various programs may share namelist/cards
            upvar ::pwtk::${inNN}::input_flow_list ifl
            set ic [lsearch -all -not -inline [exported__ [concat [getProcs_ ::pwtk::${inNN}_*] [getProcs_ ::pwtk::${inNN}::*] $ifl] $e] *_]
        }            
        ifnotempty ic {
            append result "[@ blue]* $prog input commands:[@]\n  $ic\n\n"
        }
    }
    ifexist outNN {
        if { $e eq {} } {
            set oc [lsearch -all -not -inline [concat \
                                                   [exported__ [getProcs_ ::pwtk::${outNN}_*]  $e] \
                                                   [exported__ [getProcs_ ::pwtk::${outNN}::*] $e]] *_]
        } else {
            set oc [lsearch -all -not -inline [exported__ [concat [getProcs_ ::pwtk::${outNN}_*] [getProcs_ ::pwtk::${outNN}::*]] $e] *_]
        }
        ifnotempty oc { 
            append result "[@ blue]* $prog output commands:[@]\n  $oc\n\n"
        }
    }
    # take card of misc commands (aka mc) ??
    ifexist NN {
        ifnotexist inNN {
            if { $e eq {} } {
                set nc [lsearch -all -not -inline [concat \
                                                       [exported__ [getProcs_ ::pwtk::${NN}_*] $e] \
                                                       [exported__ [getProcs_ ::pwtk::*_${NN}*] $e] \
                                                       [exported__ [getProcs_ ::pwtk::${NN}::*] $e]] *_]
            } else {
                set nc [lsearch -all -not -inline [exported__ [concat [getProcs_ ::pwtk::${NN}_*] [getProcs_ ::pwtk::*_${NN}*] [getProcs_ ::pwtk::${NN}::*]] $e] *_]
            }
            ifnotempty nc { 
                append result "[@ blue]* $NN commands:[@]\n  $nc\n\n"
            }
        }
    }
    ifempty result {
        # nothing found, try with ::pwtk::*$pattern*
        set pc [lsearch -all -not -inline [exported__ [getProcs_ ::pwtk::*${pattern}*] $e] *_]
        ifnotempty pc { 
            append result "[@ blue]* commands matching the *$pattern* pattern:[@]\n  $pc\n\n"
        }
    }
    
    return $result
}


proc ::pwtk::cmd_ {cmd} {
    if { [getCommand_ $cmd] ne {} } {
        set tail_cmd [namespace tail $cmd]
        try {
            set full_cmd [namespace eval :: namespace origin $cmd]
        } on error err {
            set full_cmd $cmd
        }
        try {
            set full_cmd_of_tail [namespace eval :: namespace origin $tail_cmd]
        } on error err {
            set full_cmd_of_tail {}
        }
        if { $cmd eq $tail_cmd } {
            return "\ncommand [@ green]$tail_cmd[@] exists, its fully-qualified name is [@ green]$full_cmd[@]\n"
        } elseif { $full_cmd_of_tail eq $full_cmd } {
            # tail_cmd --> full_cmd
            set result "command [@ green]$cmd[@] is exported and can be used as [@ green]$tail_cmd[@]"
            if { $cmd ne $full_cmd } {
                append result "\n(its fully-qualified name is [@ green]$full_cmd[@])"
            }
            return \n$result\n
        } else {
            return "\ncommand [@ green]$cmd[@] exists but is not exported\n"
        }
    } else {
        return "\ncommand [@ green]$cmd[@] does not exist\n"
    }
}    


proc ::pwtk::exported__ {procList {exported {}}} {
    set procList [lsort -unique -ascii $procList]
    if { $exported eq {} } {
        #return [lsort -unique -ascii $procList]
        return $procList
    }
    foreach pr $procList {
        set p [namespace tail $pr]
        if { [namespace eval :: info procs $p] ne {} } {
            lappend result $p
        }
    }
    return [lsort -unique -ascii [varvalue result]]
}


proc ::pwtk::supported_plugins_ {} {
    variable plugin

    ifnotexist plugin(list) { return }

    set fmt " %-12s %-20s %-s"
    set act "[@ green]activate[@] / [@ red]deactivate[@] in PWTK"
    set result "-------------------------------------------------------------------------------
[format $fmt plugin {plugin namespace} $act]
-------------------------------------------------------------------------------\n"
    foreach p [lsort -ascii $::pwtk::plugin(list)] {
        append result [format $fmt [string toupper $p] ::pwtk::$p "[@ green]$p on[@] / [@ red]$p off[@]"]\n
    }
    return "[string trim $result]    
-------------------------------------------------------------------------------"
}

# internal...
proc ::pwtk::getProcs_ {pattern} {
    # PURPOSE
    #   An extension of "info procs" to report also currently non auto_loaded procs.
    return [lsort -unique -ascii [concat [info procs $pattern] [array names ::auto_index $pattern]]]
}
proc ::pwtk::getCommand_ {cmd} {
    # PURPOSE
    #   An extension of "info commands" to report also currently non auto_loaded proc(s).
    return [lsort -unique -ascii \
                [concat [namespace eval :: info commands $cmd] \
                     [array names ::auto_index $cmd] [array names ::auto_index ::$cmd]]]
}
