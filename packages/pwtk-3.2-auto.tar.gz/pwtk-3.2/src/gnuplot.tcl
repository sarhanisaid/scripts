#
# $RCSfile: gnuplot.tcl,v $ --
#
#      This file contains PWTK's support for Gnuplot.
#
# Copyright (c) 2023-2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: gnuplot.tcl,v 1.3 2023/02/02 17:00:01 kokalj Exp $ 
#


# namespace eval ::pwtk::gp {
#     # variables used by ::pwtk::gp
#     # (they are initialized in ../config/gnuplot.tcl)
#     variable known_options
#     variable gp
#     variable options
#     variable pwtk2gp
# }
# 
# #****iv*
# # LIST
# #   ::pwtk::gp::known_options
# #
# # DESCRIPTION
# #   The purpose of "known_options" is to have a "logically" sorted
# #   options in PWTK's generated Gnuplot scripts (Gnuplot's options are
# #   options that are set with the Gnuplot's "set" command).
# #
# # BEWARE
# #   Options consisting of more than one word, such as "format x" is
# #   specified as format.x
# #
# #******
# set ::pwtk::gp::known_options {
#     tmargin     
#     rmargin 
#     bmargin 
#     lmargin 
# 
#     xtics 
#     ytics 
#     mxtics 
#     mytics 
#     x2tics 
#     y2tics 
#     mx2tics 
#     my2tics 
# 
#     xrange 
#     yrange 
#     x2range     
#     y2range 
#     
#     format.x 
#     format.y 
#     format.x2 
#     format.y2 
# 
#     xzeroaxis 
#     yzeroaxis 
# 
#     grid 
#     style.fill
# 
#     xlabel  
#     ylabel  
#     x2label 
#     y2label 
# 
#     key     
#     title       
# }
# 
# #****iv*
# # ARRAY
# #   ::pwtk::gp::options
# #
# # PURPOSE
# #   PWTK's pre-set options For gnuplot (as to make plots nicer).
# #
# #******
# 
# array set ::pwtk::gp::options {
#     mxtics     2
#     mytics     2    
#     grid       {lt -1 lc '#bbbbbb'}
#     style.fill {transparent solid 0.4}
#     xzeroaxis  {lt -1}
#     yzeroaxis  {lt -1}
# }
# 
# 
# #****iv*
# # ARRAY
# #   ::pwtk::gp::pwtk2gp
# #
# # PURPOSE
# #   Array holding the matching between PWTK and Gnuplot terminal
# #   names; the structure is the following:
# #
# #      pwtk2gp(pwtkName) == gnuplotName
# #
# # BEWARE
# #   The empty Gnuplot's terminal, {}, stands for a default Gnuplot's terminal
# #   (which is probably a window terminal); it's PWTK name is "win".
# #******
# 
# array set ::pwtk::gp::pwtk2gp {
#     ps  postscript
#     eps postscript
#     png pngcairo
#     pdf pdfcairo
#     win {}
# }
# 
# 
# #****iv*
# # ARRAY
# #   ::pwtk::gp::gp
# #
# # PURPOSE
# #   Contain the "main" config data (such as terminals, fonts...)for
# #   Gnuplot plots.
# #
# # BEWARE
# #   1. PWTK's terminal names eps, pdf, and png are named as
# #      postscript, pdfcairo, and pngcairo in Gnuplot
# #
# #   2. during initialization: gp(terminals) is set to a merge of
# #      file.terminals, win.terminals, txt.terminals
# #
# #   3. an empty win.terminal stands for Gnuplot's defult terminal
# #      (which is most-likely a window-type terminal)
# #******
# 
# array set ::pwtk::gp::gp {
#     file.terminals {postscript pdfcairo svg pngcairo}
#     win.terminals  {qt wxt x11 {}}
#     txt.terminals  {dumb}
#     
#     font         Arial
#     fontSize     14
#     svg.fontSize 18
#     png.fontSize 15
#     
#     eps.portrait.size   0.8,0.4
#     eps.landscape.size  0.53,0.6
#     pdf.size   4,3
#     png.size   800,575
#     size       640,460
# }
# 
# 
# #****iv*
# # CONTINUED
# #   ::pwtk::gp::gp
# #
# # Config for multiplot:
# #
# #   npmax == maximum number of plots per page
# #   np    == number of plots per pag
# #   npN   == limiting np values for determinning nxN values, if np > npN ==> nx = nxN
# #   nxN   == number of plots in X-dir for a given npN
# #   font.nxN == font size for a given nxN
# #
# #   spin.*** == spin-PDOS-like plots (plots with positive and negative Y-values,
# #               i.e., f(x) & -f(x))
# #******
# 
# array set ::pwtk::gp::gp {
#     eps.multisize  1.0,1.0
#     pdf.multisize  11.69,8.27
#     multisize      1200,800
# 
#     landscape.npmax 25
#     portrait.npmax  28
# 
#     landscape.np1 4
#     landscape.np2 9
#     landscape.np3 20
#     landscape.np4 30
# 
#     landscape.nx0 2
#     landscape.nx1 3
#     landscape.nx2 4
#     landscape.nx3 5
#     landscape.nx4 6
# 
#     portrait.np1 4
#     portrait.np2 10
#     portrait.np3 21
#     portrait.np4 32
#     
#     portrait.nx0 1
#     portrait.nx1 2
#     portrait.nx2 3
#     portrait.nx3 4
#     portrait.nx4 5
# 
#     spin.landscape.np1 4
#     spin.landscape.np2 9
#     spin.landscape.np3 20
#     spin.landscape.np4 30
# 
#     spin.landscape.nx0 2
#     spin.landscape.nx1 3
#     spin.landscape.nx2 4
#     spin.landscape.nx3 5
#     spin.landscape.nx4 6
#     
#     spin.portrait.np1 4
#     spin.portrait.np2 9
#     spin.portrait.np3 20
#     spin.portrait.np4 30
# 
#     spin.portrait.nx0 1
#     spin.portrait.nx1 2
#     spin.portrait.nx2 3
#     spin.portrait.nx3 4
#     spin.portrait.nx4 5
# 
#     fontSize.nx0 14
#     fontSize.nx1 11
#     fontSize.nx2 9    
#     fontSize.nx3 8
#     fontSize.nx4 7
# }


#***internal... get head from head_dot_term
proc ::pwtk::gp::head_ {head_dot_term} {
    return [file rootname $head_dot_term]
}


#***internal... get PWTK terminal name from head_dot_term
proc ::pwtk::gp::term_ {head_dot_term} {
    variable gp
    set term [string trimleft [file extension $head_dot_term] .]
    # if $term == "" ==> gp2pwtk returns "win"
    return [gp2pwtk [term_usable $term]]
}


#***internal...
proc ::pwtk::gp::parseOpt_term_ {} {
    # PURPOSE
    #   The get_term command and ::pwtk::gp::*plot constuctors
    #   share many common options. This proc "loads" them into
    #   the opt array
    
    uplevel 1 {
        set options {
            {o.arg    {} "o = orient: page orientation (portrait or landscape)"}
            {s.arg    {} "s = terminal size (i.e. window or picture size)"}
            {fs.arg   {} "fs = font size"}
            {t.arg    {} "t = title: the window title (for window-type terminals only)"}
            {spin        "spin-PDOS-like plots with positive & negative Y-values, f(x) & -f(x)"}
            {p           "page mode (gnuplot output file will contain page number)"}
            
            {type.arg map     "type of splot (map | surface | both)"}
            {pal.arg  gnuplot "palette for pm3d (PWTK has 12 predifined palettes)"}
            {nocontour        "do not use contours"}
            {cc.arg   {}      "color of contours"}

            {pause.arg {}     "value of Gnuplot's pause"}
        }
        ::pwtk::parseOpt_
        ::pwtk::checkOType_ -o  $opt(o)  {optionlist portrait landscape}
        ::pwtk::checkOType_ -s  $opt(s)  gp_size               "sx,sy size"
        ::pwtk::checkOType_ -fs $opt(fs) {number posint}       "positive integer"
    }
}


#****f* ::pwtk::gp/::pwtk::gp::pause
# SYNOPSIS
proc ::pwtk::gp::pause {{value {}}} {
    # PURPOSE
    #   Set or query a pause value for the 'pause' gnuplot command.
    #   Possibilities are:
    #
    #      pause -1 ; # pause waits until a carriage return is hit
    #      pause N  ; # pause waits for N seconds
    #      pause mouse; # pause waits until a mouse click or ctrl-C
    #
    # RETURN VALUE
    # The pause value.
    # SOURCE

    variable gp    
    if { $value ne {} } {
        array set gp [pause_ $value]
    }
    return [::pwtk::varvalue gp(pause)]
}        

#****if* Internals/::pwtk::gp::pause_
# SYNOPSIS
proc ::pwtk::gp::pause_ {value} {
    # PURPOSE
    #   Set a pause value for the 'pause' gnuplot command. Options are:
    # RETURN VALUE
    #   The following dictionary: pause $value pauseText $pauseText
    # SOURCE
    
    variable gp

    switch -- $value {
        mouse {
            set pauseText "Click on Gnuplot window"
        }
        default {
            if { [string is double -strict $value] } {
                if { $value >= 0.0 } {
                    if { $value == 1 } {
                        set pauseText "Wait for $value second"
                    } else {
                        set pauseText "Wait for $value seconds"
                    }
                } else {
                    set pauseText "Press <Enter> in the terminal"
                }
            } elseif { $value eq {} } {
                set pauseText {}            
            } else {
                ::pwtk::error "wrong value for gnuplot pause, must be 'mouse' or a number, but got: $value" 1
            }
        }
    }
    return [list pause $value pauseText $pauseText]
}
#******


#****f* ::pwtk::gp/::pwtk::gp::get_term
# SYNOPSIS
proc ::pwtk::gp::get_term {args} {
    # USAGE
    #    get_term ?OPTIONS? head.type
    #
    # i.e.:
    #
    #    get_term  ?-o ORIENT?  ?-s SIZE?  ?-fs FONTSIZE?  ?-t TITLE?  ?-spin?  ?-p?  head.type
    #
    # where "head" is the rootname of the files (Gnuplot script & output
    # file(s)) and "type" is the terminal type and file extension if plot
    # is printed to a file (e.g., eps, pdf, svg, png).
    #
    # REMARK
    # This routine is used internally by PWTK. A user should use instead the
    # ::pwtk::gp::plot object-oriented interface.
    #
    # OPTIONS
    # * -o ORIENT    --- page orientation (portrait or landscape); used explicitly only for
    #                    EPS, while for other terminals, it's a hint for the multiplot layout
    # * -s SX,SY     --- terminal size (i.e., window or picture size)
    # * -fs FONTSIZE --- font size
    # * -t TITLE     --- the window title (for window-type terminals only)
    # * -spin        --- spin-PDOS-like plots with positive & negative Y-values, f(x) & -f(x)
    # * -p           --- page mode (Gnuplot output file will contain a page number in its name)
    # 
    # Options typically do not need to be set (defaults should be OK).
    #
    # RETURN VALUE
    #   A string containing Gnuplot instructions for setting the appropriate terminal.
    #
    # SOURCE

    variable gp

    #
    # parse args ...
    #
    
    set narg 1
    set usage "?-p?  ?-o ORIENT?  ?-s SIZE?  ?-fs FONTSIZE?  ?-t TITLE?  ?-spin?  head.type"
    parseOpt_term_

    set head [head_ $args]
    set term [term_ $args]

    # -spin
    # (nothing so far for single-plot)
    
    # -p
    if { $opt(p) } {
        set page 1
    } else {
        set page {}
    }

    # -o ORIENT
    set orient [orient $term $opt(s) $opt(o)]
    
    # -s SIZE
    if { $opt(s) == {} } {
        # TODO: handle -spin option here once gp() is configured for spin-single-plot
        switch -- $term {
            eps { set size $gp(eps.$orient.size) }
            pdf { set size [osize $orient $gp(pdf.size)] }
            png { set size [osize $orient $gp(png.size)] }
            default { set size [osize $orient $gp(size)] }
        }
    } else {
        set size $opt(s)
    }

    # -fs FONTSIZE
    if { $opt(fs) == {} } {
        switch -- $term {
            svg { set fsize $gp(svg.fontSize) }
            png { set fsize $gp(png.fontSize) }
            default { set fsize $gp(fontSize) }
        }
    } else {
        set fsize $opt(fs)
    }

    # -t TITLE
    if { $opt(t) != {} } {
        set title "title [::pwtk::squote $opt(t)]"
    } else {
        set title {}
    }

    set prolog "# Gnuplot script generated by PWTK-$::pwtk::version on [clock format [clock seconds]]

set encoding utf8"

    #
    # set terminal part of the Gnuplot script
    #
    
    switch -- $term {
        eps {
#            return "$prolog
#set minussign
#set term postscript $orient enhanced color font '$gp(font),$fsize' lw $gp(lw)
#set output '$head.eps'
#set size $size\n"
            return "$prolog
set minussign
set term postscript $orient enhanced color font '$gp(font),$fsize' lw $gp(lw) size $size fontscale $gp(eps.fontscale) pointscale $gp(eps.pointscale)
set output '$head.eps'\n"
        }
        
        pdf {
#            return "$prolog
#set minussign
#set term pdfcairo enhanced color font '$gp(font),$fsize' lw $gp(lw) size $size; # size is in inches
#set output '$head.pdf'\n"
            return "$prolog
set minussign
set term pdfcairo enhanced color font '$gp(font),$fsize' lw $gp(lw) size $size fontscale $gp(pdf.fontscale) pointscale $gp(pdf.pointscale)
set output '$head.pdf'\n"
        }
        
        svg {
            return "$prolog
set minussign
set term svg size $size font '$gp(font),$fsize' enhanced lw $gp(lw); #background '#ffffff'
set output '[output svg $head $page]'\n"
        }
        
        png {
            return "$prolog
set minussign
set term pngcairo enhanced color font '$gp(font),$fsize' lw $gp(lw) size $size; #background '#ffffff'
set output '[output png $head $page]'\n"
        }
        
        qt {
            # persist deleted
            return "$prolog
set minussign
set term qt size $size font '$gp(font),$fsize' enhanced  lw $gp(lw) $title\n"
        }
        
        wxt {
            # persist deleted
            return "$prolog
set minussign
set term wxt size $size font '$gp(font),$fsize' enhanced  lw $gp(lw) $title\n"
        }
        
        x11 {
            # persist deleted
            return "$prolog
set term x11 size $size font '$gp(font),$fsize' enhanced  lw $gp(lw) background '#ffffff' $title\n"
        }

        win {
            # use a Gnuplot's default terminal
            return "$prolog\n"
        }

        dumb {
            return "$prolog
set terminal dumb enhanced"
        }
        
        default {
            ::pwtk::error "PWTK does not support the Gnuplot terminal \"$term\", must be one of [join $gp(terminals) {, }]" 1
        }
    }
}
#******


#****f* ::pwtk::gp/::pwtk::gp::term_ok
# SYNOPSIS
proc ::pwtk::gp::term_ok {term} {
    # PURPOSE
    #   Check if the terminal $term is OK.
    #
    #   This proc is typically used internally by PWTK.
    #
    # RETURN VALUE
    #   1 ... if the Gnuplot $term terminal is supported by PWTK and exists in Gnuplot
    #   0 ... otherwise
    #
    # SOURCE
    
    variable gp

    if { [auto_execok gnuplot] eq {} } {
        ::pwtk::error "no usable Gnuplot program found" 1
    }

    set term [pwtk2gp $term]

    # gp(supported_terminals) == list of terminals supported by both PWTK and Gnuplot

    ::pwtk::ifempty gp(supported_terminals) {
        set gp(terminals) [concat $gp(file.terminals) $gp(win.terminals) $gp(txt.terminals)]

        # add the empty terminal (i.e. Gnuplot's default terminal) to a
        # list of supported_terminals
        foreach type {"" file. win. txt.} {
            set gp(${type}supported_terminals) {}
        }

        # workaround: it happens that [::gp::gp print GPVAL_TERMINALS] may return an empty string
        for {set i 0} {$i < 10} {incr i} {
            if { [set gpterminals_ [::gp::gp print GPVAL_TERMINALS]] ne {} } {
                break
            }
        }
        foreach t $gpterminals_ {
            foreach type {"" file. win. txt.} {
                if { $t in $gp(${type}terminals) } {
                    lappend gp(${type}supported_terminals) $t
                }
            }
        }
    }

    if { $term in $gp(win.terminals) \
             && $::tcl_platform(platform) eq "unix" && ![info exists ::env(DISPLAY)] } {
        # win-terminal & no DISPLAY 
        return 0
    }
    if { $term in $gp(supported_terminals) } {
        return 1
    } else {
        return 0
    }
}
#******


#****f* ::pwtk::gp/::pwtk::gp::pwtk_terminals
# SYNOPSIS
proc ::pwtk::gp::pwtk_terminals {} {
    # PURPOSE
    #   Return the list of PWTK terminals available in Gnuplot. This
    #   command is similar to ::pwtk::gp::terminals but returns the
    #   PWTK terminal names.
    #
    # SOURCE 
    foreach term [terminals] {
        lappend result [gp2pwtk $term]
    }
    return [::pwtk::varvalue result]
}
#******

#****f* ::pwtk::gp/::pwtk::gp::terminals
# SYNOPSIS
proc ::pwtk::gp::terminals {} {
    # PURPOSE
    #   Return the list of Gnuplot terminals supported by PWTK that are
    #   available in the installed gnuplot.
    # SOURCE
    variable gp
    
    set pwtk_terminals [concat $gp(file.terminals) $gp(win.terminals) $gp(txt.terminals)]
    
    # workaround: it happens that [gp::gp print GPVAL_TERMINALS] may return an empty string
    for {set i 0} {$i < 10} {incr i} {
        if { [set gp_terminals [gp::gp print GPVAL_TERMINALS]] ne {} } {
            break
        }
    }

    # retain only terminals that are supported by gnuplot
    set terminals {}
    foreach term $pwtk_terminals {
        if { $term in $gp_terminals } {
            lappend terminals $term
        }
    }
    return $terminals
}
#******


#****f* ::pwtk::gp/::pwtk::gp::term_usable
# SYNOPSIS
proc ::pwtk::gp::term_usable {term} {
    # PURPOSE
    #   Return a Gnuplot name for the terminal, derived from $term,
    #   that is supported by Gnuplot.
    #
    #   This proc is typically used internally by PWTK.
    #
    # RETURN VALUE
    #   Name of the Gnuplot terminal that exists. In particular, it
    #   returns $term if the Gnuplot terminal $term exists, otherwise
    #   returns some terminal that exists ("dumb" if anything else fails).
    #
    #   The terminal search follows the logic:
    #   * if $term is win.term, return any win.term that exists
    #   * if $term is file.term, return any file.term that exists
    #   * if $term is txt.term, return any txt.term that exists
    #   If all these fail, return any or empty (=default) terminal
    #
    # SOURCE
    variable supported_terminals
    variable gp

    set term [pwtk2gp $term]
    set warning {The requested Gnuplot terminal \"$term\" is either not supported by PWTK or\ndoes not exist in Gnuplot. Using the \"$t\" terminal instead.}
    
    if { [term_ok $term] } {
        return $term
    } else {
        # if we have a win-terminal & no DISPLAY, use the dumb txt.terminal
        if { $term in $gp(win.terminals) \
                 && $::tcl_platform(platform) eq "unix" && ![info exists ::env(DISPLAY)] } {
            if { $term eq {} } {
                set term win
            }
            ::pwtk::warning "cannot use the $term terminal: no \$DISPLAY environment variable, using the dump terminal instead"
            return dumb
        }
        # get a usable file.terminal for a file.terminal,
        # win.terminal for a win.terminal, ..., or any usable terminal
        foreach type {file. win. txt. ""} {
            if { $term in $gp(${type}terminals) && [info exists gp(${type}supported_terminals)] } {
                # $term is a $type type terminal, use the first avaiable terminal
                set t [lindex $gp(${type}supported_terminals) 0]
                if { $term ne {} } {
                    # empty $term stands for a window terminal; do not print warning
                    ::pwtk::warning [subst $warning]
                }
                return $t
            }            
        }
        # no usable terminals found, return {} (i.e. empty terminal)
        set t {}
        ::pwtk::warning [subst $warning]
        return $t
    }
}
#******


#****if* Internals/::pwtk::gp::orient
proc ::pwtk::gp::orient {term opt_size opt_orient} {
    # PURPOSE
    #   Determine "orientation" from the values of the -s and -o options.
    #
    #   Rules:
    #   1. if $opt_orient != {} then $opt_orient determines the orientation
    #   2. if ($term != "eps" && $opt_size != {} && sx>sy) then landscape else portrait
    #   3. if ($term != "eps" && $opt_size == {}) landscape
    #   4. else portrait
    #
    # SEE ALSO
    #   ::pwtk::gp::osize    
    # SOURCE

    set term [::pwtk::gp::gp2pwtk $term]
    if { $opt_orient ne {} } {
        return $opt_orient
        
    } elseif { [::pwtk::gp::gp2pwtk $term] ne "eps" && $opt_size ne {} } {
        scan $opt_size %f,%f sx sy
        ifset sy $sx; # just in case
        return [expr {$sx > $sy ? "landscape" : "portrait"}]
        
    } elseif { [::pwtk::gp::gp2pwtk $term] ne "eps" && $opt_size eq {} } {
        return landscape
    }
    return portrait    
}
#******


#****if* Internals/::pwtk::gp::osize
# SYNOPSIS
proc ::pwtk::gp::osize {orient size} {
    # PURPOSE
    #   Take care of the landscape | portrait size; osize == orient-size
    #
    #   This routine is used to determine landscape & portrait sizes
    #   for non-EPS terminals (in Gnuplot EPS is handled differently,
    #   and -o & -s options are used verbatim without guessing the
    #   orientation)
    #
    # RETURN VALUE
    # * if orient == landscape then max($sx,$sy),min($sx,$sy)
    # * else min($sx,$sy),max($sx,$sy)
    #
    # SEE ALSO
    #   ::pwtk::gp::orient    
    # SOURCE
    scan $size %f,%f sx sy
    if { ! [string is double -strict $sx] || ! [string is double -strict $sy] } {
        ::pwtk::error "wrong size \"$size\", must be sx,sy" 1
    }
    set M [expr max($sx,$sy)]
    set m [expr min($sx,$sy)]
    if { $orient eq "landscape" } {
        return $M,$m
    } else {
        return $m,$M
    }
}
#******


#****if* Internals/::pwtk::gp::multiplot_array
# SYNOPSIS
proc ::pwtk::gp::multiplot_array {nplot {np_in -1} {nx_in -1} {orient portrait} {spin {}}} {
    # PURPOSE
    #   Set the multiplot data in the form of a Tcl array, i.e., set
    #   good values for pp, np, nx, ny, fsize for a given number of plots.        
    #
    # ARGUMENTS
    # * nplot --- number of plots in the multiplot 
    # * np_in --- [optional] number of plots per page (overwrites defult for a given nplot)
    # * nx_in --- [optional] number of plots in X-dir (overwrites defult for a given nplot)
    # * orient --- [optional] orientation of the multiplot, either portrait or landscape
    # * spin   --- [optional] spin-PDOS-like plots (empty string or 0 means no-spin)
    #
    # RETURN VALUE
    # A list of names & values, suitable for "array set" command, in particular:
    #
    #    [list pp $pp  np $np  nx $nx  ny $ny  fsize $fsize]
    #
    # Explantion of variables:    
    # * pp = # of pages
    # * np = average # of plots per page
    # * nx = number of plots in X-dir (aka # columns)
    # * ny = number of plots in Y-dir (aka # rows)
    # * fsize = fontSize
    #
    # * npmax = used along the way as auxiliary;
    #           stands for maximum # of plots per page, e.g., nx*ny    
    #
    # SOURCE
    
    variable gp
    variable gp_multi

    set npmax $np_in
    set nx    $nx_in
    set fsize {}

    if { $spin eq {} || $spin == 0 } {
        set spinOrient $orient
    } else {
        set spinOrient spin.$orient
    }
    
    if { $np_in < 1 } {
        set npmax $gp($orient.npmax)
    }
    set np $nplot
    set pp [expr ($nplot-1)/$npmax + 1]
    if { $pp > 1 } {
        if { $nplot%$pp } {
            set np [expr $nplot/$pp + 1]
        } else {
            set np [expr $nplot/$pp]
        }
    }

    if { $np > $gp($spinOrient.np4) } {
            
        if { $nx < 0 } { set nx $gp($spinOrient.nx4) }
        set fsize $gp(fontSize.nx4)
            
    } elseif { $np > $gp($spinOrient.np3) } {
            
        if { $nx < 0 } { set nx $gp($spinOrient.nx3) }
        set fsize $gp(fontSize.nx3)
            
    } elseif { $np > $gp($spinOrient.np2) } {
            
        if { $nx < 0 } { set nx $gp($spinOrient.nx2) }
        set fsize $gp(fontSize.nx2)
            
    } elseif { $np > $gp($spinOrient.np1) } {
            
        if { $nx < 0 } { set nx $gp($spinOrient.nx1) }
        set fsize $gp(fontSize.nx1)
            
    } else { 
        if { $nx < 0 } { set nx $gp($spinOrient.nx0) }
        set fsize $gp(fontSize.nx0)            
    }    
    
    # adjust the npmax
    if { $pp > 1 } {
        if { $np%$nx } {
            set npmax [expr $nx*($np/$nx + 1)]
        } else {
            set npmax $np
        }
        set ny [expr $npmax/$nx]
    } else {
        set npmax $nplot
        if { $nplot%$nx } {
            set ny [expr $nplot/$nx + 1]
        } else {
            set ny [expr $nplot/$nx]
        }
    }
    # adjust the np
    set np [format %.2f [expr double($nplot)/$pp]]
    
    return [list pp $pp  np $np  nx $nx  ny $ny  fsize $fsize]                
}
#******


#****f* ::pwtk::gp/::pwtk::gp::gp2pwtk
# SYNOPSIS
proc ::pwtk::gp::gp2pwtk {term} {
    # PURPOSE
    #   Map a Gnuplot terminal name to a PWTK terminal name.
    # SOURCE
    variable pwtk2gp
    foreach name [lsort [array names pwtk2gp]] {
        if { $pwtk2gp($name) == $term } {
            return $name
        }
    }
    return $term
}
#******


#****f* ::pwtk::gp/::pwtk::gp::pwtk2gp
# SYNOPSIS
proc ::pwtk::gp::pwtk2gp {term} {
    # PURPOSE
    #   Map a PWTK terminal name to a Gnuplot terminal name.
    # SOURCE
    variable pwtk2gp
    if { [info exists pwtk2gp($term)] } {
        return $pwtk2gp($term)
    } else {
        return $term
    }
}
#******


#****if* Internals/::pwtk::gp::output
# SYNOPSIS
proc ::pwtk::gp::output {term {head {p}} {pageNo {}}} {
    # PURPOSE
    #   Get the output filename for a given file terminal or empty
    #   string if a terminal is not among $gp(file.terminals).
    # SOURCE
    variable gp
    set ext  [gp2pwtk $term]
    set term [pwtk2gp $term]
    if { $term in $gp(file.terminals) } {
        switch -glob -- $term {
            postscript - pdf* {
                return $head.$ext
            }
            default {
                if { $pageNo ne {} } {
                    return $head-$pageNo.$ext
                } else {
                    return $head.$ext
                }
            }
        }
    } else {
        return {}
    }            
}
#******


#****f* ::pwtk::gp/::pwtk::gp::new_page_multiplot
# SYNOPSIS
proc ::pwtk::gp::new_page_multiplot {term pageNo mpName pauseValue {head {}}} {
    # PURPOSE
    #   Get a Gnuplot snippet for a new page for a multiplot. Do not
    #   confuse it with ::pwtk::gp::new_page_plot that is used for single-plot.
    #
    #   Typically used internally by PWTK.
    #
    # ARGUMENTS
    # * term   --- terminal type
    # * pageNo --- page number of the new page
    # * mpName --- name of the multiplot_array variable
    # * head   --- [optional] the rootname of the Gnuplot's output file
    #
    # SOURCE
    variable gp
    upvar $mpName mp
    
    if { ! [info exists mp] } {
        ::error "multiplot_array \"$mpName\" does not exists"
    }

    array set a [pause_ $pauseValue]    
    set term [pwtk2gp $term]

    if { $pageNo > 1 } {
        if { $term in $gp(file.terminals) || $term in $gp(txt.terminals) } {
            set clear "\nunset multiplot"
        } else {
            # case: $term in $gp(win.terminals)
            set clear "\npause $a(pause)\nunset multiplot"
        }
        set output "\nset output '[output $term $head $pageNo]'"
    } else {
        set clear  ""
        set output ""
    }
               
    if { $term in $gp(file.terminals) } {
        switch -- $term {
            pdfcairo - postscript {
                return "$clear
set multiplot layout $mp(ny),$mp(nx)
"
            }
            default {
                return "${clear}$output
set multiplot layout $mp(ny),$mp(nx)
"
            }
        }        
    } elseif { $term in $gp(win.terminals) } {
        if { $pageNo == $mp(pp) } {
            set title "Page $pageNo/$mp(pp)  ($a(pauseText) to Exit)"
        } else {
            set title "Page $pageNo/$mp(pp)  ($a(pauseText) to continue to next page)"
        }
        if  { $term ne {} } {
            # this does not work for empty, {}, window terminal
            return "$clear
set term $term title '$title'
set multiplot layout $mp(ny),$mp(nx) title '$title' font '$gp(font),$gp(fontSize)'
"
        } else {
            # empty terminal
            return "$clear
set multiplot layout $mp(ny),$mp(nx) title '$title'
"
        }
    } elseif { $term in $gp(txt.terminals) } {
        # txt and empty window terminal
        return "$clear
set multiplot layout $mp(ny),$mp(nx) title 'Page $pageNo/$mp(pp)'
"
    } else {
        ::pwtk::error "unsupported PWTK terminal \"$term\", must be one of [join $gp(terminals) {, }]" 1
    }
}
#******


#****f* ::pwtk::gp/::pwtk::gp::new_page_plot
# SYNOPSIS
proc ::pwtk::gp::new_page_plot {term pageNo pauseValue {head {}}} {
    # PURPOSE
    #   Get a Gnuplot snippet for a next/new page for a single-plot. Do not
    #   confuse it with ::pwtk::gp::new_page_multiplot that is used for multiplot.
    #
    #   Typically used internally by PWTK.
    #
    # ARGUMENTS
    # * term   --- terminal type
    # * pageNo --- page number of the new page
    # * head   --- [optional] the rootname of the Gnuplot's output file
    #
    # SOURCE
    variable gp

    array set a [pause_ $pauseValue]    
    set term [pwtk2gp $term]

    if { $term in $gp(file.terminals) } {
        switch -- $term {
            pdfcairo - postscript {
                return ""
            }
            default {
                return "set output '[output $term $head $pageNo]'\n"
            }
        }
        
    } elseif { $term in $gp(win.terminals) } {
        
        set title "Page $pageNo  ($a(pauseText))"
        set pause [expr { $pageNo > 1 ? "pause $a(pause)" : "" }]    
               
        if  { $term ne {} } {
            # this does not work for empty window terminal, {}
            return "$pause\nset term $term title '$title'\n"
        } else {
            # empty terminal
            return "$pause\n"
        }
    } elseif { $term in $gp(txt.terminals) } {
        # txt and empty window terminal
        return ""
        
    } else {
        ::pwtk::error "unsupported PWTK Gnuplot terminal \"$term\", must be one of [join $gp(terminals) {, }]" 1
    }
}
#******


#****if* Internals/::pwtk::gp::expandOptions
# SYNOPSIS
proc ::pwtk::gp::expandOptions {arr_set_list} {
    # PURPOSE
    #   Convert PWTK's options, passed as input (i.e. $arr_set_list),
    #   to Gnuplot options snippet according to the order, defined in
    #   $known_options. The PWTK's predefined options are also added
    #   to the output snippet.
    #
    # N.B. this routine is used only in pseudo.tcl
    #
    # SOURCE
    variable known_options

    foreach name $known_options {
        pwtk::ifexist ::pwtk::gp::options($name) {
            set arr($name) $::pwtk::gp::options($name)
        }
    }

    # sort options according to $known_options

    set opts $known_options
    
    foreach {name value} $arr_set_list {
        if { $name ni $opts } {
            # new option: let's add it to the opts list
            lappend opts $name
        }
        set arr($name) $value
    }

    set options {}
    foreach elem $opts {
        ::pwtk::ifnotempty arr($elem) {
            # PWTK-->Gnuplot (e.g. format.x --> format x)
            set opt [split $elem .]
            append options "set $opt $arr($elem)\n"
        }
    }
    return $options\n
}
#******


#****if* Internals/::pwtk::gp::checkCmdlineOpts_
# SYNOPSIS
proc ::pwtk::gp::checkCmdlineOpts_ {optVar} {
    # DESCRIPTION
    #   Check the value of the command-line specified "short" options
    #   for Gnuplot (used by ::pwtk::gp::plot::cmdlineOpts).
    # SOURCE

    upvar $optVar opt

    ::pwtk::ifnotempty opt(clw) { uplevel 1 [list ::pwtk::checkOType_ -clw $opt(clw) {number nonnegreal} "non-negative number"] }
    ::pwtk::ifnotempty opt(i)   { uplevel 1 [list ::pwtk::checkOType_ -i   $opt(i)   {numberlist integer} "list of integer numbers"] }

    ::pwtk::ifnotempty opt(xr) { uplevel 1 [list ::pwtk::checkOType_ -xr $opt(xr) gp_range "xmin:xmax range"] }
    ::pwtk::ifnotempty opt(yr) { uplevel 1 [list ::pwtk::checkOType_ -yr $opt(yr) gp_range "ymin:ymax range"] }
    ::pwtk::ifnotempty opt(zr) { uplevel 1 [list ::pwtk::checkOType_ -zr $opt(zr) gp_range "zmin:xmax range"] }
    ::pwtk::ifnotempty opt(cbr) { uplevel 1 [list ::pwtk::checkOType_ -cbr $opt(cbr) gp_range "cbmin:cbmax range"] }
    ::pwtk::ifnotempty opt(x2r) { uplevel 1 [list ::pwtk::checkOType_ -x2r $opt(x2r) gp_range "x2min:x2max range"] }
    ::pwtk::ifnotempty opt(y2r) { uplevel 1 [list ::pwtk::checkOType_ -y2r $opt(y2r) gp_range "y2min:y2max range"] }
    ::pwtk::ifnotempty opt(s)   { uplevel 1 [list ::pwtk::checkOType_ -s   $opt(s)   gp_size  "sx,sy size"] }
}
#******


#****if* Internals/::pwtk::gp::defaultCmdlineOpts_
# SYNOPSIS
proc ::pwtk::gp::defaultCmdlineOpts_ {which optionsVar usageVar {workflow {}}} {
    # DESCRIPTION
    #   Load default command-line "short" options specs for Gnuplot
    #   (e.g. these options are used by ::pwtk::gp::plot::cmdlineOpts).
    # ARGUMENTS
    # * which      --- which options to load 'plot' or 'splot'
    # * optionsVar --- name of the 'options' variable
    # * usageVar   --- name of the 'usage' variable
    # * workflow   --- if not empty && not false, load defaults for workflow plot (i.e. terminal = eps)
    # SOURCE
    uplevel 1 [list set $optionsVar {}]
    uplevel 1 [list set $usageVar   {}]

    upvar $optionsVar options
    upvar $usageVar   usage

    switch -exact -- $which {
        plot {
            set options $::pwtk::gp::plot_options
            set usage   $::pwtk::gp::plot_usage
        }
        splot {
            set options $::pwtk::gp::splot_options
            set usage   $::pwtk::gp::splot_usage
        }
        default {
            ::pwtk::error "wrong options type, must be 'plot' or 'splot', but got '$which'" 1
        }
    }

    if { $workflow ne {} } {
        if { !([string is boolean -strict $workflow] && !$workflow) } {
            ::pwtk::setOpts_ options [subst {
                t  $::pwtk::gp::gp(workflow.terminal)
            }]
        }
    }
}
#******


#****if* Internals/::pwtk::gp::execDisplay_
# SYNOPSIS
proc ::pwtk::gp::execDisplay_ {gp optVar} {
    # PURPOSE
    #   Execute gnuplot and if $opt(v), display the resulting plot for
    #   file terminals.
    # ARGUMENTS
    # * gp -- Gnuplot object
    # * optVar -- name of 'opt' array
    # RETURN VALUE
    #   Filenames of the created Gnuplot plots (for file terminals) or the
    #   empty string (for window terminals).
    # SOURCE
    upvar $optVar opt

    $gp exec
    set output [$gp outputs]
    $gp destroy

    displayPlots_ $opt(v) $opt(t) $output

    return $output
}
#******


#****if* Internals/::pwtk::gp::displayPlots_
# SYNOPSIS
proc ::pwtk::gp::displayPlots_ {visualize term images} {
    # PURPOSE
    #   Display Gnuplot generated image(s) if $visualize && $term in $gp(file.terminals)
    # ARGUMENTS
    # * visualize -- boolean flag for visualize or not
    # * term -- gnuplot terminal
    # * images -- list of images to visualize
    # SOURCE

    set term [gp2pwtk [term_usable $term]]

    if { $visualize && [::pwtk::getViewer $term] ne {} } {
        foreach img $images {
            try {
                print "Visualizing $img ..."
                ::pwtk::display $img
            } on error err {
                ::pwtk::error "cannot visulize the $img plot\n\n$err"
            }
        }
        ::pwtk::ifnotempty images { puts "" }
    }
}
#******



#****c* ::pwtk::gp/::pwtk::gp::plot
#
# PURPOSE
#    A class for creating single-plot Gnuplot objects, i.e., objects
#    for creating Gnuplot plots in a single-plot mode (for
#    multiplot-mode, see the ::pwtk::gp::multiplot class).
#
# SEE ALSO
#   For further details, see: plot::constructor
#
# EXAMPLE
#    # create with Gnuplot a PNG image of sin(x) function
#    
#    set obj [::pwtk::gp::plot new sin.png]
#    
#    $obj options {
#           xlabel {'x'}
#           ylabel {'sin(x)'}
#    }
#    $obj options {
#           xzeroaxis {lt -1}
#    }
#    $obj unset key grid
#    $obj plot { [-pi:pi] sin(x) }
#    
#    $obj exec; # this executes Gnuplot and creates sin.png image
#
#******

::oo::class create ::pwtk::gp::plot {
    #
    # In this class, the Gnuplot script consists of prolog & content
    #
    # prolog: contains a terminal definition and what comes with it;
    #         it can only be set durinf the objection creation (it is immutable)
    #
    # content: the rest of the gnuplot script (mutable)
    #

    variable prolog
    variable content
    variable head; # rootname of gnuplot script and output file
    variable term; # PWTK's terminal name and filename extension for file.terminals
    variable my_options; # iron options (i.e. a copy of ::pwtk::gp::options)
    variable options_initiated; # 1 for options initiated, 0 otherwise (options are initiated by calling the 'options' method)
    variable options_list; # contains excerpt of gnuplot script with sorted "set option value" list of gnuplot options
    variable outputs; # name of Gnuplot plots (for file terminals)
    variable page; # page-number counter (used by the new_page method)
    variable pause; # this object value for Gnuplot pause
    variable pauseText; # the text associated with the Gnuplot pause
    
    #****m* ::pwtk::gp::plot/plot::constructor
    # SYNOPSIS
    constructor {args} {
        # PURPOSE
        #   Create a new single-plot Gnuplot object.
        #
        # HOW TO USE
        #   The 'plot' Gnuplot object is created as:
        #
        #      set obj [pwtk::gp::plot new  ?OPTIONS?  ?HEAD.TERM?]
        #
        #   where OPTIONS are:
        #      -o  ORIENT
        #      -s  SX,SY
        #      -fs FONTSIZE
        #      -t  TITLE
        #      -spin
        #      -p
        #      -pause PAUSE
        #
        # ARGUMENTS
        # * OPTIONS --- see OPTIONS below
        
        # * HEAD.TERM --- (optional) "HEAD" is the rootname of gnuplot script;
        #                 "TERM" is the type of terminal (PWTK's terminal name) and
        #                 the file's extension if plot is printed to a file;
        #                 possible values are those returned by ::pwtk::gp::pwtk_terminals;
        #                 if the HEAD.TERM is omitted, a default window terminal is used
        #                 and HEAD is set to "plot"
        #
        # OPTIONS
        # * -o ORIENT    --- page orientation (portrait or landscape); used explicitly only for
        #                    EPS, while for other terminals, it's a hint for the multiplot layout
        # * -s SX,SY     --- terminal size (i.e. window or picture size)
        # * -fs FONTSIZE --- font size
        # * -t TITLE     --- the window title (for window-type terminals only)
        # * -spin        --- spin-PDOS-like plots with positive & negative Y-values, f(x) & -f(x)        
        # * -p           --- signals that more than one single-plot will be plotted (for PNG-like
        #                    terminals, the name of output image will be $head-$pageNumber.png)
        # * -pause PAUSE --- value for the Gnuplot's pause command (useful for window terminals)
        #
        # RETURN VALUE
        #   The Gnuplot single-plot object.        
        #
        # SOURCE
        
        set options_initiated 0
        array set my_options [array get ::pwtk::gp::options]
        set page 1; # N.B. page must be 1 for new_page to work correctly

        # parse command-line options/arguments
        
        set argsOrig $args
        set nargmin 0
        set nargmax 1
        set usage "new ?-p?  ?-o ORIENT?  ?-s SIZE?  ?-fs FONTSIZE?  ?-t TITLE?  ?-pause PAUSE?  ?-spin?  ?HEAD.TERM?"
        ::pwtk::gp::parseOpt_term_

        if { $args ne {} } {
            set head [::pwtk::gp::head_ $args]
            set term [::pwtk::gp::term_ $args]
            set args [lrange $argsOrig 0 end-1]
        } else {
            set id [incr ::pwtk::gp::plot_id]
            set head [::pwtk::gp::head_ plot-$id.win]
            set term [::pwtk::gp::term_ plot-$id.win]
            set args $argsOrig
        }

        # -pause
        my pause_ -1 $opt(pause)

        # specially handle the -t option
        set title {}
        if { $term in $::pwtk::gp::gp(win.terminals) } {
            if { $opt(p) == 0 } {
                set t [string trim "$opt(t) ($pauseText to Exit)"]
            } else {
                set t [string trim "$opt(t) ($pauseText to continue to next page)"]
            }
            set title [list -t $t]
        }

        set prolog [::pwtk::gp::get_term {*}$args {*}$title $head.$term]\n
    }
    #******

    
    # internal...
    method pause_ {defValue optValue} {
        # PURPOSE
        #   Set a pause value for the 'pause' gnuplot command.
        # ARGUMENTS
        # * defValue --- default value for this class
        # * optValue --- value specified with the -pause option
        
        set pause $defValue
        if { $optValue ne {} } {
            set pause $optValue
        }
        # if ::pwtk::gp::gp(pause) exists, it has a global preference
        # (usefull for tests, examples, demos)
        ::pwtk::ifnotempty ::pwtk::gp::gp(pause) {
            set pause $::pwtk::gp::gp(pause)
        }
        set pauseText [dict get [::pwtk::gp::pause_ $pause] pauseText]
    }

    
    #****m* ::pwtk::gp::plot/plot::options
    # SYNOPSIS
    method options {arr_set_list} {
        # USAGE
        #   $obj options {
        #      option1 value1
        #      option2 value2
        #      ...
        #   }
        #
        # PURPOSE        
        #   Set options for Gnuplot. To explain the syntax of "option value"
        #   pairs, consider the following Gnuplot snippet:
        #
        #       set xlabel "Distance (Bohr)"
        #       set ylabel 'Energy (Ry)'
        #       set format x '%3.1f'
        #       set format y '%3.1f'
        #
        #   This snippet is specified as:
        #
        #     $obj options {
        #        xlabel {"Distance (Bohr)"}
        #        ylabel {'Energy (Ry)'}
        #        format.x '%3.1f'
        #        format.y '%3.1f'
        #     }
        #
        # BEWARE        
        #   If the value consists of double-quotes or more than one
        #   field, it needs to be grouped with curly braces!
        #
        # REMARK
        #   PWTK will sort the options according to PWTK's preset order of options.
        #
        # SOURCE
        
        if { ! $options_initiated } {
            foreach name $::pwtk::gp::known_options {
                if { [info exists my_options($name)] } {
                    set arr($name) $my_options($name)
                }
            }
            set options_initiated 1
            set options_list $::pwtk::gp::known_options
        }

        # we want the options sorted according to $::pwtk::gp::known_options

        foreach {name value} $arr_set_list {
            set arr($name) $value
            
            if { $name ni $options_list } {
                # unknown (i.e. new) option: let's add it to the list of known options
                lappend options_list $name
            }
        }

        foreach elem $options_list {
            ::pwtk::ifnotempty arr($elem) {
                # PWTK-->Gnuplot (e.g. format.x --> format x)
                set opt [split $elem .]
                append content "set $opt $arr($elem)\n"
            }
        }        
        append content \n
    }
    #******


    #****m* ::pwtk::gp::plot/plot::set
    # SYNOPSIS
    method set {opt value} {
        # PURPOSE
        #   Set a gnuplot option.
        # ARGUMENTS
        # * opt -- name of Gnuplot options (e.g. xtics, xlabel...)
        # * value -- value of the gnuplot option
        # EXAMPLE
        #     $obj set xlabel 'This is label' offset -1
        #
        # SOURCE
        my options_initiate_
        append content "set $opt $value\n\n"
    }
    #******
    

    #****m* ::pwtk::gp::plot/plot::unset
    # SYNOPSIS
    method unset {args} {
        # USAGE
        # Either:
        #    $obj unset option1 ?option2? ?option3? ...
        # or:
        #    $obj unset { option1 ?option2? ?option3? ... }
        # ARGUMENTS
        # * args --- various Gnuplot options to unset
        # PURPOSE
        #   Unset Gnuplot options
        # SOURCE
        my options_initiate_
        foreach opt [my parse_ $args] {
            append content "unset $opt\n"
        }
        append content \n
    }
    #******


    #****m* ::pwtk::gp::plot/plot::add
    # SYNOPSIS
    method add {snippet} {
        # USAGE
        #   $obj add $snippet
        # PURPOSE
        #   Add a snippet to the Gnuplot script.
        # EXAMPLE
        #     $obj add {
        #         unset key
        #         plot [-pi:pi] sin(x)
        #     }
        #
        # SOURCE
        my options_initiate_
        append content $snippet\n\n
    }
    #******
    

    #****m* ::pwtk::gp::plot/plot::config
    # SYNOPSIS
    method config {args} {
        # PURPOSE
        #   Configure the plot using the shortcut command-line options
        #   as defined by the ::pwtk::gp::plot_options variable.
        #
        #   After the command-line options are parsed, the
        #   'cmdlineOpts' method is called.
        #
        # ARGUMENT
        # * args -- command-line options
        #
        # SOURCE

        ::pwtk::gp::defaultCmdlineOpts_ plot options usage
        set narg 0
        ::pwtk::parseOpt_
        my cmdlineOpts opt
    }
    #******


    #****m* ::pwtk::gp::plot/plot::cmdlineOpts
    # SYNOPSIS
    method cmdlineOpts {optVar} {
        # PURPOSE
        #   A convenience method to facilitate easier handling of command-line
        #   options used by scanpar.tcl, pdos.tcl, bands.tcl, etc.
        #
        # ARGUMENT
        # * optVar -- name of the 'opt' array of ::pwtk::parseOpt_
        #
        # SOURCE

        upvar $optVar opt
        ::pwtk::gp::checkCmdlineOpts_ opt

        ::pwtk::ifnotempty opt(xt)  { my set xtics $opt(xt) }
        ::pwtk::ifnotempty opt(yt)  { my set ytics $opt(yt) }
        ::pwtk::ifnotempty opt(x2t) { my set x2tics $opt(x2t) }
        ::pwtk::ifnotempty opt(y2t) { my set y2tics $opt(y2t) }

        ::pwtk::ifnotempty opt(mx)  { my set mxtics $opt(mx) }
        ::pwtk::ifnotempty opt(my)  { my set mytics $opt(my) }
        ::pwtk::ifnotempty opt(mx2) { my set mx2tics $opt(mx2) }
        ::pwtk::ifnotempty opt(my2) { my set my2tics $opt(my2) }

        ::pwtk::ifnotempty opt(xl)  { my set xlabel [::pwtk::squote $opt(xl)] }
        ::pwtk::ifnotempty opt(yl)  { my set ylabel [::pwtk::squote $opt(yl)] }
        ::pwtk::ifnotempty opt(x2l) { my set x2label [::pwtk::squote $opt(x2l)] }
        ::pwtk::ifnotempty opt(y2l) { my set y2label [::pwtk::squote $opt(y2l)] }

        ::pwtk::ifnotempty opt(xr)  { my set xrange [::pwtk::rangequote $opt(xr)] }
        ::pwtk::ifnotempty opt(yr)  { my set yrange [::pwtk::rangequote $opt(yr)] }
        ::pwtk::ifnotempty opt(x2r) { my set x2range [::pwtk::rangequote $opt(x2r)] }
        ::pwtk::ifnotempty opt(y2r) { my set y2range [::pwtk::rangequote $opt(y2r)] }

        ::pwtk::ifnotempty opt(xf)  { my set format "x [::pwtk::squote $opt(xf)]" }
        ::pwtk::ifnotempty opt(yf)  { my set format "y [::pwtk::squote $opt(yf)]" }
        ::pwtk::ifnotempty opt(x2f) { my set format "x2 [::pwtk::squote $opt(x2f)]" }
        ::pwtk::ifnotempty opt(y2f) { my set format "y2 [::pwtk::squote $opt(y2f)]" }

        ::pwtk::ifnotempty opt(tm) { my set tmargin $opt(tm) }
        ::pwtk::ifnotempty opt(bm) { my set bmargin $opt(bm) }
        ::pwtk::ifnotempty opt(lm) { my set lmargin $opt(lm) }
        ::pwtk::ifnotempty opt(rm) { my set rmargin $opt(rm) }

        ::pwtk::ifnotempty opt(key)   { my set key  $opt(key) }
        ::pwtk::ifnotempty opt(grid)  { my set grid $opt(grid) }
        ::pwtk::ifnotempty opt(title) { my set title $opt(title) }

        ::pwtk::ifnotempty opt(x) { my add $opt(x) }
    }
    #******

    
    #****m* ::pwtk::gp::plot/plot::plot
    # SYNOPSIS
    method plot {args} {
        # USAGE
        # Either:
        #    $obj plot PLOT_SPECS
        # or
        #    $obj plot { PLOT_SPECS }    
        # PURPOSE
        #   Add the "plot" snippet to the Gnuplot script (i.e.,
        #   plot $args, where $args are correctly parsed for Gnuplot).
        # EXAMPLE
        #   $obj plot sin(2*x) w l lw 3 lt 1, cos(x) w l lw 5 lt 3
        #   $obj plot { 1 + sin(x) + cos(x), exp(x) }
        # SOURCE
        my options_initiate_
        my add [concat plot [my parse_ $args]]
    }
    #******
    
    #****m* ::pwtk::gp::plot/plot::new_page
    # SYNOPSIS
    method new_page {} {
        # USAGE
        #   $obj new_page
        # PURPOSE
        #   Increase the page counter and add a snippet for the new
        #   page in the Gnuplot script.
        # SOURCE

        incr page
        append content [::pwtk::gp::new_page_plot $term $page $pause $head]\n

        if { [::pwtk::gp::pwtk2gp $term] in $::pwtk::gp::gp(file.terminals) } {            
            if { $page < 2 } {
                lappend outputs [::pwtk::gp::output $term $head]
            } else {
                lappend outputs [::pwtk::gp::output $term $head $page]
            }
        }
    }
    #******

    #****m* ::pwtk::gp::plot/plot::outputs
    # SYNOPSIS
    method outputs {} {
        # USAGE
        #   $obj outputs
        # RETURN VALUE    
        #   Return the output files (images) that will be produced by the
        #   current Gnuplot script.
        # SOURCE
        if { [info exists outputs] } {
            return [lsort -unique $outputs]
        } elseif { [::pwtk::gp::pwtk2gp $term] in $::pwtk::gp::gp(file.terminals) } {
            return $head.$term
        } else {
            return {}
        }
    }
    #******
    
    #****m* ::pwtk::gp::plot/plot::dump
    # SYNOPSIS
    method dump {} {
        # USAGE
        #   $obj dump
        # PURPOSE
        #   Returns a Gnuplot script.
        # SOURCE
        my options_initiate_
        set script ${prolog}${content}\n
        if { [::pwtk::gp::pwtk2gp $term] in $::pwtk::gp::gp(win.supported_terminals) } {
            append script "pause $pause\n"
        }
        return $script        
    }
    #******
    
    #****m* ::pwtk::gp::plot/plot::write
    # SYNOPSIS
    method write {} {
        # USAGE
        #   $obj write
        # PURPOSE
        #   Write a Gnuplot script to the $head.gp file.
        # SOURCE
        if { [::pwtk::gp::pwtk2gp $term] in $::pwtk::gp::gp(win.terminals) } {
            set txt "\n($pauseText to continue)\n"
        }
        print "Gnuplot script written to:   $head.gp[varvalue txt]"
        ::pwtk::writeFile $head.gp [my dump]
        return $head.$term
    }
    #******

    
    #****m* ::pwtk::gp::plot/plot::exec
    # SYNOPSIS
    method exec {} {
        # USAGE
        #   $obj exec
        # PURPOSE
        #   Write a Gnuplot script to the $head.gp file and execute Gnuplot.
        # SOURCE
        my write
        try {
            #exec gnuplot --persist $head.gp
            set result [exec -ignorestderr gnuplot $head.gp]
        } on error err {
            ::pwtk::error "an error occurred while executing gnuplot\n\n$err"
        }

        set ext [string toupper $term]
        set ots [my outputs]
        foreach img $ots {
            print "      $ext plot written to:   $img"
        }
        if { $ots ne {} } { puts "" }

        ::pwtk::ifnotempty result {
            puts $result
        }
        return [::pwtk::varvalue result]
    }
    #******

    
    #****m* ::pwtk::gp::plot/plot::clear    
    # SYNOPSIS
    method clear {} {
        # USAGE
        #   $obj clear
        # PURPOSE
        #   Clear the "content" part of the Gnuplot script.
        # SOURCE
        set content {}
        set options_initiated 0
    }
    #******

    # internal...
    method parse_ {arguments} {
        # PURPOSE
        #   Correctly parse arguments ($args) for gnuplot (i.e. by
        #   parsing arguments, Tcl converts "a b" to {a b}, which is
        #   not OK for gnuplot because it must be "a b"        
        if { [llength $arguments] == 1 } {
            return [concat {*}$arguments]\n            
        } else {
            set x ""
            foreach arg $arguments {
                if { [llength $arg] > 1 } {
                    append x " \"$arg\""
                } else {
                    append x " $arg"
                }
            }
            return $x\n
        }
    }

    # internal...
    method options_initiate_ {} {
        # PURPOSE
        #   To always have a default set of options defined so that
        #   gnuplot plots are nice by default.
        if { ! $options_initiated } {
            my options {}
        }
    }
}


#****c* ::pwtk::gp/::pwtk::gp::multiplot
#
# DERIVED FROM
#    ::pwtk::gp::plot
#
# PURPOSE
#    A class for creating multiplot Gnuplot objects, i.e., objects for
#    creating Gnuplot plots in a multiplot mode (for single plots, see
#    the ::pwtk::gp::plot class). It is derived from the
#    ::pwtk::gp::plot class, implying that the methods of ::pwtk::gp::plot
#    can be used.
#
# HOW TO USE
#   The 'multiplot' Gnuplot object is created as:
#      set obj [::pwtk::gp::multiplot new ?OPTIONS? auto NPLOTS ?NPMAX? ?NX?  ?HEAD.TERM?]
#   or:
#      set obj [::pwtk::gp::multiplot new ?OPTIONS? manual PP NX NY  ?HEAD.TERM?]
# 
# SEE ALSO
#   For further details, see: multiplot::constructor
#
# EXAMPLE
#   # create with Gnuplot a PDF of sin(x) and cos(x) functions on p.1
#   # and tan(x) and exp(x) on p.2
#
#   set obj [pwtk::gp::multiplot new manual 2 2 1 multiplot.pdf]
#
#   $obj options {
#          xlabel {'x'}
#          ylabel {'f(x)'}
#          xzeroaxis {lt -1}
#   }
#
#   $obj plot {[-pi:pi] sin(x)}
#   $obj plot {[-pi:pi] cos(x)}
#   
#   $obj new_page
#
#   # in "manual" mode, plot can be done also via the "add" method
#   $obj add {
#          plot [-pi:pi] tan(x)
#          plot [-pi:pi] exp(x)
#   }
#   $obj exec; # this executes Gnuplot and creates multiplot.pdf file
#
#
#******

::oo::class create ::pwtk::gp::multiplot {
    superclass ::pwtk::gp::plot

    # used in ::pwtk::gp::plot
    variable prolog
    variable content
    variable head
    variable term
    variable my_options; # iron options (i.e. a copy of ::pwtk::gp::options)
    variable options_initiated; # 1 for options initiated, 0 otherwise (options are initiated by calling the 'options' method)
    variable options_list; # contains excerpt of gnuplot script with sorted "set option value" list of gnuplot options
    variable outputs; # name of Gnuplot plots (for file terminals)
    variable page; # page-number counter
    variable pause; # this object value for Gnuplot pause
    variable pauseText; # the text associated with the Gnuplot pause
    
    # used only here
    variable mp; # array holding multiplot/multipage data
    variable plot; # plot-number counter on the current-page
    variable mode; # mode = auto | manual
    
    #****m* ::pwtk::gp::multiplot/multiplot::constructor
    # SYNOPSIS
    constructor {args} {
        # PURPOSE
        #   Create a new Gnuplot multi-plot object.
        #
        # HOW TO USE
        # Either:
        #    set obj [::pwtk::gp::multiplot new ?OPTIONS? auto NPLOTS ?NPMAX? ?NX?  ?HEAD.TERM?]
        # or:
        #    set obj [::pwtk::gp::multiplot new ?OPTIONS? manual PP NX NY  ?HEAD.TERM?]
        # where OPTIONS are:
        #    -o  ORIENT
        #    -s  SX,SY 
        #    -fs FONTSIZE
        #    -t  TITLE    
        #    -spin       
        #    -pause PAUSE        
        #
        # ARGUMENTS
        # * OPTIONS --- see OPTIONS below
        
        # * auto | manual --- automatic or manual mode (see below)
        
        # * NPLOTS, NPMAX, NX, PP, NY --- see below
        
        # * HEAD.TERM --- "HEAD" is the rootname of Gnuplot script;
        #                 "TERM" is the type of terminal (PWTK's terminal name) and
        #                        the file's extension if plot is printed to a file;
        #                        possible values are those returned by ::pwtk::gp::pwtk_terminals
        #
        # OPTIONS
        # * -o ORIENT    --- page orientation (portrait or landscape); used explicitly only for
        #                    EPS, while for other terminals, it's a hint for the multiplot layout
        # * -s SX,SY     --- terminal size (i.e. window or picture size)
        # * -fs FONTSIZE --- font size
        # * -t TITLE     --- the window title (for window-type terminals only)
        # * -spin        --- spin-PDOS-like plots with positive & negative Y-values, f(x) & -f(x)
        # * -pause PAUSE --- value for the Gnuplot's pause command (useful for window terminals)
        #
        # DESCRIPTION
        #   Two modes of multiplot Gnuplot objects are possible:
        #   * auto
        #   * manual
        #
        #   |html The <b>auto</b> mode:
        #   PWTK determines how to arrange plots on the page, i.e.,
        #   number of plots in X- and Y-directions (columns and
        #   rows). The nplots, npmax, and nx are:        
        #   * NPLOTS --- hint for the number of pages (one or more)
        #   * NPMAX  --- (optional) maximum number of plots per page
        #   * NX     --- (optional) number of plots in X-direction
        #
        #   |html The <b>manual</b> mode:
        #   User manually specifies the layout by specifying pp, nx,
        #   ny, where:        
        #   * PP --- hint for the number of pages (one or more)
        #   * NX --- number of plots in X-direction (i.e. columns)
        #   * NY --- number of plots in Y-direction (i.e. rows)
        #        
        # SOURCE

        set options_initiated 0
        array set my_options [array get ::pwtk::gp::options]
        
        set page 0
        set plot 0
                
        # command-line arguments usage:
        #      ?OPTIONS? auto   NPLOTS ?NPMAX? ?NX?  ?HEAD.TERM?
        #      ?OPTIONS? manual PP NX NY  ?HEAD.TERM?

        set nargmin 2
        set nargmax 5
        set usage "new ?-o ORIENT?  ?-s SIZE?  ?-fs FONTSIZE?  ?-t TITLE?  ?-spin?  {auto NPLOTS ?NPMAX? ?NX? | manual PP NX NY}  ?HEAD.TERM?"
        ::pwtk::gp::parseOpt_term_

        set mode [lindex $args 0]
        
        switch -- $mode {
            auto {
                # args == auto NPLOTS ?NPMAX? ?NX? ?HEAD.TERM?
                #
                # where: NPMAX = (optional) max # plots per page, overwrites default
                #        NX    = (optional) max # of plots in X-dir, overwrites default

                set nplot   [lindex $args 1]
                set lastarg [lindex $args end]
                
                if { ! [string is integer -strict $lastarg] } {
                    set head_dot_term $lastarg
                    set args [lrange $args 0 end-1]
                } else {
                    set id [incr ::pwtk::gp::multiplot_id]
                    set head_dot_term multiplot-$id.win
                }
                set orient [::pwtk::gp::orient [::pwtk::gp::term_ $head_dot_term] $opt(s) $opt(t)]

                set len   [llength $args]
                set npmax [expr { $len >= 3 ? [lindex $args 2] : -1 }]
                set nx    [expr { $len == 4 ? [lindex $args 3] : -1 }]

                if { ! [::pwtk::type::number posint -strict $nplot] } {
                    ::pwtk::error "NPLOT must be positive integer, but got $nplot" 1
                }
                if { ! [string is integer -strict $npmax] || ! [string is integer -strict $nx] } {
                    ::pwtk::error "NPMAX and NX must be integers, but got $npmax and $nx" 1
                }
                array set mp [::pwtk::gp::multiplot_array $nplot $npmax $nx $orient $opt(spin)]
            }
            
            manual {                
                # args == manual PP NX NY  ?HEAD.TERM?
                
                set pp [lindex $args 1]
                set nx [lindex $args 2]
                set ny [lindex $args 3]
                set lastarg [lindex $args 4]
                
                if { $lastarg ne {} } {
                    set head_dot_term $lastarg
                    set args [lrange $args 0 end-1]
                } else {
                    set id [incr ::pwtk::gp::multiplot_id]
                    set head_dot_term multiplot-$id.win
                }

                if { ! [::pwtk::type::number posint -strict $pp] \
                         || ! [::pwtk::type::number posint -strict $nx] \
                         || ! [::pwtk::type::number posint -strict $ny] } {
                    ::pwtk::error "PP, NX, NY must be positive integers, but got: \"$args\"" 1
                }
                array set mp [subst {
                    pp $pp
                    np [expr $nx*$ny]
                    nx $nx
                    ny $ny}]
                set mp(fsize) $opt(fs)
            }
            
            default {
                ::pwtk::error "unkown mode \"$mode\", must be either auto or manual" 1
            }
        }

        set head [::pwtk::gp::head_ $head_dot_term]
        set term [::pwtk::gp::term_ $head_dot_term]
        
        # -s
        
        if { $opt(s) == {} } {
            switch -- [::pwtk::gp::gp2pwtk $term] {
                eps { set size $::pwtk::gp::gp(eps.multisize) }
                pdf { set size $::pwtk::gp::gp(pdf.multisize) }
                default { set size $::pwtk::gp::gp(multisize) }
            }
        } else {
            set size $opt(s)
        }

        # -fs
        
        if { $opt(fs) == {} } {
            set fsize $mp(fsize)
        } else {
            set fsize $opt(fs)
        }

        # -spin & -p

        set opts {}
        if { $mp(pp) > 1 } {
            append opts "-p "
        }
        if { $opt(spin) } {
            append opts "-spin "
        }

        # -pause
        
        my pause_ mouse $opt(pause)

        # -t
        
        if { $opt(t) == {} } {
            if { $term in $::pwtk::gp::gp(win.terminals) } {
                if { $mp(pp) == 1 } {
                    set next "($pauseText to Exit)"
                } else {
                    set next "($pauseText to continue to next page)"
                }        
                set title "Page 1/$mp(pp)  $next"
            } else {
                set title {}
            }        
        } else {
            set title "title '[string trim $opt(t) ']'"
        }

        set prolog [::pwtk::gp::get_term {*}$opts -o $opt(o) -s $size -fs $fsize -t $title $head_dot_term]\n
    }
    #******

    
    #****m* ::pwtk::gp::multiplot/multiplot::new_page
    # SYNOPSIS
    method new_page {} {
        # USAGE
        #   $obj new_page
        # PURPOSE
        #   Increase the page counter and add a snippet for the new
        #   page in the Gnuplot script. The plot counter is reset.
        # SOURCE
        
        set plot 0
        incr page
        append content [::pwtk::gp::new_page_multiplot $term $page mp $pause $head]\n
        
        if { [::pwtk::gp::pwtk2gp $term] in $::pwtk::gp::gp(file.terminals) } {
            if { $page < 2 && $mp(pp) == 1 } {
                lappend outputs [::pwtk::gp::output $term $head]
            } else {
                lappend outputs [::pwtk::gp::output $term $head $page]
            }
        }
    }
    #******

    
    #****m* ::pwtk::gp::multiplot/multiplot::plot
    # SYNOPSIS
    method plot {args} {
        # USAGE
        # Either:
        #    $obj plot PLOT_SPECS
        # or:
        #    $obj plot { PLOT_SPECS }
        #
        # PURPOSE
        #   Add the "plot PLOT_SPECS" snippet to the Gnuplot script and
        #   take care of plot and page counters (new page is created when
        #   needed and, in this case, plot counter is reset).
        #
        #   For the fully "manual" mode:
        #
        #      $obj plot PLOT_SPECS
        #
        #   is equivalent to:
        #
        #      $obj add { plot PLOT_SPECS }
        #
        #   But otherwise, this method takes case of the plot and page
        #   count (new pages are created automatically when needed).
        # EXAMPLE
        #   $obj plot sin(2*x) w l lw 3 lt 1, cos(x) w l lw 5 lt 3
        #   $obj plot { 1 + sin(x) + cos(x), exp(x) }
        #   
        # SOURCE

        if { ($plot >= $mp(nx)*$mp(ny)) || ($page == 0 && $plot == 0) } {
            my new_page
        }
        incr plot

        my add [concat plot [my parse_ $args]]
    }
    #******
}


#****c* ::pwtk::gp/::pwtk::gp::splot
#
# DERIVED FROM
#    ::pwtk::gp::plot
#
# PURPOSE
#    A class for creating 'splot' Gnuplot objects, i.e., objects for
#    creating Gnuplot 3D surface and/or heatmap plots in a single-plot
#    mode. It is derived from the ::pwtk::gp::plot class, implying
#    that the methods of ::pwtk::gp::plot can be used.
#
#    By default, a heatmap is created.
#
# SEE ALSO
#    For further details, see: splot::constructor
#
# EXAMPLE
#    # create with Gnuplot a PNG heatmap image of the sin(x*y) function
#    
#    set obj [::pwtk::gp::splot new -type map -t "a simple plot" sin.png]
#    
#    $obj options {
#       xlabel 'x'
#       ylabel 'y'
#       xrange [-pi:pi]
#       yrange [-pi:pi]
#    }
#    $obj plot sin(x*y)
#    
#    $obj exec; # this executes Gnuplot and creates the 'sin.png' PNG image
#
#******

::oo::class create ::pwtk::gp::splot {
    superclass ::pwtk::gp::plot
    
    #
    # In this class, the Gnuplot script consists of prolog & content
    #
    # prolog: contains a terminal definition and what comes with it;
    #         it can only be set durinf the objection creation (it is immutable)
    #
    # content: the rest of the gnuplot script (mutable)
    #

    variable prolog
    variable content
    variable head; # rootname of gnuplot script and output file
    variable term; # PWTK's terminal name and filename extension for file.terminals
    variable my_options; # iron options (i.e. a copy of one of ::pwtk::gp::mapOptions, ::pwtk::gp::surfOptions, or ::pwtk::gp::surfmapOptions)
    variable options_initiated; # 1 for options initiated, 0 otherwise (options are initiated by calling the 'options' method)
    variable options_list; # contains excerpt of gnuplot script with sorted "set option value" list of gnuplot options
    variable outputs; # name of Gnuplot plots (for file terminals)
    variable page; # page-number counter (used by the new_page method)
    variable pause; # this object value for Gnuplot pause
    variable pauseText; # the text associated with the Gnuplot pause
    
    #****m* ::pwtk::gp::splot/splot::constructor
    # SYNOPSIS
    constructor {args} {
        # PURPOSE
        #   Create a new Gnuplot 'splot' object.
        #
        # HOW TO USE
        # Splot Gnuplot object is created as:
        #
        #   set obj [pwtk::gp::splot new ?OPTIONS?  ?HEAD.TERM?]
        #
        # where options specific for 3D surface and/or heatmap plots are: 
        #   -type TYPE
        #   -pal PALETTE
        #   -nocontour
        #   -cc CONTOUR_COLOR
        # while general options are:        
        #   -o ORIENT
        #   -s SIZE
        #   -fs FONTSIZE
        #   -t TITLE
        #   -p
        #   -pause PAUSE
        #
        # ARGUMENTS
        # * OPTIONS   --- see OPTIONS below
        # * HEAD.TERM --- "HEAD" is the rootname of gnuplot script;
        #                 "TYPE" is the type of terminal (PWTK's terminal name) and
        #                 the file's extension if plot is printed to a file;
        #                 possible values are those returned by ::pwtk::gp::pwtk_terminals        
        #
        # OPTIONS
        # Options specific for 3D surface and/or heatmap plots:
        # * -type TYPE   --- type of the Gnuplot splot: map | surface | both (default = map)
        # * -pal PALETTE --- color palette for palette-mapped 3d (pm3d) data (PWTK has a dozen predefined palettes, see the image below)
        # * -nocontour   --- turns contours off
        # * -cc  CONTOUR_COLOR --- assigns contour color
        #
        # General options:
        # * -o ORIENT    --- page orientation (portrait or landscape); used explicitly only for
        #                    EPS, while for other terminals, it's a hint for the multiplot layout
        # * -s SX,SY     --- terminal size (i.e. window or picture size)
        # * -fs FONTSIZE --- font size
        # * -t TITLE     --- the window title (for window-type terminals only)
        # * -p           --- signals that more than one single-plot will be plotted (for PNG-like
        #                    terminals, the name of output image will be $head-$pageNumber.png)
        # * -pause PAUSE --- value for the Gnuplot's pause command (useful for window terminals)
        #
        # Here are the PWTK's predefined color palettes and their
        # names that can be accessed with the -pal option. To invert a
        # palette, use "-pal {PALETTE negative}", where PALETTE is one
        # of:
        #
        # image:pwtk-palette.png
        # 
        # Note that for PALETTE only a substring that uniquely identifies it is
        # required.  For example, "-pal pa" selects the "pale-rainbow" palette.
        #
        # RETURN VALUE
        #   The Gnuplot 'splot' object.
        #
        # SOURCE

        set options_initiated 0
        set page 1; # N.B. page must be 1 for new_page to work correctly

        set argsOrig $args
        set nargmin 0
        set nargmax 1
        set usage "new  ?-type TYPE?  ?-pal PALETTE?  ?-nocontour?  ?-cc CONTOUR_COLOR?  ?-o ORIENT?  ?-s SIZE?  ?-fs FONTSIZE?  ?-t TITLE?  ?-p?  ?HEAD.TERM?"
        
        ::pwtk::gp::parseOpt_term_

        # TYPE option
        
        switch -glob -- $opt(type) {
            b* - s*m* {
                # both | surfmap
                array set my_options [array get ::pwtk::gp::surfmapOptions]
            }
            s* {
                # surface
                array set my_options [array get ::pwtk::gp::surfOptions]
            }
            h* - m* {
                # heatmap | map
                set map 1
                array set my_options [array get ::pwtk::gp::mapOptions]
            }
            default {
                ::pwtk::error "uknown splot type \"$opt(type)\", must be one of map, surface, or both" 1
            }
        }

        # -pal PALETTE
        #
        # N.B. the value of PALETTE is of form {PALETTE_NAME ?DIRECTION?},
        # where DIRECTION is optional and can be either "positive" or "negative"

        lassign $opt(pal) paletteName dir
        ::pwtk::ifset dir positive
        switch -glob -- $dir {
            p* { set dir positive }
            n* { set dir negative }
            default {
                ::pwtk::error "wrong PALETTE direction, must be \"positive\" or \"negative\", but got: $dir" 1
            }
        }
        
        lassign [array names ::pwtk::gp::palette ${paletteName}*] pal
        if { $pal eq {} } {
            ::pwtk::warning "uknown palette \"$opt(pal)\", using Gnuplot's default instead"
            my options [list palette [concat color model RGB defined]]
        } else {
            my options [list palette [concat color model RGB $::pwtk::gp::palette($pal)]]
        }     
        my options [list palette $dir]
        
        # CONTOUR-related options
        
        if { $opt(cc) ne {} } {
            set color [::pwtk::squote $opt(cc)]
            my add "# color of contours\nset for \[i=1:20\] linetype i linecolor $color"
        }
        if { $opt(nocontour) }  {
            # turn contours off for surface plots
            my unset contour
        }

        # HEAD.TERM
        
        if { $args ne {} } {
            set head [::pwtk::gp::head_ $args]
            set term [::pwtk::gp::term_ $args]
            set args [lrange $argsOrig 0 end-1]
        } else {
            set id [incr ::pwtk::gp::splot_id]
            set head [::pwtk::gp::head_ splot-$id.win]
            set term [::pwtk::gp::term_ splot-$id.win]
            set args $argsOrig
        }

        # -pause
        my pause_ -1 $opt(pause)
        
        # specially handle the -t option
        
        set title {}
        if { $term in $::pwtk::gp::gp(win.terminals) } {
            if { $opt(p) == 0 } {
                set t [string trim "$opt(t) ($pauseText to Exit)"]
            } else {
                set t [string trim "$opt(t) ($pauseText to continue to next page)"]
            }
            set title [list -t $t]
        }

        set prolog [::pwtk::gp::get_term {*}$args {*}$title $head.$term]\n
    }
    #******


    #****m* ::pwtk::gp::splot/splot::config
    # SYNOPSIS
    method config {args} {
        # PURPOSE
        #   Configure the splot using the shortcut command-line options
        #   as defined by the ::pwtk::gp::plot_options variable.
        #
        #   After the command-line options are parsed, the
        #   'cmdlineOpts' method is called.
        #
        # ARGUMENT
        # * args -- command-line options
        #
        # SOURCE

        ::pwtk::gp::defaultCmdlineOpts_ splot options usage
        set narg 0
        ::pwtk::parseOpt_
        my cmdlineOpts opt
    }
    #******


    #****m* ::pwtk::gp::splot/splot::cmdlineOpts
    # SYNOPSIS
    method cmdlineOpts {optVar} {
        # PURPOSE
        #   A convenience method to facilitate easier handling of command-line
        #   options used by scanpar.tcl, pdos.tcl, bands.tcl, etc.
        #
        # ARGUMENT
        # * optVar -- name of the 'opt' array of ::pwtk::parseOpt_.
        #
        # SOURCE

        upvar $optVar opt
        next opt

        ::pwtk::ifnotempty opt(i) { my set pm3d [list interpolate $opt(i)] }

        ::pwtk::ifnotempty opt(zt)  { my set ztics $opt(zt) }
        ::pwtk::ifnotempty opt(cbt) { my set cbtics $opt(cbt) }

        ::pwtk::ifnotempty opt(mz)  { my set mztics  $opt(mz) }
        ::pwtk::ifnotempty opt(mcb) { my set mcbtics $opt(mcb) }

        ::pwtk::ifnotempty opt(zl)  { my set zlabel [::pwtk::squote $opt(zl)] }
        ::pwtk::ifnotempty opt(cbl) { my set cblabel [::pwtk::squote $opt(cbl)] }

        ::pwtk::ifnotempty opt(zr)  { my set zrange [::pwtk::rangequote $opt(zr)] }
        ::pwtk::ifnotempty opt(cbr) { my set cbrange [::pwtk::rangequote $opt(cbr)] }

        ::pwtk::ifnotempty opt(zf)  { my set format "z [::pwtk::squote $opt(zf)]" }
        ::pwtk::ifnotempty opt(cbf) { my set format "cb [::pwtk::squote $opt(cbf)]" }
    }
    #******


    #****m* ::pwtk::gp::splot/splot::plot
    # SYNOPSIS
    method plot {args} {
        # USAGE
        # Either:
        #    $obj plot PLOT_SPECS
        # or:
        #    $obj plot { PLOT_SPECS }    
        # PURPOSE
        #   Add the "splot" snippet to the Gnuplot script.
        # EXAMPLES
        #   $obj plot sin(x*y)
        #   $obj plot { 1 + cos(x) + sin(y) }
        # SOURCE
        my options_initiate_
        my add [concat splot [my parse_ $args]]
    }
    #******    
}


