#
# $RCSfile: types.tcl,v $ --
#
#      This file contains definition of different numeric types (in
#      addition to Tcl's integer and double), such as posint, negint, ...
#
# Copyright (c) 2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: header.tcl,v 1.3 2023/01/23 12:00:01 kokalj Exp $ 
#


# internal...
proc ::pwtk::type::args_ {} {
    uplevel 1 {
        set narg [llength $args]
        if { $narg < 2 || $narg > 3 } {
            ::error "wrong # args: must be \"[::pwtk::procName] type ?-strict? number\", but got: \"[::pwtk::procName] $args\""
        }
        if { $narg == 3 } {
            if { [lindex $args 1] ne "-strict" } {
                ::error "wrong option [lindex $args 1], must be -strict"
            }
            set strict -strict
            set type   [lindex $args 0]
            set number [lindex $args 2]
        } else {
            set strict {}
            set type   [lindex $args 0]
            set number [lindex $args 1]
        }
    }
}


#****f* ::pwtk::type/::pwtk::type::number
# SYNOPSIS
proc ::pwtk::type::number {args} {
    # USAGE
    #   ::pwtk::type::number type ?-strict? value
    #
    # PURPOSE
    #   Query if a value (or number) is of correct numeric type. The
    #   following types are supported:
    #       binary
    #       fboolean
    #       boolean
    #       int | integer
    #       posint      
    #       nonposint   
    #       negint      
    #       nonnegint   
    #       real | double | float
    #       posreal | posdouble | posfloat
    #       nonposreal | nonposdouble | nonposfloat  
    #       negreal | negdouble | negfloat            
    #       nonnegreal | nonnegdouble | nonnegfloat
    #       real01
    #
    # OPTION
    # * -strict -- if this option is specified, the empty value does not much
    #
    # ARGUMENTS
    # * type -- the type
    # * value -- value for which to test the type
    #
    # RETURN VALUE
    #   1 or 0
    #
    # SOURCE
    
    args_

    # perhaps number is specified in Fortran syntax, e.g., 1.0d0
    set number [::pwtk::f2c_number $number]
    
    if { $strict eq {} && $number eq {} } {
        # for non-strict, empty string matches all types
        return 1
    }
    
    switch -glob -- $type {
        fboolean {
            # boolean + Fortran logic (.t. .f. .true. .false.)
            return [string is boolean -strict [string trim $number .]]
        }
        boolean {
            return [string is boolean -strict $number]
        }
        *int* - binary {
            if { ! [string is integer -strict $number] } {
                return 0
            }
        }
        *real - *double - *float - real01 {
            if { ! [string is double -strict $number] } {
                return 0
            }
        }
    }
    switch -glob -- $type {
        binary {
            # 0 or 1
            if { $number == 0 || $number == 1 } {
                return 1
            } else {
                return 0
            }
        }
        nonpos* {
            return [expr $number <= 0]
        }
        nonneg* {
            return [expr $number >=0]
        }
        pos* {
            return [expr $number > 0]
        }
        neg* {
            return [expr $number < 0]
        }
        int* {
            return [string is integer -strict $number]
        }
        real01 {
            # a real number within [0:1]
            return [expr $number >= 0.0 && $number <= 1.0]
        }
        real - double - float {
            return [string is double -strict $number]
        }
    }
    
    # if we came here something is wrong:
    ::error "unsupported type $type" 1
}
#******

#****f* ::pwtk::type/::pwtk::type::numberlist
# SYNOPSIS
proc ::pwtk::type::numberlist {args} {
    # USAGE
    #    ::pwtk::type::numberlist type ?-strict? numberlist
    # PURPOSE
    #   Query if the elements in the numberlist are of corrected
    #   type. For the supported types, see ::pwtk::type::number
    #
    # OPTION
    # * -strict -- if this option is specified, empty valuee do not much
    #
    # ARGUMENTS
    # * type -- the type
    # * numberlist -- list of numbers for which to test the type
    #
    # RETURN VALUE
    #   1 or 0
    #
    # SOURCE

    args_

    if { $strict eq "-strict" && $number eq {} } {
        return 0
    }

    # list elements can be comma or space separated
    foreach n [regsub -all , $number { }] {
        if { ! [number $type {*}$strict $n] } {
            return 0
        }
    }
    return 1
}
#******


#****f* ::pwtk::type/::pwtk::type::optionlist
# SYNOPSIS
proc ::pwtk::type::optionlist {args} {
    # USAGE
    #   ::pwtk::type::optionlist allowedValues ?-strict? value
    #
    # PURPOSE
    #   Query if the value is one among the allowed values (allowed
    #   values are values of the optionlist).
    #
    # OPTION
    # * -strict -- if this option is specified, the empty value does not much
    #
    # ARGUMENTS
    # * allowedValues -- list of allowed values (aka optionlist)
    # * value -- value to check (it must be one among the allowed values)
    #
    # RETURN VALUE
    #   1 or 0
    #
    # SOURCE

    args_
    set allowedValues $type
    set value $number
    if { $strict eq {} && $value eq {} } {
        return 1
    } else {        
        return [expr {$value in $allowedValues}]
    }
}
#******


#****f* ::pwtk::type/::pwtk::type::range
# SYNOPSIS
proc ::pwtk::type::range {type from to number} {
    # PURPOSE
    #   Check if a 'number' is of correct type and is in the [from,to] range.
    # RETURN VALUE
    # * 1 if number is of correct type and in range
    # * 0 otherwise
    # SOURCE
    if { $number ne {} } {
        if { ! [::pwtk::type::number $type -strict $from] || ! [::pwtk::type::number $type -strict $to]
             ||  $number < $from || $number > $to } {
            return 0
        }
    }
    return 1
}
#******


#****f* ::pwtk::type/::pwtk::type::gp_range
# SYNOPSIS
proc ::pwtk::type::gp_range {range} {
    # PURPOSE
    #   Check if the Gnuplot 'range' is in the [from:to] or from:to
    #   syntax, where 'from' and 'to' can be any string including the
    #   empty string because Gnuplot supports expressions and
    #   incomplete ranges, e.g., [from:] or [:to].
    #
    # RETURN VALUE
    # * 1 if range is of correct type
    # * 0 otherwise
    # SOURCE
    set r [split [string trim $range {[]}] :]
    if { $r ne {} && [llength $r] != 2 } {
        return 0
    }
    return 1
}
#******


#****f* ::pwtk::type/::pwtk::type::gp_size
# SYNOPSIS
proc ::pwtk::type::gp_size {size} {
    # PURPOSE
    #   Check if the Gnuplot 'size' is in the sx,sy syntax, where 'sx' and 'sy' are numbers.
    #   Incomplete sizes are not allowed, e.g., "sx," or ",sy".
    #
    # RETURN VALUE
    # * 1 if size is of correct type
    # * 0 otherwise
    # SOURCE
    set s [split $size ,]
    if { $s ne {} } {
        if { [llength $s] != 2 || ! [::pwtk::type::numberlist real -strict $s] } {
            return 0
        }
    }
    return 1
}
#******


#****f* ::pwtk::type/::pwtk::type::intseq
# SYNOPSIS
proc ::pwtk::type::intseq {value {increment 1}} {
    # PURPOSE
    #   Check if a 'value' is a continuous integer sequence (e.g. 5 7 9 11)
    # ARGUMENTS
    # * value --- the value to check
    # * increment --- requested increment for the sequence (default = 1, e.g. value = {5 6 7 8})
    # RETURN VALUE
    # * 1 if number is of correct type 
    # * 0 otherwise
    # SOURCE

    foreach i $value {
        ::pwtk::ifexist iold {
            if { $i - $iold != $increment } {
                return 0
            }
        }
        set iold $i
    }
    return 1
}
#******


#****f* ::pwtk::type/::pwtk::type::rangestring
# SYNOPSIS
proc ::pwtk::type::rangestring {value} {
    # PURPOSE
    #   Check if a 'value' is a rangestring, where rangestring is a
    #   string having the syntax allowed by ::pwtk::parseRangeString (e.g. value = {1 2 5-})
    # ARGUMENT
    # * value --- the value to check
    # RETURN VALUE
    # * 1 if number is of correct type
    # * 0 otherwise
    # SOURCE

    # checking based on ::pwtk::parseRangeString
    set value [regsub -all {(begin|first|1st)} [::pwtk::normalizeRangeString_ $value] 1]
    set value [regsub -all {(end|last)} $value 1000]; # replaced with a big integer

    foreach item $value {
        if { ! [regexp {^[0-9]+-?[0-9]*$} $item] && ! [regexp {^-?[0-9]*$} $item] } {
            return 0
        }
    }
    return 1
}
#******
