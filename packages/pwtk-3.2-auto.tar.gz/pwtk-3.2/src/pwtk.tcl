#
# $RCSfile: pwtk.tcl,v $ --
#
#
#      pwtk == PWscf's ToolKit
#
#      In this file some procs of ::pwtk:: namespace are defined
#
#
# Copyright (c) 2009-2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: pwtk.tcl,v 1.12 2021/05/07 13:23:35 tone Exp $ 
#


#****f* Evals-Execs-Errors/::pwtk::import
# SYNOPSIS
proc ::pwtk::import {scriptFile} {
    # PURPOSE    
    #   Import the specified PWTK script file. This is like the Tcl
    #   source command, but handles correctly the sourcing from
    #   various directories.
    # ARGUMENTS
    # * scriptFile -- name of the pwtk script file to import.
    # SOURCE

    variable import; # this variable is needed by ::pwtk::rsync_imports (it contains dir1 file1 dir2 file2 ...)
    variable propagate
    
    set here [pwd]
    set dir  [file dirname $scriptFile]
    set file [file tail $scriptFile]

    if { [info exists propagate(level)] && $propagate(level) > 0 } {
        # remember which files were imported (needed by ::pwtk::rsync_imports_)
        if { [file pathtype $dir] ne "relative" } {        
            lappend import $dir
        } else {
            # store dir as relative wrt $HOME
            lappend import [::fileutil::relative $::env(HOME) [file join [pwd] $dir]]
        }
        lappend import $file
    }

    cd $dir
    uplevel source $file
    cd $here
}
#******


#****f* 5.3.6. Run Auxiliaries/::pwtk::backup_io
# SYNOPSIS
proc ::pwtk::backup_io {{flag {}}} {
    # ARGUMENTS
    #   * flag -- must be either true or false (boolean) 
    #
    # PURPOSE 
    #   Either query or set (turn on/off) the I/O backup machinery,
    #   depending on the value of flag.
    #
    #   When backup is turned on and PWTK is to write to an input or
    #   output file that already exists then a backup copy of file
    #   will be made before the PWTK overwrites it.
    #
    # SOURCE
    variable state

    if { $flag != "" } {
        # e.g., .true. --> true
        set flag [string trim $flag .]
        
        if { ! [string is boolean $flag] } {
            ::pwtk::error "wrong value of flag \"$flag\"$, must be boolean" 1
        }
        set state(backup_io) [::pwtk::is_true $flag]

        if { $state(backup_io) } {
            ::pwtk::print "I/O backup is ON\n"
        } else {
            ::pwtk::print "I/O backup is OFF\n"
        }
    }
    return $state(backup_io)
}
#******


#****f* 5.3.6. Run Auxiliaries/::pwtk::ihandle
# SYNOPSIS
proc ::pwtk::ihandle {{handle ""}} {
    # PURPOSE
    #   Shortcut for ::pwtk::input_handle
    # SOURCE
    return [::pwtk::input_handle $handle]
}
#****

#****f* 5.3.6. Run Auxiliaries/::pwtk::input_handle
# SYNOPSIS
proc ::pwtk::input_handle {{handle ""}} {
    # PURPOSE
    #   Set or query the input-handle.
    #
    #   Input-handle determines how the input file is passed to
    #   Quantum-ESPRESSO executable(s).  Usual mechanism for reading
    #   the input data is:
    #
    #      program.x < input_file 
    #
    #   Hence in this case the input-handle is the input redirection
    #   operator "<". But some implementations of the MPI library have
    #   problems with the input redirection. If this happens, use the
    #   option -in (or -i, -inp, -input), followed by the input file
    #   name, e.g.:
    #
    #       program.x -in input_file
    #
    #   In the first case above the input-handle is "<", while in the
    #   latter it is "-in".
    #
    # WARNINGS
    #   This routine allows to set the input handle to an arbitrary
    #   value, hence it is user responsibility to set the handle to an
    #   acceptable value.
    #
    # ARGUMENTS
    #   * handle -- the input handle (e.g., < or -in)
    #
    # RETURN VALUE
    #   The value of the input_handle.
    #
    # SOURCE
    variable RUNopt

    if { $handle != "" } {
        set RUNopt(input_handle) $handle
    }
    return $RUNopt(input_handle)
}
#******


#****f* 5.4. Directories and Pseudopotentials/::pwtk::outdir
# SYNOPSIS 
proc ::pwtk::outdir {{outdir ""}} {
    # PURPOSE
    #   Set (or query) the pw.x's outdir directory 
    #
    # NOTES 
    #   Developer's note: the proc sets the value of the QEdir(ESPRESSO_TMPDIR)
    #   variable if $outdir != {}.
    #
    # RETURN VALUE 
    #   The value of the outdir.
    #
    # SOURCE
    variable QEdir
    
    if { $outdir == "" } {
	return [outdir_query]
    }
    
    set QEdir(ESPRESSO_TMPDIR) $outdir
    return $QEdir(ESPRESSO_TMPDIR)
}
#****

#****f* 5.4. Directories and Pseudopotentials/::pwtk::outdir_prefix_append
# SYNOPSIS 
proc ::pwtk::outdir_prefix_append {dir} {
    # PURPOSE        
    #   Append the specified directory to outdir_prefix. For the
    #   explanation of outdir_prefix, see ::pwtk::outdir_prefix
    #
    # IMPORTANT
    #   To make ::pwtk::outdir_prefix_append effective,
    #   ::pwtk::outdir_postfix must be called in set mode after
    #   ::pwtk::outdir_prefix_append
    #
    # RETURN VALUE 
    #   The value of the outdir_prefix.
    #
    # SOURCE
    variable QEdir

    if { [varvalue QEdir(outdirPrefix)] == {} } {
        set QEdir(outdirPrefix) $dir
    } else {
        set QEdir(outdirPrefix) [file join $QEdir(outdirPrefix) $dir]
    }
    return $QEdir(outdirPrefix)
}
#******

#****f* 5.4. Directories and Pseudopotentials/::pwtk::outdir_prefix
# SYNOPSIS 
proc ::pwtk::outdir_prefix {{prefix {}}} {
    # PURPOSE        
    #   Set (or query) the outdir's root (top) directory, e.g.,
    #   /scratch/$env(USER)/pwscf. This routine is typically used in
    #   configuration file, ~/.pwtk/pwtk.tcl. The full outdir is then
    #   constructed by subsequent call to ::pwtk::outdir_postfix, and
    #   the outdir is: $outdir_prefix/$outdir_postfix.
    #
    # IMPORTANT
    #   To make ::pwtk::outdir_prefix effective,
    #   ::pwtk::outdir_postfix must be called in set mode after
    #   ::pwtk::outdir_prefix
    #
    # RETURN VALUE 
    #   The value of the outdir_prefix.
    #
    # SOURCE
    variable QEdir
    if { $prefix == "" } {
	return [varvalue QEdir(outdirPrefix)]
    }
	
    return [set QEdir(outdirPrefix) $prefix]
}
#******

#****f* 5.4. Directories and Pseudopotentials/::pwtk::outdir_postfix
# SYNOPSIS 
proc ::pwtk::outdir_postfix {{postfix {}}} {
    # PURPOSE        
    #   Set (or query) the outdir_postfix.
    #
    #   Note that the full "outdir" is:
    #   $outdir_prefix/$outdir_postfix. Beware that prior to calling
    #   this routine in set mode, the ::pwtk::outdir_prefix command should
    #   be called.
    #
    # RETURN VALUE 
    #   * if "postfix" argument was specified, then value of the resulting "outdir"
    #   * if "postfix" argument was not specified, then the current value
    #     of "outdir_postfix" or an empty string if the "outdir_postfix" is not set
    #
    # SOURCE
 
    variable QEdir
    
    if { $postfix == "" } {
	return [varvalue QEdir(outdirPostfix)]
    }

    set QEdir(outdirPostfix) $postfix
    
    if { ! [info exists QEdir(outdirPrefix)] } {
	if { [info exists ::env(ESPRESSO_TMPDIR)] } {
	    set QEdir(outdirPrefix) $::env(ESPRESSO_TMPDIR)
	}
        ifset QEdir(outdirPrefix) [::fileutil::tempdir]
        warning "do not use outdir_postfix if outdir_prefix is not defined, setting outdir_prefix to $QEdir(outdirPrefix)"
    }
    return [outdir [file join $QEdir(outdirPrefix) $postfix]]
}
#******

#****f* 5.4. Directories and Pseudopotentials/::pwtk::outdir_query
# SYNOPSIS 
proc ::pwtk::outdir_query {{hard {}}} {
    # USAGE
    #   outdir_query ?-hard?
    #
    # PURPOSE
    #   Query the outdir directory.
    #
    # RETURN VALUE
    #   The value of the current outdir.
    #
    #   If -hard option is specified and outdir is not defined, the
    #   routine returns the value of ESPRESSO_TMPDIR enviromental
    #   variable if it is defined or "."  (i.e. current directory) otherwise.
    #
    # SOURCE

    input_push
       ::pwtk::pwi::loadDefaults_ 
       set outdir [::pwtk::input::namelistGetVarValue CONTROL outdir 1]    
    input_pop

    if { $outdir == "" } {
	variable QEdir
	if { [info exists QEdir(ESPRESSO_TMPDIR)] && $QEdir(ESPRESSO_TMPDIR) != "" } {
	    set outdir $QEdir(ESPRESSO_TMPDIR)
	}
    }

    # -hard option
    if { $hard != "" } {
        if { $hard != "-hard" } {
            ::pwtk::error "wrong option '$hard', must be -hard" 1
        } elseif { $outdir == {} } {
            global env
            if { [info exists env(ESPRESSO_TMPDIR)] } {
                set outdir $env(ESPRESSO_TMPDIR)
            } else {
                set outdir .
            }
        }
    }
    
    return $outdir
}
#****


#****f* 5.4. Directories and Pseudopotentials/::pwtk::outdir_create
# SYNOPSIS 
proc ::pwtk::outdir_create {} {
    # PURPOSE
    #   Create the outdir directory if it does not exist.
    #
    #  NOTES
    #   This proc is typically used only by the PWTK internally.
    #
    #  RETURN VALUE
    #   The name of the created "outdir".
    #
    # SOURCE

    set outdir [outdir_query]

    if { ! [file isdirectory $outdir] && $outdir != "" } {
	if { [catch {file mkdir $outdir}] } {
	    ::pwtk::error "cannot create \"outdir\" directory: $outdir"
	}
    } 
    return $outdir
}
#****



#****f* 5.4. Directories and Pseudopotentials/::pwtk::outdir_clean
# SYNOPSIS 
proc ::pwtk::outdir_clean {} {
    # PURPOSE
    #   Remove all prefix.* files from the outdir.
    #
    # WARNINGS
    #   This is a very dangerous routine !!!
    #
    # SOURCE

    set outdir [outdir_query]
    if { $outdir != "" } {
	dir_clean_ $outdir
    }
}
#****


#****f* 5.4. Directories and Pseudopotentials/::pwtk::wfcdir
# SYNOPSIS 
proc ::pwtk::wfcdir {{wfcdir ""}} {
    # PURPOSE
    #   Set (or query) the pw.x's wfcdir directory 
    #
    # NOTES 
    #   Developer's note: the proc sets the value of the QEdir(ESPRESSO_WFCDIR)
    #   variable if $wfcdir != {}.
    #
    # RETURN VALUE 
    #   The value of the wfcdir.
    #
    # SOURCE
    variable QEdir
    
    if { $wfcdir == "" } {
	return  [wfcdir_query]
    }
    
    set QEdir(ESPRESSO_WFCDIR) $wfcdir
    return $QEdir(ESPRESSO_WFCDIR)
}
#****


#****f* 5.4. Directories and Pseudopotentials/::pwtk::wfcdir_prefix_append
# SYNOPSIS 
proc ::pwtk::wfcdir_prefix_append {dir} {
    # PURPOSE        
    #   Append the specified directory to wfcdir_prefix. For the
    #   explanation of wfcdir_prefix, see ::pwtk::wfcdir_prefix
    #
    # IMPORTANT
    #   To make ::pwtk::wfcdir_prefix_append effective,
    #   ::pwtk::wfcdir_postfix must be called in set mode after
    #   ::pwtk::wfcdir_prefix_append
    #
    # RETURN VALUE 
    #   The value of the wfcdir_prefix.
    #
    # SOURCE
    variable QEdir

    if { [varvalue QEdir(wfcdirPrefix)] == {} } {
        set QEdir(wfcdirPrefix) $dir
    } else {
        set QEdir(wfcdirPrefix) [file join $QEdir(wfcdirPrefix) $dir]
    }
    return $QEdir(wfcdirPrefix)
}
#******

#****f* 5.4. Directories and Pseudopotentials/::pwtk::wfcdir_prefix
# SYNOPSIS 
proc ::pwtk::wfcdir_prefix {{prefix {}}} {
    # PURPOSE        
    #   Set (or query) the wfcdir's root (top) directory, e.g.,
    #   /scratch/$env(USER)/pwscf. This routine is typically used in
    #   configuration file, ~/.pwtk/pwtk.tcl. The full wfcdir is then
    #   constructed by subsequent call to ::pwtk::wfcdir_postfix, and
    #   the wfcdir is: $wfcdir_prefix/$wfcdir_postfix.
    #
    # IMPORTANT
    #   To make ::pwtk::wfcdir_prefix effective,
    #   ::pwtk::wfcdir_postfix must be called in set mode after
    #   ::pwtk::wfcdir_prefix_append
    #
    # RETURN VALUE 
    #   The value of the wfcdir_prefix.
    #
    # SOURCE
    variable QEdir

    if { $prefix == "" } {
	return [varvalue QEdir(wfcdirPrefix)]
    }
    return [set QEdir(wfcdirPrefix) $prefix]
}
#******



#****f* 5.4. Directories and Pseudopotentials/::pwtk::wfcdir_postfix
# SYNOPSIS 
proc ::pwtk::wfcdir_postfix {{postfix {}}} {
    # PURPOSE        
    #   Set (or query) the wfcdir's subdirectory.
    #
    #   Note that the full "wfcdir" is:
    #   $wfcdir_prefix/$wfcdir_postfix. Prior to calling this routine
    #   in set mode, the ::pwtk::wfcdir_prefix command should be called.
    #
    # RETURN VALUE 
    #   * if "postfix" argument was specified, then value of the resulting "wfcdir"
    #   * if "postfix" argument was not specified, then the current value
    #     of "wfcdir_postfix" or an empty string if the wfcdir_postfix is not set
    #
    # SOURCE
 
    variable QEdir

    if { $postfix == "" } {
	return [varvalue QEdir(wfcdirPostfix)]
    }

    set QEdir(wfcdirPostfix) $postfix

    if { ! [info exists QEdir(wfcdirPrefix)] } {
	global env	
	if { [info exists env(ESPRESSO_WFCDIR)] } {
	    ::pwtk::warning "do not use wfcdir_postfix if wfcdir_prefix is not defined, setting wfcdir_prefix to env(ESPRESSO_WFCDIR), which is $env(ESPRESSO_WFCDIR)"
	    set QEdir(wfcdirPrefix) $env(ESPRESSO_WFCDIR)
	}
    }

    if { [varvalue QEdir(wfcdirPrefix)] == {} } {
	::pwtk::error "wfcdir_prefix should be called prior to wfcdir_postfix" 1
    }
    return [wfcdir [file join $QEdir(wfcdirPrefix) $postfix]]
}
#******



#****f* 5.4. Directories and Pseudopotentials/::pwtk::wfcdir_query
# SYNOPSIS 
proc ::pwtk::wfcdir_query {{hard {}}} {
    # USAGE
    #   wfcdir_query ?-hard?
    #
    # PURPOSE
    #   Query the wfcdir directory.
    #
    # RETURN VALUE
    #   The value of the current wfcdir.
    #
    #   If -hard option is specified and wfcdir is not defined, the
    #   routine returns the value of the ESPRESSO_TMPDIR enviromental
    #   variable if it is defined or "."  (i.e. current directory) otherwise.
    #
    #   N.B. ESPRESSO_TMPDIR is used in favor of the ESPRESSO_WFCDIR
    #   enviromental variable because QE does not use the latter.
    #    
    # SOURCE

    input_push
       ::pwtk::pwi::loadDefaults_ 
       set wfcdir [::pwtk::input::namelistGetVarValue CONTROL wfcdir 1]    
    input_pop

    if { $wfcdir == "" } {
	variable QEdir
	if { [info exists QEdir(ESPRESSO_WFCDIR)] && $QEdir(ESPRESSO_WFCDIR) != "" } {
	    set wfcdir $QEdir(ESPRESSO_WFCDIR)
	}
    }

    # -hard option
    if { $hard != "" } {
        if { $hard != "-hard" } {
            ::pwtk::error "wrong option \"$hard\", must be -hard" 1
        } elseif { $wfcdir == {} } {
            global env
            if { [info exists env(ESPRESSO_TMPDIR)] } {
                set wfcdir $env(ESPRESSO_TMPDIR)
            } else {
                set wfcdir .
            }
        }
    }

    return $wfcdir
}
#****



#****f* 5.4. Directories and Pseudopotentials/::pwtk::wfcdir_create
# SYNOPSIS 
proc ::pwtk::wfcdir_create {} {
    # PURPOSE
    #   Create the wfcdir directory.
    #
    #  NOTES
    #   This proc is typically used only by the PWTK internally.
    #
    #  RETURN VALUE
    #   The name of the created "wfcdir".
    #
    # SOURCE

    set wfcdir [wfcdir_query]

    if { ! [file isdirectory $wfcdir] && $wfcdir != "" } {
	if { [catch {file mkdir $wfcdir}] } {
	    ::pwtk::error "cannot create \"wfcdir\" directory: $wfcdir"
	}
    } 
    return $wfcdir
}
#****



#****f* 5.4. Directories and Pseudopotentials/::pwtk::wfcdir_clean
# SYNOPSIS 
proc ::pwtk::wfcdir_clean {} {
    # PURPOSE
    #   Remove all prefix.* files from the wfcdir.
    #
    # WARNINGS
    #   This is a very dangerous routine. Be careful!!!
    #
    # SOURCE

    set wfcdir [wfcdir_query]
    if { $wfcdir != "" } {
	dir_clean_ $wfcdir
    }
}
#****



#****if* Internals/::pwtk::dir_clean_
# SYNOPSIS 
proc ::pwtk::dir_clean_ {dir {prefix ""}} {
    # PURPOSE
    #   Delete all prefix.* files in the specified directory.
    #
    #   For internal use only.

    if { $prefix == "" } {
	input_push
	   ::pwtk::pwi::loadDefaults_ 
	   set prefix [::pwtk::input::namelistGetVarValue CONTROL prefix 1]    
	input_pop
    }

    if { $prefix == "" } {
	set prefix pwscf
    }
    
    if { $dir != "" && $prefix != "" } {
        
	::pwtk::print "Cleaning directory $dir ..."
	if { [file isdirectory $dir] } {
	    foreach file [lsort [glob  -nocomplain -- [file join $dir $prefix.*] [file join $dir ${prefix}_*]]] {
                if { $file != "" && $file != "/" && $file != "/*" } {
                    ::pwtk::print "      force-deleting $file"
                    file delete -force -- $file
                }
	    }
	}
    }
}
#******


#****f* 5.4. Directories and Pseudopotentials/::pwtk::outdir_backup
# SYNOPSIS
proc ::pwtk::outdir_backup {{postfix bck}} {
    # USAGE
    #   ::pwtk::outdir_backup ?POSTFIX?
    #
    # PURPOSE
    #   Make a backup copy of the 'outdir', i.e.,
    #
    #      file copy -force -- $outdir $outdir.POSTFIX
    #
    # ARGUMENT
    # * POSTFIX -- (optional, default = bck) how the backup copy will be name, i.e., $outdir.POSTFIX
    #
    # RETURN VALUE
    # * the pathname of the created outdir backup copy
    #
    # SOURCE

    return [xxxdir_backup_ outdir $postfix]
}
#******


#****f* 5.4. Directories and Pseudopotentials/::pwtk::wfcdir_backup
# SYNOPSIS
proc ::pwtk::wfcdir_backup {{postfix bck}} {
    # USAGE
    #   ::pwtk::wfcdir_backup ?POSTFIX?
    #
    # PURPOSE
    #   Make a backup copy of the 'wfcdir' if 'wfcdir' is defined and not equal "." and it
    #   differs from 'outdir'.
    #
    # ARGUMENT
    # * POSTFIX -- (optional, default = bck) how the backup copy will be name, i.e., $wfcdir.POSTFIX
    #
    # RETURN VALUE
    # * the pathname of the created wfcdir backup copy
    #
    # SOURCE

    set outdir [outdir_query -hard]; # if outdir is undefined, we get "."
    set wfcdir [wfcdir_query -hard]; # if wfcdir is undefined, we get "."

    if { $wfcdir ne $outdir && $wfcdir ne "." } {
        return [xxxdir_backup_ wfcdir $postfix]
    }
    return {}
}
#******


#****if* Internals/::pwtk::xxxdir_backup_
# SYNOPSIS
proc ::pwtk::xxxdir_backup_ {dir postfix} {
    # PURPOSE
    #   Actual implementation of ::pwtk::outdir_backup & ::pwtk::wfcdir_backup
    # SOURCE

    set xxxdir [file normalize [${dir}_query -hard]]; # N.B. if outdir/wfcdir is undefined, [${dir}_query -hard] returns "."

    if { ! [file exists $xxxdir] } {
        ::pwtk::error "$dir directory \"$xxxdir\" does not exist" 1
    }

    if { $xxxdir eq "." } { set xxxdir [pwd] }
    set backup  $xxxdir.$postfix

    # get a unique name
    set i ""
    while { [file exists ${backup}$i] } {
        if { $i eq "" } { set i 0 }
        incr i
    }
    set backup ${backup}$i

    print "Making a backup copy of '$dir':\n- $dir     :  $xxxdir\n- backup copy:  $backup\n"

    try {
        file copy -force -- $xxxdir $backup
    } on error err {
        # this happens in the following cases:
        # 1. when the user does not have the permission to create $backup dir
        # 2. when the $xxxdir create files that the user does not have permission to copy
        # ...
        #
        # in such cases, return $xxxdir

        uplevel 1 [list ::pwtk::error "failed to make a backup copy of $dir\n\n$err"]
        return $xxxdir
    }
    return $backup
}
#******


#****f* 5.5. Executions/::pwtk::nice
# SYNOPSIS
proc ::pwtk::nice {args} {
    # PURPOSE
    #   Set or query the niceness value for the execution of programs
    #   (aka "nice"). Here is an example of how the program is run in
    #   the terminal with the highest niceness (aka nice -19):
    #    
    #     nice -19 program.x
    #
    #   or for parallel execution:
    #
    #     nice -19 mpirun -n 8 program.x
    #
    #   The effect of this command is that, for example, with the
    #   "::pwtk::nice -19" call, all subsequent calculations will be
    #   run with nice -19.
    #
    # USAGE
    #   Set mode:
    #     ::pwtk::nice value
    #
    #   Query mode:    
    #     ::pwtk::nice
    #
    # ARGUMENTS
    # * value -- value of the niceness; irrespective of whether
    #            negative or positive value is supplied, its magnitude
    #            is used and the 'nice' is run as: nice -[expr abs($value)]
    #
    # RETURN VALUE
    #   The current (absolute) value of the niceness or an empty string
    #   if niceness was not set.
    #
    # SOURCE    
    variable RUNopt

    if { [llength $args] == 0 } {
        return [expr { [info exists RUNopt(NICE)] ? $RUNopt(NICE) : {} }]
    } elseif { [llength $args] == 1 } {
        set args [lindex $args 0]
        if { $args != {} } {
            if { ! [string is integer $args] } {
                ::pwtk::error  "expecting an integer but got: $args" 1
            }
            set RUNopt(NICE) [expr abs($args)]
            set RUNopt(NICE_CMD) "nice -$RUNopt(NICE)"
        } else {
            set RUNopt(NICE) {}
            set RUNopt(NICE_CMD) {}
        }
    } else {
        ::pwtk::error "expecting zero or one argument, but got: $args" 1
    }
    return $RUNopt(NICE)
}
#****


#****f* 5.5. Executions/::pwtk::container
# SYNOPSIS
proc ::pwtk::container {args} {
    # PURPOSE
    #   Set or query the "container exec" command. Without a container,
    #   a program is run as:
    #
    #     $prefix program.x $postfix ...
    #
    #   But when a container image is used, the program is run as:
    #
    #     $container $prefix program.x $postfix ...
    #
    #   Example:
    #     singularity exec /path/to/image.sif mpirun -n 8 program.x -npool 2
    #
    #   In this case:
    #     container == singularity exec /path/to/image.sif
    #     prefix    == mpirun -n 8
    #     postfix   == -npool 2
    #
    # USAGE
    #   Set mode:
    #
    #     ::pwtk::container arg1 arg2 ...
    #
    #   Query mode:
    #
    #     ::pwtk::container
    #
    #   To clear the value of the "container", set it to an empty string, i.e.:
    #
    #     ::pwtk::container {}
    #
    # RETURN VALUE
    #   The value of the container exec command
    #   (e.g. "singularity exec /path/to/image.sif").
    #
    # SOURCE    
    variable RUNopt

    if { [llength $args] == 0 } {
        return [varvalue RUNopt(CONTAINER_EXEC)]
    } elseif { [llength $args] == 1 } {
        set RUNopt(CONTAINER_EXEC) {*}$args
    } else {
        set RUNopt(CONTAINER_EXEC) $args
    }
    return $RUNopt(CONTAINER_EXEC)
}
#****


#****f* 5.5. Executions/::pwtk::prefix
# SYNOPSIS
proc ::pwtk::prefix {args} {
    # PURPOSE
    #   Set or query the prefix for the parallel execution of programs. In
    #   parallel mode programs are run as:
    #
    #     $prefix program.x $postfix
    #
    #   An example would be:  mpirun -n 8 program.x -npool 2    
    #
    # USAGE
    #   Set mode:
    #
    #     ::pwtk::prefix value
    #
    #   Query mode:
    #
    #     ::pwtk::prefix
    #
    # RETURN VALUE
    #   The value of the prefix.
    #
    # SOURCE    
    variable RUNopt

    if { [llength $args] == 0 } {
        return [expr { [info exists RUNopt(PREFIX)] ? $RUNopt(PREFIX) : {} }]
    } elseif { [llength $args] == 1 } {
        eval set RUNopt(PREFIX) $args
    } else {
        set RUNopt(PREFIX) $args
    }
    return $RUNopt(PREFIX)
}
#****


#****f* 5.5. Executions/::pwtk::serial_prefix
# SYNOPSIS
proc ::pwtk::serial_prefix {args} {
    # PURPOSE
    #   Set or query the serial_prefix for the serial execution of
    #   programs. In serial mode programs are run as:
    #
    #     $serial_prefix program.x $serial_postfix
    #
    #   An example would be:  VAR=value program.x
    #
    #   Another example where this options needs to be used is when
    #   using QE executables from the container. For example the
    #   following instructs PWTK how to run serial code from
    #   the singularity container:
    #
    #    serial_prefix "singularity exec /path/to/qe-6.7.simg"
    #
    #   where /path/to/qe-6.7.simg is the singularity container image.
    #
    # USAGE
    #   Set mode:
    #
    #     ::pwtk::serial_prefix value
    #
    #   Query mode:
    #
    #     ::pwtk::serial_prefix
    #
    # RETURN VALUE
    #   The value of the serial_prefix.
    #
    # SOURCE    
    variable RUNopt

    if { [llength $args] == 0 } {
        return [expr { [info exists RUNopt(SERIAL_PREFIX)] ? $RUNopt(SERIAL_PREFIX) : {} }]
    } elseif { [llength $args] == 1 } {
        eval set RUNopt(SERIAL_PREFIX) $args
    } else {
        set RUNopt(SERIAL_PREFIX) $args
    }
    return $RUNopt(SERIAL_PREFIX)
}
#****


#****f* 5.5. Executions/::pwtk::postfix
# SYNOPSIS 
proc ::pwtk::postfix {args} {
    # PURPOSE
    #   Set or query the postfix for the parallel execution of programs. In
    #   the parallel mode, programs are run as: 
    #
    #     $prefix program.x $postfix.
    #
    #   An example would be:  mpirun -n 8 program.x -npool 2
    #
    # USAGE
    #   Set mode:
    #
    #     ::pwtk::postfix value
    #
    #   Query mode:
    #
    #     ::pwtk::postfix
    #
    # RETURN VALUE
    #   The value of the postfix.
    #
    # SOURCE
    variable RUNopt
    if { [llength $args] == 0 } {
        return [expr { [info exists RUNopt(POSTFIX)] ? $RUNopt(POSTFIX) : {} }]       
    } elseif { [llength $args] == 1 } {
        eval set RUNopt(POSTFIX) $args
    } else {
        set RUNopt(POSTFIX) $args
    }
    return $RUNopt(POSTFIX)
}
#****

#****f* 5.5. Executions/::pwtk::serial_postfix
# SYNOPSIS 
proc ::pwtk::serial_postfix {args} {
    # PURPOSE
    #   Set or query the prostfix for the serial execution of programs. In
    #   the serial mode, programs are run as: 
    #
    #     $serial_prefix program.x $serial_postfix.
    #
    #   An example would be:  ESPRESSO_PSEUDO=~/pw/pseudo pw.x -environ
    #
    # USAGE
    #   Set mode:
    #
    #     ::pwtk::serial_postfix value
    #
    #   Query mode:
    #
    #     ::pwtk::serial_postfix
    #
    # RETURN VALUE
    #   The value of the serial_postfix.
    #
    # SOURCE
    variable RUNopt
    if { [llength $args] == 0 } {
        return [expr { [info exists RUNopt(SERIAL_POSTFIX)] ? $RUNopt(SERIAL_POSTFIX) : {} }]       
    } elseif { [llength $args] == 1 } {
        eval set RUNopt(SERIAL_POSTFIX) $args
    } else {
        set RUNopt(SERIAL_POSTFIX) $args
    }
    return $RUNopt(SERIAL_POSTFIX)
}
#****


#****f* 5.4. Directories and Pseudopotentials/::pwtk::bin_dir
# SYNOPSIS 
proc ::pwtk::bin_dir {args} {
    # PURPOSE
    #   Set or query the directory where the Quantum-ESPRESSO binaries
    #   are located.
    #
    # USAGE
    #   Set mode:
    #
    #     ::pwtk::bin_dir value    
    #
    #   Query mode:
    #
    #     ::pwtk::bin_dir
    #
    # RETURN VALUE
    #   The value of the bin_dir.
    #
    # SOURCE
    variable QEdir

    if { [llength $args] == 0 } {
	if { [info exists QEdir(BIN_DIR)] } {
	    return $QEdir(BIN_DIR)
	} else {
	    return ""
	}
    } elseif { [llength $args] != 1 } {
        pwtk::error "wrong # arguments, must be: \"bin_dir value\",\nbut got \"bin_dir $args\"" 1
    }

    set bin_dir [lindex $args 0]

    if { ! [file isdirectory $bin_dir] } {
	::pwtk::warning "bin_dir \"$bin_dir\" does not exist."
    }

    set QEdir(BIN_DIR) $bin_dir

    global env
    set env(PATH) $QEdir(BIN_DIR):$env(PATH)

    return $QEdir(BIN_DIR)
}
#****


#****f* 5.4. Directories and Pseudopotentials/::pwtk::pseudo_dir
# SYNOPSIS 
proc ::pwtk::pseudo_dir {args} {
    # PURPOSE
    #   Set or query the directory where pseudo-potential files are located.
    #
    # USAGE
    #   Set mode:
    #
    #     ::pwtk::pseudo_dir value    
    #
    #   Query mode:
    #
    #     ::pwtk::pseudo_dir
    #
    # RETURN VALUE
    #   The value of the pseudo_dir.
    #
    # SOURCE
    variable QEdir

    if { [llength $args] == 0 } {
        return [varvalue QEdir(ESPRESSO_PSEUDO)]
    } elseif { [llength $args] != 1 } {
        pwtk::error "wrong # arguments, must be: \"pseudo_dir value\",\nbut got \"pseudo_dir $args\"" 1
    }

    set pseudo_dir [lindex $args 0]
    
    if { ! [file isdirectory $pseudo_dir] } {
	::pwtk::warning "pseudo_dir \"$pseudo_dir\" does not exist."
    }

    return [set QEdir(ESPRESSO_PSEUDO) $pseudo_dir]
}
#****


#****f* 5.5. Executions/::pwtk::prog
# SYNOPSIS 
proc ::pwtk::prog {prog {pathname {}}} {}
proc ::pwtk::prog {args} {
    # USAGE
    #    ::pwtk::prog PROG ?PATHNAME?
    #
    # PURPOSE
    #   Explicitly set or query the full pathname/filename for $prog
    #   executable.
    #
    #   Set mode:    
    #     ::pwtk::prog PROG PATHNAME
    #   Query mode:
    #     ::pwtk::prog PROG
    #
    # ARGUMENTS
    #   * PROG -- canonical name of the QE program (e.g. pw.x)
    #   * PATHNAME -- (optional) full pathname of the PROG executable (e.g. /usr/bin/pw.x);
    #                 if not specified, the current value for PROG is returned
    #
    # FURTHER DESCRIPTION
    #   For example: 
    #       ::pwtk::prog pw.x /full/path/to/pw.x
    #   is equivalent to:
    #       ::pwtk::pw /full/path/to/pw.x
    #
    #
    # RETURN VALUE
    #   The full pathname for the PROG, /full/path/to/prog (e.g. /full/path/to/pw.x)
    #
    # SOURCE
    variable QEprog

    lassign $args prog pathname
    set PROG [string toupper [regsub {\.x$} $prog {}]]

    if { [llength $args] == 1 } {
        # query mode
        ifempty QEprog($PROG) {
            return [findExecutable $prog]
        } else {
            return $QEprog($PROG)
        }
    } elseif { [llength $args] == 2 } {
        # set mode
        return [set QEprog($PROG) [findExecutable $pathname]]
    } else {
        ::pwtk::error "wrong number of arguments, must be [procName] PROG ?PATHNAME?, but got: [procName] $args" 1
    }
}
#****


#****a* 5.5. Executions/Individual Executables
# DESCRIPTION   
#   Routines for explicitly setting individual QE executables.
#
# REMARK
#   Consider using the general ::pwtk::prog command instead.
#******

#****f* Individual Executables/::pwtk::pw
# SYNOPSIS 
proc ::pwtk::pw {pw} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for pw.x executable
    #   (i.e. /full/path/to/pw.x).
    # RETURN VALUE
    #   The value of the pw.
    # SOURCE
    variable QEprog

    return [set QEprog(PW) [findExecutable $pw]]   
}
#****


#****f* Individual Executables/::pwtk::cp
# SYNOPSIS 
proc ::pwtk::cp {cp} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for cp.x executable
    #   (i.e. /full/path/to/cp.x).
    # RETURN VALUE
    #   The value of the cp.
    # SOURCE
    variable QEprog

    return [set QEprog(CP) [findExecutable $cp]]
}
#****


#****f* Individual Executables/::pwtk::ph
# SYNOPSIS 
proc ::pwtk::ph {ph} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for ph.x executable
    #   (i.e. /full/path/to/ph.x).
    # RETURN VALUE
    #   The value of the ph.
    # SOURCE
    variable QEprog

    return [set QEprog(PH) [findExecutable $ph]]
}
#****


#****f* Individual Executables/::pwtk::pp
# SYNOPSIS 
proc ::pwtk::pp {pp} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for pp.x executable
    #   (i.e. /full/path/to/pp.x).
    # RETURN VALUE
    #   The value of the pp.
    # SOURCE
    variable QEprog

    return [set QEprog(PP) [findExecutable $pp]]
}
#****


#****f* Individual Executables/::pwtk::projwfc
# SYNOPSIS 
proc ::pwtk::projwfc {projwfc} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for projwfc.x executable
    #   (i.e. /full/path/to/projwfc.x).
    # RETURN VALUE
    #   The value of the projwfc.
    # SOURCE
    variable QEprog

    return [set QEprog(PROJWFC) [findExecutable $projwfc]]
}
#****


#****f* Individual Executables/::pwtk::dynmat
# SYNOPSIS 
proc ::pwtk::dynmat {dynmat} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for dynmat.x executable
    #   (i.e. /full/path/to/dynmat.x).
    # RETURN VALUE
    #   The value of the dynmat.
    # SOURCE
    variable QEprog

    return [set QEprog(DYNMAT) [findExecutable $dynmat]]
}
#****


#****f* Individual Executables/::pwtk::matdyn
# SYNOPSIS 
proc ::pwtk::matdyn {matdyn} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for matdyn.x executable
    #   (i.e. /full/path/to/matdyn.x).
    # RETURN VALUE
    #   The value of the matdyn.
    # SOURCE
    variable QEprog

    return [set QEprog(MATDYN) [findExecutable $matdyn]]
}
#****


#****f* Individual Executables/::pwtk::q2r
# SYNOPSIS 
proc ::pwtk::q2r {q2r} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for q2r.x executable
    #   (i.e. /full/path/to/q2r.x).
    # RETURN VALUE
    #   The value of the q2r.
    # SOURCE
    variable QEprog

    return [set QEprog(Q2R) [findExecutable $q2r]]
}
#****


#****f* Individual Executables/::pwtk::neb
# SYNOPSIS 
proc ::pwtk::neb {neb} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for neb.x executable
    #   (i.e. /full/path/to/neb.x).
    # RETURN VALUE
    #   The value of the neb.
    # SOURCE
    variable QEprog

    return [set QEprog(NEB) [findExecutable $neb]]
}
#****


#****f* Individual Executables/::pwtk::dos
# SYNOPSIS 
proc ::pwtk::dos {dos} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for dos.x executable
    #   (i.e. /full/path/to/dos.x).
    # RETURN VALUE
    #   The value of the dos.
    # SOURCE
    variable QEprog

    return [set QEprog(DOS) [findExecutable $dos]]
}
#****


#****f* Individual Executables/::pwtk::bands
# SYNOPSIS 
proc ::pwtk::bands {bands} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for bands.x executable
    #   (i.e. /full/path/to/bands.x).
    # RETURN VALUE
    #   The value of the bands.
    # SOURCE
    variable QEprog

    return [set QEprog(BANDS) [findExecutable $bands]]
}
#****

#****f* Individual Executables/::pwtk::molecularpdos
# SYNOPSIS 
proc ::pwtk::molecularpdos {molecularpdos} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for molecularpdos.x executable
    #   (i.e. /full/path/to/molecularpdos.x).
    # RETURN VALUE
    #   The value of the molecularpdos.
    # SOURCE
    variable QEprog

    return [set QEprog(MOLECULARPDOS) [findExecutable $molecularpdos]]
}
#****


#****f* Individual Executables/::pwtk::hp
# SYNOPSIS 
proc ::pwtk::hp {hp} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for hp.x executable
    #   (i.e. /full/path/to/hp.x).
    # RETURN VALUE
    #   The value of the hp.
    # SOURCE
    variable QEprog

    return [set QEprog(HP) [findExecutable $hp]]
}
#****


#****f* Individual Executables/::pwtk::turbo_davidson
# SYNOPSIS 
proc ::pwtk::turbo_davidson {turbo_davidson} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for turbo_davidson.x executable
    #   (i.e. /full/path/to/turbo_davidson.x).
    # RETURN VALUE
    #   The value of the turbo_davidson.
    # SOURCE
    variable QEprog

    return [set QEprog(TURBO_DAVIDSON) [findExecutable $turbo_davidson]]
}
#****


#****f* Individual Executables/::pwtk::turbo_lanczos
# SYNOPSIS 
proc ::pwtk::turbo_lanczos {turbo_lanczos} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for turbo_lanczos.x executable
    #   (i.e. /full/path/to/turbo_lanczos.x).
    # RETURN VALUE
    #   The value of the turbo_lanczos.
    # SOURCE
    variable QEprog

    return [set QEprog(TURBO_LANCZOS) [findExecutable $turbo_lanczos]]
}
#****


#****f* Individual Executables/::pwtk::turbo_eels
# SYNOPSIS 
proc ::pwtk::turbo_eels {turbo_eels} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for turbo_eels.x executable
    #   (i.e. /full/path/to/turbo_eels.x).
    # RETURN VALUE
    #   The value of the turbo_eels.
    # SOURCE
    variable QEprog

    return [set QEprog(TURBO_EELS) [findExecutable $turbo_eels]]
}
#****


#****f* Individual Executables/::pwtk::turbo_spectrum
# SYNOPSIS 
proc ::pwtk::turbo_spectrum {turbo_spectrum} {
    # PURPOSE
    #   Explicitly set the full pathname/filename for turbo_spectrum.x executable
    #   (i.e. /full/path/to/turbo_spectrum.x).
    # RETURN VALUE
    #   The value of the turbo_spectrum.
    # SOURCE
    variable QEprog

    return [set QEprog(TURBO_SPECTRUM) [findExecutable $turbo_spectrum]]
}
#****



#****f* 5.4. Directories and Pseudopotentials/::pwtk::pseudo_download
# SYNOPSIS
proc ::pwtk::pseudo_download {args} {
    # USAGE
    #   ::pwtk::pseudo::download  ?-url URL?  PSEUDO1  ?PSEUDO2? ...
    #
    # PURPOSE    
    #   Download the pseudopotential files from the URL directory to
    #   'pseudo_dir' if they are not present in 'pseudo_dir'.
    #
    # OPTION
    # * -url ... list of URL addresses from where to download the pseudopotentials;
    #            default = {https://pseudopotentials.quantum-espresso.org/upf_files/ http://pseudopotentials.quantum-espresso.org/upf_files/}
    #
    # ARGUMENTS
    # * PSEUDO1, PSEUDO2, ... list of pseudopotential files to download from URL
    #
    # EXAMPLE
    #   ::pwtk::pseudo::download Fe.pz-nd-rrkjus.UPF O.pz-rrkjus.UPF
    #
    # RETURN VALUE
    #   The list of downloaded pseudopotentials.
    #
    # SOURCE

    # parse options & arguments
    
    set nargmin 1
    set nargmax -1    
    set usage "-url URL  PSEUDO1 ?PSEUDO2? ..."
    set options {
        {url.arg {https://pseudopotentials.quantum-espresso.org/upf_files http://pseudopotentials.quantum-espresso.org/upf_files} "URL addresses from where to download the pseudopotentials"}
    }
    ::pwtk::parseOpt_

    set pseudoList $args
    set urls $opt(url)

    # get pseudo_dir
    #
    # from INPUT_PW.html: 
    #    Default: value of the $ESPRESSO_PSEUDO environment variable if set;
    #            '$HOME/espresso/pseudo/' otherwise
    
    set pseudo_dir [::pwtk::input::namelistGetVarValue CONTROL pseudo_dir trim]
    ::pwtk::ifset pseudo_dir [::pwtk::pseudo_dir]
    ::pwtk::ifset pseudo_dir [varvalue ::env(ESPRESSO_PSEUDO)]
    ::pwtk::ifset pseudo_dir $::env(HOME)/espresso/pseudo

    try {
        if { ! [file exists $pseudo_dir] } {
            infoMsg "from [procName]: creating pseudo_dir $pseudo_dir "
            file mkdir $pseudo_dir
        }
    } on error err {
        ::pwtk::error "error creating pseudo_dir $pseudo_dir\n\n$err" 1
    }

    # wget or curl ?
    
    set dnl [::pwtk::getExecutable wget curl]
    
    # download PPs
    
    set result {}
    foreach pseudo $pseudoList {
        set full_pseudo [file normalize [file join $pseudo_dir $pseudo]]
        if { ! [file exists $full_pseudo] } {
            switch -glob -- $dnl {
                *wget { set o -O }
                *curl { set o -o }
                default {
                    ::pwtk::error "cannot download $pseudo from the internet: neither wget nor curl found" 1
                }
            }
            set nl 1
            foreach url $urls {
                ::pwtk::print "Downloading $pseudo from $url"
                ::pwtk::try_exec -i -- $dnl $url/$pseudo $o $full_pseudo

                # sometimes a download from https://* fails due to
                # certificate issue. Hence, check that $full_pseudo
                # exists and is of non-zero size
                
                if { [file exists $full_pseudo] } {
                    if { [file size $full_pseudo] > 0 } {
                        break
                    } else {
                        file delete $full_pseudo
                    }
                }
            }
            if { ! [file exists $full_pseudo] || [file size $full_pseudo] == 0 } {
                ::pwtk::error "failed to download the $pseudo pseudopotential from [join $urls { and }]" 1
            }
            lappend result $pseudo
        }
    }
    if { [info exists nl] } { puts "" }
    
    return $result
}
#******


#****f* 5.4. Directories and Pseudopotentials/::pwtk::pseudo_auto_download
# SYNOPSIS
proc ::pwtk::pseudo_auto_download {args} {
    # USAGE
    #   # query mode
    #   pseudo_auto_download
    #
    #   # activate auto-downloading of pseudopotentials
    #   pseudo_auto_download on
    #
    #   # deactivate auto-downloading of pseudopotentials
    #   pseudo_auto_download off
    #
    # PURPOSE
    #   Query or set (activate, deactivate) the auto-downloading of
    #   pseudopotentials from the internet.    
    #
    # RETURN VALUE
    # * 1 if the auto-downloading of pseudopotentials is enabled
    # * 0 otherwise
    #
    # SOURCE
    variable state

    if { $args ne {} } {
        if { ! [::pwtk::type::number fboolean -strict $args] } {
            ::pwtk::error "expected boolean but got \"$args\"" 1
        }
        if { [is_true $args] } {
            set state(pseudo_auto_download) 1
        } else {
            set state(pseudo_auto_download) 0
        }
    }

    return $state(pseudo_auto_download)
}
#******
