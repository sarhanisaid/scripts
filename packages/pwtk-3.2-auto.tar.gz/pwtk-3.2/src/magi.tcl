#
# $RCSfile: magi.tcl,v $ --
#
#      This file contains procs for handling the turbo_magnon.x input.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: magi.tcl,v 1.1 2021/05/01 19:24:39 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::magi_fprint {{file {}}} { uplevel ::pwtk::magi::fprint $file }
proc ::pwtk::magi_clear  {}          { uplevel ::pwtk::magi::clear }
proc ::pwtk::magi_get    {}          { uplevel ::pwtk::magi::get }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::magi/::pwtk::magi::fprint
# SYNOPSIS
proc ::pwtk::magi::fprint {{file {}}} {
# PURPOSE
#   Print the content of turbo_magnon.x input to a file or to stdout if the
#   file argument was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::magi $file
}
#****


#****f* ::pwtk::magi/::pwtk::magi::get
# SYNOPSIS
proc ::pwtk::magi::get {} {
    # DESCRIPTION    
    #   Return the content of the turbo_magnon.x input 
    # SOURCE
    variable namelist_flow_list
    
    ::pwtk::lri::loadDefaults_

    foreach nml $namelist_flow_list {
        append inp [::pwtk::input::namelistGet $nml]
    }
   
    return $inp
}
#******
    
#****f* ::pwtk::magi/::pwtk::magi::clear
# SYNOPSIS
proc ::pwtk::magi::clear {} {
    # DESCRIPTION    
    #   Clear the content of the turbo_magnon.x input 
    # SOURCE
    variable input_flow_list
    foreach name $input_flow_list {
	::pwtk::input::clear $name
    }
}
#******
    
#****f* ::pwtk::magi/::pwtk::magi::load_fromMAGI
# SYNOPSIS
proc ::pwtk::magi::load_fromMAGI {magi {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing turbo_magnon.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * magi -- filename of the turbo_magnon.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?

    #
    # SOURCE
    variable namelist_flow_list

    ::pwtk::lri::load_from_input_  turbo_magnon.x  $namelist_flow_list  $magi  $clear_existing
}
#******
