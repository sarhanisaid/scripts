#
# $RCSfile: queue.tcl,v $ --
#
#      In this file a generic support for queueing system is
#      implemented.
#
#      In the case of running a program via a queueing system, the
#      pwtk does not run the programs directly, but it constructs a
#      batch shell script and then submits it to the queueing system.
#
#
# Copyright (c) 2009-2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: queue.tcl,v 1.5 2021/05/03 20:16:43 tone Exp $ 
#


#****f* ::pwtk::queue/::pwtk::queue::init
# SYNOPSIS
proc ::pwtk::queue::init {queueSystem queueSubmitCmd queueDirectiveString} {
    # PURPOSE    
    #   Initialization of a batch queuing support for the
    #   $queueSystem.  It initializes the variables and creates
    #   ${queueSystem}_*** flavor of commands.
    #
    #   A given implementation of a queuing system must define it's
    #   own 'init' proc (for an implementation, see
    #   ::pwtk::slurm::init). Additionally, it may also define the
    #   ::pwtk::${queueSystem}::parseOptions_ proc.
    #
    # ARGUMENTS
    #   * queueSystem -- name of the batch queuing system (e.g. slurm, ll, lsf, ...)
    #   * queueSubmitCmd -- queuing system submit command (e.g. sbatch, qsub...)
    #   * queueDirectiveString -- string used to specify directives in batch shell script
    #                             (e.g. #SBATCH, #PBS...)
    # SOURCE

    variable queue    
    variable profile
    variable pwtk_profile

    set queue($queueSystem,directive) $queueDirectiveString
    set queue($queueSystem,submitCmd) $queueSubmitCmd
    set queue($queueSystem,submitOpts) {}
    
    foreach part {profile head pwtk tail} {
        ::pwtk::ifset queue($queueSystem,$part) {}
    }
                            
    # define the short-cut ${queueSystem}_*** commands
    
    set QUEUE [string toupper $queueSystem]

    if { [info procs ::pwtk::${queueSystem}_head] eq {} } {
        proc ::pwtk::${QUEUE} {args} "uplevel ::pwtk::queue::QUEUE $queueSystem \$args"

	foreach sep {:: _} {
            proc ::pwtk::${queueSystem}${sep}head  {args} [concat ::pwtk::queue::head $queueSystem \{*\}\$args]
            proc ::pwtk::${queueSystem}${sep}tail  {args} [concat ::pwtk::queue::tail $queueSystem \{*\}\$args]
        
            proc ::pwtk::${queueSystem}${sep}get    {{profileName {}}} [concat ::pwtk::queue::get $queueSystem \{*\}\$profileName]
            proc ::pwtk::${queueSystem}${sep}clear  {} [list ::pwtk::queue::clear $queueSystem]
            proc ::pwtk::${queueSystem}${sep}fprint {{file {}}} [concat ::pwtk::queue::fprint $queueSystem \{*\}\$file]

            proc ::pwtk::${queueSystem}${sep}profile {profileName {queueSpecs {}} {pwtkSpecs {}}} \
                [concat ::pwtk::queue::profile $queueSystem \$profileName \$queueSpecs \$pwtkSpecs]
            proc ::pwtk::${queueSystem}${sep}profileDefault {profileName} \
                [concat ::pwtk::queue::profileDefault $queueSystem \$profileName]       
            proc ::pwtk::${queueSystem}${sep}pwtk_profile {profileName {pwtkSpecs {}}} \
                [concat ::pwtk::queue::pwtk_profile $queueSystem \$profileName \$pwtkSpecs]
            proc ::pwtk::${queueSystem}${sep}pwtk_profileDefault {profileName} \
                [concat ::pwtk::queue::pwtk_profileDefault $queueSystem \$profileName]
        }
        foreach cmd {
            head
            tail       
            get 
            clear
            fprint

            profile
            profileDefault
            pwtk_profile
            pwtk_profileDefault
	} {
            namespace eval ::pwtk namespace export ${queueSystem}_$cmd
            namespace eval :: namespace import ::pwtk::${queueSystem}_$cmd
        }
    }
}
#******


proc ::pwtk::queue::compatibility {} {
    # PURPOSE
    #   Support BACKWARD compatibility for PWTK version < 3.0, i.e.,
    #   the old config specs, which were specified via the arrays
    #   ::pwtk::${queueSystem}::profile(*) and ::pwtk::${queueSystem}::pwtk_profile(*)
    
    set queueSystem [uplevel 1 namespace current]
    
    foreach elem [array names ::pwtk::${queueSystem}::profile] {
        upvar ::pwtk::${queueSystem}::profile _profile
	set profile($queueSystem,$elem) $_profile($elem)
    }
    foreach elem [array names ::pwtk::${queueSystem}::pwtk_profile] {
        upvar ::pwtk::${queueSystem}::pwtk_profile _pwtk_profile
	set pwtk_profile($queueSystem,$elem) $_pwtk_profile($elem)
    }
}


#****f* ::pwtk::queue/::pwtk::queue::QUEUE
# SYNOPSIS
proc ::pwtk::queue::QUEUE {queueSystem args} {
    # PURPOSE
    #   This is a driver for the execution of PWTK script with the
    #   batch-queuing system. It creates a batch shell script and a
    #   pwtk script that is executed within batch shell script. Then
    #   it submits the batch shell script to the queue.
    #
    #   This is a generic command used by the implementation of
    #   specific queuing systems, such as SLURM, LL, LSF, which are
    #   created with "::pwtk::queue::init $queueSystem ..."
    #
    #   The batch shell script consists of four parts:
    #
    #        profile   (always exists)
    #         |
    #        head      (optional)
    #         |
    #        pwtk      (always exists)
    #         |
    #        tail      (optional)
    #
    #   where:
    #   * profile -- contains the batch-queue directives (e.g. #SBATCH);
    #                it is set with ${queueSystem}_profile command

    #   * head -- contains optional shell commands that are executed
    #             prior to executing PWTK, such as "module load ...";
    #             it is set with ${queueSystem}_head command
    
    #   * pwtk -- in this part, the PWTK script is executed;
    #             it is set internally by PWTK
    
    #   * tail -- contains optional shell commands that are executed
    #             after the PWTK script finishes;
    #             it is set with ${queueSystem}_tail command
    #
    # USAGE    
    #     ::pwtk::queue::QUEUE queueSystem ?profile? ?-option value ...? script
    # or 
    #     ::pwtk::queue::QUEUE queueSystem ?profile? ?-option value ...? file
    #
    # EXAMPLES
    #     ::pwtk::queue::QUEUE queueSystem file.pwtk
    #     ::pwtk::queue::QUEUE queueSystem { ...script code... }
    #     ::pwtk::queue::QUEUE queueSystem -option1 value1 -option2 -option3 ... file.pwtk
    #     ::pwtk::queue::QUEUE queueSystem -option1 value1 -option2 -option3 ... { ...script code... }
    #
    #     ::pwtk::queue::QUEUE queueSystem profile file.pwtk
    #     ::pwtk::queue::QUEUE queueSystem profile { ...script code...}
    #     ::pwtk::queue::QUEUE queueSystem profile -option1 value1 -option2 -option3 ... file.pwtk
    #     ::pwtk::queue::QUEUE queueSystem profile -option1 value1 -option2 -option3 ... { ...script code... }
    #
    # REMARK
    #   The last argument of the ::pwtk::queue::QUEUE can be either a PWTK script-code or a PWTK file.
    #
    # ARGUMENTS
    #   * queueSystem -- name of the batch queuing system (e.g. slurm, ll, lsf, ...)
    #   * args        -- various arguments (see USAGE and EXAMPLES)
    #     
    # SOURCE
    
    variable direct
    variable queue
    variable counter
    variable pwtk_profile

    # direct mode (i.e. pwtk is executed directly from the created batch script)    
    set direct 1
    incr counter
    
    #
    # parse command-line arguments
    #

    set QUEUE   [string toupper $queueSystem]    
    set nargs   [llength $args]
    set lastarg [lindex $args end]
    set profileName default

    if { $nargs == 0 } {
        ::pwtk::error "no script provided to the $QUEUE command" 1
    } elseif { $nargs == 1 } {
        # called as: $QUEUE script
        # (no parsing of args needed)

        ::pwtk::queue::setProfile_ $queueSystem default

    } elseif { $nargs >= 2} {
        # called with profile and/or options
        # N.B. some options have values but others have not, hence do not make the even-odd check!

        if { [regexp ^- $args] } {
            # the profile was not specified, use default
            set args [concat default $args]            
            incr nargs
        }
        set profileName [lindex $args 0]
        ::pwtk::queue::setProfile_ $queueSystem {*}[lrange $args 0 $nargs-2]
    }

    # script or file ?
        
    if { [file exists $lastarg] } {
        # the last argument is a file
        set scriptHead [file tail [file rootname $lastarg]]
        set script     [::pwtk::readFile $lastarg]
    } else {
        # the last argument is a script code
        set scriptHead [file tail [file rootname [info script]]]
        set script     $lastarg
    }
    
    # PWTK profile script
    
    ::pwtk::ifnotempty pwtk_profile($queueSystem,$profileName) {
        set pwtk_profile_ $pwtk_profile($queueSystem,$profileName)\n
    }
    set script [::pwtk::varvalue pwtk_profile_]$script

    # filenames

    if { $scriptHead ne {} } { append scriptHead . }
    set pwtk_scriptName  [::pwtk::queue::scriptName_ ${scriptHead}$queueSystem.pwtk]
    set pwtk_logName     $pwtk_scriptName.log
    set queue_scriptName [::pwtk::queue::scriptName_ ${scriptHead}$queueSystem.sh]

    writeFile $pwtk_scriptName [::pwtk::propagate_dump]\n$script
    set queue($queueSystem,pwtk) "pwtk $pwtk_scriptName > $pwtk_logName 2>&1\n\n"

    # printout
    
    ::pwtk::printTitle $QUEUE "running PWTK script within the $QUEUE batch queuing system"    
    ::pwtk::print "batch PWTK script  :  $pwtk_scriptName"
    ::pwtk::print "batch PWTK log file:  $pwtk_logName"
    ::pwtk::print "batch profile name :  $profileName"
    ::pwtk::ifnotempty pwtk_profile_ {
        ::pwtk::print "batch PWTK script profile:\n"
        ::pwtk::print [::pwtk::trimIndent $pwtk_profile_]
    }
    ::pwtk::print "\n$QUEUE batch script:  $queue_scriptName
Content of the $QUEUE script:\n\n[::pwtk::skipEmptyLines [get $queueSystem]]\n"

    # submit to $QUEUE
    
    ::pwtk::queue::submit  $queueSystem  $queue_scriptName
    
    set direct 0
}
#****


#****f* ::pwtk::queue/::pwtk::queue::clear
# SYNOPSIS
proc ::pwtk::queue::clear {queueSystem} {
    # PURPOSE
    #   Clear the content of a batch queue shell-script.
    # ARGUMENT
    #   * queueSystem -- one among the supported queue systems (slurm, lsf, ll)
    #
    # SOURCE

    variable queue
    array set queue [list $queueSystem,profile {} $queueSystem,head {} $queueSystem,pwtk {} $queueSystem,tail {}]
}
#******


#****if* Internals/::pwtk::queue::optionParser
proc ::pwtk::queue::optionParser {queueSystem parser} {
    # USAGE
    #   ::pwtk::queue::optionParser $queueSystem none
    # or
    #   ::pwtk::queue::optionParser $queueSystem parse
    #
    # DESCRIPTION
    #   How to parse options, specified on the QUEUE command-line. Possibilities are:
    #   * none -- do not parse options, but add them verbatim as the command-line options of the $queue($queueSystem,submitCmd) command
    #   * parse -- parse options and incorporate them into the Slurm batch script file
    #
    # SOURCE
    
    if { [info procs ::pwtk::${queueSystem}::parseOptions_] ne {} } {
        rename ::pwtk::${queueSystem}::parseOptions_ {}
    }
    switch -glob --  $parser {
        none {
            rename ::pwtk::${queueSystem}::addOptionsToCmdLine_ ::pwtk::${queueSystem}::parseOptions_
        }
        parse* {
            rename ::pwtk::${queueSystem}::addOptionsToBatchScript_ ::pwtk::${queueSystem}::parseOptions_
        }
        default {
            ::pwtk::error "wrong type of the ${queueSystem} option parser '$parser', must be 'none' or 'parse'" 1
        }
    }
}
#******


#****if* Internals/::pwtk::queue::setProfile_
# SYNOPSIS
proc ::pwtk::queue::setProfile_ {queueSystem args} {
    # PURPOSE
    #   This proc sets the profile-part of the batch-queuing script,
    #   i.e., the top part of the batch shell script containing #QUEUE
    #   directives, where QUEUE = SBATCH, BSUB...
    #
    # USAGE
    #   setProfile_ queueSystem ?PROFILE? ?OPTIONS?
    #
    # ARGUMENTS
    #   * queueSystem -- name of batch queuing system (e.g. slurm, ll, lsf, ...)
    #   * PROFILE     -- (optional) name of the profile (if not specified, default profile is used)
    #   * OPTIONS     -- (optional) batch-queuing options (e.g. -option1 value1 -option2 -option3 ...)
    #
    # SOURCE

    variable profile
    variable queue

    if { [regexp ^- $args] } {
        # profile was not specified, use default
        set args [concat default $args]
    }
    set profileName [lindex $args 0]
    if { ! [info exists profile($queueSystem,$profileName)] } {
        ::pwtk::error "the $queueSystem profile '$profileName' does not exist." 1
    }

    if { [info procs ::pwtk::${queueSystem}::parseOptions_] ne {} } {
        # implementation of this queue system has its parseOptions_ proc
        
	::pwtk::${queueSystem}::parseOptions_ {*}$args        
    } else {
        # Use the generic recipe, i.e., treat the QUEUE command-line
        # options as the command-line options of the $queue($queueSystem,submitCmd) command

	set queue($queueSystem,profile) [::pwtk::trimIndent $profile($queueSystem,$profileName)]\n
        set queue($queueSystem,submitOpts) [lrange $args 1 end]
    }
}
#******


#****if* Internals/::pwtk::queue::part_
proc ::pwtk::queue::part_ {what queueSystem args} {
    variable queue

    if { [llength $args] > 0 } {
        # mode = set or clear
        set queue($queueSystem,$what) [::pwtk::trimIndent {*}$args]\n
    }
    return [::pwtk::varvalue queue($queueSystem,$what)]    
}
#******


#****f* ::pwtk::queue/::pwtk::queue::head
# SYNOPSIS
proc ::pwtk::queue::head {queueSystem args} {
    # PURPOSE
    #   Set, clear, or query the head-part of the batch-queuing shell script.
    #
    # USAGE
    #   set mode:
    #       ::pwtk::queue::head $queueSystem { ...shell-script code... }
    #   clear mode:
    #       ::pwtk::queue::head $queueSystem {}
    #   query mode:
    #       ::pwtk::queue::head $queueSystem
    #
    # RETURN VALUE
    #   The content of the head-part of the batch-queuing shell script.
    #
    # SOURCE
    return [::pwtk::queue::part_ head $queueSystem {*}$args]
}
#****


#****f* ::pwtk::queue/::pwtk::queue::tail
# SYNOPSIS
proc ::pwtk::queue::tail {queueSystem args} {
    # PURPOSE
    #   Set, clear, or query the tail-part of the batch-queuing shell script.
    #
    # USAGE
    #   set mode:
    #       ::pwtk::queue::tail $queueSystem { ...shell-script code... }
    #   clear mode:
    #       ::pwtk::queue::tail $queueSystem {}
    #   query mode:
    #       ::pwtk::queue::tail $queueSystem
    #
    # RETURN VALUE
    #   The content of the tail-part of the batch-queuing shell script.
    #
    # SOURCE
    return [::pwtk::queue::part_ tail $queueSystem {*}$args]
}
#****


#****f* ::pwtk::queue/::pwtk::queue::get
# SYNOPSIS
proc ::pwtk::queue::get {queueSystem {profileName {}}} { 
    # PURPOSE
    #   Returns the content of the whole $queueSystem batch shell script.
    #
    #   If the 'profileName' is not specified, the last used profile
    #   is used and if no profile was used, the default profile is used.
    #
    # ARGUMENTS
    #   * queueSystem -- name of batch queuing system (e.g. slurm, ll, lsf, ...)

    #   * profileName -- (optional) for which profile to return the
    #                    content of the whole $queueSystem batch shell-script;
    #
    # SOURCE
    variable queue
    variable profile

    if { $profileName eq {} } {
        if { [info exists queue($queueSystem,profile)] } {
            set profileScript $queue($queueSystem,profile)
        } else {
            set profileScript [::pwtk::varvalue profile($queueSystem,default)]
        }
    } else {
        ::pwtk::ifnotexist profile($queueSystem,$profileName) {
            ::pwtk::error "the $queueSystem profile '$profileName' does not exist" 1
        }
        set profileScript $profile($queueSystem,$profileName)
    }
    return ${profileScript}[::pwtk::varvalue queue($queueSystem,head)][::pwtk::varvalue queue($queueSystem,pwtk)][::pwtk::varvalue queue($queueSystem,tail)]
}
#****


#****f* ::pwtk::queue/::pwtk::queue::fprint
# SYNOPSIS
proc ::pwtk::queue::fprint {queueSystem {file ""}} { 
    # PURPOSE
    #   Write the content of the batch shell script for the queueSystem to file or stdout.
    # ARGUMENTS
    #   * queueSystem -- name of batch-queuing system (e.g. slurm, ll, lsf, ...)
    #   * file        -- (optional) filename to print to; if not specified, stdout is used
    # SOURCE
    
    if { $file eq {} } {
        puts [get $queueSystem]
    } else {
        ::pwtk::writeFile $file [get $queueSystem]
    }
}
#***


#****f* ::pwtk::queue/::pwtk::queue::submit
# SYNOPSIS
proc ::pwtk::queue::submit {queueSystem {file ""}} {
    # PURPOSE    
    #   A generic proc for submitting to the $queueSystem queuing
    #   system. An implementation of a specific queing system may
    #   define a custom submit routine, which is used if defined.
    #   
    # ARGUMENTS
    #   * queueSystem -- name of the batch queuing system (e.g. slurm, ll, lsf, ...)
    #   * file        -- filename of the batch script that will be written (optional, default = job.$queueSystem)
    # SOURCE
    
    if { $file == {} } {
	set scriptName job.$queueSystem
    }
    fprint $queueSystem {*}$file

    if { $queueSystem eq "queue" } {
        # prevent an infinite recursive call to ::pwtk::queue::submit
        # with '::pwtk::queue::submit queue ?file?'
        return
    } elseif { [info procs ::pwtk::${queueSystem}::submit] ne {} } {

        # the submit command for $queueSystem is defined	
	::pwtk::${queueSystem}::submit $file    
	
    } else {
        # a generic 'submit' recipe        
        variable queue
        
        ::pwtk::ifexist queue($queueSystem,submitCmd) {
            ::pwtk::print  "Running:   exec $queue($queueSystem,submitCmd) $queue($queueSystem,submitOpts) $file &"
            ::pwtk::print [::pwtk::try_exec -- {*}$queue($queueSystem,submitCmd) {*}$queue($queueSystem,submitOpts) $file &]

            # BEWARE: queue($queueSystem,submitOpt) are one-time options, reset them 
            set queue($queueSystem,submitOpts) {}
        } else {
            ::pwtk::error "cannot submit jobs because the '$queueSystem' queuing system was not initialized" 1
        }
    }
}
#****


#****f* ::pwtk::queue/::pwtk::queue::profile
# SYNOPSIS
proc ::pwtk::queue::profile {queueSystem profileName {queueProfileSpecs {}} {pwtkProfileSpecs {}}} {
    # PURPOSE
    #   Set or query a profile $profileName for a given $queueSystem queuing system.
    #
    # ARGUMENTS
    #   * queueSystem -- name of the batch-queuing system (e.g. slurm, lsf, ll)
    #   * profileName -- name of the profile 
    #   * queueProfileSpecs -- profile's definition named $profileName for $queueSystem 
    #   * pwtkProfileSpecs  -- PWTK specs associated with the $profileName profile for $queueSystem
    #
    # RETURN VALUE
    #   The value of the queueSystem's profileName profile or an empty
    #   string if the profile does not exist
    #
    # SOURCE
    variable profile

    if { $queueProfileSpecs ne "" } {
        set profile($queueSystem,$profileName) $queueProfileSpecs
    }
    if { $pwtkProfileSpecs ne "" } {
        pwtk_profile $queueSystem $profileName $pwtkProfileSpecs
    }
    return [::pwtk::varvalue profile($queueSystem,$profileName)]
}
#******


#****f* ::pwtk::queue/::pwtk::queue::pwtk_profile
# SYNOPSIS
proc ::pwtk::queue::pwtk_profile {queueSystem profileName {pwtkProfileSpecs {}}} {
    # PURPOSE
    #   Set or query a PWTK profile $profileName for a given $queueSystem queuing system.
    #
    # ARGUMENTS
    #   * queueSystem -- name of batch queuing system (e.g. slurm, lsf, ll ...)
    #   * profileName -- name of profile 
    #   * pwtkProfileSpecs -- profile's definition
    #
    # RETURN VALUE
    #   The value of the queueSystem's profileName pwtk_profile or an empty
    #   string if the pwtk_profile does not exist    
    # SOURCE
    variable pwtk_profile

    if { $pwtkProfileSpecs ne "" } {
        set pwtk_profile($queueSystem,$profileName) $pwtkProfileSpecs
    }
    return [::pwtk::varvalue pwtk_profile($queueSystem,$profileName)]
}
#******


#****f* ::pwtk::queue/::pwtk::queue::profileDefault
# SYNOPSIS
proc ::pwtk::queue::profileDefault {queueSystem profileName} {
    # PURPOSE
    #   Set a given profile as a default profile.
    # ARGUMENTS
    #   * queueSystem -- name of batch queuing system (e.g. slurm, ll, lsf, ...)
    #   * profileName -- name of profile that will become default-profile
    # SOURCE
    variable profile

    if { ! [info exists profile($queueSystem,$profileName)] } {
	::pwtk::error "${queueSystem}'s profile $profileName does not exist, cannot set it as the default profile"
    }
    set profile($queueSystem,default) $profile($queueSystem,$profileName)
}
#******


#****f* ::pwtk::queue/::pwtk::queue::pwtk_profileDefault
# SYNOPSIS
proc ::pwtk::queue::pwtk_profileDefault {queueSystem profileName} {
    # PURPOSE
    #   Set a given PWTK profile as a default profile.
    # ARGUMENTS
    #   * queueSystem -- name of batch queuing system (e.g. slurm, ll, lsf, ...)
    #   * profileName -- name of profile that will become default-profile
    # SOURCE
    variable pwtk_profile

    if { ! [info exists pwtk_profile($queueSystem,$profileName)] } {
	::pwtk::error "${queueSystem}'s PWTK profile $profileName does not exist, cannot set it as the default profile"
    }
    set pwtk_profile($queueSystem,default) $pwtk_profile($queueSystem,$profileName)
}
#******


# internal...
proc ::pwtk::queue::scriptName_ {scriptName} {
    # PURPOSE
    #   Get a scriptName such that for multiple QUEUE runs, the new
    #   scripts do not overwrite the previous ones
    variable counter

    # just in case
    if { ! [info exists counter] || $counter < 1 } {
        set counter 1
    }

    set head [file tail [file rootname  $scriptName]]
    set ext  [file extension $scriptName]
    return $head.${counter}$ext
}
