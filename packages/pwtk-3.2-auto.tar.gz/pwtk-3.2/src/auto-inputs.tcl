#
# $RCSfile: auto-inputs.tcl,v $ --
#
#      This file contains the (semi)auto input definitions for those
#      QE programs that are not manually coded into PWTK.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: auto-inputs.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#

::pwtk::defineInput4Program cppp.x cpppi runCPPP {
    { namelist INPUTPP.ntyp CPPP }
}

::pwtk::defineInput4Program kcw.x kcwi runKCW {
    { namelist CONTROL KCW_CONTROL }
    { namelist WANNIER {} }
    { namelist SCREEN {} }
    { namelist HAM {} }
    { card K_POINTS {} }
}

::pwtk::defineInput4Program postahc.x postahci runPOSTAHC {
    { namelist INPUT POSTAHC }
}

::pwtk::defineInput4Program band_interpolation.x band_inti runBAND_INTERPOLATION {
    { namelist INTERPOLATION {} }
    { card_wo_flags ROUGHNESS {} }
    { card_wo_flags USER_STARS {} }
    { card K_POINTS {} }
}

::pwtk::defineInput4Program d3hess.x d3hessi runD3HESS {
    { namelist INPUT D3HESS }
}

::pwtk::defineInput4Program oscdft_et.x oscdft_eti runOSCDFT_ET {
    { namelist OSCDFT_ET_NAMELIST OSCDFT_ET }
}
::pwtk::defineSynonym oscdft_eti OSCDFT_ET OSCDFT_ET_NAMELIST 

::pwtk::defineInput4Program oscdft_pp.x oscdft_ppi runOSCDFT_PP {
    { namelist OSCDFT_PP_NAMELIST OSCDFT_PP }
}
::pwtk::defineSynonym oscdft_ppi OSCDFT_PP OSCDFT_PP_NAMELIST

::pwtk::defineInput4Program ppacf.x ppacfi runPPACF {
    { namelist PPACF {} }
}

::pwtk::defineInput4Program pprism.x pprismi runPPRISM {
    { namelist INPUTPP RISM_INPUTPP }
    { namelist PLOT RISM_PLOT }
}

::pwtk::defineInput4Program bgw2pw.x bgw2pwi runBGW2PW {
    { namelist INPUT_BGW2PW {} }
}

::pwtk::defineInput4Program pw2bgw.x pw2bgwi runPW2BGW {
    { namelist INPUT_PW2BGW {} }
}

::pwtk::defineInput4Program pw2gw.x pw2gwi runPW2GW {
    { namelist INPUTPP INPUT_PW2GW }
}

::pwtk::defineInput4Program pw2wannier90.x pw2wan90i runPW2WANNIER90 {
    { namelist INPUTPP INPUT_PW2WAN }
}

::pwtk::defineInput4Program pwcond.x pwcondi runPWCOND {
    { namelist.affix INPUTCOND {} }
} {
    INPUTCOND { recover = .true. }
}

::pwtk::defineInput4Program all_currents.x all_curri runALL_CURRENTS {
    { namelist ENERGY_CURRENT {} }
}

::pwtk::defineInput4Program ld1.x ld1i runLD1 {
    { namelist.affix INPUT LD1_INPUT }
    { namelist.affix INPUTP LD1_INPUTP }
    { namelist.affix TEST LD1_TEST }
}
