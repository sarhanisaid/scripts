#
# lobster_run -scf -nscf KGRID -dir DIR  ?OPTIONS?  HEAD  ?LOBSTER_INPUT_DATA?
#
# eval_in_dir myCalc.d {
#    lobster_run -scf -nscf KGRID -dir DIR  ?OPTIONS?  HEAD  ?LOBSTER_INPUT_DATA?
#    lobster_plot -dir DIR ...SPECS...
#    lobster_multiplot -dir DIR ...SPECS...
#    lobster_sumdos -dir DIR  ATOM_INDICES
# }



# ::pwtk::pw_lobster -autodir | -dir DIR ... HEAD   ?LOBSTER_INPUT_DATA?
# ::pwtk::pw_lobster -d | -dir | -indir DIR ... HEAD   ?LOBSTER_INPUT_DATA?
# ::pwtk::pw_lobster -subdir | -insubdir DIR ... HEAD   ?LOBSTER_INPUT_DATA?
#
# lobster_dir $HEAD --> returns directory name
#
# ::pwtk::pw_lobster -d -nscf KGRID
# ::pwtk::lobster -d NAME
# ::owtk::lobster_info -d NAME
# ::pwtk::lobster_*plot -d NAME | -dir NAME .... ::pwtk::lobster_sudos -DIR
#
# eval_in_dir lobster.$head.d {
#    pw_lobster -$head
#    lobster_multiplot ...
# }
#
# eval_in_dir [lobster_dir $head] {
#    pw_lobster -dir $head
#    lobster_multiplot -dir $head ...
# }
#


dummy foreach {abbr res} {
    COHP            COHPCAR.dat
    DOSCAR.LSO.atm1 DOSCAR.LSO.atm1.dat
    DOS.LSO.atm1    DOSCAR.LSO.atm1.dat
    DOS.atm1        DOSCAR.atm1.dat
    {DOS.atm3- 8}   DOSCAR.atm3-8.dat
} {
    pwtk::test "::pwtk::lobster::datfile_ $abbr" $res
}
dummy foreach {abbr res} {
    COHP            COHPCAR.lobster
    DOSCAR.LSO.atm1 DOSCAR.LSO.lobster
    DOS.LSO.atm1    DOSCAR.LSO.lobster
    DOS.atm1        DOSCAR.lobster
} {
    pwtk::test "::pwtk::lobster::lobsterfile_ $abbr" $res
}


dummy foreach {abbr res} {
    COHP            { }
    DOSCAR.LSO.atm1 1
    DOS.LSO.atm1,3-6  1,3-6
    DOS.orbatm1-      1-
    {DOS.orbatm3- 8}  3-8
} {
    pwtk::test "::pwtk::lobster::atmindices_ {*}$abbr" $res
}

#proc ::pwtk::pw_lobster {args}
#proc ::pwtk::lobster {args}
# these two procs go to:
proc ::pwtk::lobster_run {args}

# not needed
#proc ::pwtk::lobster_head_ {head}
#proc ::pwtk::lobster_dir_ {head}

proc ::pwtk::lobster::CAR_info_ {file} --> ::pwtk::lobster::info --> lobster_info
proc ::pwtk::lobster::CAR_dat_ {file}  --> ::pwtk::lobster::datafy --> lobster_datafy
proc ::pwtk::lobster::COXXCAR_info_ {file} --> lobster_COXXCAR_info_ 
proc ::pwtk::lobster::COXXCAR_dat_ {file} --> lobster_COXXCAR_dat_
proc ::pwtk::lobster::DOSCAR_info_ {file} --> lobster_DOSCAR_info_
proc ::pwtk::lobster::DOSCAR_dat_ {file} --> lobster_DOSCAR_dat_

proc ::pwtk::lobster::plot {args} --> lobster_plot
proc ::pwtk::lobster::multiplot {args} lobster_multiplot
proc ::pwtk::lobster::sumdos {atomList {doscar DOSCAR}} --> lobster_sumdos
proc ::pwtk::lobster::xplotParseCmdline_ {} --> lobster_xplotParseCmdline_
proc ::pwtk::lobster::plot_ {optVar fileLVar datLVar fileInterL {spinId {}}} --> lobster_plot_ 

# TODO: name can be dir/name
proc ::pwtk::lobster::property_ {name {plus_cohp 0}}
proc ::pwtk::lobster::datfile_ {name {nat {}}}
proc ::pwtk::lobster::lobsterfile_ {name}
proc ::pwtk::lobster::indices_ {name {nat {}}}

proc ::pwtk::lobster::normalize_interaction_expr_ {interExpr}
proc ::pwtk::lobster::coxx_using_ {whichSpin integrated nproj interExpr}
proc ::pwtk::lobster::dos_using_ {whichSpin nspin interExpr}
