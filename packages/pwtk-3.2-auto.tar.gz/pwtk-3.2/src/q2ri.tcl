#
# $RCSfile: q2ri.tcl,v $ --
#
#      This file contains the procs for handling the q2r.x input.
#
# Copyright (c) 2021  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: q2ri.tcl,v 1.2 2021/05/03 14:21:08 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::q2ri_fprint {{file {}}} { uplevel ::pwtk::q2ri::fprint $file }
proc ::pwtk::q2ri_get    {}          { uplevel ::pwtk::q2ri::get }
proc ::pwtk::q2ri_clear  {}          { uplevel ::pwtk::q2ri::clear }
proc ::pwtk::q2ri_getAffix {}        { uplevel ::pwtk::q2ri::getAffix }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::q2ri/::pwtk::q2ri::fprint
# SYNOPSIS
proc ::pwtk::q2ri::fprint {{file {}}} {
# PURPOSE
#   Print the content of q2r.x input data to a file or to stdout if the
#   file was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::q2ri $file
}
#****


#****f* ::pwtk::q2ri/::pwtk::q2ri::get
# SYNOPSIS
proc ::pwtk::q2ri::get {} {
    # DESCRIPTION    
    #   Return the content of the q2r.x input. 
    # SOURCE
    
    loadDefaults_

    # q2r.x uses INPUT namelist, but this name is too generic,
    # hence pwtk uses Q2R instead, hence we need to substitute the
    # Q2R string with INPUT

    set    input_ [regsub -- {\&Q2R} [::pwtk::input::namelistGet Q2R] {\&INPUT}]
    append input_ [::pwtk::input::cardGetContent Q2R.affixCards]
    
    return [::pwtk::skipEmptyLines $input_]
}
#******
    

#****f* ::pwtk::q2ri/::pwtk::q2ri::getAffix
# SYNOPSIS
proc ::pwtk::q2ri::getAffix {} { 
    # PURPOSE
    #   Return the last part of the matdyn.x input file, that is, the
    #   cards following the Q2R (or INPUT) namelist.
    # SOURCE
    return [::pwtk::input::cardGetContent Q2R.affixCards]
}
#****

#****f* ::pwtk::q2ri/::pwtk::q2ri::clear
# SYNOPSIS
proc ::pwtk::q2ri::clear {} {
    # DESCRIPTION    
    #   Clear the content of the q2r.x input.
    # SOURCE
    variable input_flow_list
    
    foreach name [concat $input_flow_list Q2R.affixCards] {
	::pwtk::input::clear $name
    }
}
#******


proc ::pwtk::q2ri::loadDefaults_ {} {
    # load some default values, when user has omitted them 

    namespace eval ::pwtk::input {
        defaultVarValue_ Q2R fildyn  ""
    }
}


#****f* ::pwtk::q2ri/::pwtk::q2ri::load_fromQ2RI
# SYNOPSIS
proc ::pwtk::q2ri::load_fromQ2RI {q2ri {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing q2r.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * q2ri -- filename of the q2r.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?
    #
    # SOURCE

    ::pwtk::fileMustExist $q2ri "q2r.x input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current q2r.x input data ...
	::pwtk::input::clear Q2R
    }
    
    set fid [open $q2ri r]
    
    # q2r.x input file must contain the INPUT namelist
    
    if { [catch {set nml [::pwtk::readNml $fid INPUT]}] } {
        ::pwtk::error "input file \"$q2ri\" does not appear to be a q2r.x input file" 1
    }
    # replace INPUT with Q2R
    eval [regsub INPUT $nml Q2R]
    ::pwtk::input::namelists_ityp2atmSymb_ $::pwtk::q2ri::input_flow_list
    
    # read the rest of the q2r.x input file
    while { ! [eof $fid] } {
        ::pwtk::input::cardAppend Q2R.affixCards [gets $fid]
    }
    close $fid
}
#******
