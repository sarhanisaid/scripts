#
# $RCSfile: parse_opt.tcl,v $ --
#
#      This file contains some procs for parsing options, used
#      internally by PWTK.
#
# Copyright (c) 2023-2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: parse_opt.tcl,v 1.3 2023/01/20 09:45:01 kokalj Exp $ 
#


#****if* Internals/::pwtk::parseOpt_
# SYNOPSIS
proc ::pwtk::parseOpt_ {} {    
    # DESCRIPTION    
    #   A convenience routine for parsing options for procs that are
    #   of "proc name {args} {...}" form, where the usage is as:
    #
    #     name -opt1 -opt2 val -opt3 -val   arg1  arg2 arg3
    #          ^^^^^^^^^^^^^^^^^^^^^^^^^^   ^^^^^^^^^^^^^^^
    #           |                                 |
    #           +--- options and their values     + extra agruments that follow after options
    # BEWARE
    # In addition to the args variable, the following variables must
    # also be defined to use this proc:    
    # * options ... option specs for ::cmdline::getoptions
    # * usage   ... usage string to print for "usage" error
    #
    # and either:
    # * narg    ... number of arguments that follow the options (in above example narg == 3);
    #               if narg < 0 then no checking is performed
    # or:
    # * nargmin, nargmax ... min and max number of allowed arguments that follow the options;
    #                        if nargmax < 0 then no checking is performed
    #
    #
    # The parsed opions are stored in "opt" array.
    #
    # SOURCE
    
    uplevel 1 {
        foreach var {args options usage} {            
            if { ! [info exists $var] } {
                ::error "coding error: variable $var does not exist"
            }
        }
        set args_ $args 
        array set opt [::cmdline::getoptions args $options "error while executing:\n\n[pwtk::procName] $args_\n\n[::pwtk::procName] options:"]
        
        if { [info exists narg] } {
            if { $narg >= 0 && [llength $args] != $narg } {
                # nargs
                ::pwtk::error "wrong # args, should be:\n\n[::pwtk::procName] $usage\n\nbut got: [::pwtk::procName] $args_" 1
            }
        } elseif { [info exists nargmin] && [info exists nargmax] } {
            # nargmin nargmax
            if { [llength $args] < $nargmin } {
                ::pwtk::error "wrong # args, should be:\n\n[::pwtk::procName] $usage\n\nbut got: [::pwtk::procName] $args_" 1
            }
            if { $nargmax >= 0 && [llength $args] > $nargmax } {
                ::pwtk::error "wrong # args, should be: \n\n[::pwtk::procName] $usage\n\nbut got: [::pwtk::procName] $args_" 1
            }
            # if nargmax < 0 ==> no checking
        } else {
            ::error "coding error: neither narg nor nargmin & nargmax exist"
        }        
    }
}
#******


#****if* Internals/::pwtk::parseKnownOpt_
# SYNOPSIS
proc ::pwtk::parseKnownOpt_ {} {    
    # DESCRIPTION
    #   Similar to ::pwtk::parseOpt_ but ignores any unknown options,
    #   i.e., the difference between ::pwtk::parseKnownOpt_ and ::pwtk::parseOpt_
    #   is that the former uses ::cmdline::getKnownOptions and the latter
    #   ::cmdline::getoptions.
    #
    #   A convenience routine for parsing known options for procs that are
    #   of "proc name {args} {...}" form, where the usage is as:
    #
    #     name -opt1 -opt2 val -opt3 -val   arg1  arg2 arg3
    #          ^^^^^^^^^^^^^^^^^^^^^^^^^^   ^^^^^^^^^^^^^^^
    #           |                                 |
    #           +--- options and their values     + extra agruments that follow after options
    # BEWARE
    # In addition to the args variable, the following variables must
    # also be defined to use this proc:    
    # * options ... option specs for ::cmdline::getoptions
    # * usage   ... usage string to print for "usage" error
    #
    # and either:
    # * narg    ... number of arguments that follow the options (in above example narg == 3);
    #               if narg < 0, no checking is performed
    # or:
    # * nargmin ... min number of allowed arguments that follow the options;
    #               if nargmin < 0, no checking is performed
    #
    # N.B. nargmax is not considered here because due to unknown options,
    # the max number of argumemts is unknown
    #    
    # The parsed opions are stored in "opt" array.
    #
    # SOURCE
    
    uplevel 1 {
        foreach var {args options usage} {            
            if { ! [info exists $var] } {
                ::error "coding error: variable $var does not exist"
            }
        }
        set args_ $args 
        array set opt [::cmdline::getKnownOptions args $options "error while executing:\n\n[pwtk::procName] $args_\n\n[::pwtk::procName] options:"]
        
        if { [info exists narg] } {
            # nargs
            if { $narg >= 0 && [llength $args] < $narg } {
                ::pwtk::error "wrong # args, should be:\n\n[::pwtk::procName] $usage\n\nbut got: [::pwtk::procName] $args_" 1
            }
        } elseif { [info exists nargmin] } {
            # nargmin
            if { $nargmin >= 0 && [llength $args] < $nargmin } {
                ::pwtk::error "wrong # args, should be:\n\n[::pwtk::procName] $usage\n\nbut got: [::pwtk::procName] $args_" 1
            }
        } else {
            ::error "coding error: neither narg nor nargmin exist"
        }        
    }
}
#******


#****if* Internals/::pwtk::checkOType_
# SYNOPSIS
proc ::pwtk::checkOType_ {option value type {typeTxt {}}} {
    # DESCRIPTION
    #   Check that the value of an option is of correct type.
    #
    #   Note that empty string matches the type (for the opposite
    #   behaviour, use the strict version, checkOTypeStrict_)
    #
    # ARGUMENTS
    # * option == name of the option
    # * value  == value of the option
    # * type   == type for the value
    # * typeTxt == [optional, default = $type] a textual-type of value that is printed
    #              to error message (for example: type = double, typeTxt = number)
    # SOURCE
    if { $typeTxt == {} } {
        set typeTxt $type
    }
    set option -[string trim $option -]
    set err "expected a $typeTxt for the value of the $option option, but got: \"$value\""

    switch -exact -- [lindex $type 0] {
        number -
        numberlist -
        range -
        gp_range -
        gp_size -
        intseq -
        rangestring {
            if { ! [eval ::pwtk::type::$type [list $value]] } {
                uplevel 1 [list ::pwtk::error $err 1]
            }
        }
        optionlist {
            set allowedValues [lrange $type 1 end]
            if { ! [::pwtk::type::optionlist $allowedValues $value] } {
                uplevel 1 [list ::pwtk::error "expected one of [join $allowedValues {, }] for the value of the $option option, but got: \"$value\"" 1]
            }
        }
        default {
            if { ! [string is $type $value] } {
                uplevel 1 [list ::pwtk::error $err 1]
            }
        }
    }
}
#******


#****if* Internals/::pwtk::checkOTypeStrict_
# SYNOPSIS
proc ::pwtk::checkOTypeStrict_ {option value type {typeTxt {}}} {
    # DESCRIPTION
    #   A strict version of checkOType_, where empty string do not match the type.
    #
    # type can be: intList, doubleList, type accepted by "string is...."
    #
    # SOURCE
    if { $typeTxt == {} } {
        set typeTxt $type
    }
    set option -[string trim $option -]
    set err "expected a $typeTxt for the value of the $option option, but got: \"$value\""

    switch -exact -- [lindex $type 0] {
        number -
        numberlist {
            if { ! [eval ::pwtk::type::$type -strict [list $value]] } {
                 uplevel 1 [list ::pwtk::error $err 1]
            }
        }
        range -
        gp_range -
        gp_size -
        intseq -
        rangestring {
            if { $value eq {} || ! [eval ::pwtk::type::$type [list $value]] } {
                uplevel 1 [list ::pwtk::error $err 1]
            }
        }
        optionlist {
            set allowedValues [lrange $type 1 end]
            if { ! [::pwtk::type::optionlist $allowedValues -strict $value] } {
                uplevel 1 [list ::pwtk::error [list "expected one of [join $allowedValues {, }] for the value of the $option option, but got: \"$value\"" 1]
            }
        }
        default {
            if { ! [string is $type -strict $value] } {
                uplevel 1 [list ::pwtk::error $err 1]
            }
        }
    }
}
#******


#****if* Internals/::pwtk::trimImplicitOpts_
# SYNOPSIS
proc ::pwtk::trimImplicitOpts_ {optionListArgs} {
    # DESCRIPTION
    #   Trim implicit -?, -help, and -- options from the option-list
    # SOURCE
    return [regsub -all {(\-\?|\-help|\-\-)} $optionListArgs {}]
}
#******


#------------------------------------------------------------------------
#
# Below are several commands for handling the command-line options.
# They were initially implemented for handling the command-line
# options for Gnuplot for scanpar.tcl, pdos.tcl, and band.tcl plotting
# routines.
#------------------------------------------------------------------------


#****if* Internals/::pwtk::fmtUsage_
# SYNOPSIS
proc ::pwtk::fmtUsage_ {usage} {
    # DESCRIPTION
    #   Format the "usage" list for printout in ::pwtk::parseOpt_.
    # ARGUMENT
    # * usage --- the 'usage' list (e.g. see the 'plot_usage' list in ../config/gnuplot.tcl)
    # SOURCE
    set result {}
    set lastval -1
    foreach optval $usage {
        # skip multiple empty elements
        if { $optval ne {} || ($optval eq {} && $lastval ne {}) } {
            append result "\\\n    $optval "
        }
        set lastval $optval
    }
    return $result
}
#******


#****if* Internals/::pwtk::addOpt_
# SYNOPSIS
proc ::pwtk::addOpt_ {optionsVar usageVar newOpt newUsage} {
    # DESCRIPTION
    #   Format the "usage" list for printout in ::pwtk::parseOpt_.
    #
    # ARGUMENTS
    # * optionsVar --- name of the 'options' variable
    # * usageVar   --- name of the 'usage' variable
    # * newOpt     --- specs for a new option to add (in the syntax of 'options')
    # * newUsage   --- the 'usage' type description for the new option 'newOpt'
    #
    # SOURCE

    upvar $optionsVar options
    upvar $usageVar   usage
    lappend options $newOpt
    lappend usage {} $newUsage
}
#******


#****if* Internals/::pwtk::addOpts_
# SYNOPSIS
proc ::pwtk::addOpts_ {optionsVar usageVar newOpts newUsage} {
    # DESCRIPTION
    #   Similar to ::pwtk::addOpt_, but for several options.
    #
    # ARGUMENTS
    # * optionsVar --- name of the 'options' variable
    # * usageVar   --- name of the 'usage' variable
    # * newOpts    --- specs for new options to add (in the syntax of 'options')
    # * newUsage   --- the 'usage' type description for the new options 'newOpts'
    #
    # SOURCE
    upvar $optionsVar options
    upvar $usageVar   usage
    foreach opt $newOpts {
        lappend options $opt
    }
    lappend usage {} {*}$newUsage
}
#******


#****if* Internals/::pwtk::ignoredOpts_
# SYNOPSIS
proc ::pwtk::ignoredOpts_ {ignoredList cmdline} {
    # PURPOSE
    #   Print and info message that a specified option is ignored.
    # ARGUMENTS
    # * ignoredList --- list of ignored options
    # * cmdline --- command line to check for ignored options
    # SOURCE
    foreach opt $ignoredList {
        if { $opt in $cmdline } {
            infoMsg "from  [procName -2]: option $opt is ignored"
        }
    }
}
#******


#****if* Internals/::pwtk::deleteOpts_
# SYNOPSIS
proc ::pwtk::deleteOpts_ {optionsVar usageVar args} {
    # DESCRIPTION
    #   Delete options from 'optionsVar' and 'usageVar'.
    #
    # ARGUMENTS
    # * optionsVar --- name of the 'options' variable
    # * usageVar   --- name of the 'usage' variable
    # * args       --- options to delete
    #
    # SOURCE
    upvar $optionsVar options
    upvar $usageVar   usage

    set aux_options $options
    set aux_usage   $usage

    foreach opt $args {
        set new_options {}
        set new_usage   {}
        set opt [string trim $opt -]

        foreach optSpec $aux_options {
            lassign $optSpec thisOpt
            if { ! ($opt eq $thisOpt || "$opt.arg" eq $thisOpt) } {
                lappend new_options $optSpec
            }
        }

        # plain list variant
        foreach usageSpec $aux_usage {
            lassign $usageSpec thisOpt
            if { $thisOpt ne "-$opt" } {
                lappend new_usage $usageSpec
            }
        }
        set aux_options $new_options
        set aux_usage   $new_usage
    }

    set options $new_options
    set usage   $new_usage
}
#******


#****if* Internals/::pwtk::deprecatedOpts_
proc ::pwtk::deprecatedOpts_ {deprecatedSpecs argsVar} {
    # PURPOSE
    #   Check for the use of deprecated options and replace them with
    #   the renamed options.
    #
    # ARGUMENTS
    # * deprecatedSpecs -- specification of deprecated options (see below)
    # * argsVar -- name of the variable holding the command-line to check
    #
    # The 'deprecatedSpecs' is the list of specs of deprecated options
    # with the following structure:
    #
    #    set deprecatedSpecs {
    #       {-old1 -new1}
    #       {-old2 -new2}
    #       ...
    #    }
    #
    # where -old1 is the name of the deprecated option and -new1 is
    # the renamed option, and so on for -old2...
    #
    # SOURCE

    upvar $argsVar args

    foreach old_new $deprecatedSpecs {
        lassign $old_new old new
        if { "$old" in $args } {
            ::pwtk::deprecated "from [procName -2]: the $old command-line option is deprecated; it was replaced by the $new option"
            # substitute
            foreach ind [lsearch -all -exact $args $old] {
                set args [lreplace $args $ind $ind $new]
            }
        }
    }
}
#******


#****if* Internals/::pwtk::setOpts_
# SYNOPSIS
proc ::pwtk::setOpts_ {optionsVar optValList} {
    # PURPOSE
    #   Set options values in the 'options' list variable, which has
    #   the syntax required by ::cmdline::getoptions
    #
    # ARGUMENTS
    # * optionsVar --- name of the 'options' variable
    # * optValList --- list of option-value pairs, i.e., {opt1 val1 opt2 val2 ...}
    #
    # SOURCE

    upvar $optionsVar options

    set ovL {}
    set new_options {}

    # purify optValList
    foreach {opt val} $optValList {
        regsub {\.arg$} [string trim $opt -] {} opt
        set found($opt) 0
        lappend ovL $opt $val
    }

    foreach optionSpecs $options {
        lassign $optionSpecs option value text

        set result {}
        foreach {opt val} $ovL {
            if { $opt eq $option } {
                ::pwtk::error "the -$opt option is valueless" 1
            }
            if { "$opt.arg" eq $option } {
                set found($opt) 1
                set result [list $option $val $text]
                break
            }
        }
        if { $result eq {} } {
            set result $optionSpecs
        }
        lappend new_options $result
    }

    foreach {opt val} $ovL {
        if { ! $found($opt) } {
            ::pwtk::error "the -$opt option is not among allowed options" 1
        }
    }

    set options $new_options
}
#******
