#
# $RCSfile: flo.tcl,v $ --
#
#
#      This file contains the implemenation of FLO task.  
#
#      FLO == first_last_opt, a path-type transition state search
#      (i.e. neb or smd), where first and last images are first
#      optimized by the BFGS algorithm, and only then the path
#      calculation is performed with neb.x using the optimized
#      coordinates for first & last images.
#
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: flo.tcl,v 1.6 2021/05/07 13:22:26 tone Exp $ 
#
# ------------------------------------------------------------------------
#
# FLO == first_last_opt for the PATH calculation
#
# ------------------------------------------------------------------------

#****f* FLO/::pwtk::flo_run
# DESCRIPTION
# Shortcut for ::pwtk::flo::run
# SOURCE
proc ::pwtk::flo_run {prefix {ion_dynamics bfgs}} { uplevel [list ::pwtk::flo::run $prefix {*}$ion_dynamics] }
#******

#****f* FLO/::pwtk::flo::run
# SYNOPSIS
proc ::pwtk::flo::run {head {ion_dynamics bfgs}} {
    # PURPOSE    
    #   Perform the FLO (first_last_opt) type PATH calculations, which
    #   consists of the following:
    #
    #     1. pw.x relax calculation to optimize the 1st image
    #     2. pw.x relax calculation to optimize the last image
    #     3. neb.x path calculation with optimized 1st and last image
    #
    #   See also ::pwtk::flo for more information on FLO.
    #
    # ARGUMENTS
    #   * head -- headname  of the input file (e.g., headname of "name.in" is "name")
    #   * ion_dynamics -- what type of pw.x relax calculation to perform (default = BFGS)
    #
    # SOURCE

    printTitle_ "Performing the First-Last-Optimize (FLO) path calculation."

    set restart_mode [::pwtk::input::namelistGetVarValue PATH restart_mode trim]
    set name         [regsub {^neb.} $head {}]

    # do some checks ...

    if { ${restart_mode} == "restart" } {
        ::pwtk::error "PATH { restart_mode = 'restart' } is incompatible with FLO" 1
    }
    
    # first create the input files
    # (look into ::pwtk::flo::input_files proc for the input file names)

    ::pwtk::input::pushpop {        
        set outdir [::pwtk::outdir_query -hard]
        set ion_dynamics [::pwtk::squote $ion_dynamics]

        CONTROL " calculation  = 'relax'  
                  restart_mode = 'from_scratch' 
                  outdir       = '[file join $outdir relax.IS]' "
        IONS    " ion_dynamics = $ion_dynamics "
        
        # optimize the first image

        ATOMIC_POSITIONS [::pwtk::nebi::getImageUnit first] [::pwtk::nebi::getImageAtmPos first]
        ::pwtk::pwi::setNAtoms
        
        print_ "Optimizing the first image (IS) with pw.x using the $ion_dynamics algorithm ...\n"
        runPW relax.IS.$name

        # optimize the last image
        
        CONTROL " outdir = '[file join $outdir relax.FS]' "
        ATOMIC_POSITIONS [::pwtk::nebi::getImageUnit last] [::pwtk::nebi::getImageAtmPos -if_pos last]

        print_ "Optimizing the last image (FS) with pw.x using the $ion_dynamics algorithm ...\n"
        runPW relax.FS.$name
    }

    # fill-in the optimized coordinates
    print_ "Using the optimized coordinates for the first and last images"
    
    CONTROL { calculation =  restart_mode = }
    input_clear IONS

    ::pwtk::nebi::replaceImage first [::pwtk::pwo::getAtmPos relax.IS.$name.out]
    ::pwtk::nebi::replaceImage last  [::pwtk::atmPosToCoor [::pwtk::pwo::getAtmPos relax.FS.$name.out]]
        
    print_ "Running the neb.x calculation ...\n"
    runNEB $head.in    
}
#******


proc ::pwtk::flo::print_ {message} {    
    ::pwtk::print FLO $message
}


proc ::pwtk::flo::printTitle_ {title} {    
    ::pwtk::printTitle FLO $title
}
