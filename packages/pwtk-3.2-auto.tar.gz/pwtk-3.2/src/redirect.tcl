#
# $RCSfile: redirect.tcl,v $ --
#
#      This file contains ...
#
# Copyright (c) 2014  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: redirect.tcl,v 1.3 2015/01/12 17:00:01 kokalj Exp $ 
#

#****f* Messaging/::pwtk::redirect_stdout_to
# SYNOPSIS
proc ::pwtk::redirect_stdout_to {filename script} {
    # DESCRIPTION
    #   Redirect stdout and stderr to a file and also print stderr to stderr.
    #   
    #   Inspired by:
    #      https://wiki.tcl-lang.org/page/puts+workaround
    #      https://stackoverflow.com/questions/8531031/how-can-i-redirect-stdout-into-a-file-in-tcl
    #
    # ARGUMENTS
    # * filename -- redirect stdout to a file named "filename"
    # * script   -- script for which the stdout is redirected to a file
    #
    # RETURN VALUE
    #   An empty string, just like the Tcl puts command.
    #
    # SOURCE
    
    global pwtk_redirect_channel_

    # inspired by https://wiki.tcl-lang.org/page/puts+workaround & https://stackoverflow.com/questions/8531031/how-can-i-redirect-stdout-into-a-file-in-tcl
    
    rename puts ::tcl::orig_puts
    set pwtk_redirect_channel_ [open $filename w]

    proc ::puts {args} {
        global pwtk_redirect_channel_
        
        set nargs [llength $args]
        
        if {$nargs<1 || $nargs>3} {
            ::error "wrong # args: should be \"puts ?-nonewline? ?channelId? string\""
        }

        set nl {}
        if { [lindex $args 0] == "-nonewline" } {
            set nl -nonewline
            set args [lrange $args 1 end]
        }

        if { [llength $args] == 1 } {
            set args [list stdout [join $args]]
        }

        set channel [lindex $args 0]
        set string  [lindex $args 1]

        if { $channel == "stdout" } {
            set channel $pwtk_redirect_channel_
        } elseif { $channel == "stderr" } {
            # print to stderr & $pwtk_redirect_channel_
            set channel [list stderr $pwtk_redirect_channel_]
        }
        foreach ch $channel {
            eval ::tcl::orig_puts $nl $ch [list $string]
            flush $ch
        }
        return
    }    

    uplevel $script    

    close $pwtk_redirect_channel_
    rename ::puts {}
    rename ::tcl::orig_puts ::puts
}
#******


#****f* Messaging/::pwtk::redirect_stderr_to
# SYNOPSIS
proc ::pwtk::redirect_stderr_to {filename script} {
    # DESCRIPTION
    #   Redirect stderr to a file.
    #   
    #   Inspired by:
    #      https://wiki.tcl-lang.org/page/puts+workaround
    #      https://stackoverflow.com/questions/8531031/how-can-i-redirect-stdout-into-a-file-in-tcl
    #
    # ARGUMENTS
    # * filename -- redirect stderr to a file named "filename"
    # * script   -- script for which the stderr is redirected to a file
    #
    # RETURN VALUE
    #   An empty string, just like the Tcl puts command.
    #
    # SOURCE
    
    global pwtk_redirect_channel_

    # inspired by https://wiki.tcl-lang.org/page/puts+workaround & https://stackoverflow.com/questions/8531031/how-can-i-redirect-stdout-into-a-file-in-tcl
    
    rename puts ::tcl::orig_puts
    set pwtk_redirect_channel_ [open $filename w]

    proc ::puts {args} {
        global pwtk_redirect_channel_
        
        set nargs [llength $args]
        
        if {$nargs<1 || $nargs>3} {
            ::error "wrong # args: should be \"puts ?-nonewline? ?channelId? string\""
        }

        set nl {}
        if { [lindex $args 0] == "-nonewline" } {
            set nl -nonewline
            set args [lrange $args 1 end]
        }

        if { [llength $args] == 1 } {
            set args [list stdout [join $args]]
        }

        set channel [lindex $args 0]
        set string  [lindex $args 1]

        if { $channel == "stderr" } {
            set channel $pwtk_redirect_channel_
        }
        foreach ch $channel {
            eval ::tcl::orig_puts $nl $ch [list $string]
            flush $ch
        }
        return
    }    

    uplevel $script

    close $pwtk_redirect_channel_
    rename ::puts {}
    rename ::tcl::orig_puts ::puts
}
#******


#****f* Messaging/::pwtk::redirect
# SYNOPSIS
proc ::pwtk::redirect {args} {
    # USAGE
    #   redirect ?stdout? ?stderr? script 
    #   redirect ?stderr? ?stdout? script
    #
    # DESCRIPTION
    #   Redirect printing to stdout/stderr to a return value.
    #   
    #   Inspired by:
    #      https://wiki.tcl-lang.org/page/puts+workaround
    #      https://stackoverflow.com/questions/8531031/how-can-i-redirect-stdout-into-a-file-in-tcl
    #
    # ARGUMENTS
    # * channels -- which channels to redirect. Possibilities: stdout, stderr, or both of them
    # * script   -- script for which the stdout/stderr is redirected
    #
    # RETURN VALUE
    #   A return value of the script.
    #
    # SOURCE

    global pwtk_redirect_channels_  pwtk_redirect_result_

    set pwtk_redirect_result_ {}    
    set pwtk_redirect_channels_ {}
    set len [llength $args]

    lassign $args arg1 arg2 arg3
    
    if { $len == 1 } {
        set pwtk_redirect_channels_ stdout
        set script $arg1
    } elseif { $len == 2 } {
        switch $arg1 {
            stdout - stderr {
                set pwtk_redirect_channels_ $arg1
            } default {
                ::pwtk::error "wrong channel '$arg1', must be stdout or stderr" 1
            }
        }
        set script $arg2
    } elseif { $len == 3 } {
        foreach arg [list $arg1 $arg2] {
            switch $arg {
                stdout - stderr {
                    lappend pwtk_redirect_channels_ $arg
                } default {
                    ::pwtk::error "wrong channel '$arg', must be stdout or stderr" 1
                }
            }
        }
        set script $arg3
    } else {
        ::pwtk::error "wrong # of args, must be redirect ?stdout? ?stderr? script" 1
    }
    
    rename puts ::tcl::orig_puts

    proc ::puts {args} {
        global pwtk_redirect_channels_ pwtk_redirect_result_
        
        set nargs [llength $args]        
        if {$nargs<1 || $nargs>3} {
            ::error "wrong # args: should be \"puts ?-nonewline? ?channelId? string\""
        }

        set nl \n
        if { [lindex $args 0] == "-nonewline" } {
            set nl {}
            set args [lrange $args 1 end]
        }

        if { [llength $args] == 1 } {
            set args [list stdout [join $args]]
        }

        set channel [lindex $args 0]
        set string  [lindex $args 1]

        if { $channel in $pwtk_redirect_channels_ } {
            append pwtk_redirect_result_ ${string}$nl
        } else {
            ::tcl::orig_puts $channel ${string}$nl
        }
    } 

    uplevel $script

    set result $pwtk_redirect_result_
    unset pwtk_redirect_result_

    rename ::puts {}
    rename ::tcl::orig_puts ::puts

    return $result
}
#******
