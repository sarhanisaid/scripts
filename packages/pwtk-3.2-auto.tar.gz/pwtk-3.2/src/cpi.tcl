#
# $RCSfile: cpi.tcl,v $ --
#
#      This file contains the procs for handling the cp.x input.
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: cpi.tcl,v 1.3 2021/05/03 14:21:08 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::cpi_fprint    {{file {}}} { uplevel ::pwtk::cpi::fprint $file }
proc ::pwtk::cpi_get       {}          { uplevel ::pwtk::cpi::get }
proc ::pwtk::cpi_clear     {}          { uplevel ::pwtk::cpi::clear }
proc ::pwtk::cpi_visualize {}          { uplevel ::pwtk::cpi::visualize }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::cpi/::pwtk::cpi::fprint
# SYNOPSIS
proc ::pwtk::cpi::fprint {{file {}}} {
# PURPOSE
#   Print the content of cp.x input data to a file or to stdout if the
#   file was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::cpi $file
}
#****

#****f* ::pwtk::cpi/::pwtk::cpi::clear
# SYNOPSIS
proc ::pwtk::cpi::clear {} {
# PURPOSE
#   Clear the stored cp.x input data.
# SOURCE

    variable input_flow_list
    
    foreach name $input_flow_list {
	::pwtk::input::clear $name
    }
}
#****


#****f* ::pwtk::cpi/::pwtk::cpi::get
# SYNOPSIS
proc ::pwtk::cpi::get {} {
    # PURPOSE
    #   Return the content of the cp.x input 
    # SOURCE

    variable input_flow_list
    variable all_atomic_species

    set all_atomic_species [::pwtk::input::cardGetContent ATOMIC_SPECIES]
    
    ::pwtk::input::pushpop {

        # check the ntyp vs ATOMIC_SPECIES compatibility
    
        if { [::pwtk::pwi::getNTyp] != [::pwtk::input::namelistGetVarValue SYSTEM ntyp] } {
            pwtk::infoMsg "ntyp and number of atomic species specified in ATOMIC_SPECIES card
are not equal; filtering out unused atom   ic species"
        }
    
        # EXCEPTION: starting from QE v4.0, the cp.x aborts if unused
        # atomic species are specified, which is what we don't want:
        # filter-out unused species
        
        ATOMIC_SPECIES [::pwtk::pwi::filterAtomicSpecies]
        SYSTEM " ntyp = [::pwtk::pwi::getNTyp] "
        
        # convenient feature: make a dummy call to ELECTRONS as this
        # namelist must be always present, even if it is empty
        
        ELECTRONS {}
        
        ::pwtk::input::clear_

        # remove AUTOPILOT
        set input_flow_ [regsub -all -- AUTOPILOT $input_flow_list {}]
        foreach name $input_flow_ {	
            loadDefaults_ $name
            ::pwtk::input::appendInput_ $name
        }
        set result [::pwtk::input::get_]
        
        # handle AUTOPILOT
        set autopilot [::pwtk::input::cardGetContent AUTOPILOT]
        if { $autopilot != {} } {
            append result "AUTOPILOT\n"
            append result [string trimright $autopilot]\n
            append result "ENDRULES\n"            
        }
    }
    # at this point, unfiltered ATOMIC_SPECIES are restored

    unset all_atomic_species
    
    return $result
}
#****


#****f* ::pwtk::cpi/::pwtk::cpi::visualize
# SYNOPSIS
proc ::pwtk::cpi::visualize {} {
    # PURPOSE
    #   Visualize the structure from cp.x input file with xcrysden. If
    #   xcrysden is not detected, the input file is merely printed to
    #   stdout.
    # SOURCE
    ::pwtk::pwi::visualize
}
#****


#****f* ::pwtk::cpi/::pwtk::cpi::load_fromCPI
# SYNOPSIS
proc ::pwtk::cpi::load_fromCPI {cpi {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing cp.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * cpi -- filename of the cp.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?
    #
    # SOURCE

    ::pwtk::fileMustExist $cpi "cp.x input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current cp.x input data ...
	::pwtk::cpi::clear
    }

    # cp.x input file must contain the CONTROL namelist

    if { [catch {::pwtk::readNamelists $cpi CONTROL 1}] } {
	::pwtk::error "input file \"$cpi\" does not appear to be a cp.x input file" 1
    }    

    set output [::pwtk::readNamelists $cpi $::pwtk::cpi::namelist_flow_list]
    append output [::pwtk::readCards $cpi $::pwtk::cpi::card_flow_list ENDRULES]
    
    eval $output
    ::pwtk::input::namelists_ityp2atmSymb_ $::pwtk::cpi::namelist_flow_list
}
#******


#****f* ::pwtk::cpi/::pwtk::cpi::getAtmSymbList
# SYNOPSIS
proc ::pwtk::cpi::getAtmSymbList {} {
    # PURPOSE
    #   Get a sequential list of atomic-symbols from ATOMIC_POSITIONS card (in the same order), i.e.:
    #      AtmSy1
    #      AtmSy2
    #      ...
    # SOURCE

    return [::pwtk::pwi::getAtmSymbList]
}
#******


# ------------------------------------------------------------------------
#
# internal procs ...
#
# ------------------------------------------------------------------------

proc ::pwtk::cpi::loadDefaults_ {{name CONTROL}} {
    # load some default values, when user has omitted them 

    if { $name == "CONTROL" } {
	namespace eval ::pwtk::input {
	    defaultVarValue_ CONTROL outdir     [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
	    defaultVarValue_ CONTROL wfcdir     [::pwtk::getDir_ QEdir(ESPRESSO_WFCDIR)]
	    defaultVarValue_ CONTROL pseudo_dir [::pwtk::getDir_ QEdir(ESPRESSO_PSEUDO)]
	}
    }
}
