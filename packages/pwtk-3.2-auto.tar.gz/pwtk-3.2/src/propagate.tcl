#
# $RCSfile: propagate.tcl,v $ --
#
#      This file contains contains the PWTK's "propagate" mechanism.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: propagate.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#

#****a* 5.3. Run Calculations/5.3.7. Propagate 
# DESCRIPTION
#   The "propagate" is a simple mechanism that propagates script
#   snippets to child PWTK instances. Child PWTK instances are
#   remotes, backgrounds, threads, thread-pools, and queues...
#
#   Consider, for example, the following script:
#   
#       import common.pwtk
#       SYSTEM { ecutwfc = 30.0 }
#
#       remote machine1 {
#           runPW calc1
#       }
#
#   This script will fail. The problem is that the 'remote' command
#   creates a script file from the script supplied to it (in this case
#   "runPW calc1") and runs it on the remote "machine1" host. Hence,
#   the script run on the "machine1" is not aware of the PWTK state
#   that precedes the 'remote' command. In contrast, this script will
#   succeed:
#
#       propagate {
#          import common.pwtk
#          SYSTEM { ecutwfc = 30.0 }       
#       }
#
#       remote machine1 {
#          runPW calc1
#       }
#    
#   The point is that the 'propagate' command informs PWTK, which
#   script excerpts should be propagated to the child PWTK
#   processes. In this case the script executed on the remote host
#   looks something like:
#
#       import common.pwtk
#       SYSTEM { ecutwfc = 30.0 }       
#       runPW calc1
#
#   and the 'runPW' command will be able to construct the pw.x input and run it.
#
#******


#****f* 5.3.7. Propagate/::pwtk::propagate
proc ::pwtk::propagate {script} {
    # USAGE
    #   ::pwtk::propagate script
    #
    # DESCRIPTION    
    #   ::pwtk::propagate adds the supplied script snippet to the
    #   propagate script, which is propagated to PWTK child
    #   instances. Child PWTK instances are remotes, backgrounds,
    #   threads, thread-pools, and queues.
    #
    #   Furthermore, ::pwtk::propagate also executes the supplied
    #   script, i.e., the whole action of ::pwtk::propagate is:
    #
    #      append propagate(script) $script\n
    #      uplevel 1 $script
    #
    #   For further details, see
    #   |html <a href="propagate_tcl52E32E20Run20Calculations2F52E32E72E20Propagate.html">
    #   |html 5.3.7. Propagate</a>.
    #
    # ARGUMENTS
    # * script -- a script to append to the propagate script
    #
    # SOURCE
    variable propagate

    set l [incr propagate(level)]
    if { $l == 1 } {
        # N.B only the 1st-level propagate call should append to the
        # propagate script or else the higher level propagate scripts
        # will appear multiple times in $propagate(script)
        append propagate(script) $script\n
    }
    set code [catch {uplevel 1 $script} result]
    incr propagate(level) -1
    return -code $code $result
}
#******


#****f* 5.3.7. Propagate/::pwtk::propagate_clear
proc ::pwtk::propagate_clear {} {
    # PURPOSE
    #   Clear the propagate script.
    # SOURCE
    variable propagate
    unset propagate(script)
}
#******


#****if* Internals/::pwtk::propagate_dump
proc ::pwtk::propagate_dump {{hard_dump {}}} {
    # PURPOSE
    #   Return the current propagate script.
    #
    # REMARK
    #   This routine is typically used only internally by PWTK.
    # SOURCE
    variable propagate

    ifexist propagate(script) {
        set result "
# propagate stuff

propagate \{
$propagate(script)
\}\n"
    }
    append result [::pwtk::dumpVars 3 $hard_dump]\n
    return $result
}
#******



#****if* Internals/::pwtk::dumpVars
proc ::pwtk::dumpVars {level {hard_dump {}}} {
    # PURPOSE    
    #   Dump variables defined in the current scope.
    #
    # REMARK
    #   This routine is typically used only internally by PWTK.
    #
    # SOURCE
    variable dump_set

    if { $hard_dump eq {} } {
        set dump_set ::pwtk::ifset
    } else {
        set dump_set set
    }
    
    uplevel $level {
        pwtk::ifexist res { unset res }
            
        foreach var [info vars] {
            #if { ! [regexp {^(_scriptFile|PWTK_APPLICATION|pwtk_cmd_|auto_path|auto_index|auto_execs|env|errorCode|errorInfo|tcl_..*|argc|argv|argv0)$} $var] } {}
            if { ! [regexp {^(PWTK_APPLICATION|auto_path|auto_index|auto_execs|env|errorCode|errorInfo|tcl_..*|argc|argv|argv0)$} $var] } {
                if { [array exists $var] } {
                    foreach name [array names $var] {
                        append res "$::pwtk::dump_set ${var}($name) [list [::pwtk::varvalue ${var}($name)]]\n"
                    }
                } else {
                    append res "$::pwtk::dump_set $var [list [::pwtk::varvalue ${var}]]\n"
                }
            }
        }
        set res "# load dumped variables\n\n$res\n"
        return $res
    }
}
#******
