#
# $RCSfile: atoms.tcl,v $ --
#
#      This file contains various atomic radii. The radii are mainly
#      based on Wikipedia data page,
#      https://en.wikipedia.org/wiki/Atomic_radii_of_the_elements_(data_page)
#
#      For radii missing therein, the values were searched on the internet.
#
# Copyright (c) 2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: atoms.tcl,v 1.3 2023/01/24 17:00:01 kokalj Exp $ 
#


set ::pwtk::atomSymbols {
    H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co
    Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb
    Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re
    Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm
}

#
# The structure of the "::pwtk::atomDataList",  for each element:
#     { atomicNumber symbol name R_empirical R_calc R_vdW R_cov }
#       0            1      2    3           4      5     6
#
# radii are given in pm

set ::pwtk::atomDataList {
    {  1  H  hydrogen   25  53  110  32  }
    {  2  He  helium   120  31  140  46  }
    {  3  Li  lithium   145  167  181  133  }
    {  4  Be  beryllium   105  112  153  102  }
    {  5  B  boron   85  87  192  85  }
    {  6  C  carbon   70  67  170  75  }
    {  7  N  nitrogen   65  56  155  71  }
    {  8  O  oxygen   60  48  152  63  }
    {  9  F  fluorine   50  42  147  64  }
    {  10  Ne  neon   160  38  154  67  }
    {  11  Na  sodium   180  190  227  155  }
    {  12  Mg  magnesium   150  145  173  139  }
    {  13  Al  aluminium   125  118  184  126  }
    {  14  Si  silicon   110  111  210  116  }
    {  15  P  phosphorus   100  98  180  111  }
    {  16  S  sulfur   100  88  180  103  }
    {  17  Cl  chlorine   100  79  175  99  }
    {  18  Ar  argon   71  71  188  96  }
    {  19  K  potassium   220  243  275  196  }
    {  20  Ca  calcium   180  194  231  171  }
    {  21  Sc  scandium   160  184  211  148  }
    {  22  Ti  titanium   140  176  187  136  }
    {  23  V  vanadium   135  171  205  134  }
    {  24  Cr  chromium   140  166  200  122  }
    {  25  Mn  manganese   140  161  200  119  }
    {  26  Fe  iron   140  156  200  116  }
    {  27  Co  cobalt   135  152  200  111  }
    {  28  Ni  nickel   135  149  163  110  }
    {  29  Cu  copper   135  145  140  112  }
    {  30  Zn  zinc   135  142  139  118  }
    {  31  Ga  gallium   130  136  187  124  }
    {  32  Ge  germanium   125  125  211  121  }
    {  33  As  arsenic   115  114  185  121  }
    {  34  Se  selenium   115  103  190  116  }
    {  35  Br  bromine   115  94  183  114  }
    {  36  Kr  krypton   115  88  202  117  }
    {  37  Rb  rubidium   235  265  303  210  }
    {  38  Sr  strontium   200  219  249  185  }
    {  39  Y  yttrium   180  212  240  163  }
    {  40  Zr  zirconium   155  206  230  154  }
    {  41  Nb  niobium   145  198  207  147  }
    {  42  Mo  molybdenum   145  190  209  138  }
    {  43  Tc  technetium   135  183  205  128  }
    {  44  Ru  ruthenium   130  178  205  125  }
    {  45  Rh  rhodium   135  173  200  125  }
    {  46  Pd  palladium   140  169  163  120  }
    {  47  Ag  silver   160  165  172  128  }
    {  48  Cd  cadmium   155  161  158  136  }
    {  49  In  indium   155  156  193  142  }
    {  50  Sn  tin   145  145  217  140  }
    {  51  Sb  antimony   145  133  206  140  }
    {  52  Te  tellurium   140  123  206  136  }
    {  53  I  iodine   140  115  198  133  }
    {  54  Xe  xenon   140  108  216  131  }
    {  55  Cs  caesium   260  298  343  232  }
    {  56  Ba  barium   215  253  268  196  }
    {  57  La  lanthanum   195  226  250  180  }
    {  58  Ce  cerium   185  210  248  163  }
    {  59  Pr  praseodymium   185  247  247  176  }
    {  60  Nd  neodymium   185  206  229  174  }
    {  61  Pm  promethium   185  205  243  173  }
    {  62  Sm  samarium   185  238  242  172  }
    {  63  Eu  europium   185  231  240  168  }
    {  64  Gd  gadolinium   180  233  238  169  }
    {  65  Tb  terbium   175  225  237  168  }
    {  66  Dy  dysprosium   175  228  235  167  }
    {  67  Ho  holmium   175  226  233  166  }
    {  68  Er  erbium   175  226  232  165  }
    {  69  Tm  thulium   175  222  230  164  }
    {  70  Yb  ytterbium   175  222  228  170  }
    {  71  Lu  lutetium   175  217  227  162  }
    {  72  Hf  hafnium   155  208  225  152  }
    {  73  Ta  tantalum   145  200  220  146  }
    {  74  W  tungsten   135  193  210  137  }
    {  75  Re  rhenium   135  188  205  131  }
    {  76  Os  osmium   130  185  200  129  }
    {  77  Ir  iridium   135  180  200  122  }
    {  78  Pt  platinum   135  177  175  123  }
    {  79  Au  gold   135  174  166  124  }
    {  80  Hg  mercury   150  171  155  133  }
    {  81  Tl  thallium   190  156  196  144  }
    {  82  Pb  lead   180  154  202  144  }
    {  83  Bi  bismuth   160  143  207  151  }
    {  84  Po  polonium   190  135  197  145  }
    {  85  At  astatine   180  127  202  147  }
    {  86  Rn  radon   170  120  220  142  }
    {  87  Fr  francium   260  298  348  232  }
    {  88  Ra  radium   215  253  283  201  }
    {  89  Ac  actinium   195  226  200  186  }
    {  90  Th  thorium   180  210  200  175  }
    {  91  Pa  protactinium   180  247  200  169  }
    {  92  U  uranium   175  206  200  170  }
    {  93  Np  neptunium   175  205  200  171  }
    {  94  Pu  plutonium   175  238  200  172  }
    {  95  Am  americium   175  231  200  166  }
    {  96  Cm  curium   176  233  200  166  }
}
set ::pwtk::minAtomicNumber 1
set ::pwtk::maxAtomicNumber 96


#****f* Atoms/::pwtk::isAtomLabel
# SYNOPSIS
proc ::pwtk::isAtomLabel {string} {
    # PURPOSE
    #   Return 1 if string is an atom label accodint to the QE syntax,
    #   and 0 otherwise
    #
    #   BEWARE: if string is an atomic number, 0 is returned!
    #
    #   QE-syntax for atomic label:    
    #      chemical-symbol X (1 or 2 characters, case-insensitive) or
    #      chemical-symbol plus a number or a letter, Xn (e.g. Fe1) 
    #      or X_* or X-* (e.g. C1, C_h)
    #
    #      max total length cannot exceed 3 characters!
    #
    # SOURCE
    
    if { [string is double $string] || [string length $string] > 3 } {
        return 0
    }
    if { [atomSymbol $string] ne "X" } {
        return 1
    } else {    
        return 0
    }
}
#******


#****f* Atoms/::pwtk::atomSymbol
# SYNOPSIS
proc ::pwtk::atomSymbol {atomStr} {
    # USAGE
    #    atomSymbol atomStr
    #
    # DESCRIPTION
    #    Get the atomic symbol from the supplied string. 
    #
    # ARGUMENTS
    # * atomStr -- string from which to find the atomic symbol
    #              (it can be atomic number or a decorated string, e.g., Fe_u, Fe_d)
    #
    # RETURN VALUE
    #   atomic-symbol; if atom is not found, "X" (e.g. dummy atom) is returned.
    #
    # SOURCE

    variable atomDataList
    variable atomSymbols
    
    set unknown X
    
    # is $atomStr an atomic number ?
    
    if { [string is integer -strict $atomStr] } {
        if { $atomStr >= $::pwtk::minAtomicNumber && $atomStr <= $::pwtk::maxAtomicNumber } {
            return [lindex $atomSymbols $atomStr-1]
        } else {
            return $unknown
        }
    }

    # $atomStr is a string; first, try two letters, then a single letter
    
    foreach idx {1 0} {
        set atom [string range $atomStr 0 $idx]
        if { $atom in $atomSymbols } {
            return $atom
        }
        #foreach a $::pwtk::atomDataList {
        #    set symb [lindex $a 1]
        #    if { $atom == $symb } {
        #        return $symb
        #    }
        #}
    }

    return $unknown
}
#******


#****f* Atoms/::pwtk::atomRadius
# SYNOPSIS
proc ::pwtk::atomRadius {args} {
    # USAGE
    #    atomRadius  [-pm | -angs | -bohr]  elem  [radtype]
    #
    # DESCRIPTION
    #    Get the $radType atomic radius for element $elem.
    #
    # OPTIONS
    # * -pm ... get radius in pm units
    # * -angs ... get radius in Angstrom units (DEFAULT)
    # * -bohr ...get radius in Bohr units
    #
    # ARGUMENTS
    # * elem -- atomic number or symbol
    # * radType -- type of radius (empirical, calculated, covalent, vdw)
    #
    # SOURCE
    
    variable angs2bohr
    
    set nargmin 1
    set nargmax 2
    set usage "?-angs | -bohr | -pm?  element ?radType?"    
    set options {
        {angs "angstrom (default)"}
        {bohr "bohr"}
        {pm   "pico-meter"}
    }
    parseOpt_

    set elem [lindex $args 0]
    set type [lindex $args 1]
    if { $type == {} } {
        set type cov
    }    

    if { $opt(angs)*$opt(bohr) + $opt(angs)*$opt(pm) + $opt(bohr)*$opt(pm) > 0 } {
        ::pwtk::error "only one of -angs, -bohr, -pm options must be specified, but got $args_" 1
    }

    set conv 0.01; # pm-to-angs (DEFAULT)  
    if { $opt(bohr) } {
        set conv [expr 0.01*$angs2bohr]; # pm-to-bohr
    } elseif { $opt(pm) } {
        set conv 1.0
    }
    
    switch -glob -- $type {
        emp*  {
            set ir 3;  # index of R in the atomData
            set rr 200; # unknown-element R (in pp)
        }
        calc* {
            set ir 4
            set rr 200
        }
        vdw* - van* {
            set ir 5
            set rr 300
        }
        cov*  {
            set ir 6
            set rr 200
        }
        default {
            ::pwtk::error "unknown radius type \"$radType\", must be one of emprirical, calculated, covalent, vdw or van-der-waals" 1
        }
    }

    if { [string is integer -strict $elem] } {
        set ie 0
    } else {
        set ie 1
    }

    foreach atom $::pwtk::atomDataList {
        if { $elem == [lindex $atom $ie] } {            
            return [expr $conv*[lindex $atom $ir]]
        }
    }

    # if we came here, element is not known
    ::pwtk::warning "unknown element \"$elem\"; PWTK only knows elements up to No.96"
    return [expr $conv*$rr]
}
#******


#print [pwtk::atomRadius -angs XX cov]
#print "
#Checking atomRadius:
#"
#
#foreach elem {S 16 7 43 Sm Xe} {
#    foreach type {emp calc cov vdw} {
#        foreach unit {bohr angs pm} {
#            set cmd "pwtk::atomRadius -$unit $elem $type"
#            print "$cmd: [eval $cmd]"
#        }
#        puts ""
#    }
#}

#foreach {str} {
#    Fe_up
#    8
#    111
#    Tone
#    Seq
#    S3
#} {
#    puts "atomSymbol $str :   [pwtk::atomSymbol $str]"
#}
