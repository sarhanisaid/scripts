#
# $RCSfile: bi.tcl,v $ --
#
#      This file contains the procs for handling the bands.x input.
#
# Copyright (c) 2019  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: bi.tcl,v 1.2 2021/05/03 14:21:08 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::bi_fprint {{file {}}} { uplevel ::pwtk::bi::fprint $file }
proc ::pwtk::bi_get    {}          { uplevel ::pwtk::bi::get }
proc ::pwtk::bi_clear  {}          { uplevel ::pwtk::bi::clear }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::bi/::pwtk::bi::fprint
# SYNOPSIS
proc ::pwtk::bi::fprint {{file {}}} {
# PURPOSE
#   Print the content of bands.x input data to a file or to stdout if the
#   file was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::bi $file
}
#****


#****f* ::pwtk::bi/::pwtk::bi::get
# SYNOPSIS
proc ::pwtk::bi::get {} {
    # DESCRIPTION    
    #   Return the content of the bands.x input 
    # SOURCE

    loadDefaults_
    
    return [::pwtk::input::namelistGet BANDS]
}
#******
    

#****f* ::pwtk::bi/::pwtk::bi::clear
# SYNOPSIS
proc ::pwtk::bi::clear {} {
    # DESCRIPTION    
    #   Clear the content of the bands.x input 
    # SOURCE
    variable input_flow_list
    
    foreach name $input_flow_list {
	::pwtk::input::clear $name
    }
}
#******
    

proc ::pwtk::bi::loadDefaults_ {} {
    # load some default values, when user has omitted them 

    namespace eval ::pwtk::input {
	defaultVarValue_ BANDS outdir  [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
	defaultVarValue_ BANDS prefix  ""
    }
}


#****f* ::pwtk::bi/::pwtk::bi::load_fromBI
# SYNOPSIS
proc ::pwtk::bi::load_fromBI {bi {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing bands.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * bi -- filename of the bands.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?
    #
    # SOURCE

    ::pwtk::fileMustExist $bi "bands.x input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current bands.x input data ...
	::pwtk::input::clear BANDS
    }

    # read the namelists

    set output [::pwtk::readNamelists $bi $::pwtk::bi::input_flow_list]

    # bands.x must contain a BANDS namelist
    if { $output == "" } {
	::pwtk::error "input file \"$bi\" does not appear to be a bands.x input file" 1
    }

    eval $output
    ::pwtk::input::namelists_ityp2atmSymb_ $::pwtk::bi::input_flow_list
}
#******
