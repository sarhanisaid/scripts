#
# $RCSfile: run.tcl,v $ --
#
#
#      This file contains procs for running programs.
#
#
# Copyright (c) 2009--2014  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: run.tcl,v 1.14 2021/05/07 13:24:43 tone Exp $ 
#

#****a* 5.3. Run Calculations/5.3.1. Run Programs (plain way)
# DESCRIPTION
#
#   A plain way of running executables.
#
#******

#****a* 5.3. Run Calculations/5.3.6. Run Auxiliaries
# DESCRIPTION
#
#   Some auxiliary routines, useful for running calculations.
#
#******



#****f* 5.3.1. Run Programs (plain way)/::pwtk::execute
# SYNOPSIS
proc ::pwtk::execute {args} {
    # USAGE
    #   execute ?switches? program ?arg1? ?arg2? ?arg3? ...
    #
    # PURPOSE
    #   A proc analogous to Tcl's exec, but searches for the "program"
    #   executable using the ::pwtk::findExecutable. The arguments are
    #   passed to exec verbatim.
    #
    # ARGUMENTS
    #   * switches -- switches to Tcl's exec command (-ignorestderr, -keepnewline, --)
    #   * program  -- name of executable to execute
    #   * arg1, arg2...  -- command-line arguments to supply to "program"
    #
    # SOURCE
    set options {
        {ignorestderr "Stops the exec command from treating the output of messages to the pipeline's standard error channel as an error case."}
        {keepnewline  "Retains a trailing newline in the pipeline's output. Normally a trailing newline will be deleted."}
    }
    array set opt [::cmdline::getoptions args $options [list [lindex [info level 0] 0] options:]]

    if { $opt(ignorestderr) } {
        append execOpts "-ignorestderr "
    }
    if { $opt(keepnewline) } {
        append execOpts "-keepnewline "
    }
    append execOpts "--"

    set prog [findExecutable [lindex $args 0]]
    set args [lrange $args 1 end]

    if { $prog eq {} } {
        ::pwtk::error "cannot find the executable \"[lindex $args 0]\"" 1
    }
    ::pwtk::print "Running: exec $execOpts $prog $args\n"    
    return [exec {*}$execOpts $prog {*}$args]
}
#******


#****f* 5.3.1. Run Programs (plain way)/::pwtk::run
# SYNOPSIS
proc ::pwtk::run {args} {
    # USAGE
    #   run [OPTIONS] PROGRAM  INPUT  ?OUTPUT?  ?&?
    #
    #   Options are:
    #     -bg
    #     -append
    #     -serial
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Run a given Quantum-ESPRESSO (QE) program. It is implicitly
    #   assumed that QE program reads from stdin and writes to stdout,
    #   that is, it is assumed that the standard usage from the
    #   terminal or shell-script is:
    #
    #       PROGRAM < INPUT > OUTPUT
    #
    #   The equivalent PWTK statement is:
    #
    #      run PROGRAM INPUT ?OUTPUT?
    #
    #   where INPUT is the name of the input file and OUTPUT is
    #   the name of the output file. Note that the OUTPUT argument
    #   is optional; if it is not specified it is automatically
    #   constructed from the input file name. For example, if the
    #   INPUT is "file.in" then the OUTPUT is "file.out", but if the
    #   input filename does not have .in or .inp extension, then the
    #   name of the output is simply file.out, where "file" is the
    #   input filename.
    #
    #   See the ::pwtk::findExecutable for how the executable is located.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append --- treat the output file in append mode (default = overwrite)
    #   * -serial --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX   --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE --- explicitly specify the executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    #   * PROGRAM -- name of executable
    #   * INPUT   -- input file (or the rootname for the I/O files)
    #   * OUTPUT  -- [optional] name of file to write the output to 
    #                (default = $head.out, where $head is the prefix of the input file)
    #   * &       -- [optional] run calculation in background (synonymous with the -bg option)
    #
    # RETURN VALUE
    #   The name of the output file, unless the -bg option was
    #   specified in which case the ID of the backhound job is
    #   returned, which can be used for ::pwtk::run_wait.
    #
    # SOURCE

    variable state
    variable run_options
    variable RUNopt
    variable run
    variable makeInputAndRun_

    # for prerun & remedy a recursive call to run is made, store how to call it
    
    set args_orig $args
    set run_cmd {
        ifexist makeInputAndRun_ {
            #set result [eval makeInputAndRun_ $makeInputAndRun_]
            set result [makeInputAndRun_ {*}$makeInputAndRun_]
        } else {
            #set result [eval run $args_orig]
            set result [run {*}$args_orig]
        }
        concat $result
    }
    
    #
    # parse arguments
    #

    set bg 0
    set lastarg [lindex $args end]
    if { $lastarg eq "&" } {
        set bg 1
        set args [lrange $args 0 end-1]
    }
    set usage "\n\nUsage: ::pwtk::run  ?OPTIONS?  PROGRAM  INPUT  ?OUTPUT?  ?&?\n\nOptions are:"

    array set opt [::cmdline::getoptions args $run_options $usage]

    if { [llength $args] < 2 || [llength $args] > 3 } {
	error [::cmdline::usage $run_options $usage] 1
    }

    # &" is synonymous with -bg
    if { $bg } {
        set opt(bg) 1
    }

    lassign $args program input output
    set ihandle $RUNopt(input_handle)
    
    if { $output == "" } {
	set output [outputName_ $input]
    }
    if { $opt(ihandle) != {} } {
	set ihandle $opt(ihandle)
    }

    # if in restart-mode & job is already done, do not run it again
    
    if { $state(restart) && [::pwtk::job_done $output] } {
        ::pwtk::print "The $program job \"$output\" already done.\n"
        return $output
    }    
    
    # check for excluding options: (prefix || postfix) vs serial 
    
    if { $opt(serial) && $opt(prefix) != "" } {
	::pwtk::error "exclusive -serial and -prefix options were specified" 1
    }
    if { $opt(serial) && $opt(postfix) != "" } {
	::pwtk::error "exclusive -serial and -postfix options were specified" 1
    }
    
    # store the name of program, input & output files (they may be queried from other procs)
    
    array set run [list program $program input $input output $output]
    set pname [file tail $program]

    # handle "prerun"

    set preruns [::pwtk::preruns_ $pname]
    if { $preruns ne {} } {
        ::pwtk::input::pushpop {
            foreach name $preruns {
                #::pwtk::print "Evaluating the prerun script:\n$state($name)"
                eval $state($name)
                unset state($name)
            }
            eval $run_cmd
        }
        return [varvalue result]
    }

    #
    # determine prefix & postfix
    #

    if { ! $opt(serial) } {
	# parallel run 
	# (beware: do not swap the below lines, because order matters !!!)
	set prefix  [list {*}[::pwtk::getVar_ RUNopt(NICE_CMD)] {*}[::pwtk::getVar_ RUNopt(CONTAINER_EXEC)] {*}[::pwtk::getVar_ RUNopt(PREFIX)]]
	set postfix [::pwtk::getVar_ RUNopt(POSTFIX)]
	if { $opt(prefix)  != "" } { set prefix  $opt(prefix) }
	if { $opt(postfix) != "" } { set postfix $opt(postfix) }	
    } else {
	# serial run
	set prefix  [list {*}[::pwtk::getVar_ RUNopt(NICE_CMD)] {*}[::pwtk::getVar_ RUNopt(CONTAINER_EXEC)] {*}[::pwtk::getVar_ RUNopt(SERIAL_PREFIX)]]
	set postfix [::pwtk::getVar_ RUNopt(SERIAL_POSTFIX)]
    }

    #
    # find the executable
    #
    if { $opt(exec) == "" } {
	set prog [findExecutable $program]
    } else {
	# executable was explicitly specified (check if it is OK)
	set prog $opt(exec)
	if { $state(bin_query) && [auto_execok $prog] == "" } {
            ::pwtk::error "explicitly specified program '$prog' is not executable" 1
        }	
    }
    ::pwtk::print "Executable: $prog"

    # check if the input file exists and is readable 

    if { ! [file readable $input] } {
	::pwtk::error "file '$input' does not exist or is not readable" 1
    }
        
    # redirection and write mode

    set mode w
    set redirect ">"
    if { $opt(append) } {
	set mode a
	set redirect ">>"
    } else { 
	if { [backup_io] } {
	    # make a backup copy of output
	    file_backup $output
	}
    }

    # check if the output file is writeable

    try {
        close [open $output a]
    } on error errVar {
        ::pwtk::error "output file '$output' is not writable\n\n$errVar" 1
    }    
    
    # write to output the hostname where calculation is run 

    set redirect_orig $redirect
    set host_ [info hostname]    
    if { $host_ != "" } {
        ::pwtk::writeFile $output "### Running on host: $host_" $mode
        set redirect ">>"
    }

    # remove the error file
    
    if { [file exists $output.error] } {
        file delete $output.error
    }

    #### run the calculation ###############################################
    #
    set rr [string trim "$prefix [file tail $prog] $postfix"]
    try {
        if { ! $opt(bg) } {
            # foreground
            ::pwtk::print "Running: $rr $ihandle $input $redirect_orig $output\n"
            eval exec $prefix $prog $postfix $ihandle $input $redirect $output
        } else {
            # background;            
            # make a push to prevent stack-level == 0, for which ::pwtk::input::peek returns an empty string
            ::pwtk::input::pushpop {                
                ::pwtk::print "Running in background: $rr $ihandle $input $redirect_orig $output 2> $output.error &"
                set id [incr run(bg.ID)]                    
                set pid [eval exec $prefix $prog $postfix $ihandle $input $redirect $output 2> $output.error &]
                ::pwtk::print "PID of the background process = $pid\n"
                # tk
                array set run [list bg.prog,$id  $prog \
                                   bg.pname,$id  $pname \
                                   bg.output,$id $output  \
                                   bg.PID,$id    $pid \
                                   bg.peek,$id   [::pwtk::input::peek] \
                                   bg.run_cmd,$id $run_cmd]                           
                # tk_end
            }
            
            return $id
        }
    } on error errMsg {
        ::pwtk::writeFile $output.error $errMsg
    }
    #
    ########################################################################

    # handle "remedy"
    
    if { [remedy $pname] } {
        if { [checkForError $output $prog 0] } {
            set remedy [remedy $pname get]
            ::pwtk::infoMsg "Trying to remedy the $pname error by using the remedy script:\n$remedy"
            ::pwtk::input::pushpop {
                remedy $pname clear
                eval $remedy
                eval $run_cmd
            }
            return [varvalue result]
        }
    } else {
        checkForError $output $prog $state(stopOnError)
    }

    # handle "postrun"

    set postruns [::pwtk::postruns_ $pname]
    if { $postruns ne {} } {
        foreach name $postruns {
            # should a postrun be done inside pushpop? NO!
            #::pwtk::print "Evaluating the postrun script:\n$state($name)"
            eval $state($name)        
        }
    }

    return [varvalue output]
}
#******


#****f* 5.3.6. Run Auxiliaries/::pwtk::bin_query
# SYNOPSIS
proc ::pwtk::bin_query {{query {}}} {
    # USAGE
    #    ::pwtk::bin_query true|false
    #
    # PURPOSE
    #   Should PWTK use its "machinery" (via ::pwtk::findExecutable) to
    #   locate the QE binaries and query whether they are executable or
    #   not (default is to query, i.e. "bin_query true").
    #
    #   If bin_query is set to false, then QE executables (pw.x, pp.x,
    #   ph.x ...) are used verbatim without any checking if they exist
    #   or are executable.
    #
    #   Usually it is good to query. An example when querying should be
    #   disabled is when using executables from a software container, yet
    #   the PWTK is run outside the container.
    #
    # SOURCE
    variable state

    if { $query != {} } {
        # e.g., .true. --> true
        set query [string trim $query .] 
        
        if { ! [string is boolean $query] } {
            ::pwtk::error "expecting a boolean, but got \"$query\",\nwhile executing \"bin_query $query\"" 1
        }
        set state(bin_query) [::pwtk::is_true $query]

        if { $state(bin_query) } {
            ::pwtk::print "Querying of executables is ON\n"
        } else {
            ::pwtk::print "Querying of executables is OFF\n"
        }

    }
    return $state(bin_query)
}
#****


#****f* 5.3.6. Run Auxiliaries/::pwtk::findExecutable
# SYNOPSIS
proc ::pwtk::findExecutable {program {abort 1}} {
    # PURPOSE    

    #   Find the executable of a given Quantum-ESPRESSO (QE) program,
    #   using the following set of rules:    
    #   |html <ol>
    #   |html <li>First, the value of the associated program's variable is
    #   |html queried (i.e., QEprog(PW), QEprog(PH), QEprog(PP) as set by
    #   |html the ::pwtk::prog calls). If the variable exists,
    #   |html it is checked that it points to an executable.</li>
    #   |html <li>If (1) fails, the value of $QEdir(BIN_DIR)/$program is tried.</li>
    #   |html <li>If even (2) fails, the plain $program is tried, and if it fails, an error is thrown if $abort != 0</li>
    #   |html </ol>
    #
    # This command is typically used internally by PWTK.
    #
    # ARGUMENTS
    #   * program -- name of the executable
    #   * abort   -- (optional, default = 1) abort if executable is not found
    #
    # SOURCE
    
    variable state

    if { ! $state(bin_query) } {
        # querying of binaries is disabled, use $program varbatim
        return $program
    }
    
    set head  [headname [file rootname $program] .x]
	    
    # A. query the value of QEprog(PW), QEprog(PH), QEprog(PP)... variables
    
    set HEAD  [string toupper $head]
    set prog  [auto_execok [::pwtk::getVar_ QEprog($HEAD)]]
    if { $prog ne {} } {
        return $prog
    }
	    
    # B. if (a) fails try as $QEdir(BIN_DIR)/$program, $QEdir(BIN_DIR)/$head.x, or $QEdir(BIN_DIR)/$head
    
    foreach name [list $program $head.x $head] {
        set prog [auto_execok [file join [::pwtk::getVar_ QEdir(BIN_DIR)] $name]]
        if { $prog ne {} } {
            return $prog
	}
    }
    
    # C. if ((a) && (b)) fail try as plain $program, $head.x, or $head
    
    foreach name [list $program $head.x $head] {
        set prog [auto_execok $name]
        if { $prog ne {} } {
            return $prog
	}
    }

    if { $prog eq {} } {
	::pwtk::error "can't find a usable \"$program\" executable" $abort
    }

    return $program
}
#******


#****f* 5.3.6. Run Auxiliaries/::pwtk::job_done
# SYNOPSIS
proc ::pwtk::job_done {outputFile} {
    # PURPOSE
    #   Check if a given QE output-file corresponds to a normally
    #   finished job (it searches for "JOB DONE." string) and checks
    #   that there is no error in the output-file.
    #
    # RETURN VALUE
    #   The return valueis 1 if output file corresponds to a normally
    #   finished job, and zero otherwise.
    #
    # ARGUMENTS
    # * outputFile -- name of the output file
    #
    # SOURCE

    try {
        set fid [open $outputFile r]
    } on error errVar {
        return 0
    }

    # if job is completed normaly, the the last record in the output
    # file is:
    #
    # =----------------------------...
    #    JOB DONE.
    # =----------------------------...    

    set ind 0
    set marker -1000; # BEWARE: do not set marker to 0 or else the check at the end will fail

    while { ! [eof $fid] } {
	#
	gets $fid line
        incr ind
        if { [regexp -- {^=--------------+=$} $line] } {
            gets $fid line
            incr ind
            if { [string match {*JOB DONE.*} $line] } {
                gets $fid line
                incr ind
                if { [regexp -- {^=--------------+=$} $line] } {
                    set marker $ind
                }
            }
        }
    }
    close $fid
    
    # if this block is the last:
    #
    # =----------------------------...
    #    JOB DONE.
    # =----------------------------...
    #
    # then $marker+1 == $ind; but let's use some safety offset !
    #
    # check also that there is no error in the $outputFile
    
    if { $marker + 30 > $ind && ![::pwtk::checkForError $outputFile {} 0 1]} {
        return 1
    } else {
        return 0
    }
}
#******

    
#****f* 5.3.6. Run Auxiliaries/::pwtk::checkForError
# SYNOPSIS
proc ::pwtk::checkForError {outputFile prog {_stopOnError 0} {_silent 0}} {
    # PURPOSE
    #   Check for error in the pw.x, ph.x, ... output file, and
    #   depending on the error type and value of _stopOnError the
    #   aplication may exit.
    #
    #   The "exit" statement will be executed only if (i) _stopOnError > 0
    #   or (ii) (_stopOnError < 0 and error type is "runtime error" or "hard error")
    #   
    #   The presence of error is checked as follows: We check for one
    #   of the error strings, however the output might be appended
    #   from the previous run, so we check for error string after the
    #   last "Program PWSCF" string !!!
    #
    # ARGUMENTS
    #   * outputFile -- name of output file
    #   * prog       -- name of executable (i.e., name of QE program: pw.x, ph.x, ...)
    #   * _stopOnError -- if _stopOnError > 0, the application will exit upon error
    #                     detection; if _stopOnError < 0, the application will exit
    #                     only upon detection of "runtime error" or "hard error"
    #   * _silent -- if true, do not print error message
    #
    # RETURN VALUE
    #   * 1 -- if error is found
    #   * 0 otherwise
    #
    # SOURCE

    variable error

    fileMustExist $outputFile "output file"
    set fid [open $outputFile r]

    # this is list of error stings + types

    set errorPatternAndType {
	{*convergence NOT achieved after*}      {convergence failure}
	{*scf convergence NOT achieved*}        {convergence failure}
        {*No convergence has been achieved*}    {convergence failure}
        {*reached the maximum number of steps*} {convergence failure}
	{*Signal Received, stopping ...*}       {interrupt signal received}
	{*Maximum CPU time exceeded*}           {maximum cpu time exceeded}
	{*Program stopped by user request*}     {soft exit} 
	{*Fortran runtime error*}               {runtime error}
        {*Per user-direction, the job has been aborted.*}   {MPI error}
	{*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*} {hard error}
    }

    # this is equivalent to: setErrorInfo_ {} {} -1
    set error(type)  ""
    set error(line)  ""
    set error(line_number) -1

    # MPI errors are handled a bit differently
    set mpi_error 0
    set mpi_line  {}
    set mpi_line_number -1
    
    set ind    1
    set marker 0
    
    while { ! [eof $fid] } {
	#
	gets $fid line
	
	if { [regexp -- {^     Program} $line] && [regexp -- {starts} $line] } {

	    set marker $ind

	} else {            
            foreach {pattern type} $errorPatternAndType {                
                if { [string match $pattern $line] } {
                    if { $type == "hard error" } {
                        # special handling of hard error: check that
                        # the next line contains "Error" string
                        gets $fid line2
                        if { [string match {* Error in*}  $line2] } {
                            gets $fid line3
                            setErrorInfo_ "hard error" $line\n$line2\n$line3 $ind
                        }
                    } elseif { $type == "MPI error" } {
                        # N.B. MPI error is reported only if other error is not detected
                        set mpi_error 1
                        set mpi_line $line
                        set mpi_line_number $ind
                    } else {
                        setErrorInfo_ $type $line $ind
                    }
                }
            }
        }
        incr ind        
    }
    close $fid

    if { $mpi_line_number > $marker && !($error(line_number) > $marker) } {
        # only MPI error was detected
        setErrorInfo_ "MPI error" $mpi_line $mpi_line_number
    }

    if { $error(line_number) > $marker } {
	if { $_stopOnError < 0 } {
	    if { $error(type) == "runtime error" || $error(type) == "hard error" } {
		set _stopOnError 1
	    } else {
		set _stopOnError 0
	    }
	}
	
	set msg "An error occurred during the $prog run !!!
For details see the output file: [file join [pwd] $outputFile]

Error INFO:
  error detected on line number: $error(line_number)
  error type  : $error(type)
  error string: $error(line)"

        if { ! $_silent } {
            # print the error message
            ::pwtk::error $msg $_stopOnError
        }
        return 1
    } else {
	# BEWARE: "error" variable may be used from other procs to
	# further query the status of error, hence clear the error
	# variable, because the run was OK.
	
	setErrorInfo_ {} {} -1
    }
    return 0
}
#******


#****if* Internals/::pwtk::dryrunFailed
# SYNOPSIS
proc ::pwtk::dryrunFailed {outputFile prog} {
    # PURPOSE
    #   Check if dryrun failed.
    # ARGUMENTS
    # * outputFile --- dryrun's output file
    # * prog       --- QE program (pw.x, cp.x, neb.x)
    # RETURN VALUE
    #   * 1 -- if error is found
    #   * 0 otherwise
    # SOURCE
     variable error
     checkForError $outputFile $prog 0 1
     if { $error(type) eq {} || $error(type) eq "soft exit" } {
         return 0
     }
     return 1
}
#******


# internal ...
proc ::pwtk::filterQEerror_ {text} {
    # PURPOSE
    #   Strip the line "error detected on line number:" from the
    #   checkForError's error message because the line-number depends
    #   on the number of procs used.
    #
    #   This routine is used by test (e.g. in ::pwtk::test)
    
    foreach line [split $text \n] {
        if { ! [regexp {error detected on line number} $line] } {
            append result $line\n
        }
    }
    return [varvalue result]
}


#****f* 5.3.3. Run Modifiers/::pwtk::restart
# SYNOPSIS
proc ::pwtk::restart {{restart {}}} {
    # PURPOSE
    #   Set or query the PWTK restart mode. The restart mode can be
    #   either ON or OFF. If restart mode is ON then the calculation
    #   will not be performed if it is already done (default = OFF).
    #       
    # ARGUMENTS
    # * restart -- (optional) either ON or OFF (or any other boolen
    #              value such as true, false, yes, no, 1, 0)
    # RETURN VALUE
    #   The value of the restart mode.
    #
    # SOURCE
    variable state

    if { $restart != {} } {
        # e.g., .true. --> true
        set restart [string trim $restart .]
        
        if { ! [string is boolean $restart] } {
            ::pwtk::error "wrong value of restart \"$restart\", must be boolean" 1
        }
        set state(restart) [::pwtk::is_true $restart]

        if { $state(restart) } {
            ::pwtk::print "Restart mode is ON\n"
        } else {
            ::pwtk::print "Restart mode is OFF\n"
        }
    }
    return $state(restart)
}
#******
        

#****f* 5.3.3. Run Modifiers/::pwtk::stopOnError
# SYNOPSIS
proc ::pwtk::stopOnError {{stopOnError {}}} {
    # PURPOSE

    #   Set or query the "stopOnError" flag, which can be either ON or
    #   OFF. If "stopOnError" is ON, the PWTK execution aborts if an
    #   error occurs during QE calculation, whereas if "stopOnError"
    #   is OFF, then the execution of PWTK script continues even if an
    #   error occurs during QE calculation.
    #
    # ARGUMENTS    
    # * stopOnError -- (optional) either ON or OFF (or any other boolen
    #                  value such as true, false, yes, no, 1, 0)    
    # RETURN VALUE
    #   The value of the "stopOnError" flag.
    #
    # SOURCE
    variable state

    if { $stopOnError != {} } {        
        # e.g., .true. --> true
        set stopOnError [string trim $stopOnError .] 
        
        if { ! [string is boolean $stopOnError] } {
            ::pwtk::error "expecting a boolean argument, but got \"$stopOnError\",\nwhile executing \"stopOnError $stopOnError\"" 1
        }
        set state(stopOnError) [::pwtk::is_true $stopOnError]

        if { $state(stopOnError) } {
            ::pwtk::print "stopOnError mode is ON\n"
        } else {
            ::pwtk::print "stopOnError mode is OFF\n"
        }

    }
    return $state(stopOnError)
}
#******


# ------------------------------------------------------------------------
#
# INTERNAL procs
#
# ------------------------------------------------------------------------
proc ::pwtk::setErrorInfo_ {type line lineNumber} {
    variable error
    set error(type)  $type
    set error(line)  $line
    set error(line_number) $lineNumber
}



proc ::pwtk::makeInputAndRun_ {absNamespace prog args} {
    # PURPOSE: make the appropriate input file and run the 'prog' calculation
    #
    # USAGE: makeInputAndRun_  absNamespace prog [options] input ?output?
    variable run_options
    variable makeInputAndRun_

    # handle treatrun
    treat_run_ {*}$args

    set makeInputAndRun_ [concat $absNamespace $prog $args]
    set argv $args
    set opt  [::cmdline::getoptions argv $run_options]

    # check for correct usage

    if { [llength $argv] < 1 } {
        ::error "wrong # args: should be \"[procName] ?options? input ?output?"
    }       

    # parse arguments

    #set module [headname $prog .x] ; # tk Thu Feb 29 02:00:20 PM CET 2024
    set input  [inputName_ [lindex $argv 0]]
    set output [lindex $argv 1]
    
    # create the input file

    ::pwtk::input::fprint_ ${absNamespace} $input

    # if needed, download pseudopotentials (for pw.x, cp.x, and neb.x only)

    ::pwtk::download_needed_PPs_ $absNamespace

    # take care of plugins

    variable state
    variable plugin
    foreach p [varvalue plugin(list)] {
        if { [info exists state($p)] && $state($p) } {
            # REMARK: so far QE ignores unknown flags, hence the below
            # check is not yet needed, but it is a good practice:
            
            if { $prog in $plugin($p,programs) } {            
                # write the plugin input file and its copy
                ::pwtk::${p}::save_$plugin($p,input) [file rootname $plugin($p,input)].$input

                # activate the plugin via postfix flag
                set flag [string trimleft $plugin($p,flag) -]
                if { [lsearch -regexp [postfix] ^-+$flag] < 0 } {
                    postfix {*}[postfix] $plugin($p,flag)
                }
            }
        }
    }
    
    # run the calculation

    set last [string last [string trim $argv] [string trim $args]]
    set opts [string range $args 0 $last-1]

    #set result [run {*}$opts $module.x $input {*}$output]
    set result [run {*}$opts $prog $input {*}$output]
    ifexist makeInputAndRun_ {
        unset makeInputAndRun_
    }
    return $result
}


proc ::pwtk::inputName_ {input} {

    # add the .in to $input if it is not of type head.in or head.inp

    set ext [file extension $input]
    if { [string match -nocase ".in" $ext] || [string match -nocase ".inp" $ext] } {
	return $input
    }
    return $input.in
}


proc ::pwtk::outputName_ {input} {

    # if input is of type head.inp or head.in, then output is head.out
    # if input is of type head, then output is input.out

    set head [headname $input {.in .inp}]
    return $head.out
}


# internal...
proc ::pwtk::download_needed_PPs_ {absNamespace} {
    # PURPOSE
    #   Trigger the download of the needed PPs for the calculation
    if { $absNamespace in {::pwtk::pwi ::pwtk::cpi ::pwtk::nebi} && [pseudo_auto_download] } {
        foreach {atm mass pp} [::pwtk::pwi::filterAtomicSpecies ${absNamespace}::getAtmSymbList] {
            lappend pps $pp
        }
        if { [info exists pps] } {
            ::pwtk::pseudo_download {*}$pps
        }
    }
}
