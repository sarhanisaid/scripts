#
# $RCSfile: davi.tcl,v $ --
#
#      This file contains procs for handling the turbo_davidson.x input.
#
# Copyright (c) 2021  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: davi.tcl,v 1.1 2021/05/01 19:24:39 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::davi_fprint {{file {}}} { uplevel ::pwtk::davi::fprint $file }
proc ::pwtk::davi_clear  {}          { uplevel ::pwtk::davi::clear }
proc ::pwtk::davi_get    {}          { uplevel ::pwtk::davi::get }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::davi/::pwtk::davi::fprint
# SYNOPSIS
proc ::pwtk::davi::fprint {{file {}}} {
# PURPOSE
#   Print the content of turbo_davidson.x input data to a file or to stdout if the
#   file was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::davi $file
}
#****


#****f* ::pwtk::davi/::pwtk::davi::get
# SYNOPSIS
proc ::pwtk::davi::get {} {
    # DESCRIPTION    
    #   Return the content of the turbo_davidson.x input 
    # SOURCE
    variable namelist_flow_list
    
    ::pwtk::lri::loadDefaults_

    foreach nml $namelist_flow_list {
        append inp [::pwtk::input::namelistGet $nml]
    }
   
    return $inp
}
#******

#****f* ::pwtk::davi/::pwtk::davi::clear
# SYNOPSIS
proc ::pwtk::davi::clear {} {
    # DESCRIPTION    
    #   Clear the content of the turbo_davidson.x input 
    # SOURCE
    variable input_flow_list
    
    foreach nml $input_flow_list {
        ::pwtk::input::clear $name
    }
}
#******

#****f* ::pwtk::davi/::pwtk::davi::load_fromDAVI
# SYNOPSIS
proc ::pwtk::davi::load_fromDAVI {davi {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing turbo_davidson.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * davi -- filename of the turbo_davidson.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?
    #
    # SOURCE
    variable namelist_flow_list

    ::pwtk::lri::load_from_input_  turbo_davidson.x  $namelist_flow_list  $davi  $clear_existing
}
#******
