#
# $RCSfile: time.tcl,v $ --
#
#      This file contains routines associated with time.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: time.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#

#****f* Time/::pwtk::time2s
# SYNOPSIS
proc ::pwtk::time2s {opt {time {}}} {
    # USAGE
    #   time2s  ?-real?  TIME
    #
    # PURPOSE
    #   Convert the time to seconds and round it to an integer,
    #   unless the -real option is specified.
    #
    # OPTION
    # * -real ... return the converted time as a real number (without
    #             this option, the time is returned as an integer number)
    #
    # ARGUMENT
    # * TIME -- the time to convert, specified as 1h, 1d... (see below).
    #           If TIME is specified without a unit, seconds are assumed.
    #
    # Units of time ("*" implies any string, e.g., micro* matches microseconds):
    # * micro* = microseconds
    # * ms = milliseconds
    # * no unit specified = seconds
    # * m, min* = minutes    
    # * h, H, hour* = hours
    # * d, D, day*  = days
    # * w, W, week* = weeks
    # * M, month*   = months
    # * y, Y, year* = years
    #
    # SOURCE
    return [expr [::pwtk::time2ms $opt $time]/1000]
}
#******

#****f* Time/::pwtk::time2ms
# SYNOPSIS
proc ::pwtk::time2ms {opt {time {}}} {
    # USAGE
    #   time2ms  ?-real?  TIME
    #
    # PURPOSE
    #   Convert the time to milliseconds and round it to an integer,
    #   unless the -real option is specified.
    #
    # OPTION
    # * -real ... return the converted time as a real number (without
    #             this option, the time is returned as an integer number)
    #
    # ARGUMENT
    # * TIME -- the time to convert, specified as 1h, 1d... (see below).
    #           If TIME is specified without a unit, seconds are assumed.
    #
    # Units of time ("*" implies any string, e.g., micro* matches microseconds):
    # * micro* = microseconds
    # * ms = milliseconds
    # * no unit specified = seconds
    # * m, min* = minutes    
    # * h, H, hour* = hours
    # * d, D, day*  = days
    # * w, W, week* = weeks
    # * M, month*   = months
    # * y, Y, year* = years
    #
    # SOURCE
    
    if { [string match -r* $opt] } {
        # time2ms -real time
        set real 1
    } elseif { $time eq {} } {
        # time2ms time
        set real 0
        set time $opt
    } else {        
        ::pwtk::error "wrong args: should be \"time2ms  ?-real?  TIME\", but got \"[procName] $opt [list $time]\"" 1
    }

    set unit  [string trim [regsub {^[\-+0-9.eE]+} $time {}]]
    set value [regsub [string trim $unit] $time {}]
    if { ! [string is double $value] } {
        ::pwtk::error "wrong time \"$time\", time should be a number" 1
    }
    ifempty value { set value 1 }

    # in seconds:
    set min   60
    set hour  3600
    set day   [expr {24*$hour}]
    set week  [expr {7*$day}]
    set month [expr {30*$day}]
    set year  [expr {365*$day}]        

    switch -glob $unit {
        micro*        { set sec 1e-6 }
        ms            { set sec 1e-3 }
        s - sec*      { set sec 1 }
        m - min*      { set sec $min }
        h - H - hour* { set sec $hour }
        d - D - day*  { set sec $day }
        w - W - week* { set sec $week }
        M - mon*      { set sec $month }
        y - Y - year* { set sec $year }
        {} {
            # no unit: default time-unit is second
            set sec 1
        }
        default {
            pwtk::error "wrong unit \"$unit\", must be one of microsec, ms, s, m, h, d, w, N, y" 1
        }
    }

    # return time in ms
    set time [expr {1000 * $sec * $value}]
    if { $real } {
        return [expr double($time)]
    } else {
        return [expr {round($time)}]
    }
}
#******


#****f* Time/::pwtk::time2unit
# SYNOPSIS
proc ::pwtk::time2unit {unit time} {
    # USAGE
    #   ::pwtk::time2unit UNIT TIME
    #
    # PURPOSE
    #   Convert the time to requested unit and return the result as a real number.
    #
    # ARGUMENTS
    # * UNIT -- time-unit to convert the time to
    # * TIME -- the time to convert, specified in the format accepted by ::pwtk::time2ms
    #
    # Units of time ("*" implies any string, e.g., micro* matches microseconds):
    # * micro* = microseconds
    # * ms = milliseconds
    # * no unit specified, s, sec* = seconds
    # * m, min* = minutes    
    # * h, H, hour* = hours
    # * d, D, day*  = days
    # * w, W, week* = week
    # * M, month*   = month
    # * y, Y, year* = year
    #    
    #   
    # SOURCE

    # in milliseconds:
    set sec   1000
    set min   [expr {60*$sec}]
    set hour  [expr {60*$min}]
    set day   [expr {24*$hour}]
    set week  [expr {7*$day}]
    set month [expr {30*$day}]
    set year  [expr {365*$day}]        
    
    # convert time to ms
    set time [expr double([time2ms -real $time])]

    switch -glob [string trim $unit -] {
        micro*        { return [expr {1000*$time}] }
        ms            { return $time }
        s - sec*      { return [expr {$time/$sec}] }
        m - min*      { return [expr {$time/$min}] }
        h - H - hour* { return [expr {$time/$hour}] }
        d - D - day*  { return [expr {$time/$day}] }
        w - W - week* { return [expr {$time/$week}] }
        M - mon*      { return [expr {$time/$month}] }
        y - Y - year* { return [expr {$time/$year}] }
        default {
            ::pwtk::error "wrount unit of time; must be one of micro, ms, s, h, h, d, w, M, or y, but got $unit" 1
        }
    }
}
#******


#****f* Time/::pwtk::measure_time
# SYNOPSIS
proc ::pwtk::measure_time {args} {
    # USAGE
    #    ::pwtk::measure_time  ?-fmt FORMAT?  script  ?stdoutRedirectFile?
    #
    # PURPOSE
    #   Time the execution of a script. This routine is very similar
    #   to the Tcl 'time' command, but provides more descriptive
    #   printout and reports time in seconds. It is intended for
    #   scripts, such as calculations, which take long time.
    #
    # OPTION
    # * -fmt FORMAT ... format of the printed time (in C syntax, default = %.3f)
    #
    # ARGUMENTS
    # * script ... script to time its execution
    # * stdoutRedirectFile ... (optional) if given, it is the name of the file
    #                          to which stdout of the script is redirected to
    # SOURCE

    set nargmin 1
    set nargmax 2
    set usage "?-fmt FORMAT?  script  ?stdoutRedirectFile?"
    set options {
        {fmt.arg   %.3f   "format (precision) of the reported time in seconds"}
    }
    parseOpt_
    lassign $args script stdoutRedirectFile

    print TIME "Timing the execution of a script:"
    print "\n[string trim $script \n]\n"
    
    if { $stdoutRedirectFile ne {} } {
        infoMsg "stdout redirected to a log file :  $stdoutRedirectFile"
    }
    
    print "Executing script at [clock format [clock seconds]]"
    
    set t0 [clock milliseconds]
    if { $stdoutRedirectFile eq {} } {
        uplevel $script
    } else {
        uplevel ::pwtk::redirect_stdout_to $stdoutRedirectFile $script        
    }
    set t [clock milliseconds]

    print "Script execution finished at [clock format [clock seconds]]\n"
    
    set dt [format $opt(fmt) [pwtk::time2s -r [expr $t - $t0]ms ]]
    print "Time needed to execute the script: $dt seconds\n"

    return $dt
}
#******
