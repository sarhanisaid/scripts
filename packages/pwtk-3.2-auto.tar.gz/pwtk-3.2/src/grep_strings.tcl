#--
# INCOMING
#
#   Consider using a separate file for all grep-strings that are used
#   by pwtk.  The grep strings mainly pertain to grepping the output
#   grepping files, in particular, the PWO.
#--

namespace eval ::pwtk {
    variable pwo_string

    set pwo_string(alat_old) {*lattice parameter (a_0)   =*}
    set pwo_string(alat_new) {*lattice parameter (alat)  =*}

    set pwo_string(nat)          {*number of atoms/cell*}
    set pwo_string(crystal_axes) {*crystal axes: (cart. coord. in units of a*}
}

