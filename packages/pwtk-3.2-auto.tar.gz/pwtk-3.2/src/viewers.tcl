#
# $RCSfile: viewers.tcl,v $ --
#
#      This file contains a few routines for displaying pdf, svg, png
#      documents/images.
#
# Copyright (c) 2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: viewers.tcl,v 1.0 2023/02/08 17:00:01 kokalj Exp $ 
#


#****f* Viewers/::pwtk::getViewer
# SYNOPSIS
proc ::pwtk::getViewer {type {prog {}}} {
    # PURPOSE
    #   Set or query a usable viewer executable for viewing the $type
    #   documents/images.
    # ARGUMENTS
    # * type -- type of document/image (ps, eps, pdf, png, svg...)
    # RETURN VALUE
    # * A usable viewer executable or an empty string if none found.
    # SOURCE
    variable viewers
    
    if { $prog != {} && [auto_execok $prog] != {} } {
        set viewer $prog
    } 

    ifnotexist viewer {
        # take case of $type correctness    
        switch -nocase -- $type {
            ps - eps - pdf - doc { set type pdf }
            svg     { set type svg }
            default { set type png }
        }

        return [getExecutable {*}$viewers($type)]
    }
}
#******


#****f* Viewers/::pwtk::docViewer
# SYNOPSIS
proc ::pwtk::docViewer {{viewer {}}} {
    # DESCRIPTION
    #    Set or query an EPS & PDF document viewer.
    #
    # RETURN VALUE
    #    * If a usable doc-viewer is found: the name of the EPS & PDF document-viewer executable
    #    * Otherwise: an empty string
    #
    # SOURCE
    variable docViewer
    return [set docViewer [getViewer pdf $viewer]]
}
#******


#****f* Viewers/::pwtk::imgViewer
# SYNOPSIS
proc ::pwtk::imgViewer {{viewer {}}} {
    # DESCRIPTION
    #    Set or query a bitmap image viewer.
    #
    # RETURN VALUE
    #    * If a usable image-viewer is found: the name of the image-viewer executable
    #    * Otherwise: an empty string
    #
    # SOURCE
    variable imgViewer
    return [set docViewer [getViewer png $viewer]]
}
#******


#****f* Viewers/::pwtk::svgViewer
# SYNOPSIS
proc ::pwtk::svgViewer {{viewer {}}} {
    # DESCRIPTION
    #    Set or query a SVG image viewer.
    #
    # RETURN VALUE
    #    * If a usable image-viewer is found: the name of the image-viewer executable
    #    * Otherwise: an empty string
    #
    # SOURCE
    variable svgViewer
    return [set docViewer [getViewer svg $viewer]]
}
#******


#****f* Viewers/::pwtk::display
# SYNOPSIS
proc ::pwtk::display {args} {
    # USAGE
    #   display  ?-type DOCUMENT_TYPE?  FILE1  ?FILE2? ... ?&?
    #
    # PURPOSE
    #   Display document(s) with a viewer. By default, the document
    #   type is obtained from the document file extension, unless the
    #   document type is explicitly given with the -type option.
    #
    #   If the last argument is "&", then the document viewer is
    #   executed in the background mode.
    #
    # OPTION
    # * -type DOCUMENT_TYPE ... type of the document (eps, pdf, png...);
    #                           if not specifed, the document type is
    #                           obtained from the file extension
    #
    # ARGUMENTS
    # * FILE1, FILE2, ... documents to display
    # * &             ... if the last argument is &, the viewer
    #                     is executed in the background mode
    #
    # SOURCE

    set lastarg [lindex $args end]
    set bg {}
    if { $lastarg eq "&" } {
        set bg &
        set args [lrange $args 0 end-1]
    }
    ifexist ::env(PWTK_PAUSE) {
        # check if PWTK_PAUSE is a positive number: in this case open the viewer for $PWTK_PAUSE seconds
        if { [::pwtk::type::number posreal -strict $::env(PWTK_PAUSE)] } {
            set bg &
            set pause [time2ms ${::env(PWTK_PAUSE)}sec]
        }
    }
    
    set nargmin 1
    set nargmax -1    
    set usage "-type DOCUMENT_TYPE  FILE1  ?FILE2? ..."
    set options {
        {type.arg {} "type of the document (eps, pdf, png...)"}
    }
    ::pwtk::parseOpt_
    
    foreach document $args {    
        if { $opt(type) eq {} } {
            # get the doc type from the file extension
            set ext [string trimleft [file extension $document] .]
        } else {
            set ext $opt(type)
        }

        switch -nocase -- $ext {
            ps - eps - pdf {
                set viewer [docViewer]
            }
            svg {
                set viewer [svgViewer]
            }
            default {
                set viewer [imgViewer]
            }
        }

        if { $viewer != {} } {
            try {
                set pid [exec -ignorestderr $viewer $document {*}$bg]
                ifexist pause {
                    # kill the viewer after $pause milliseconds
                    # (we use "catch" because a user may already closed the window)
                    delayed_eval $pause catch [list exec kill $pid]
                }
            } on error err {
                ::pwtk::error "an error occured while trying to display the document \"$document\"\n\n$err"
            }
        } else {
            ::pwtk::error "cannot display \"$document\"; no usable viewer found"
        }
    }
}
#******
