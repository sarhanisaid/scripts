#
# $RCSfile: xcd.tcl,v $ --
#
#      This file contains some xcrysden (http://www.xcrysden.org/)
#      scripting support.
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: xcd.tcl,v 1.4 2021/05/01 19:23:21 tone Exp $ 
#

#****n* XCrySDen/::pwtk::xcd
# DESCRIPTION
#   This namespace contains a few commands for running xcrysden (mainly used by ::pwtk::pwi::tabulateStructs &
#   ::pwtk::pwo::tabulateStructs utilities to create snapshots by xcrysden).
#
#   The main command used by tabulateStructs utilities is ::pwtk::xcd::makeFigs
#******

namespace eval ::pwtk::xcd {
    variable runScript 1
    variable scriptOption -s

    variable scriptHead {
	scripting::filter::pwscfOutput -lc $structureFile $reduce
        update
        update idletask
    }

    variable scriptTail {
	# --------------------------------------------------
	# print to file
	# --------------------------------------------------
	
	raise .
        update
        update idletask
        set xcMisc(titlefile) $printFile
        scripting::printToFile $printFile
        update
	exit 0
    }
}


#****f* ::pwtk::xcd/::pwtk::xcd::oldScriptFmt
# SYNOPSIS
proc ::pwtk::xcd::oldScriptFmt {} {
    # PURPOSE
    # This proc informs PWTK that supplied xcrysden script is in old
    # (prior to version 1.6) format
    #   
    # SOURCE
    variable scriptOption
    set scriptOption --os
}
#******


#****f* ::pwtk::xcd/::pwtk::xcd::newScriptFmt
# SYNOPSIS
proc ::pwtk::xcd::newScriptFmt {} {
    # PURPOSE
    # This proc informs PWTK that supplied xcrysden script is in
    # new (version >= 1.6) format (this is the default)
    #   
    # SOURCE
    variable scriptOption
    set scriptOption -s
}
#******


#****f* ::pwtk::xcd/::pwtk::xcd::runScript
# SYNOPSIS
proc ::pwtk::xcd::runScript {flag} {
    # PURPOSE
    #   Inform PWTK when to run xcrysden script.    
    # ARGUMENTS
    # * flag -- allowed values 0, 1, 2
    #
    # The meaning of the flag values:
    # * 0 -- do not run xcrysden script
    # * 1 -- run xcrysden script
    # * 2 -- run xcrysden only if a figure does not yet exist
    #
    # SOURCE
    variable runScript
    if { $flag != 0 && $flag != 1 && $flag != 2 } {
	::pwtk::error "wrong flag received in ::pwtk::xcd::runScript, must be:\n0 -- do not run xcrysden script\n1 -- run xcrysden script\n2 -- run only if picture does not exist yet" 
    }
    set runScript $flag
}
#******


#****f* ::pwtk::xcd/::pwtk::xcd::scriptHead
# SYNOPSIS
proc ::pwtk::xcd::scriptHead {text} {
    # PURPOSE
    #   Set the preamble (aka head) of the xcrysden script.
    # SOURCE
    variable scriptHead
    set scriptHead $text
}
#******


#****f* ::pwtk::xcd/::pwtk::xcd::scriptTail
# SYNOPSIS
proc ::pwtk::xcd::scriptTail {text} {
    # PURPOSE
    #   Set the tail of the xcrysden script.
    # SOURCE
    variable scriptTail
    set scriptTail $text
}
#******


#****f* ::pwtk::xcd/::pwtk::xcd::makeFigs
# SYNOPSIS
proc ::pwtk::xcd::makeFigs {fileList scriptList type {reduce 3}} {
    # PURPOSE
    #   Make figures with xcrysden.
    # ARGUMENTS
    # * fileList -- list of I/O files for which to create snapshot figures
    # * scriptList -- list of xcrysden state scripts; these scripts will be executed for each file in $fileList
    # * type -- type of the structure (initial | latest | optimized)
    # * reduce -- whether to reduce the dimension of the structure (3 = bulk, 2 = slab, 1 = polymer, 0 = molecule)
    # SOURCE
    variable scriptFID
    variable runScript
    variable scriptOption
    
    set emptyScript 0

    if { $scriptList == {} } {
	# user didn't supply a script, make an empty script
	set emptyScript 1
	set scriptList [file join [::fileutil::tempdir] dummy.xcrysden]
	::pwtk::writeFile $scriptList ""
    }

    # write and run xcrysden scripts and make figures ...
    
    foreach file $fileList {
	set head [file rootname [file tail $file]]

	set figGroup {}

	foreach script $scriptList {
	    
	    set scriptHead [file rootname [file tail $script]]
	    if { $emptyScript } {
		set prefix ${head}_${type}
	    } else {
		set prefix ${head}_${type}_$scriptHead
	    }
	    set scriptName $prefix.xcrysden
	    set printFile  $prefix.png
	    
	    lappend figGroup $printFile

	    set scriptFID  [open $scriptName "w"]	    	    
	    make_script_ $script $file $printFile $reduce
	    close $scriptFID	    

	    if { $runScript == 1 } {
		catch {exec xcrysden $scriptOption $scriptName}
	    } elseif { $runScript == 2 } {
		if { ! [file exists $printFile] } {
		    catch {exec xcrysden $scriptOption $scriptName}
		}
	    }
	}
	lappend figList $figGroup
    }

    return $figList
}
#******

# internal ...

proc ::pwtk::xcd::make_script_ {script structureFile printFile {reduce 3}} {
    variable scriptHead
    variable scriptTail
    write_ [subst -nocommands -nobackslashes $scriptHead]
    write_ [::pwtk::readFile $script]     
    write_ [subst -nocommands -nobackslashes $scriptTail]
}

proc ::pwtk::xcd::write_ {text} {
    variable scriptFID
    puts $scriptFID $text
}

