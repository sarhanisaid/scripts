#
# $RCSfile: slurm.tcl,v $ --
#
#      This file contains the implementation for supporting the SLURM
#      queueing system.
#
# Copyright (c) 2019-2024  Anton Kokalj     (tone.kokalj@ijs.si)
#
# THANKS: Matic Poberznik (matic.poberznik@ijs.si) contributed to the
#         initial version of slurm.tcl
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: slurm.tcl,v 1.2 2021/05/07 13:25:18 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# PUBLIC procs
#
# ------------------------------------------------------------------------


# N.B. the ::pwtk::SLURM and slurm_* commands are created dynamically
# by calling the ::pwtk::slurm::init command but they are documented here.


#****f* ::pwtk::slurm/::pwtk::SLURM
#
# PURPOSE
# The master command for the SLURM batch queuing. It manages the
# submission to SLURM.
#
# USAGE
#     SLURM { ...script code... }
#     SLURM file.pwtk
# or
#     SLURM options { ...script code... }
#     SLURM options file.pwtk
# or
#     SLURM profile ?options? { ...script code... }
#     SLURM profile ?options? file.pwtk
#
# DESCRIPTION
# The above "profile" is a user defined profile for SLURM, i.e., a set
# of #SBATCH directives, whereas the above "options" are the Slurm
# options, specified with the Slurm syntax, supporting short and long
# options, i.e.:
#
#     -N2 --tasks=32 -t 06:00:00 ...
#
# Note that short options can be specified as, e.g., -N2 or -N 2,
# whereas long options are specified as, e.g., --nodes=2
#
# BEWARE

# Note that Tcl uses different quoting than shell. Therefore, option
# values which contain whitespaces and square bractets are specified
# differently. For example, the equivalence for the shell command:
#
#      sbatch -n2 --nodelist="node1, node2, node3" ...
#      sbatch -n2 --nodelist="node[1-3]" ...
#
# in PWTK is: 
# 
#      SLURM -n2 {--nodelist=node1, node2, node3} ...
#      SLURM -n2 {--nodelist=node[1-3]} ...
# or
#      SLURM -n2 "--nodelist=node1, node2, node3" ...
#      SLURM -n2 "--nodelist=node\[1-3\]" ...
# 
#
# FURTHER DESCRIPTION
# Here is an example of the usage of the SLURM command:
#   SLURM --nodes=1 --ntasks=4  { import job.pwtk }      (N.B. ...script code... version)
# or
#   SLURM --nodes=1 --ntasks=4  job.pwtk                 (N.B. file.pwtk version)
#
# If "profile" is omitted, the "default" profile is used, which is
# guaranteed to exist because it is defined in the
# |html <a href="../config/slurm.tcl">$PWTK/config/slurm.tcl</a> file.
#
# Here is an example of two user defined profiles, named "parallel" and "long":
#
#    slurm_profile parallel {
#        #!/bin/sh
#        #SBATCH --nodes=1
#        #SBATCH --ntasks=16
#        #SBATCH --time=6:00:00
#        #SBATCH --partition=parallel
#    }
#    
#    slurm_profile long {
#        #!/bin/sh
#        #SBATCH --nodes=1
#        #SBATCH --ntasks=64
#        #SBATCH --time=2-00:00:00
#        #SBATCH --partition=long
#    }
#
# It is a good practice to also define the PWTK specifics (aka
# pwtk_profile) associated with the SLURM profiles. For example, for
# the above "long" profile with --ntasks=64, it would be reasonable to
# use "mpirun -n 64" as a default. This can be achieved with:
#
#    slurm_pwtk_profile longpar { prefix mpirun -n 64 }
#
# There is also a compact version which defines the SLURM profile and
# the associated PWTK profile simultaneously, i.e.:
#
#    slurm_profile long {
#        #!/bin/sh
#        #SBATCH --nodes=1
#        #SBATCH --ntasks=64
#        #SBATCH --time=2-00:00:00
#        #SBATCH --partition=longpar
#    } {
#        prefix mpirun -n 64
#    }
#
# Here, the 2nd argument to the 'slurm_profile' command is the SLURM
# profile and the last argument is the associated PWTK profile. This
# form is recommended because it avoid typos/mismatches between
# profile and pwtk_profile names.
#
# IMPORTANT
# A typical place where to store SLURM profiles for frequent use is in
# the ~/.pwtk/slurm.tcl configuration file (N.B. in the ~/.pwtk/slurm.tcl
# configuration file, the prefix 'slurm_' can be omitted).
#
# FURTHER DESCRIPTION
# The 'slurm_profile' command can be used to define profiles on the
# fly within the PWTK script, e.g.:
#
#   slurm_profile n24 {
#        #!/bin/sh
#        #SBATCH --nodes=2
#        #SBATCH --ntasks-per-node=12
#        #SBATCH --ntasks=24
#        #SBATCH --time=12:00:00
#   } {
#        prefix mpirun -np 24
#   }
#
#   SLURM n24 job.pwtk
#
# The final effect of the SLURM command is to submit either the script
# code encapsulated inside the SLURM { ... } command or the script
# file specified with the SLURM command (e.g. SLURM file.pwtk) to the
# Slurm job scheduling system via the sbatch command.
# 
#******


#****f* ::pwtk::slurm/::pwtk::slurm_profile
# USAGE
#   slurm_profile profileName profileSpecs ?pwtkSpecs?
#
# DESCRIPTION
#   Define a SLURM "profile" within the PWTK script. See also ::pwtk::SLURM.
#
#   Here is an example of how a new slurm profile can be defined and used:
#
#      slurm_profile n24 {
#         #!/bin/sh
#         #SBATCH --nodes=2
#         #SBATCH --ntasks-per-node=12
#         #SBATCH --ntasks=24
#         #SBATCH --time=12:00:00
#      }
#
#      SLURM n24 {
#         load_fromPWI scf.in
#         CONTROL { calculation = 'relax' }
#         IONS {}
#         runPW relax.in
#      }
#
# ARGUMENTS
# * profileName -- name of the profile
# * profileSpecs -- definition of the 'profileName' profile
# * pwtkSpecs -- definition of the PWTK profile to be used when
#                the 'profileName' SLURM profile is used
#
# IMPORTANT
# A typical place where to store SLURM profiles for frequent use is in
# the ~/.pwtk/slurm.tcl configuration file. Note that in the ~/.pwtk/slurm.tcl
# configuration file, the prefix 'slurm_' can be omitted.
#
# EXAMPLE
#    slurm_profile n24 {
#       #!/bin/sh
#       #SBATCH --nodes=2
#       #SBATCH --ntasks-per-node=12
#       #SBATCH --ntasks=24
#       #SBATCH --time=12:00:00
#    } {
#       prefix mpirun -np 24
#    }
#******

#****f* ::pwtk::slurm/::pwtk::slurm_profileDefault
# USAGE
#   slurm_profileDefault profileName
# DESCRIPTION
#   Make the 'profileName' profile the default SLURM profile.
#******

#****f* ::pwtk::slurm/::pwtk::slurm_pwtk_profile
# USAGE
#   slurm_pwtk_profile profileName pwtkSpecs
# DESCRIPTION
#   Define the PWTK profile named 'profileName' and associate it with
#   the SLURM profile of the same name.
#
# EXAMPLE
#   slurm_pwtk_profile n24 {
#      prefix mpirun -n 24
#   }
#******

#****f* ::pwtk::slurm/::pwtk::slurm_pwtk_profileDefault
# USAGE
#   slurm_pwtk_profileDefault profileName
# DESCRIPTION
#   Make the pwtk 'profileName' profile the default PWTK profile for
#   SLURM.
#******

#****f* ::pwtk::slurm/::pwtk::slurm_head
# USAGE
#   slurm_head { ...batch sh-script snippet here... }
#
# EXAMPLE
#   slurm_head {
#      echo "Today is `date`"
#      module load QuantumESPRESSO/7.3.1
#   }
#
# DESCRIPTION
#   This command sets the "head" part of the SLURM batch shell
#   script. In PWTK, the batch shell script is composed of four
#   parts:
#
#        profile   (always exists)
#         |
#        head      (optional)
#         |
#        pwtk      (always exists)
#         |
#        tail      (optional)
#
#   where:
#   * profile -- contains the batch-queue directives (e.g. #SBATCH);
#                it is set with slurm_profile command
#   * head -- contains optional shell commands that are executed
#             prior to executing PWTK, such as "module load ...";
#             it is set with slurm_head command
#   * pwtk -- in this part, the PWTK script is executed;
#             it is set internally by PWTK
#   * tail -- contains optional shell commands that are executed
#             after the PWTK script finishes;
#             it is set with slurm_tail command
#******

#****f* ::pwtk::slurm/::pwtk::slurm_tail
# USAGE
#   slurm_tail { batch sh-script excerpt }
#
# EXAMPLE
#   slurm_tail {
#      # copy the scratch files in WORKDIR to $PWD
#      cp -a $WORKDIR .
#   }
#
# DESCRIPTION
#   This command sets the "tail" part of the SLURM batch shell
#   script. In PWTK, the batch shell script is composed of four parts
#   (for description, see ::pwtk::slurm_head).
#******

#****f* ::pwtk::slurm/::pwtk::slurm_clear
# USAGE
#   slurm_clear
# DESCRIPTION
#   Clear the current content of the SLURM batch shell script as stored in PWTK.
#******

#****f* ::pwtk::slurm/::pwtk::slurm_fprint
# USAGE
#   slurm_fprint ?FILE?
# PURPOSE
#   Typically used intenally by PWTK.
# DESCRIPTION
#   Print the current content of the SLURM batch shell script to FILE
#   or to stdout if FILE was not specified.
#******

#****f* ::pwtk::slurm/::pwtk::slurm_get
# USAGE
#   slurm_get ?profileName?
# PURPOSE
#   Typically used intenally by PWTK.
# DESCRIPTION
#   Return the current content of the SLURM batch shell script.
#******


# ------------------------------------------------------------------------    
#
# INTERNAL procs
#
# ------------------------------------------------------------------------


#****if* Internals/::pwtk::slurm::init
# SYNOPSIS
proc ::pwtk::slurm::init {} {
    # PURPOSE
    #    Used intenally by PWTK.
    # DESCRIPTION
    #    Initialization of the SLURM batch queuing system.
    # SOURCE

    ::pwtk::queue::init slurm sbatch "#SBATCH"
    optionParser none
}
#******


#****f* ::pwtk::slurm/::pwtk::slurm::optionParser
proc ::pwtk::slurm::optionParser {parser} {
    # USAGE
    #   ::pwtk::slurm::optionParser none
    # or
    #   ::pwtk::slurm::optionParser parse
    #
    # DESCRIPTION
    #   How to parse options specified on the SLURM command-line. Possibilities are:
    #   * none -- do not parse options, but add them verbatim as the command-line options of the 'sbatch' command
    #   * parse -- parse options and incorporate them into the Slurm batch script file
    #
    # SOURCE

    ::pwtk::queue::optionParser slurm $parser
}
#******


#****if Internals/::pwtk::slurm::addOptionsToCmdLine_
proc ::pwtk::slurm::addOptionsToCmdLine_ {profileName args} {
    # PURPOSE
    #   This routine has the same purpose as
    #   ::pwtk::slurm::addOptionsToBatchScript_ but instead of
    #   incorporating Slurm options specified on the SLURM command
    #   line, contained in $args, into a batch script, it delegates
    #   them to the 'sbatch' command as the command-line
    #   options. Hence, this routine performs the following two tasks:   
    #   1. create the profile part of the batch script from the 'profileName' profile
    #   2. arranges for sbatch command to be called as: sbtach {*}$args FILE
    #
    # ARGUMENTS
    # * profileName -- name of the slurm profile
    # * args -- command-line options specified on the SLURM command line.
    #
    # SOURCE

    set ::pwtk::queue::queue(slurm,profile) [::pwtk::trimIndent [::pwtk::varvalue ::pwtk::queue::profile(slurm,$profileName)]]\n
    set ::pwtk::queue::queue(slurm,submitOpts) $args    
}
#******


#****if Internals/::pwtk::slurm::addOptionsToBatchScript_
proc ::pwtk::slurm::addOptionsToBatchScript_ {profileName args} {
    # PURPOSE
    #   Parse the slurm options stored in $args, and produce a slurm
    #   profile by merging them with the corresponding $profileName slurm
    #   profile. The result is stored in the
    #   ::pwtk::queue::queue(slurm,profile) variable.
    # ARGUMENTS
    # * profileName -- name of the slurm profile
    # * args -- command-line options of the SLURM command.
    # SOURCE

    set ::pwtk::queue::queue(slurm,submitOpts) {}
    
    if { $args eq {} } {
        # use the profile verbatim
        set ::pwtk::queue::queue(slurm,profile) [::pwtk::trimIndent [::pwtk::varvalue ::pwtk::queue::profile(slurm,$profileName)]]\n
    } else {
        # add the command-line options to the slurm $profileName profile
        
        # the SLURM profile looks like:
        
        #!/bin/sh
        #SBATCH --nodes=2 --ntasks-per-node=16
        #SBATCH --ntasks=32 --mem-per-cpu=16g        
        #SBATCH --exclusive --wrap="sh5util -j $SLURM_JOB_ID"

        set content [::pwtk::expandSOpts [::pwtk::varvalue ::pwtk::queue::profile(slurm,$profileName)]]
        set args    [::pwtk::expandSOpts $args]
        
        # first parse the profile, then the $args options
        parseScript__ $content opt_list SBATCH
        parseOpts__ $args    opt_list
        
        # 'opt_list' now contains the update list of options, build an
        # updated SLURM profile by preserving the line-order of options

        proc addOpts__ {optVar} {
            upvar $optVar opt_l
            foreach {opt val} [array get opt_l] {
                set sep [expr {[regexp -- ^-- $opt] && $val ne {} ? "=" : " "}]
                if { [llength $val] > 1 } {
                    append ::pwtk::queue::queue(slurm,profile) [format "#SBATCH %s${sep}\"%s\"\n" $opt $val]
                } else {
                    append ::pwtk::queue::queue(slurm,profile) [format "#SBATCH %s${sep}%s\n" $opt $val]
                }
            }
        }

        set ::pwtk::queue::queue(slurm,profile) {}        
        set first_non_comment 0
        
        foreach line [split $content \n] {
            set ff [lindex $line 0]
            
            if { [regexp "^#SBATCH" $ff] } {                
                parseScript__ $line opt_line
                foreach {opt val} [array get opt_line] {
                    ::pwtk::ifexist opt_list($opt) {
                        set val $opt_list($opt)
                        unset opt_list($opt); # N.B. this is important for processing the extra-command line options below
                    }
                    set sep [expr {[regexp -- ^-- $opt] && $val ne {} ? "=" : " "}]
                    if { [llength $val] > 1 } {
                        append new_line [format "%s${sep}\"%s\" " $opt $val]
                    } else {
                        append new_line [format "%s${sep}%s " $opt $val]
                    }
                }
                ::pwtk::ifexist new_line {
                    append ::pwtk::queue::queue(slurm,profile) "#SBATCH $new_line\n"
                    unset new_line
                }
                unset opt_line
            } elseif { [regexp "^#" $ff] && ! $first_non_comment } {
                # a comment but not #SBATCH, add it verbatim
                append ::pwtk::queue::queue(slurm,profile) [string trimleft $line]\n
                
            } else {
                if { [llength $line] > 0 } {
                    if { ! $first_non_comment } {
                        # the first non-comment non-whitespace line
                        set first_non_comment 1
                        
                        # From the slurm documentation: sbatch stops processing
                        # further #SBATCH directives once the first non-comment
                        # non-whitespace line has been reached in the script.
                        
                        # Hence, we add now the command-line options not
                        # present in the profile (they were not yet added)
                        
                        addOpts__ opt_list
                    }                            
                    append ::pwtk::queue::queue(slurm,profile) [string trimleft $line]\n
                }
            }
        }
        if { ! $first_non_comment } {
            addOpts__ opt_list
        }
    }
}


# Internal...
proc ::pwtk::slurm::parseOpts__ {content optVar {sbatch_only {}}} {
    # PURPOSE
    #   Parse the content of the slurm profile or the command-line
    #   options and store options and their values in the $optVar
    #   array. For valueless options, an empty value is assigned.    
    # ARGUMENTS
    # * content -- content to parse (N.B. short options were already expanded)
    # * optVar -- name of the array to store the parsed options
    # * sbatch_only -- (optional) if not empty, parse only the #SBATCH lines
    
    upvar $optVar opt

    # AFAIK short and long options are specified as: -o value --option=value

    foreach line [split $content \n] {
        set line [string trim $line]
        if { $sbatch_only ne {} && ! [regexp ^#SBATCH $line] } {
            # not the #SBATCH, ignore
            continue
        }
        if { [regexp ^# $line] } {
            # the first field is # or #word, skip it
            set line [string range $line [string length [lindex $line 0]] end]
        }

        while {[llength $line] > 0} {
            set line [string trim $line]
            set o   [lindex $line 0]
            set v   {}
    
            if { [regexp -- ^-- $o] } {
                if { [regexp = $o] } {
                    # --option=VALUE
                    set ind [string first = $o]
                    set v [string range $o $ind+1 end]
                    set o [string range $o 0 $ind-1]
                    set opt($o) $v
                } else {
                    # --option
                    set opt($o) {}
                }
            } elseif { [regexp -- ^- $o] } {
                set v [lindex $line 1]
                if { ! [regexp -- ^- $v] } {
                    # -o VALUE
                    set opt($o) $v
                    set line [lrange $line 1 end]; # need to chop and extra element from $line
                } else {
                    # -o
                    set opt($o) {}
                }
            } else {
                # not an option, nevertheless store it as valueless option without the "-" prefix
                set opt($o) {}
            }
            set line [lrange $line 1 end]
        }
    }
}


# Internal...
proc ::pwtk::slurm::parseScript__ {content optVar {sbatch_only {}}} {
    # PURPOSE
    #   Parse the content of the slurm profile or the command-line
    #   options and store options and their values in the $optVar
    #   array. For valueless options, an empty value is assigned.    
    # ARGUMENTS
    # * content -- content to parse
    # * optVar -- name of the array to store the parsed options
    # * sbatch_only -- (optional) if not empty, parse only the #SBATCH lines
    
    upvar $optVar opt

    # AFAIK short and long options are specified as: -o value --option=value

    foreach line [split $content \n] {
        set line [string trim $line]
        if { $sbatch_only ne {} && ! [regexp ^#SBATCH $line] } {
            # not the #SBATCH, ignore
            continue
        }
        if { [regexp ^# $line] } {
            # the first field is # or #word, skip it
            set line [string range $line [string length [lindex $line 0]] end]
        }

        while {[llength $line] > 0} {
            set line [string trim $line]
            set o   [lindex $line 0]
            set v   {}
            set aux [regsub = $line { }]
    
            if { [regexp -- ^-- $o] } {
                if { [regexp = $o] } {
                    # --option=VALUE
                    lassign $aux o v
                    set opt($o) $v
                    set line [string range $line [string length [lrange $aux 0 1]]+1 end]
                } else {
                    # --option
                    set opt($o) {}
                    set line [string range $line [string length $o]+1 end]
                }
            } elseif { [regexp -- ^- $o] } {
                set v [lindex $line 1]
                if { ! [regexp -- ^- $v] } {
                    # -o VALUE
                    set opt($o) $v
                    set line [string range $line [string length "$o $v"]+1 end]
                } else {
                    # -o
                    set opt($o) {}
                    set line [string range $line [string length $o]+1 end]
                }
            } else {
                # not an option, nevertheless store it as valueless option without the "-" prefix
                set opt($o) {}
                set line [string range $line [string length $o]+1 end]                
            }
        }
    }
}
