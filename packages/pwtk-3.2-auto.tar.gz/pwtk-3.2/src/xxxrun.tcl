#
# $RCSfile: xxxrun.tcl,v $ --
#
#      This file contains remedy, prerun, postrun, treatrun... routines.
#
# Copyright (c) 2023-2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: xxxrun.tcl,v 1.3 2023/01/27 17:00:01 kokalj Exp $ 
#

#****a* 5.3. Run Calculations/5.3.3. Run Modifiers
#
# DESCRIPTION
#
#   A collection of routines that change the default execution pipeline
#   for running programs.
#
#******

#****f* 5.3.3. Run Modifiers/::pwtk::remedy
# SYNOPSIS
proc ::pwtk::remedy {prog {mode {}} {script {}}} {
    # USAGE
    #   The allowed forms are:
    #      remedy PROG                 
    #      remedy PROG { SCRIPT }      \___ these two are synonymous
    #      remedy PROG set { SCRIPT }  /
    #      remedy PROG append { SCRIPT }    
    #      remedy PROG get
    #      remedy PROG exec
    #      remedy PROG clear
    #
    #   Where:
    #   * remedy PROG -- query if the remedy mode is active for the PROG executable
    #   * remedy PROG get -- get the remedy script
    #   * remedy PROG { SCRIPT } -- set the remedy script 
    #   * remedy PROG set { SCRIPT } -- set the remedy script
    #   * remedy PROG append { SCRIPT } -- append to remedy script
    #   * remedy PROG exec -- execute a remedy script
    #   * remedy PROG clear -- clear the remedy script (i.e. turn remedy off)
    #    
    # DESCRIPTION
    #
    #   A simple one-attempt remedy mode (for a more elaborate
    #   remedy-mode for pw.x, see: ::pwtk::runPW_remedy). If a given
    #   PROG QE calculation fails, it will be retried by first executing a
    #   "remedy" script and then repeating the calculation. The
    #   "remedy" script is executed in the pushpop mode. Hence, after
    #   the remedy completion, the PWTK state is the same as before
    #   the remedy invocation. The remedy logic is as follows:
    #
    #       if calculation failed {
    #          input_pushpop {
    #             eval remedyScript
    #             repeat the failed calculation
    #          }
    #       }
    #
    # ARGUMENTS
    # * PROG -- the canonical name of the QE executable (e.g. pw.x, ph.x)
    # * MODE -- one of: get, set, append, clear
    # * SCRIPT -- remedy script
    #
    # RETURN VALUE
    # * remedy get ... returns the remedy script (or empty string if remedy is inactive)
    # * otherwise: 0 or 1 (1 = remedy is active; 0 = remedy is inactive)
    #
    # SOURCE
    variable state

    if { $mode eq "" } {
        # query mode
        ifempty state(remedy,$prog) {
            return 0
        } else {
            return 1
        }
    }

    switch -exact -- $mode {
        get {
            ifexist state(remedy,$prog) {
                return $state(remedy,$prog)
            } else {
                return {}
            }
        }
        set {
            set state(remedy,$prog) $script\n
            return 1
        }
        append {
            append state(remedy,$prog) $script\n
            return 1
        }
        exec {
            ifnotempty state(remedy,$prog) {
                eval $state(remedy,$prog)
                return 1
            } else {
                return 0
            }
        }
        clear {
            unset state(remedy,$prog)
            return 0
        }
        default {
            if { $script eq {} } {
                # it is: remedy PROG { SCRIPT }
                # hence the "MODE" argument is the "SCRIPT"
                set state(remedy,$prog) $mode\n
                return 1
            } else {
                # wrong usage
                ::pwtk::error "wrong mode \"$mode\", must be one of set, append, clear" 1
            }
        }
    }
    # should not come here
    return 0
}
#******


#****f* 5.3.3. Run Modifiers/::pwtk::prerun
# SYNOPSIS
proc ::pwtk::prerun {prog args} {
    # USAGE 
    #   prerun PROG                ... get the prerun script for the PROG program
    #   prerun PROG { SCRIPT }     ... set the prerun script for the PROG program
    #   prerun PROG {}       --+   
    #   prerun PROG clear    --+-- ... clear the prerun script for the PROG program
    #   prerun PROG append { SCRIPT } ... append SCRIPT to the prerun script for the PROG program
    #
    # PURPOSE
    #   Get, set, append, or clear a script that is executed just before running the PROG program.
    #
    #   Example:
    #      prerun pw.x {
    #         puts "Time before the pw.x execution:  [clock format [clock seconds]]"
    #      }
    #
    # ARGUMENTS
    # * PROG -- canonical name of the QE program, i.e., pw.x, pp.x...
    # * SCRIPT -- script code to execute before running the PROG program.
    #
    # RETURN VALUE
    #   The prerun script for the PROG program or empty string if the
    #   script does not exist.
    #
    # SOURCE
    return [::pwtk::xxxrun_ prerun $prog {*}$args]
}
#******

#****f* 5.3.3. Run Modifiers/::pwtk::postrun
# SYNOPSIS
proc ::pwtk::postrun {prog args} {
    # USAGE 
    #   postrun PROG                ... get the postrun script for the PROG program
    #   postrun PROG { SCRIPT }     ... set the postrun script for the PROG program
    #   postrun PROG {}       --+   
    #   postrun PROG clear    --+-- ... clear the postrun script for the PROG program
    #   postrun PROG append { SCRIPT } ... append SCRIPT to the postrun script for the PROG program
    #
    # PURPOSE
    #   Get, set, append, or clear a script that is executed immediately after running the PROG program.
    #
    #   Example:
    #      postrun pw.x {
    #         puts "Time after the pw.x execution:  [clock format [clock seconds]]"
    #      }
    #
    # ARGUMENTS
    # * PROG -- canonical name of the QE program, i.e., pw.x, pp.x...
    # * SCRIPT -- script code to execute immediately after running the PROG program.
    #
    # RETURN VALUE
    #   The postrun script for the PROG program or empty string if the
    #   script does not exist.
    #
    # SOURCE
    return [::pwtk::xxxrun_ postrun $prog {*}$args]
}
#******



#****if* Internals/::pwtk::test
# SYNOPSIS
proc ::pwtk::xxxrun_ {xxx prog args} {
    # PURPOSE
    #   Used internally by PWTK's ::pwtk::prerun or ::pwtk::postrun.    
    # ARGUMENTS
    # * xxx ... prerun or postrun
    # * prog ... canonical name of QE executable
    # * args ... arguments of ::pwtk::prerun & ::pwtk::postrun
    # SOURCE
    variable state
    
    lassign $args arg1 arg2
    set prog [file tail $prog]
    
    if { [llength $args] == 0 } {
        # query mode
        return [varvalue state($xxx,$prog)]
        
    } elseif { [llength $args] == 1 } {
        # set or clear mode
        if { $arg1 eq "clear" || $arg1 eq {} } {
            set state($xxx,$prog) {}
        } else {        
            set state($xxx,$prog) $arg1
        }
    } elseif { [llength $args] == 2 && $arg1 eq "append" } {
        # append mode
        append state($xxx,$prog) \n$arg2
    } else {
        ::pwtk::error "wrong # of arguments, must be one of:\n
$xxx $prog           
$xxx $prog { SCRIPT }
$xxx $prog {}        
$xxx $prog clear     
$xxx $prog append { SCRIPT }\n
but got:
$xxx $prog $args" 1
    }
    return [varvalue state($xxx,$prog)]
}
#******


# internal...
proc ::pwtk::prerun_plugin_ {plugin prog args} {
    # PURPOSE
    #   Similar to ::pwtk::prerun but used internally by PWTK for plugins.
    return [::pwtk::xxxrun_ prerun $prog,$plugin {*}$args]
}

# internal...
proc ::pwtk::postrun_plugin_ {plugin prog args} {
    # PURPOSE
    #   Similar to ::pwtk::postrun but used internally by PWTK for plugins.
    return [::pwtk::xxxrun_ postrun $prog,$plugin {*}$args]
}

# internal ...
proc ::pwtk::preruns_ {prog} {
    # PURPOSE
    #   Return a list of active preruns (i.e. "active" names of state(prerun,$prog*) array).
    return [::pwtk::xxxruns_active_ prerun $prog]
}

# internal ...
proc ::pwtk::postruns_ {prog} {
    # PURPOSE
    #   Return a list of active postruns (i.e. "active" names of state(postrun,$prog*) array).
    return [::pwtk::xxxruns_active_ postrun $prog]
}

# internal ...
proc ::pwtk::xxxruns_active_ {xxx prog} {
    # PURPOSE
    #   Return a list of active $xxx-es (xxx == prerun or postrun).
    variable state
    set activated {}
    foreach name [lsort -decreasing [array names state $xxx,${prog}*]] {
        if { [info exists state($name)] && $state($name) ne "" } {
            lappend activated $name
        }
    }
    return $activated
}


#****f* 5.3.3. Run Modifiers/::pwtk::treatrun
# SYNOPSIS
proc ::pwtk::treatrun {runCmd newCmd} {
    # EXAMPLE
    #   treatrun runPW rerunPW
    #
    # DESCRIPTION
    #
    #   This command allows to replace a default implementation of the
    #   runCmd command. This is distinct from the Tcl "rename"
    #   command. With the above example, runPW will behave as rerunPW
    #   (but both commands still exist as such, it is just that the
    #   behaviour of runCmd is temporarily modified to behave as
    #   newCmd).
    #
    #   A given treatrun can be cleared by assigning it to an empty
    #   string, i.e., treatrun runCmd {}
    #
    # ARGUMENTS
    # * runCmd -- one of the runXX or rerunXX commands, defined in runXX.tcl source file
    # * newCmd -- command for the new behavior; must be of the following form: "proc newCmd args script"
    #
    # EXAMPLE
    #    # Let's say that for each runPW execution, we would like to print
    #    # a time. This can be achieved with treatrun as follows:
    #
    #     proc my_runPW {args} {
    #        puts "Time is:  [clock format [clock seconds]]"
    #        eval runPW $args
    #     }
    #     treatrun runPW my_runPW
    #
    # SOURCE
    variable state
    variable runXX_exportList
    
    if { $runCmd ni $runXX_exportList } {
        ::pwtk::error "unsupported runCmd \"$runCmd\", must be one of: [join $supported {, }]" 1    
    }
    
    ifnotempty newCmd {
        set state(treatrun,$runCmd) $newCmd
    } else {
        unset state(treatrun,$runCmd)
    }
}
#******



#*** internal...
# BEWARE:
#
#   As a default, treat_run_ is executed in makeInputAndRun_, unless
#   some special preprocessing is needed, such as in runPW, runCP,
#   runNEB, and rerunXXX cmds. In such procs, treat_run_ is the first
#   cmd and then treat_run_ in makeInputAndRun_ have no effect,
#   because due to its-own mechanism, treat_run_ is only called once.
#
proc ::pwtk::treat_run_ {args} {
    variable state
    
    set runXX [namespace tail [procName -2]]

    if { [info exists state(treatrun,$runXX)] && $state(treatrun,$runXX) ne {} } {
        ::pwtk::input::pushpop {
            set cmd $state(treatrun,$runXX)
            unset state(treatrun,$runXX)
            ::pwtk::infoMsg "treating $runXX as $cmd"
            eval $cmd $args
        }
        return -code return
    }
}
