#
# $RCSfile: struct_utils.tcl,v $ --
#
#      This file contains some structural utilities.
#
# Copyright (c) 2009-2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: struct_utils.tcl,v 1.19 2021/05/01 19:23:21 tone Exp $ 
#
# -------------------------------------------------------------------------------

#****a* 5.6. Structural Utilities/pwi_struct_utils
# DESCRIPTION
# A collection of routines that returns some structure data from the
# pw.x input data.
# 
#******


#****f* ::pwtk::pwi/::pwtk::pwi::getXSF
# SYNOPSIS
proc ::pwtk::pwi::getXSF {} {
    # DESCRIPTION
    #   Return the XSF-formatted structural data from the current pw.x
    #   input data.  
    # SOURCE

    set input  [::fileutil::tempfile pw.]
    set output [::fileutil::tempfile xsf.]

    ::pwtk::pwi_fprint $input
    
    set pwi2xsf [::pwtk::getExecutable [::pwtk::getVar_ PWI2XSF]]
    if { $pwi2xsf eq {} } {
	::pwtk::error "cannot find the PWI-to-XSF (aka pwi2xsf.sh) converter" 1
    }

    ::pwtk::try_exec -- $pwi2xsf $input > $output
    return [::pwtk::readFile $output]
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::getXSFPrimVec
# SYNOPSIS
proc ::pwtk::pwi::getXSFPrimVec {} {
    #  DESCRIPTION
    #   Return the XSF's PRIMVEC data from the current pw.x input data, e.g.:
    #      PRIMVEC
    #        ax ay az
    #        bx by bz
    #        cx cy cz
    # SOURCE

    set xsf [split [::pwtk::pwi::getXSF] \n]
    set ind [lsearch $xsf *PRIMVEC*]
    
    return [join [lrange $xsf $ind [expr {$ind + 3}]] \n]
}
#******



#****f* ::pwtk::pwi/::pwtk::pwi::getXSFPrimCoor
# SYNOPSIS
proc ::pwtk::pwi::getXSFPrimCoor {} {
    #  DESCRIPTION
    #    Return the XSF's PRIMCOORD data from the current pw.x input data, e.g.
    #      PRIMCOORD
    #        nat 1
    #        AtmSymb1 x1 y1 z1
    #        AtmSymb2 x2 y2 z2
    #        ...
    #   BEWARE: works correctly for non-path calculations only
    # SOURCE

    set xsf [split [::pwtk::pwi::getXSF] \n]
    set ind [lsearch $xsf *PRIMCOOR*]
    
    return [join [lrange $xsf $ind end] \n]
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::getPrimVec
# SYNOPSIS
proc ::pwtk::pwi::getPrimVec {lenUnit} {
    # PURPOSE
    #   Get the primitive lattice vectors (aka CELL_PARAMETERS) in the
    #   'lenUnit' units from the pw.x input data in the form:
    #
    #        ax  ay  az
    #        bx  by  bz
    #        cx  cy  cz
    #
    #   If ibrav == 0, the lattice vectors from the CELL_PARAMETERS
    #   card, converted to 'lenUnit' are returned.  Otherwise, the lattice vectors are
    #   generated from the celldm(i) or A,B,C... parameters.
    #
    #   If lattice vectors cannot be generated from the input data
    #   (i.e. in case of insufficient data), the empty string is returned.
    #
    # ARGUMENTS
    # * lenUnit -- unit in which to return the lattice vectors (angstrom, bohr, or alat).
    #
    # RETURN VALUE
    #   Primitive lattice vectors in requested unit or an empty string.
    #
    # SOURCE

    set ibrav [ibrav]
    set alat  [alat]
    set unit [::pwtk::input::cardGetFlags CELL_PARAMETERS trim]
    set cell [::pwtk::input::cardGetContent CELL_PARAMETERS]

    # alat may not exist: in this case [alat] returns 0.0
    set notDefined 1e-8
    if { $alat < $notDefined } {
        set alat [expr 0.5*$notDefined]
    }
    
    # scaling factor to convert from bohr to $lenUnit
    switch -glob -- $lenUnit {
        angs* { set scale $::pwtk::bohr2angs }
        bohr  { set scale 1.0 }
        alat  {
            if { $alat < $notDefined } {
                # alat not defined: use bohr (see below)
                set scale 1.0
            } else {
                set scale [expr 1.0/$alat]
            }
        }
        default {
            ::pwtk::error "wrong unit $lenUnit, must be one of angstrom, bohr, or alat" 1
        }
    }

    # Rules:
    #   1. if (ibrav == 0 || ibrav eq {}) && cell ne {}, use cell
    #   2. else get lattice-vectors from one_atom_dryrunPW
    #

    if { $ibrav == 0 || $ibrav eq "" } {
        if { $cell eq "" } {
            return {}
        } else {
            if { $unit == "" } {
                # from input_pw.html:
                #   for CELL_PERAMETERS without unit: if alat is
                #   defined, it implies "CELL_PERAMETERS (alat)"
                #
                #   if neither unit nor lattice parameter are specified, 'bohr'
                #   is assumed - DEPRECATED, will no longer be allowed
                
                if { $alat < $notDefined } {
                    set unit bohr
                } else {
                    set unit alat
                }
            }
        }
        
        # convert $cell to bohr
        switch -glob -- $unit {
            angs* { set scale2 $::pwtk::angs2bohr }
            bohr  { set scale2 1.0 }
            alat  { set scale2 $alat }
            default {
                ::pwtk::error "wrong unit $unit, must be one of angstrom, bohr, or alat" 1
            }
        }
    } elseif { $cell ne {} } {
        ::pwtk::error "cell parameters are specified twice, i.e., ibrav !=0 & CELL_PARAMETERS card exists" 1
    } else {
        # ibrav != 0:  get lattice vectors (in alat) from one-atom pw.x dry-run
        set cell [::pwtk::pwo::getPrimVec [::pwtk::one_atom_dryrunPW]]
        set scale2 $alat
    }
    set cell [::pwtk::scaleVec [expr $scale*$scale2] $cell]

    return [::pwtk::CELL_PARAMETERS_math_parser $cell]
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::getAtmPosUnit
# SYNOPSIS
proc ::pwtk::pwi::getAtmPosUnit {{enforce {}}} {
    # USAGE
    #   ::pwtk::pwi::getAtmPosUnit ?enforce?
    #
    # PURPOSE
    #   Get the unit in which ATOMIC_POSITIONS are specified. If the
    #   ATOMIC_POSITIONS card is specified without the explicit unit,
    #   an empty string is returned, unless enforce != "".
    #
    # ARGUMENT
    # * enforce -- always return the unit (i.e. if the ATOMIC_POSITIONS card
    #              is specified without the explicit unit, return alat)
    #
    # SOURCE
    set unit [::pwtk::input::cardGetFlags ATOMIC_POSITIONS trim]
    if { $unit eq {} && $enforce ne {} } {
        set unit alat
    }
    return $unit
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::getAtmPos
# SYNOPSIS
proc ::pwtk::pwi::getAtmPos {{path_allowed 0}} {
    # PURPOSE
    #   Get verbatim atomic positions from the pw.x ATOMIC_POSITIONS card, i.e.:
    #     AtmSy1  x1 y1 z1  [if_pos(1) if_pos(2) if_pos(3)]
    #     AtmSy2  x2 y2 z2  [if_pos(1) if_pos(2) if_pos(3)]
    #     ....
    #
    #   For path calculation of very old pw.x (prior to neb.x) and if 'path_allowed' == 1, it returns:
    #     first_image
    #     AtmSy1  x1 y1 z1  [if_pos(1) if_pos(2) if_pos(3)]
    #     AtmSy2  x2 y2 z2  [if_pos(1) if_pos(2) if_pos(3)]
    #     ...
    #
    # ARGUMENTS
    # * path_allowed -- (optional, default = 0) if 1, allow the path type verbatim atomic positions (for very old pw.x, prior to neb.x)
    #
    # RETURN VALUE
    # * atomic positions as specified in the ATOMIC_POSITIONS card
    #
    # SOURCE

    set coor [::pwtk::input::cardGetContent ATOMIC_POSITIONS]    
    set nl ""
    set new_coor ""
    
    foreach line [split $coor \n] {
	if { [string match -nocase {*first_image} $line] && ! $path_allowed} {
	    ::pwtk::error "::pwtk::pwi::getAtmPos works only for non-path type input" 1
	}

	# purify the empty lines (check for syntax errors as well)

	set len [llength $line]

	# can be:  atmSybm  x y z
	# or:      atmSymb  x y z  if_pos(x) if_pos(y) if_pos(z)
        
	if { $path_allowed && [string match *_image* $line] } {
	    append new_coor ${nl}${line}
	    set nl "\n"	    
	} elseif { $len == 4 || $len == 7 } {
	    append new_coor ${nl}${line}
	    set nl "\n"
	} elseif { $len > 0 } {
	    # it's not an empty line --> SYNTAX error
	    ::pwtk::error "syntax error in ATOMIC_POSITIONS card, line = $line" 1
	}
    }
    
    return $new_coor
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::getAtmPosSegment
# SYNOPSIS
proc ::pwtk::pwi::getAtmPosSegment {atomList} {
    # PURPOSE
    #   Get requested segment of atoms as specified by $atomList from
    #   ATOMIC_POSITIONS card.
    #
    # ARGUMENTS
    #   * atomList -- list of indices of atoms to extract; the index of
    #                 the first atom is 1 (list of atoms can also have
    #                 a symbolic compact syntax supported by
    #                 ::pwtk::parseRangeString)    
    # SOURCE

    return [::pwtk::getAtmPosSegment $atomList [::pwtk::input::cardGetContent ATOMIC_POSITIONS] ]
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::getNAtoms
# SYNOPSIS
proc ::pwtk::pwi::getNAtoms {} {
    # PURPOSE
    #   Return the number of atoms in the ATOMIC_POSITIONS card.
    # SOURCE

    set atmPos [::pwtk::input::cardGetContent ATOMIC_POSITIONS]
 
    if { [string match -nocase {*first_image*} [lindex $atmPos 0]] } {
	# path calculation
	set nat 0
	foreach line [lrange [split $atmPos \n] 1 end] {
	    if { [string match -nocase *intermediate_image* $line] || [string match -nocase *last_image* $line] } {
		return $nat
	    } elseif { [llength $line] == 4 || [llength $line] == 7 } {	    
		incr nat
	    }
	}
    } else {
	return [::pwtk::getNAtoms $atmPos]
    }
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::getNTyp
# SYNOPSIS
proc ::pwtk::pwi::getNTyp {} {
    # PURPOSE
    #   Return number of species in ATOMIC_SPECIES card
    # SOURCE

    set species [::pwtk::input::cardGetContent ATOMIC_SPECIES]
    set ntyp    0

    foreach line [split $species \n] {	
	if { [llength $line] == 3 } {
	    incr ntyp
	}
    }
    return $ntyp
}
#******


#****f* pwi_struct_utils/::pwtk::pwi::coorToAtmPos
# SYNOPSIS
proc ::pwtk::pwi::coorToAtmPos {coor} {
    # PURPOSE
    #   Transform the supplied atomic coordinates (aka Coor) to
    #   AtmPos, that is, supplement the supplied 'coor' atomic
    #   coordinates (atmSymb x y z) with the if_pos(:) flags from the
    #   current pw.x input data.
    #
    # ARGUMENTS
    # * coor -- Coor to transform to AtmPos
    #
    # REMARK
    #   This command keeps the pw.x input data intact.
    #
    # RETURN VALUE
    #   The "coor" transformed to "atmPos".
    #
    # SOURCE

    set calculation [::pwtk::input::namelistGetVarValue CONTROL calculation 1]
    if { $calculation == "neb" || $calculation == "smd" } {
	set allow_path 1
    } else {
	set allow_path 0
    }
    set coor [::pwtk::purifyCoor $coor]
    set old_atmPos [::pwtk::pwi::getAtmPos $allow_path]
    
    if { [string match -nocase {*first_image*} [lindex $old_atmPos 0]] } {	
	# we have a path calculation, get rid of the first_image line	
	set old_atmPos [join [lrange [split $old_atmPos \n] 1 end] \n]
    }
    
    set atmPos ""
    foreach old_line [split $old_atmPos \n] line [split $coor \n] {	
	if { [regexp intermediate_image $old_line] || [regexp last_image $old_line] } {
	    # we have done it
	    break
	}
        if { $line eq {} } {
            # we have done it
	    break
	}

	# keep only the AtmSymb x y z fields from $coor
	set len [llength $line]
	if { $len != 4 && $len != 7 } {
	    ::pwtk::error "wrong number of fields in coorLine, $len, must be 4 or 7" 1
	}
	set line [lrange $line 0 3]
	
	if { [llength $old_line] > 4 } {
	    # if_pos(:) are present on the current old_line, use them
	    
	    set line [concat $line [lrange $old_line 4 6]]
	}

	append atmPos "${line}\n"
    }
    
    # if atmPos is empty, just use the input $coor
    if { $atmPos == "" } {
        set atmPos $coor
    }

    return [::pwtk::purifyCoor $atmPos]
}
#****


# -------------------------------------------------------------------------------



### currently disabled (to enable, add one *)
#***a* 5.6. Structural Utilities/pwo_struct_utils
# DESCRIPTION
# A collection of routines that returns some structural data from the
# pw.x output data.
# 
#******


#****f* ::pwtk::pwo/::pwtk::pwo::getXSF
# SYNOPSIS
proc ::pwtk::pwo::getXSF {flag pwoFile} {
    # DESCRIPTION    
    #   Return the XSF-formatted structure data from the pw.x output file
    # ARGUMENTS
    #   * flag    -- the option to pass to pwo2xsf.sh filter, one of -ic, -lc, -oc, or -a
    #   * pwoFile -- pw.x output file
    # SOURCE

    set output [::fileutil::tempfile xsf.]
    
    set pwo2xsf [::pwtk::getExecutable [::pwtk::getVar_ PWO2XSF]]
    if { $pwo2xsf eq {} } {
	::pwtk::error "cannot find the PWO-to-XSF (aka pwo2xsf.sh) converter" 1
    }

    exec -- $pwo2xsf $flag $pwoFile > $output
    return [::pwtk::readFile $output]
}
#****



#****f* ::pwtk::pwo/::pwtk::pwo::getXSFPrimVec
# SYNOPSIS
proc ::pwtk::pwo::getXSFPrimVec {flag pwoFile {anim_index ""}} {
    # DESCRIPTION
    #   Return the XSF-formatted lattice vectors (PRIMVEC section) from the pw.x output file, i.e.:
    #      PRIMVEC
    #        ax ay az
    #        bx by bz
    #        cx cy cz
    # ARGUMENTS
    #   * flag    -- the option to pass to pwo2xsf.sh filter, one of -ic, -lc, -oc, or -a
    #   * pwoFile -- pw.x output file
    #   * anim_index -- animation index to append to PRIMVEC keyword
    # SOURCE
    set output [::fileutil::tempfile xsf.]
    
    set  pwo2xsf [::pwtk::getExecutable [::pwtk::getVar_ PWO2XSF]]
    if { $pwo2xsf eq {} } {
	::pwtk::error "cannot find the PWO-to-XSF (aka pwo2xsf.sh) converter" 1
    }

    exec -- $pwo2xsf $flag $pwoFile > $output
    
    set xsf    [split [::pwtk::readFile $output] \n]
    set ind    [lsearch $xsf *PRIMVEC*]

    set    vec "PRIMVEC $anim_index\n"
    append vec "[join  [lrange $xsf [expr {$ind + 1}] [expr {$ind + 3}]] \n]"
    return $vec
}
#****


#****f* ::pwtk::pwo/::pwtk::pwo::getXSFPrimCoor
# SYNOPSIS
proc ::pwtk::pwo::getXSFPrimCoor {flag pwoFile {anim_index ""}} {
    # DESCRIPTION
    #   Return the XSF-formatted atoms (PRIMCOORD section) from the pw.x output file, i.e.:
    #      PRIMCOORD
    #        nat 1
    #        AtmSymb1 x1 y1 z1
    #        AtmSymb2 x2 y2 z2
    #        ...
    # ARGUMENTS
    #   * flag    -- the option to pass to pwo2xsf.sh filter, one of -ic, -lc, -oc, or -a
    #   * pwoFile -- pw.x output file
    #   * anim_index -- animation index to append to PRIMCOORD keyword
    # SOURCE

    set output [::fileutil::tempfile xsf.]
    
    set  pwo2xsf [::pwtk::getExecutable [::pwtk::getVar_ PWO2XSF]]
    if { $pwo2xsf eq {} } {
	::pwtk::error "cannot find the PWO-to-XSF (aka pwo2xsf.sh) converter" 1
    }

    exec -- $pwo2xsf $flag $pwoFile > $output
    
    set xsf    [split [::pwtk::readFile $output] \n]
    set ind    [lsearch $xsf *PRIMCOOR*]
    set natoms [lindex [lindex $xsf [expr {$ind + 1}]] 0]

    set    coor "PRIMCOORD $anim_index\n"
    append coor "[lindex $xsf [expr {$ind + 1}]]\n"
    append coor "[join  [lrange $xsf [expr {$ind + 2}] [expr {$ind + 2 + $natoms}]] \n]"
    return $coor
}
#****


#****f* ::pwtk::pwo/::pwtk::pwo::getNAtoms
# SYNOPSIS
proc ::pwtk::pwo::getNAtoms {pwoFile} {
    # PURPOSE
    #   Return the number of atoms (i.e. nat) from the pw.x output file.
    # ARGUMENTS
    #   pwoFile -- name of pw.x output file
    # SOURCE

    set fid [open $pwoFile r]

    while { ! [eof $fid] } {
	#
	gets $fid line
	#
	if { [string match {*number of atoms/cell*} $line] } {
	    close $fid
	    return [lindex $line end]
	}
    }

    close $fid
    ::pwtk::error "$pwoFile is not a pw.x output file: number of atoms/cell record not found"
    return 0
}
#******	

#****f* ::pwtk::pwo/::pwtk::pwo::getPrimVecUnit
# SYNOPSIS
proc ::pwtk::pwo::getPrimVecUnit {pwoFile {index end}} {
    # PURPOSE
    #   Return the unit in which the CELL_PARAMETERS are specified in
    #   the pw.x output file.
    # ARGUMENTS
    #   * pwoFile -- pw.x output file    
    #   * index -- (optional, default = end) sequential index of the
    #              lattice vectors to query.    
    # SOURCE
    lassign [split [string trim [getPrimVec -k $pwoFile $index]] \n] line
    set unit [::pwtk::trimCardFlag [lrange $line 1 end]]

    # beware that for alat, pw.x prints something like: (alat= value)    
    return [lindex [split $unit =] 0]
}
#******

#****f* ::pwtk::pwo/::pwtk::pwo::getPrimVec
# SYNOPSIS
proc ::pwtk::pwo::getPrimVec {args} {
    # USAGE
    #   ::pwtk::pwo::getPrimVec ?-k? pwoFile ?index?
    #
    # DESCRIPTION
    #   Get the index-th primitive vectors (CELL_PARAMETERS card) from the pw.x output file.
    #
    # RETURN VALUE
    #   If -k option is specified then it returns primitive vectors with keyword line, e.g.:
    #
    #     CELL_PARAMETERS (alat)
    #        ax ay az
    #        bx by bz
    #        cx cy cz
    #
    #   otherwise it returns:
    #
    #        ax ay az
    #        bx by bz
    #        cx cy cz
    #
    # BEWARE
    #   CELL_PARAMETERS card is returned only if the card is found in
    #   the PWO output file unless index==0 or index==end (in this
    #   case, the initial lattice-vectors are returned; for index==end,
    #   the initial lattice-vectors are returned if CELL_PARAMETERS
    #   records are missing in the output).
    #
    # ARGUMENTS
    #   * -k      -- (optional) option to request to include the CELL_PARAMETERS
    #                line in the result    
    #   * pwoFile -- pw.x output file    
    #   * index -- (optional, default = end) sequential index of the
    #              lattice vectors to extract. The input vectors have
    #              an index of 0, while for the last vectors the
    #              "end" string can be used.
    #
    # SOURCE

    return [eval ::pwtk::pwo::getStructData vectors $args]
}
#******


#****f* ::pwtk::pwo/::pwtk::pwo::getAtmPosUnit
# SYNOPSIS
proc ::pwtk::pwo::getAtmPosUnit {pwoFile} {
    # USAGE
    #   ::pwtk::pwo::getAtmPosUnit
    #
    # PURPOSE
    #   Get the ATOMIC_POSITIONS's unit from the pw.x output file.
    #
    #   If the pw.x output file does not contain the ATOMIC_POSITIONS
    #   record, "alat" of the initial coordinates in the output is returned.
    #
    # ARGUMENT
    # * pwoFile -- pw.x output file
    #
    # SOURCE
    set atmPos [::pwtk::pwo::getAtmPos -k $pwoFile]
    return [::pwtk::trimCardFlag [lrange [lindex [split [string trim $atmPos] \n] 0] 1 end]]
}
#******
  

#****f* ::pwtk::pwo/::pwtk::pwo::getAtmPos
# SYNOPSIS
proc ::pwtk::pwo::getAtmPos {args} {
    # USAGE
    #   ::pwtk::pwo::getAtmPos ?-k? pwoFile ?index?
    #
    # PURPOSE
    #   Get the index-th ATOMIC_POSITIONS card from pw.x the output file. 
    #
    # RETURN VALUE
    #   If -k option is specified then it returns atomic positions with keyword line:
    #   
    #     ATOMIC_POSITIONS (unit)
    #        AtmPos1   x1 y1 z1   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos2   x2 y2 z2   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos3   x3 y3 z3   [if_pos(1) if_pos(2) if_pos(3)]
    #        ....    
    #
    #   otherwise it returns:
    #
    #        AtmPos1   x1 y1 z1   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos2   x2 y2 z2   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos3   x3 y3 z3   [if_pos(1) if_pos(2) if_pos(3)]
    #        ....    
    #
    # ARGUMENTS
    #   * -k      -- (optional) option to request to include the ATOMIC_POSITIONS
    #                line in the result    
    #   * pwoFile -- pw.x output file
    #   * index -- (optional, default = end) sequential index of the
    #              atomic positions to extract. The input positions
    #              have an index of 0, while for the last reported
    #              atomic positions, a string "end" can be used.
    #
    # SOURCE

    return [eval ::pwtk::pwo::getStructData positions $args]
}
#******


#****f* ::pwtk::pwo/::pwtk::pwo::getAtmPosSegment
# SYNOPSIS
proc ::pwtk::pwo::getAtmPosSegment {atomList pwo {index end}} {
    # PURPOSE
    #   Get the requested segment of atoms from the index-th
    #   ATOMIC_POSITIONS card from the pw.x output file.
    #
    # ARGUMENTS
    # * atomList -- list of indices of atoms to extract; the index of
    #               the first atom is 1 (list of atoms can also have a
    #               symbolic compact syntax supported by
    #               ::pwtk::parseRangeString)
    
    # * pwo -- pw.x output file
    
    # * index -- (optional, default = end) sequential index of the
    #            atomic position card to extract. The input positions
    #            have an index of 0, while for the last reported
    #            atomic positions, a string "end" can be used.
    #
    # SOURCE

    return [::pwtk::getAtmPosSegment $atomList [::pwtk::pwo::getAtmPos $pwo $index]]
}
#******


#****f* ::pwtk::pwo/::pwtk::pwo::getForces
# SYNOPSIS
proc ::pwtk::pwo::getForces {args} {
    # USAGE
    #   ::pwtk::pwo::getForces [-k] pwoFile [index]
    #
    # PURPOSE
    #   Get the index-th atomic forces (i.e. "Forces acting on atoms")
    #   from pw.x output file (in Ry/Bohr units)
    #
    # RETURN VALUE
    #   If -k option is specified then it returns atomic forces with the keyword line:
    #   
    #     ATOMIC_FORCES
    #        fx1 fy1 fz1
    #        fx2 fy2 fz2
    #        fx3 fy3 fz3
    #        ....    
    #
    #   otherwise it returns:
    #
    #        fx1 fy1 fz1
    #        fx2 fy2 fz2
    #        fx3 fy3 fz3
    #        ....    
    #
    # ARGUMENTS
    #   * -k      --- (optional) option to request to include the ATOMIC_FORCES
    #                line in the result    
    #   * pwoFile --- pw.x output file
    #   * index --- (optional, default = end) sequential index of the
    #               atomic forces to extract. The first forces in the
    #               output file have the index of 0, while for the
    #               last reported forces positions a string "end" can
    #               be used.
    #
    # SOURCE

    return [eval ::pwtk::pwo::getStructData forces $args]
}
#******


#****f* ::pwtk::pwo/::pwtk::pwo::getStruct
# SYNOPSIS
proc ::pwtk::pwo::getStruct {args} {
    # USAGE
    #   ::pwtk::pwo::getStruct [-k] pwoFile [index]
    #
    # PURPOSE
    #   Get the index-th structure (CELL_PARAMETERS and
    #   ATOMIC_POSITIONS) from pw.x output file, i.e.:
    #
    # RETURN VALUE    
    #   If -k option is specified then it returns atomic positions with keyword line:
    #
    #     CELL_PARAMETERS (alat)
    #        ax ay az
    #        bx by bz
    #        cx cy cz
    #
    #     ATOMIC_POSITIONS (alat)
    #        AtmPos1   x1 y1 z1   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos2   x2 y2 z2   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos3   x3 y3 z3   [if_pos(1) if_pos(2) if_pos(3)]
    #        ....    
    #
    #   else it return
    #
    #        ax ay az
    #        bx by bz
    #        cx cy cz
    #
    #        AtmPos1   x1 y1 z1   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos2   x2 y2 z2   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos3   x3 y3 z3   [if_pos(1) if_pos(2) if_pos(3)]
    #        ....    
    #
    # BEWARE
    #   CELL_PARAMETERS card is returned only if the card is found in
    #   the PWO output file unless index==0 or index==end (in this
    #   case, the initial lattice-vectors are returned).
    #           
    # ARGUMENTS
    #   * -k    -- (optional) option to request to include the ATOMIC_POSITIONS
    #              and CELL_PARAMETERS lines in the result    
    #   * pwoFile -- pw.x output file   
    #   * index -- (optional, default = end) sequential index of the
    #              structure to extract. The input structure has an
    #              index of 0, while for the last reported structure a
    #              string "end" can be used.
    #
    # SOURCE

    return [eval ::pwtk::pwo::getStructData both $args]
}
#****


#****f* ::pwtk::pwo/::pwtk::pwo::getStructData
# SYNOPSIS
proc ::pwtk::pwo::getStructData {what args} {
    # USAGE
    #   ::pwtk::pwo::getStructData what [-k] pwoFile [index]
    #    
    # PURPOSE
    #   The master structure retrieval routine for getting the
    #   index-th structure (CELL_PARAMETERS, ATOMIC_POSITIONS,
    #   ATOMIC_FORCES and their combination) from pw.x output file.
    #
    #   Not meant to be used directly, use the ::pwtk::pwo::getPrimVec,
    #   ::pwtk::pwo::getAtmPos, or ::pwtk::pwo::getStruct instead.
    #           
    # ARGUMENTS
    #   * what  -- what to extract (see below)
    #   * -k    -- (optional) option to request to include the ATOMIC_POSITIONS
    #              and/or CELL_PARAMETERS lines in the result    
    #   * pwoFile -- pw.x output file
    #   * index -- (optional, default = end )sequential index of the
    #              structure to extract. The input structure has an
    #              index of 0, while for the last reported structure a
    #              string "end" can be used.
    #
    # Possible values for the 'what' argument:
    # * cell, vectors, CELL_PARAMETERS ==> returns CELL_PARAMETERS
    # * atoms, coordinates, positions, ATOMIC_POSITIONS ==> returns ATOMIC_POSITIONS
    # * atomforce, coorforce, posforce ==> returns ATOMIC_POSITIONS & ATOMIC_FORCES with the following lines "atmSymbol  x y z  fx fy fz"
    # * both ==> returns CELL_PARAMETERS + ATOMIC_POSITIONS
    # * all ==> implies cell + atomforce
    #
    # SOURCE

    # parse arguments ...
    
    set options {
        {k "include the keyword line in the result"}
    }
    set usage ":   ::pwtk::pwo::getStructData what \[-k] pwoFile \[index]"

    array set opt [::cmdline::getoptions args $options $usage]

    set narg [llength $args]
    if { $narg < 1 || $narg > 2 } {
        ::pwtk::error "Usage $usage" 1
    }

    set prependKeyword $opt(k)
    set pwoFile [lindex $args 0]
    set index   [expr { $narg == 1 ? "end" : [lindex $args 1] }]    
    
    # do the job ...
    
    set fid    [open $pwoFile r]
    set l_vec  {}
    set l_coor {}
    set l_force {}
    set nat    0
    set l_first_vec  1
    set l_first_coor 1

    if { ! [string is boolean $prependKeyword]  } {
	::pwtk::error "prependKeyword must be of boolean type; assuming it is true"
	set prependKeyword 1
    }

    while { ! [eof $fid] } {
	#
	gets $fid line
	#
	if { [string match {*number of atoms/cell*} $line] } {
	    
	    set nat [lindex $line end]
	    
	} elseif { [string match {*crystal axes: \(cart. coord. in units of a*} $line] && $l_first_vec } {

	    set l_first_vec 0

	    if { $prependKeyword} {
		set vec "CELL_PARAMETERS (alat)\n"
	    } else {
		set vec ""
	    }

	    append vec [lrange [string map {( "" ) ""} [gets $fid]] 2 4]\n
	    append vec [lrange [string map {( "" ) ""} [gets $fid]] 2 4]\n
	    append vec [lrange [string map {( "" ) ""} [gets $fid]] 2 4]\n

	    lappend l_vec $vec

	} elseif { [string match CELL_PARAMETERS* $line] } {
	    
	    if { $prependKeyword} {
		set vec $line\n
	    } else {
		set vec ""
	    }

	    append vec [gets $fid]\n
	    append vec [gets $fid]\n
	    append vec [gets $fid]\n

	    lappend l_vec $vec
        
	} elseif { [string match {*Cartesian axes*} $line] && $l_first_coor } {
            #
            # initial coordinates 
            #
	    set l_first_coor 0
	    gets $fid line; # empty line
	    gets $fid line; # site n.     atom                  positions (a_0 units)
	    
	    if { $prependKeyword} {
                set key "ATOMIC_POSITIONS (alat)\n"
	    } else {
		set key ""
	    }

            set coor ""            
	    for {set ia 0} {$ia < $nat} {incr ia} {
		set line [gets $fid]
		append coor [concat [lindex $line 1] [lrange [string map {( " " ) " "} $line] 5 7]]\n
	    }

            # Try to transform coor to atmPos, but be cautious:
            # perhaps ATOMIC_POSITIONS card is empty or has a
            # different number of atoms; use transformation only if
            # the number-of-atoms matches
            
	    set atmPos [::pwtk::pwi::coorToAtmPos $coor]
            if { [::pwtk::getNAtoms $coor] == [::pwtk::getNAtoms $atmPos] } {
                lappend l_coor ${key}$atmPos
            } else {
                lappend l_coor ${key}$coor
            }
	} elseif { [string match ATOMIC_POSITIONS* $line] } {

	    if { $prependKeyword} {
		set coor $line\n
	    } else {
		set coor ""
	    }
	    
	    for {set ia 0} {$ia < $nat} {incr ia} {
		append coor [gets $fid]\n
	    }

	    lappend l_coor $coor
	} elseif { [string match {*Forces acting on atoms*} $line] } {

	    if { $prependKeyword } {
                set force "ATOMIC_FORCES\n"
	    } else {
		set force ""
	    }

            gets $fid; # empty line
	    for {set ia 0} {$ia < $nat} {incr ia} {
		append force [lrange [gets $fid] end-2 end]\n
	    }
            lappend l_force $force
        }
    }
    close $fid

    proc atomforce_ {prependKeyword l_coor l_force index} {
        set coor  [lindex $l_coor $index]
        set force [lindex $l_force $index]
        if { $prependKeyword } {
            # strip the keyword from $l_coor & $l_force
            append result [concat [lindex [split $coor \n] 0] [lindex [split $force \n] 0]]\n
            #
            set coor  [join [lrange [split $coor  \n] 1 end] \n]
            set force [join [lrange [split $force \n] 1 end] \n]
        }
        foreach {a x y z} $coor {fx fy fz} $force {
            append result [format $::pwtk::fmt_coor(7) $a $x $y $z  $fx $fy $fz]
        }
        return $result
    }

    switch -nocase -glob --  $what {	
	cell* -
	vec* {
            # vectors
	    set result [lindex $l_vec $index]
	}
	both {
            # vectors + atoms
	    set result [lindex $l_vec $index]\n[lindex $l_coor $index]	    
	}
        all {
            # vectors + atoms + forces            
	    set result [lindex $l_vec $index]\n
            append result [::pwtk::pwo::atomforce_ $prependKeyword $l_coor $l_force $index]
        }
        atomfor* -
        pos*for* -
        coor*for* {
            # atoms + forces
            set result [::pwtk::pwo::atomforce_ $prependKeyword $l_coor $l_force $index]
        }
	atom* -
	pos* -
	coor* {
            # atoms
	    set result [lindex $l_coor $index]
	}
        for* {
            # forces
            set result [lindex $l_force $index]
        }
	default {
	    ::pwtk::error "wrong type of data requested ($what), must be one of vectors, positions, forces, both, or all" 1
	    #set result [lindex $l_coor $index]
	}
    }

    return $result
}
#****

# -------------------------------------------------------------------------------

#****a* 5.6. Structural Utilities/xsf_struct_utils
# DESCRIPTION
# A collection of routines that returns some pw.x formatted structure
# data from the XSF file.
# 
#******


#****f* xsf_struct_utils/::pwtk::xsf::getAnimsteps
# SYNOPSIS
proc ::pwtk::xsf::getAnimsteps {xsfFile} {
    # PURPOSE
    #   Return the number of snapshots in the XSF file (in XSF
    #   jargon this is called number of ANIMSTEPS).    
    # ARGUMENTS
    #   xsfFile -- name of XSF file
    # SOURCE
    ::pwtk::fileMustExist $xsfFile XSF
    
    set nimages 1
    pwtk::lineread line $xsfFile {
        if { [regexp ANIMSTEPS $line] } {
            set nimages [lindex $line end]
            break
        }
    }
    return $nimages
}
#******

#****f* xsf_struct_utils/::pwtk::xsf::getDim
# SYNOPSIS
proc ::pwtk::xsf::getDim {xsfFile} {
    # PURPOSE
    #   Return the dimension of structure in the XSF file.
    # ARGUMENTS
    #   xsfFile -- name of XSF file
    # SOURCE

    ::pwtk::fileMustExist $xsfFile XSF
    
    set fid [open $xsfFile r]
    set dim -1

    while { ! [eof $fid] } {
	#
	gets $fid line
	#
	switch -glob -- $line {
	    *DIM-GROUP* {
		gets $fid line		
		set dim [lindex $line 0]
	    }
	    *CRYSTAL* {
		set dim 3
	    }
	    *SLAB* {
		set dim 2
	    }
	    *POLYMER* {
		set dim 1
	    }
	    *MOLECULE* - *ATOMS* {
		set dim 0
	    }
	    default {
		# do nothing
	    }
	}
	
	if { $dim > -1 } {
	    close $fid
	    return $dim
	}
    }
    
    # if we come that far, the file is not XSF file

    ::pwtk::error "$xsfFile is not an XSF file" 1
    close $fid
    return 0
}
#******


#****f* xsf_struct_utils/::pwtk::xsf::getNAtoms
# SYNOPSIS
proc ::pwtk::xsf::getNAtoms {xsfFile} {
    # PURPOSE
    #   Return the number of atoms in the XSF file.
    # ARGUMENTS
    #   xsfFile -- name of XSF file
    # SOURCE

    ::pwtk::fileMustExist $xsfFile XSF
    
    set xsfList [split [::pwtk::skipEmptyLines [::pwtk::readFile $xsfFile]] \n]
    set ind [lsearch $xsfList *PRIMCOOR*]
    if { $ind > -1 } {
	return [lindex [lindex $xsfList [expr {$ind + 1}]] 0]
    } else {
	::pwtk::error "$xsfFile is not an XSF file" 1
    }
}
#******

#****f* xsf_struct_utils/::pwtk::xsf::getPrimVecUnit
# SYNOPSIS
proc ::pwtk::xsf::getPrimVecUnit {xsfFile} {
    # USAGE
    #   ::pwtk::xsf::getPrimVecUnit xsfFile
    #
    # PURPOSE    
    #   Return the unit in which the primitive vectors are specified
    #   in the XSF file. Beware that XSF supports only "angstroms"
    #   units, but XSF2 (i.e. XSF version-2) supports also other
    #   units.
    #
    # SOURCE

    ::pwtk::fileMustExist $xsfFile XSF
    
    set xsfList [split [::pwtk::skipEmptyLines [::pwtk::readFile $xsfFile]] \n]
    set ind     [lsearch $xsfList *PRIMVEC*]

    if { $ind > -1 } {
        return [::pwtk::xsf::getUnit_ [lindex $xsfList $ind]]
    } else {
        ::pwtk::error "$xsfFile is not an XSF file" 1
    }
    return ""
}
#******


#****f* xsf_struct_utils/::pwtk::xsf::getPrimVec
# SYNOPSIS
proc ::pwtk::xsf::getPrimVec  {xsfFile} {
    # USAGE
    #   ::pwtk::xsf::getPrimVec xsfFile
    #
    # PURPOSE
    #   Return the primitive vectors from the XSF file, that is, the PRIMVEC
    #   section without the PRIMVEC keyword line, i.e:
    #
    #        ax ay az
    #        bx by bz
    #        cx cy cz
    #
    # SOURCE
    variable vec_unit

    ::pwtk::fileMustExist $xsfFile XSF
    
    set xsfList [split [::pwtk::skipEmptyLines [::pwtk::readFile $xsfFile]] \n]
    set ind     [lsearch $xsfList *PRIMVEC*]

    if { $ind > -1 } {
        return [join [lrange $xsfList [expr {$ind + 1}] [expr {$ind + 3}]] \n]
    } else {
	::pwtk::error "$xsfFile is not an XSF file" 1
    }
    return ""
}
#******


#****f* xsf_struct_utils/::pwtk::xsf::getPrimCoorUnit
# SYNOPSIS
proc ::pwtk::xsf::getPrimCoorUnit  {xsfFile} {
    # USAGE
    #   ::pwtk::xsf::getPrimCoorUnit xsfFile
    #
    # PURPOSE
    #   Return the unit in which the primitive coordinates are
    #   specified in the XSF file. Beware that XSF supports only
    #   "angstroms" units, but XSF2 (i.e. XSF version-2) supports also
    #   other units.
    #
    # SOURCE

    ::pwtk::fileMustExist $xsfFile XSF
    
    set xsfList [split [::pwtk::skipEmptyLines [::pwtk::readFile $xsfFile]] \n]
    set ind     [lsearch $xsfList *PRIMCOOR*]

    if { $ind > -1 } {
        return [::pwtk::xsf::getUnit_ [lindex $xsfList $ind]]
    } else {
        ::pwtk::error "$xsfFile is not an XSF file" 1
    }
    return ""
}
#******


#****f* xsf_struct_utils/::pwtk::xsf::getPrimCoor
# SYNOPSIS
proc ::pwtk::xsf::getPrimCoor {xsfFile {image 1}} {
    # PURPOSE
    #   Return the primitive atomic positions from XSF file (PRIMCOORD section), i.e.:
    #        AtmSymb1 x1 y1 z1  
    #        AtmSymb2 x2 y2 z2  
    #        ...
    #   or
    #        AtmSymb1 x1 y1 z1  fx1 fy1 fz1
    #        AtmSymb2 x2 y2 z2  fx2 fy2 fz2
    #        ...
    #
    #    Depending on whether forces are present or not.
    #
    # ARGUMENTS
    #   * xsfFile -- name of xsf-file
    #   * image (optional) -- index of the image to extract from the AXSF file (default = 1st image); the 1st image has index 1
    #
    # SOURCE
    #variable coor_unit

    ::pwtk::fileMustExist $xsfFile XSF
    
    set xsfList [split [::pwtk::skipEmptyLines [::pwtk::readFile $xsfFile]] \n]
    set indices [lsearch -all $xsfList *PRIMCOOR*]
    set nimages [llength $indices]
    
    if { $nimages < 1 } {
        ::pwtk::error "$xsfFile is not an XSF file" 1
    }
    
    if { $image < 1 || $image > $nimages } {
        ::pwtk::warning "image index $image, out of range. Must be within \[1,$nimages\]"
        if { $image < 1 } {
            set image 1
        } elseif { $image > $nimages } {
            set image $nimages
        }
    }

    set ind [lindex $indices $image-1]
    set nat [lindex [lindex $xsfList [expr {$ind + 1}]] 0]

    if { [string is integer $ind] && $ind > -1 } {
	set coor [join [lrange $xsfList [expr {$ind + 2}] [expr {$ind + $nat + 1}]] \n]
        
	foreach line [split $coor \n] {
	    set atmSymb [string totitle [lindex $line 0]]
	    set coor    [lrange $line 1 6]
	    append new_coor "$atmSymb   $coor\n"
	}
	return $new_coor
    } else {
	::pwtk::error "failed to extract image No.$image from the XSF file $xsfFile" 1
    }
    return ""
}
#******


proc ::pwtk::xsf::getUnit_ {unitLine} {
    # PURPOSE
    #   Get the unit from unitLine, where unitLine is either
    #   "PRIMVEC unit" or "PRIMCOORD unit" (useful for XSF.v2)
    #
    #   default-unit = ansgtrom (i.e. if unit is not specified)

    set unit  angstrom
    set unit_ [lindex $unitLine 1]
    
    switch -glob -- $unit_ {
	angstrom* -
	bohr -
	alat -
	crystal {
	    set unit $unit_
	}
	prim* {
	    # primitive-crystal
	    set unit crystal
	}
    }
    return $unit
}


# ------------------------------------------------------------------------

#****a* 5.6. Structural Utilities/generic_struct_utils
# DESCRIPTION
# Collections of routines that manipulate supplied vectors and coordinates.
#******

#****f* generic_struct_utils/::pwtk::purifyVec
# SYNOPSIS
proc ::pwtk::purifyVec {vec} {
    # PURPOSE   
    #   Returns purified lattice vectors in such a way that empty
    #   lines and other junks (such as PRIMVEC or CELL_PARAMETERS
    #   keywords) are removed. Only lines with precisely 3 fields
    #   survive, so it returns:
    #     ax ay az
    #     bx by bz
    #     cx cy cz
    # SOURCE

    set pureVec "" ; # $vec might be an empty string
    set nl ""
    foreach line [split $vec \n] {
	if { [llength $line] == 3 \
                 && [::pwtk::is_double [lindex $line 0]] \
                 && [::pwtk::is_double [lindex $line 1]] \
                 && [::pwtk::is_double [lindex $line 2]] } {	    
            append pureVec ${nl}${line}
            set nl "\n"
        }
    }
    return $pureVec
}
#****


#****f* generic_struct_utils/::pwtk::purifyCoor
# SYNOPSIS
proc ::pwtk::purifyCoor {coor} {
    # PURPOSE   
    #   Return purified Coor or AtmPos (AtmSymb x y z [ix] [iy] [iz]) in such a
    #   way that empty lines and other junk (such as PRIMCOORD or
    #   ATOMIC_POSITIONS keywords) are removed. Only lines with 4 or
    #   7 fields survive, so it returns:
    #        AtmSymb1   x1 y1 z1   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmSymb2   x2 y2 z2   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmSymb3   x3 y3 z3   [if_pos(1) if_pos(2) if_pos(3)]
    #        ....
    # SOURCE
    set pureCoor "" ; # $coor might be an empty string
    set nl ""
    foreach line [split $coor \n] {
	if { [llength $line] == 4 || [llength $line] == 7 } {
            # additional check to prevent constructs like ATOMIC_POSITIONS { alat }
            if { [::pwtk::is_double [lindex $line 1]] } {                
                append pureCoor ${nl}${line}
                set nl "\n"
            }
	}
    }
    return $pureCoor
}
#****


#****f* generic_struct_utils/::pwtk::atmPosToCoor
# SYNOPSIS
proc ::pwtk::atmPosToCoor {atmPos} {
    # PURPOSE   
    #   Tranform the "atmPos" to "coor", where "atmPos" are:
    #
    #      atmSymb x y z [if_pos(1) if_pos(2) if_pos(3)]
    #      ...
    #
    #  and "coor" are:
    #
    #      atmSymb x y z
    #      ....
    #
    #   It also removes empty lines and other junks. So it returns only:    
    #        AtmSymb1   x1 y1 z1   
    #        AtmSymb2   x2 y2 z2   
    #        AtmSymb3   x3 y3 z3   
    #        ....
    #
    # SOURCE
    
    set pureCoor "" ; # $coor might be an empty string
    set nl ""
    foreach line [split $atmPos \n] {
	if { [llength $line] == 4 || [llength $line] == 7 } {
            # additional check to prevent constructs like ATOMIC_POSITIONS { alat }
            if { [::pwtk::is_double [lindex $line 1]] } {
                append pureCoor "${nl}[lrange $line 0 3]"
                set nl "\n"
            }
	}
    }
    return $pureCoor
}
#****


#****f* generic_struct_utils/::pwtk::coorToAtmPos
# SYNOPSIS
proc ::pwtk::coorToAtmPos {coor refAtmPos} {
    # PURPOSE   
    #   Tranform "coor" to "atmPos" according to the reference atmPos, where "coor" are:
    #       AtmSymb1 x1 y1 z1
    #       AtmSymb2 x2 y2 z2
    #       ...
    #   and "atmPos" are:
    #       AtmSymb1 x1 y1 z1 [if_pos1(1) if_pos1(2) if_pos1(3)]
    #       AtmSymb2 x2 y2 z2 [if_pos2(1) if_pos2(2) if_pos2(3)]
    #       ...    
    #
    #   Note that coor can be prepended with the "ATOMIC_POSITIONS
    #   (unit)" line and in this case also the resulting "atmPos" will
    #   be prepended with the "ATOMIC_POSITIONS (unit)" line
    #
    # ARGUMENTS
    # * coor -- coordinates to tranform to atmPos
    # * refAtmPos -- reference atmPos used for the "if_pos" info
    #
    # SOURCE

    # parse refAtmPos and store the if_pos records
    
    set N 0
    foreach line [split [::pwtk::purifyCoor $refAtmPos] \n] {
        incr N
        set if_pos($N,1) [lindex $line 4]
        set if_pos($N,2) [lindex $line 5]
        set if_pos($N,3) [lindex $line 6]        
    }

    # parse coor and supplement it with the if_pos fields
    
    set atmPos ""
    set nl ""
    set i 0
    
    foreach line [split $coor \n] {
        if { [regexp ATOMIC_POSITIONS $line] } {
            append atmPos $line
            set nl \n
            continue
        }
        set nf [llength $line]
	if { $nf == 4 || $nf == 7 } {
            incr i
            set ifp {}
            if { $i <= $N } {
                set ifp [concat $if_pos($i,1) $if_pos($i,2) $if_pos($i,3)]
            }            
            append atmPos "${nl}$line   $ifp"
            set nl \n
	}
    }
    return $atmPos
}
#******


#****f* generic_struct_utils/::pwtk::getNAtoms
# SYNOPSIS
proc ::pwtk::getNAtoms {atmPos} {
    # PURPOSE
    #   Return the number of atoms in the AtmPos string.
    # ARGUMENTS
    #   atmPos -- the AtmPos string in the format:
    #           AtmSy1 x1 y1 z1 [if_pos(1) if_pos(2) if_pos(3)]
    #           AtmSy2 x2 y2 z2 [if_pos(1) if_pos(2) if_pos(3)]
    #           ...
    # SOURCE
    return [llength [split [::pwtk::purifyCoor $atmPos] \n]]
}
#******


#****f*  generic_struct_utils/::pwtk::shiftCoor
# SYNOPSIS
proc ::pwtk::shiftCoor {dx dy dz coor} {
    # PURPOSE    
    #    Displace given coordinates by ($dx,$dy,$dz) vector.
    # ARGUMENTS    
    #  * dx, dy, dz -- displacement vector
    #  * coor       -- coordinates to displace
    # SOURCE
    
    # multiply by 1.0 to force the use of floating-point arithmetics
    # (dx can be expression such as 1/2)
    set dx [expr 1.0*$dx]
    set dy [expr 1.0*$dy]
    set dz [expr 1.0*$dz]
    
    set result ""
    foreach line [split $coor \n] {	
	if { [llength $line] == 4 } {
            lassign $len sym x y z
            # multiply x,y,z by 1.0 to force the use of floating-point arithmetics
	    append result [format $::pwtk::fmt_coor(4) \
			       $sym [expr 1.0*$x + $dx] [expr 1.0*$y + $dy] [expr 1.0*$z + $dz]]
	}
    }
    return $result
}
#******

#****f*  generic_struct_utils/::pwtk::shiftAtmPos
# SYNOPSIS
proc ::pwtk::shiftAtmPos {dx dy dz atmPos} {
    # PURPOSE    
    #    Displace given atomic coordinates by ($dx,$dy,$dz) vector.
    # ARGUMENTS    
    #  * dx, dy, dz -- displacement vector
    #  * atmPos     -- atomic coordinates to displace
    # SOURCE

    # multiply by 1.0 to force the use of floating-point arithmetics
    # (dx can be expression such as 1/2)
    set dx [expr 1.0*$dx]
    set dy [expr 1.0*$dy]
    set dz [expr 1.0*$dz]

    set result ""
    foreach line [split $atmPos \n] {	
	set len [llength $line]
	if { $len == 4 || $len == 7 } {
            lassign $line sym x y z ix iy iz  
            # multiply x,y,z by 1.0 to force the use of floating-point arithmetics
	    append result [format $::pwtk::fmt_coor(4) \
			       $sym [expr 1.0*$x + $dx] [expr 1.0*$y + $dy] [expr 1.0*$z + $dz] $ix $iy $iz]
	}
    }
    return $result
}
#******


#****f* generic_struct_utils/::pwtk::scaleCoor
# SYNOPSIS
proc ::pwtk::scaleCoor {args} {
    # USAGE
    #   ::pwtk::scaleCoor scale_x ?scale_y? ?scale_z? coor
    # PURPOSE
    #   Scale the coordinates.
    # ARGUMENTS
    #  * scale_x --- scale factor for x-coordinates
    #  * scale_y --- (optional) scale factor for y-coordinates (default = scale_x)
    #  * scale_z --- (optional) scale factor for z-coordinates (default = scale_x)
    #  * coor    --- coordinates to scale
    # SOURCE

    if { [ llength $args] < 2 || [llength $args] > 4 } {
	::pwtk::error "wrong number of arguments, must be:   pwtk::scaleCoor scale_x ?scale_y? ?scale_z? coor" 1
    }

    set nargs [llength $args]
    set scale(0) [lindex $args 0]
    set scale(1) $scale(0)
    set scale(2) $scale(0)
    for {set i 1} {$i<$nargs-1} {incr i} {
	set scale($i) [lindex $args $i]
    }
    set coor [lindex $args end]

    set result ""
    foreach line [split $coor \n] {	
	if { [llength $line] == 4 } {	
	    lassign $line sym x y z
            # we multiply by 1.0 to force the use of floating-point arithmetics (scale can be expression such as 1/2) 
	    append result [format $::pwtk::fmt_coor(4) \
			       $sym [expr 1.0*$x*$scale(0)] [expr 1.0*$y*$scale(1)] [expr 1.0*$z*$scale(2)]]
	}
    }
    return $result
}
#******


#****f*  generic_struct_utils/::pwtk::scaleAtmPos
# SYNOPSIS
proc ::pwtk::scaleAtmPos {args} {
    # USAGE
    #   ::pwtk::scaleAtmPos scale_x ?scale_y? ?scale_z? atmPos
    # PURPOSE
    #   Scale given atomic positions.
    # ARGUMENTS
    #  * scale_x --- scale factor for x-coordinates
    #  * scale_y --- (optional) scale factor for y-coordinates (default = scale_x)
    #  * scale_z --- (optional) scale factor for z-coordinates (default = scale_x)
    #  * atmPos  --- atomic positions (aka AtmPos)
    # SOURCE

    if { [ llength $args] < 2 || [llength $args] > 4 } {
	::pwtk::error "wrong number of arguments, must be:   pwtk::scaleAtmPos scale_x ?scale_y? ?scale_z? atmPos" 1
    }

    set nargs [llength $args]
    set scale(0) [lindex $args 0]
    set scale(1) $scale(0)
    set scale(2) $scale(0)
    for {set i 1} {$i<$nargs-1} {incr i} {
	set scale($i) [lindex $args $i]
    }
    set atmPos [lindex $args end]

    set result ""
    foreach line [split $atmPos \n] {	
	set len [llength $line]
	if { $len == 4 || $len == 7 } {
            lassign $line sym x y z ix iy iz
	    # we multiply by 1.0 to force the use of floating-point arithmetics (scale can be expression such as 1/2)
	    append result [format $::pwtk::fmt_atmPos($len) \
			       $sym [expr $x * 1.0*$scale(0)] [expr $y * 1.0*$scale(1)] [expr $z * 1.0*$scale(2)] $ix $iy $iz]
	}
    }
    return $result
}
#******


#****f* generic_struct_utils/::pwtk::deleteCoor
# SYNOPSIS
proc ::pwtk::deleteCoor {deleteList coor} {
    # PURPOSE
    #   Delete requested atoms from the supplied coordinates.
    # ARGUMENTS
    #   * deleteList -- list of indices of atoms to delete; index of
    #                   the first atom is 1 (list of atoms can also
    #                   have a symbolic compact syntax supported by
    #                   ::pwtk::parseRangeString)   
    #   * coor        -- atomic coordinates in the form "AtmSymb x y z"
    #
    # SOURCE

    set nat        [::pwtk::getNAtoms $coor]
    set coorList   [split [::pwtk::purifyCoor $coor] \n]
    set sortedList [lsort -integer -decreasing [::pwtk::parseRangeString $deleteList [::pwtk::getNAtoms $coor]]]

    set newCoor {}
    for {set ia 1} {$ia <= $nat} {incr ia} {
        if { ! ($ia in $sortedList) } {
            append newCoor [lindex $coorList $ia-1]\n
        }
    }
    return $newCoor
}
#******


#****f* generic_struct_utils/::pwtk::deleteCoorRange
# SYNOPSIS
proc ::pwtk::deleteCoorRange {from to coor} {
    # PURPOSE
    #   Delete requested range of atoms from the supplied coordinates.
    # ARGUMENTS
    #   * from -- atom index for the begining of the range
    #   * to   -- atom index for the end of the range (can be end)
    #   * coor        -- atomic coordinates in the form "AtmSymb x y z"    
    # SOURCE

    # replace "end" with number-of-atoms
    set to [regsub {^end} $to [::pwtk::getNAtoms $coor]]
    
    set from [::pwtk::evalExpr $from]
    set to   [::pwtk::evalExpr $to]
    
    if { $from > $to } {
        pwtk::error "\"from\" index is larger than \"to\" index, while executing:
deleteCoorRange $from $to { $coor }" 1
    }
    return [deleteCoor [seq $from $to] $coor]    
}
#******


#****f* generic_struct_utils/::pwtk::scaleVec
# SYNOPSIS
proc ::pwtk::scaleVec {args} {
    # USAGE
    #   ::pwtk::scaleVec scale_x ?scale_y? ?scale_z? vecs
    # PURPOSE
    #   Scale (lattice) 3D vectors
    # ARGUMENTS
    #  * scale_x --- scale factor for x-components
    #  * scale_y --- (optional) scale factor for y-components (default = scale_x)
    #  * scale_z --- (optional) scale factor for z-components (default = scale_x)
    #  * vecs    --- 3D vectors to scale in the form of a list (can be many), i.e. vx1 vy1 vz1  vx2 vy2 vz2  ...
    # SOURCE

    if { [ llength $args] < 2 || [llength $args] > 4 } {
	::pwtk::error "wrong number of arguments, must be:   pwtk::scaleVec scale_x ?scale_y? ?scale_z? vectors" 1
    }

    # parse args

    set nargs [llength $args]
    
    set scale(0) [lindex $args 0]
    set scale(1) $scale(0)
    set scale(2) $scale(0)

    for {set i 1} {$i < $nargs-1} {incr i} {
	set scale($i) [lindex $args $i]
    }
    
    set vec [lindex $args end]

    # scale vectors

    set nl {}
    set result {}
    foreach {x y z} $vec {
	append result "$nl[expr $scale(0) * $x]   [expr $scale(1) * $y]   [expr $scale(2) * $z]"
        set nl \n
    }
    
    return $result
}
#******


#****f* generic_struct_utils/::pwtk::getAtmPosSegment
# SYNOPSIS
proc ::pwtk::getAtmPosSegment {atomList atmPos} {
    # PURPOSE
    #   Get requested segment of atoms as specified by "atomList" from
    #   the supplied atomic-positions "atmPos".
    #
    # ARGUMENTS
    #   * atomList -- list of indices of atoms to delete; the index of
    #                 the first atom is 1 (list of atoms can also have
    #                 a symbolic compact syntax supported by
    #                 ::pwtk::parseRangeString)    
    # SOURCE

    set nat      [getNAtoms $atmPos]
    set atomList [::pwtk::parseRangeString $atomList $nat]
    set atmPosL  [split [purifyCoor $atmPos] \n]
    
    set result ""    
    foreach atom $atomList {
        # check if in range
        if { $atom > $nat || $atom < 1 } {
            ::pwtk::error "atom index $atom out of range, should be within \[1, $nat\]" 1
        } else {
            # ok, add this atom
            lappend result [lindex $atmPosL $atom-1]
        }
    }    
    return [join $result \n]
}
#******

#****f* generic_struct_utils/::pwtk::replaceAtom
# SYNOPSIS
proc ::pwtk::replaceAtom {atomIndex atomSpecs atmPos} {
    # PURPOSE
    #   Replace the atom with index "atomIndex" in "atmPos" with the new atom
    #   (i.e. atomic-symbol + coordinates) specified by "atomSpecs".
    #
    # ARGUMENTS
    # * atomIndex -- index of atom to replace
    # * atomSpecs -- specs for new atom, i.e., atmSymbol x y z ?if_pos(x) if_pos(y) if_pos(z)?)
    # * atmPos -- atomic positions data
    #
    # RETURN VALUE
    #   new "atmPos" with the atom "atomIndex" replaced with new specs
    #
    # SOURCE
    
    set nat [getNAtoms $atmPos]
    if { $atomIndex < 1 || $atomIndex > $nat } {
        ::pwtk::error "atom index $atom out of range, should be within \[1, $nat\]" 1
    }
    if { ! ([llength $atomSpecs] == 4 || [llength $atomSpecs] == 7) } {
        ::pwtk::error "wrong atom specs \"$atomSpecs\", must consist of 4 or 7 fields" 1
    }
    
    set newAtmPos ""
    set nl ""
    set ind 1
    foreach atom [split [purifyCoor $atmPos] \n] {
        if { $atomIndex == $ind } {
            set atom $atomSpecs
        }
        append newAtmPos ${nl}$atom
        set nl \n
        incr ind
    }
    return $newAtmPos
}
#******


#****f* generic_struct_utils/::pwtk::vecFromTo
# SYNOPSIS
proc ::pwtk::vecFromTo {fromUnit toUnit vecs} {
    # PURPOSE
    #   Transform 3D vectors from one unit to another one. Units can
    #   be bohr, angstrom, or a real number interpreted as 'alat'.
    #
    # ARGUMENTS
    # * fromUnit -- units in which the input 3D lattice vectors are specified (either bohr, angstrom, or a real number interpreted as 'alat')
    # * toUnit   -- units in which to return the output 3D lattice vectors (either bohr, angstrom, or a real number interpreted as 'alat')
    # * vecs     -- 3D lattice vectors (can be many)
    #
    # SOURCE
    
    # transform to Bohr
    
    switch -glob $fromUnit {
        bohr  { set scale 1.0 }
        angs* { set scale $::pwtk::angs2bohr }
        default  {
            if { [string is double -strict $fromUnit] } {
                # interpreted as alat
                set scale $fromUnit
            } else {
                ::pwtk::error "wrong input unit (aka fromUnit); expected bohr, angstrom, or a real number, but got $fromUnit"
            }
        }
    }
    set vecs [scaleVec $scale $vecs]

    # transform to $toUnit
    
    switch -glob $toUnit {
        bohr  { set scale 1.0 }
        angs* { set scale $::pwtk::bohr2angs }
        default  {
            if { [string is double -strict $toUnit] } {
                # interpreted as alat
                set scale [expr 1.0/$toUnit]
            } else {
                ::pwtk::error "wrong output unit (aka toUnit); expected bohr, angstrom, or a real number, but got $toUnit"
            }
        }
    }
    return [scaleVec $scale $vecs]
}
#******


#****f* generic_struct_utils/::pwtk::coorToCrystal
# SYNOPSIS
proc ::pwtk::coorToCrystal {latvec coor} {
    # PURPOSE
    #   Transform Cartesian coordinates to crystal coordinates. It is
    #   assumed that unit-cell vectors and coordinates are in the same
    #   units.
    #
    # ARGUMENTS
    # * latvec -- unit-cell lattice vectors (specified either as a
    #             vector of 9 numbers, {v1x v1y v1z  v2x v2y v2z  v3x v3y v3z},
    #             or 3x3 list of lists)    
    # * coor -- atomic Cartesian coordinates
    #
    # RETURN VALUE
    # * atomic coordinates in crystal units
    #
    # SOURCE

    set crysCoor {}
    set Tinv [invert3x3 $latvec]
    
    foreach line [split [purifyCoor $coor] \n] {
        if { [llength $line] == 4 || [llength $line] == 7 } {
            set xyz [lassign $line asym]
            append crysCoor "$asym [::math::linearalgebra::matmul $xyz $Tinv]\n"
        }
    }
    return $crysCoor
}
#******


#****f* generic_struct_utils/::pwtk::coorToCartesian
# SYNOPSIS
proc ::pwtk::coorToCartesian {latvec coor} {
    # PURPOSE
    #   Transform crystal coordinates to Cartesian coordinates. The
    #   transformed coordinates will be in the same unit as the input
    #   unit-cell vectors.
    #
    # ARGUMENTS
    # * latvec -- unit-cell lattice vectors (specified either as a
    #             vector of 9 numbers, {v1x v1y v1z  v2x v2y v2z  v3x v3y v3z},
    #             or 3x3 list of lists)    
    # * coor -- atomic crystal coordinates
    #
    # RETURN VALUE
    # * atomic Cartesian coordinates in the same units as 'latvec'
    #
    # SOURCE

    set cartCoor {}

    set latvec [matricize $latvec]
    foreach line [split [purifyCoor $coor] \n] {
        if { [llength $line] == 4 || [llength $line] == 7 } {
            set abc [lassign $line asym]
            append cartCoor "$asym [::math::linearalgebra::matmul $abc $latvec]\n"
        }
    }
    return $cartCoor
}
#******


#****f* generic_struct_utils/::pwtk::atmPosToCrystal
# SYNOPSIS
proc ::pwtk::atmPosToCrystal {latvec atmPos} {
    # PURPOSE
    #   Transform Cartesian atomic-positions (aka atmPos) to crystal atomic-positions.
    #   For more details, see: ::pwtk::coorToCrystal.
    # SOURCE
    return [coorToAtmPos [coorToCrystal $latvec [atmPosToCoor $atmPos]] $atmPos]    
}
#******


#****f* generic_struct_utils/::pwtk::atmPosToCartesian
# SYNOPSIS
proc ::pwtk::atmPosToCartesian {latvec atmPos} {
    # PURPOSE
    #   Transform atomic-positions (aka atmPos) from crystal units to Cartesian atomic-positions.
    #   For more details, see: ::pwtk::coorToCartesian.
    return [coorToAtmPos [coorToCartesian $latvec [atmPosToCoor $atmPos]] $atmPos]    
}
#******


#****f* generic_struct_utils/::pwtk::barycenter
# SYNOPSIS
proc ::pwtk::barycenter {atmPos {listOfAtoms {}}} {
    # PURPOSE
    #   Return the barrycenter of atomic positions "atmPos". If the
    #   optional 'listOfAtoms' argument is specified, then only the
    #   barycenter of the specified atoms is calculated.
    #
    # ARGUMENTS
    # * atmPos -- atomic positions (atSym x y z [ix iy iz] per line)

    # * lisfOfAtoms -- [optional] list of atom indices for which to
    #                  calculate the barycenter (the first atoms has
    #                  the index of 1; list of atoms can also have a
    #                  symbolic compact syntax supported by
    #                  ::pwtk::parseRangeString).  If not specified,
    #                  the barycenter of all the atoms is calculated.
    #
    # SOURCE

    set atmPos [purifyCoor $atmPos]
    set nat    [getNAtoms $atmPos]

    # get the list of atoms for which to calculate the barycenter
    
    if { $listOfAtoms ne {} } {
        set sortedList [lsort -integer -increasing [::pwtk::parseRangeString $listOfAtoms $nat]]
    } else {
        set sortedList [seq 1 $nat]
    }

    # check that indices are in range

    foreach index $sortedList { ::pwtk::int_in_range1_ $index $nat }

    # get the listed atoms

    set atmPosList [split $atmPos \n]    
    foreach ind $sortedList { lappend coorL [lindex $atmPosList $ind-1] }

    # calculate the barycenter
    
    lassign {0. 0. 0.} mx my mz
    unset nat 
    foreach atom $coorL {
        lassign $atom atm x y z
        set mx [expr $mx + $x]
        set my [expr $my + $y]
        set mz [expr $mz + $z]
        incr nat
    }
    ifset nat 1; # just in case if $atmPos == {}
    return [lmap m "$mx $my $mz" {expr $m/double($nat)}]
}
#******


#****f* generic_struct_utils/::pwtk::atmPosTo
# SYNOPSIS
proc ::pwtk::atmPosTo {atmPos x0 y0 z0} {
    # PURPOSE
    #   Shift atomic positions "atmPos" such that the barycenter is at "x0 y0 z0".
    # ARGUMENTS
    # * atmPos -- atomic positions (atSym x y z [ix iy iz] per line)
    # * x0 y0 z0 -- point where to shift the barycenter to
    # RETURN VALUE
    #   Shifted atomic positions
    # SOURCE
    
    lassign [barycenter $atmPos] mx my mz
    return [shiftAtmPos -$mx+$x0 -$my+$y0 -$mz+$z0 $atmPos]
}
#******


#****f* generic_struct_utils/::pwtk::atmPosToBarycenter
# SYNOPSIS
proc ::pwtk::atmPosToBarycenter {atmPos} {
    # PURPOSE
    #   Shift atomic positions "atmPos" such that barycenter is at "0 0 0".
    # ARGUMENTS
    # * atmPos -- atomic positions (atSym x y z [ix iy iz] per line)    
    # RETURN VALUE
    #   Shifted atomic positions.
    # SOURCE

    return [::pwtk::atmPosTo $atmPos 0.0 0.0 0.0]
}    
#******


#****f* generic_struct_utils/::pwtk::boundingBox
# SYNOPSIS
proc ::pwtk::boundingBox {atmPos} {
    # PURPOSE
    #   Get the bounding box of the atomic positions "atmPos" (useful
    #   for molecules).
    # ARGUMENTS
    # * atmPos -- atomic positions (atSym x y z [ix iy iz] per line)    
    # RETURN VALUE
    #   Bounding box as a list of "xmin xmax  ymin ymax  zmin zmax".
    # SOURCE

    foreach i {1 2 3} {
        set min($i) +1e20
        set max($i) -1e20
    }
    foreach atom [split [purifyCoor $atmPos] \n] {
        incr ia
        lassign $atom atm tau(1,$ia) tau(2,$ia) tau(3,$ia)
        foreach i {1 2 3} {
            if { $tau($i,$ia) < $min($i) } { set min($i) $tau($i,$ia) }
            if { $tau($i,$ia) > $max($i) } { set max($i) $tau($i,$ia) }
        }
    }    
    return [list $min(1) $max(1) $min(2) $max(2) $min(3) $max(3)]
}
#******


#****f* generic_struct_utils/::pwtk::boxSize
# SYNOPSIS
proc ::pwtk::boxSize {atmPos} {
    # PURPOSE
    #   Return the edge lengths of the "atmPos" molecular bounding box.
    # RETURN VALUE
    #   The box edge lengths as the "size_x size_y size_z" list.
    # SOURCE
    
    lassign [boundingBox $atmPos]  min(1) max(1) min(2) max(2) min(3) max(3)
    foreach i {1 2 3} { lappend result [expr $max($i) - $min($i)] }
    return $result
}
#******


#****f* generic_struct_utils/::pwtk::boxify
# SYNOPSIS
proc ::pwtk::boxify {atmPos a {b ""} {c ""}} {
    # PURPOSE
    # Return the edge lengths of the orthorhombic box that
    # encapsulates the "atmPos" molecular structure with the margins
    # (vacuum) a, b, c along thre x, y, z direction.
    #
    # The margins a, b, c can be specified as 1, 2, or, 3 numbers:
    # * 1 number  = a ("cubic" margins a,a,a)
    # * 2 numbers = a c ("tetragonal" margins a,a,c)
    # * 3 numbers = a b c ("orthorhombic" margins a,b,c)
    # RETURN VALUE
    #   The box edge lengths as the "size_x size_y size_z" list (aka
    #   orthorhombic A, B, C parameters).    
    # SOURCE
    
    lassign [boxSize $atmPos] s(1) s(2) s(3)
    
    # orthorhombic: a b c    
    lassign "$a $b $c" l(1) l(2) l(3)

    if { $l(2) eq {} } {
        # cubic: a a a        
        set l(3) [set l(2) $l(1)]
    }
    if { $l(3) eq {} } {
        # tetragonal: a a c
        set l(3) $l(2)
        set l(2) $l(1)
    }

    foreach i {1 2 3} { lappend result [expr $s($i) + $l($i)] }
    return $result
}
#******


#****f* generic_struct_utils/::pwtk::boxifyCell
# SYNOPSIS
proc ::pwtk::boxifyCell {atmPos a {b ""} {c ""}} {
    # PURPOSE
    #   Similar to ::pwtk::boxify but instead of the box edge lengths
    #   the orthorhombic cell parameters are returned as:
    #      size_x  0.0  0.0
    #      0.0  size_y  0.0
    #      0.0  0.0  size_z
    # SOURCE

    return [m2cell [matricize [join [boxify $atmPos $a $b $c] x] ]]
}
#******



#****f* generic_struct_utils/::pwtk::formatCoor
# SYNOPSIS
proc ::pwtk::formatCoor {coor} {
    # PURPOSE
    #   Format the coordinates (Coor) for pretty printout.
    # ARGUMENT
    # * coor -- atomi coordinates in the form:
    #
    #      symb x y z
    #      ...
    # or
    #      symb x y z  fx fy fz
    #      ...        
    # SOURCE
    variable fmt_coor
    set result ""
    foreach line [split $coor \n] {
        set len [llength $line]
        if { $len == 4 || $len == 7 } {            
            append result [format $fmt_coor($len) {*}$line]
        }
    }
    return $result
}
#******


#****f* generic_struct_utils/::pwtk::formatAtmPos
# SYNOPSIS
proc ::pwtk::formatAtmPos {atmPos} {
    # PURPOSE
    #   Format the atomic positions (AtmPos) for pretty printout.
    # ARGUMENT
    # * atmPos -- atomi positions in the form:
    #
    #      symb x y z
    #      ...
    # or
    #      symb x y z  if_pos(x) if_pos(y) if_pos(z)
    #      ...        
    # SOURCE
    variable fmt_atmPos
    set result ""
    foreach line [split $atmPos \n] {
        set len [llength $line]
        if { $len == 4 || $len == 7 } {
            append result [format $fmt_atmPos($len) {*}$line]
        }
    }
    return $result
}
#******
