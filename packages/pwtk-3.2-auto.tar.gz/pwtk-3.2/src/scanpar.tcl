#
# $RCSfile: scanpar.tcl,v $ --
#
#      This file contains utility commands for performing scan
#      calculations and tabulating & plotting the corresponding
#      results, in particular, commands: scanpar, write, finish, plot,
#      multiplot, heatmap, and splot.
#
# Copyright (c) 2023-2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: scanpar.tcl,v 1.3 2023/02/03 17:00:01 kokalj Exp $ 
#


#****f* 5.8. Parameter Scans/::pwtk::scanpar
# SYNOPSIS
proc ::pwtk::scanpar {paramName values script} {
    # USAGE    
    #   ::pwtk::scanpar paramName values script
    #
    # ARGUMENTS
    # * paramName --- name of the parameter to scan
    # * values  --- list of parameter values to scan
    # * script  --- script to execute for each value of the parameter
    #
    # DESCRIPTION    
    #   The 'scanpar' command is analogous to a one-parameter Tcl
    #   "foreach" command and has a similar syntax, but (1) it keeps
    #   track of the scanned parameter to make the creation of
    #   datafiles a bit easier, and (2) uses input data stacking
    #   (::pwtk::input::push_pop) to restore the input data after the
    #   completion of the scan.
    #
    #   Below are two examples using the "foreach" and "scanpar"
    #   commands that are analogous.
    #
    # EXAMPLES
    #   # to illustrate what "scanpar" does, we first do an example
    #   # using the "foreach" Tcl command, and then repeat the same
    #   # example using "scanpar"
    #
    #   # 1. using "foreach"
    #
    #   write ecut.dat "# columns are: ecut data"
    #   input_pushpop {
    #      foreach ecut {10 14 18 22} {
    #         SYSTEM "ecutwfc = $ecut"
    #         runPW scf.ecut$ecut
    #         write ecut.dat "$k [pwo_totene scf.ecut$ecut.out]"
    #      }
    #   }
    #   plot -xl "ecutwfc (Ry)" -yl "Total energy (Ry)" ecut.dat
    #
    #   # 2. the same example using "scanpar"
    #
    #   scanpar ecut {10 14 18 22} {
    #      SYSTEM "ecutwfc = $ecut"
    #      runPW scf.ecut$ecut
    #      write ecut.dat [pwo_totene scf.ecut$ecut.out]
    #   }
    #   plot -xl "ecutwfc (Ry)" -yl "Total energy (Ry)" ecut.dat
    #
    # EXPLANATION
    #   In both examples above, identical "ecut.dat" datafile is
    #   created, but with "scanpar", the 1st-line comment is
    #   automatically created and the parameter $k is not specified in
    #   the "write" command because "write" adds $k automatically as
    #   it knows which parameter(s) is (are) being scanned with
    #   "scanpar".
    #
    # SOURCE

    variable scanpar
    variable scanparList
    
    upvar $paramName par

    if { [info exists scanparList] && ($paramName in $scanparList) } {
        ::pwtk::error  "scanpar already scans the \"$paramName\" parameter, name of the parameter must be unique" 1
    }

    ifnotempty scanparList {
        set d_ ""
        foreach p $scanparList {
            upvar $p p_
            append pt "${d_}$p = ${p_}"
            set d_ {, }
        }
        print "${pt}: scanning the paramater \"$paramName\" for values:   [join $values {, }]\n"
    } else {
        print "Scanning the paramater \"$paramName\" for values:   [join $values {, }]\n"
    }
    
    lappend scanparList $paramName
    input_pushpop {
        foreach par $values {
            # save the current value of the parameter (used by "write" if
            # called within the script)
            set scanpar($paramName) $par
            set code [catch {uplevel 1 $script} result]
            if {($code != 0) && ($code != 4)} { 
                break 
            }
        }
    }
    set scanparList [lrange $scanparList 0 end-1]
    if { $scanparList eq {} } {
        unset scanparList
        unset scanpar($paramName)
    }
    
    if { ($code == 0) || ($code == 3) || ($code == 4) } {
        return $result
    }
    return -code $code $result
}
#******


#****f* 5.8. Parameter Scans/::pwtk::write
# SYNOPSIS
proc ::pwtk::write {args} {
    # USAGE
    #   ::pwtk::write ?-a? DATAFILE LINE
    #
    # OPTION
    # * -a       --- in the first call of write on a given datafile, open the datafile in append mode (default = "w", i.e., truncate-and-write)
    #
    # ARGUMENTS
    # * DATAFILE --- name of the file for writing the data
    # * LINE     --- line-of-data to write to the datafile
    #
    # PURPOSE    
    #   "write" writes a line-of-data to a data file. If "write" is
    #   executed within the "scanpar" loops, the content of the line
    #   is prefixed with the list of scanning parameters. For example,
    #   the snipptet:
    #
    #        scanpar k {4 8} {
    #           scanpar ecut {20 30} {
    #              write energy.dat [pwo_totene scf.k$k.ecut$ecut.out]
    #           }
    #        }
    #
    #   writes the lines in the form:  $k  $ecut  energy
    # 
    # SOURCE
    
    variable write_fid
    variable scanpar
    variable scanparList
    
    # parse args

    set narg 2
    set usage "?-a? datafile line"
    set options {
        {a "open the datafile in the append mode"}
    }
    parseOpt_
    set mode     [expr { $opt(a) ? "a" : "w"}]
    set datafile [lindex $args 0]
    set line     [lindex $args 1]

    # write to datafile
    
    ifnotexist write_fid($datafile) {
        set write_fid($datafile) [open $datafile $mode]
        if  { [info exists scanparList] } {
            # write the first line as a comment documenting what columns are"
            puts $write_fid($datafile) "# columns are: $scanparList data"
        }
    }
    if { [info exists scanparList] && [string trim $line] ne {} } {
        # do not write "$params {}" line
        foreach pn $scanparList {
            upvar $pn p
            ifexist p {
                append params "$p "
            } else {                
                ifexist scanpar($pn) {
                    append params "$scanpar($pn) "
                }
            }
        }
        set line [concat $params $line]
    }    
    puts $write_fid($datafile) $line
    flush $write_fid($datafile)
    return $datafile
}
#******


#****f* 5.8. Parameter Scans/::pwtk::finish
# SYNOPSIS
proc ::pwtk::finish {datafiles} {
    # USAGE
    #   ::pwtk::finish {DATAFILE1 ?DATAFILE2? ...}
    #
    # ARGUMENTS
    # * DATAFILE1 --- 1st datafile to close
    # * DATAFILE2 --- 2nd datafile to close
    # * ...
    #
    # PURPOSE    
    #   Close the channels associated with the supplied datafiles that
    #   were built with the "write" command. Its function is analogous
    #   to the Tcl "close" comand.
    #
    #   If a datafile is not associated with an open channel, nothing
    #   is done and no error is returned.
    #
    # SOURCE
    variable write_fid

    set closed 0
    foreach df $datafiles {
        ifexist write_fid($df) {
            flush $write_fid($df)
            close $write_fid($df)
            unset write_fid($df)
            print "Data were written to datafile:   $df"
            set closed 1
        }
    }
    if { $closed } { puts "" }
}
#******


#***internal...
proc ::pwtk::plotParseOpt_ {} {
    uplevel 1 {
        ::pwtk::gp::defaultCmdlineOpts_ plot options usage
        set usage "[fmtUsage_ $usage]  $arguments"
        set nargmin 1
        set nargmax -1        
        deprecatedOpts_ $::pwtk::gp::deprecated_options args
        parseOpt_
        ::pwtk::gp::checkCmdlineOpts_ opt
    }
}


#****f* 5.8. Parameter Scans/::pwtk::plot
# SYNOPSIS
proc ::pwtk::plot {args} {    
    # USAGE
    #   ::pwtk::plot ?PLOTTING-OPTIONS?  DATAFN1  ?DATAFN2? ...
    #
    #   where DATAFN1, DATAFN2, ... are either datafiles or functions to plot.
    #
    #   PLOTTING-OPTIONS are:
    #
    #     -xt  XTICS 
    #     -yt  YTICS 
    #     -x2t X2TICS 
    #     -y2t Y2TICS 
    #      
    #     -mx  MXTICS 
    #     -my  MYTICS 
    #     -mx2 MX2TICS 
    #     -my2 MY2TICS 
    #      
    #     -xl  XLABEL 
    #     -yl  YLABEL 
    #     -x2l X2LABEL 
    #     -y2l Y2LABEL 
    #      
    #     -xr  XRANGE 
    #     -yr  YRANGE 
    #     -x2r X2RANGE 
    #     -y2r Y2RANGE 
    #      
    #     -xf  XFORMAT 
    #     -yf  YFORMAT 
    #     -x2f X2FORMAT 
    #     -y2f Y2FORMAT 
    #      
    #     -tm TOP_MARGIN 
    #     -bm BOTTOM_MARGIN 
    #     -lm LEFT_MARGIN 
    #     -rm RIGHT_MARGIN 
    #
    #     -key   KEY
    #     -grid  GRID
    #     -title TITLE
    #
    #     -u USING 
    #     -w WITH 
    #     -x EXTRA 
    #      
    #     -out ROOTNAME
    #     -t   TERMINAL
    #     -s   PX,PY
    #     -v 
    #
    #   A more detailed description of PLOTTING-OPTIONS and ARGUMENTS is provided below.
    #
    # PURPOSE
    #   ::pwtk::plot plots data from one or more datafiles or functions on
    #   the same plot. If the datafiles were created with the
    #   ::pwtk::write command, they are closed prior to being plotted.
    #
    #   This is meant as a fast way of plotting simple data.
    #   For a more elaborate and configurable plotting, use the
    #   ::pwtk::gp::plot object-oriented interface instead.
    #
    #   For an example, see the example in ::pwtk::scanpar.
    #
    # PLOTTING OPTIONS
    # * -xt  XTICS  --- X-axis tics 
    # * -yt  YTICS  --- Y-axis tics 
    # * -x2t X2TICS --- X2-axis tics
    # * -y2t Y2TICS --- Y2-axis tics

    # * -mx  MXTICS  --- frequency of minor tics marks for X axis
    # * -my  MYTICS  --- frequency of minor tics marks for Y axis
    # * -mx2 MX2TICS --- frequency of minor tics marks for X2 axis
    # * -my2 MY2TICS --- frequency of minor tics marks for Y2 axis

    # * -xl  XLABEL  --- label for X axis
    # * -yl  YLABEL  --- label for Y axis
    # * -x2l X2LABEL --- label for X2 axis
    # * -y2l Y2LABEL --- label for Y2 axis

    # * -xr  XRANGE  --- X-axis range specified as MIN:MAX (where MIN and MAX are numbers)
    # * -yr  YRANGE  --- Y-axis range specified as MIN:MAX
    # * -x2r X2RANGE --- X2-axis range specified as MIN:MAX
    # * -y2r Y2RANGE --- Y2-axis range specified as MIN:MAX
    
    # * -xf XFORMAT   --- format for the X-axis numbers (in C syntax)
    # * -yf YFORMAT   --- format for the Y-axis numbers
    # * -x2f X2FORMAT --- format for the X2-axis numbers
    # * -y2f Y2FORMAT --- format for the Y2-axis numbers

    # * -tm TOP_MARGIN    --- top margin specs (aka Gnuplot's tmargin)
    # * -bm BOTTOM_MARGIN --- bottom margin (aka bmargin)
    # * -lm LEFT_MARGIN   --- left margin (aka lmargin)
    # * -rm RIGHT_MARGIN  --- right margin (aka rmargin)

    # * -key   KEY   --- key (or legend) containing a title for each plot in the graph
    # * -grid  GRID  --- grid, e.g., -grid {lt -1 dt (5,1,2,1)}
    # * -title TITLE --- title, e.g., -title {'This is title' font 'Arial,12'}

    # * -u USING   --- Gnuplot's "using" plot specs
    # * -w WITH    --- Gnuplot's "with" plot specs
    # * -x EXTRA   --- extra Gnuplot commands/configuration, e.g., -x {set title 'simple band structure'}

    # * -out ROOTNAME  --- rootname for the Gnuplot-script and,
    #                      for file terminals, the output image file
    # * -t TERMINAL --- terminal to plot to; possible terminals are those returned
    #                   by ::pwtk::gp::pwtk_terminals (file-terminals: eps, pdf, svg, png;
    #                   window-terminals: win, qt, wxt, x11).
    # * -s PX,PY    --- terminal size in pixels (default = 1200,800); ignored for EPS
    # * -v          --- visualize the generated plot file (for file terminals)

    #
    # ARGUMENTS
    # * DATAFN1 --- the 1st datafile or function to plot
    # * DATAFN2 --- the 2nd datafile or function to plot
    # * ...
    #
    # RETURN VALUE
    # * the name of the created image (for file terminals)
    # * an empty string (for non-file terminals)
    #
    # SOURCE

    variable write_fid
    
    # parse args
    set arguments "DATAFN1  ?DATAFN2? ..."
    plotParseOpt_
        
    ifnotempty opt(u) { set opt(u) "u $opt(u)" }
    ifset opt(xl) ''
    ifset opt(yl) ''
    
    # plot's name

    if { $opt(out) ne {} } {
        set head [headname $opt(out) .$opt(t)]
    } else {
        if { [llength $args] == 1 && [file exists $args] } {
            set head plot-[file tail [file rootname $args]]
        } else {
            set id [incr ::pwtk::gp::plot_id]
            set head plot-$id
        }
    }

    # plot
    
    finish $args
    
    foreach datafn $args {
        if { [file exists $datafn] } {
            # datafn is a file
            set with [expr { $opt(w) eq {} ? $::pwtk::gp::gp(datafile_with) : $opt(w) }]
            append plot "[squote $datafn] $opt(u) w $with, "
        } else {
            # datafn is a function, skip $opt(u)
            set with [expr { $opt(w) eq {} ? $::pwtk::gp::gp(function_with) : $opt(w) }]
            append plot "$datafn w $with, "
        }
    }
    set plot [string trim $plot {, }]

    set gp [::pwtk::gp::plot new -s $opt(s) $head.$opt(t)]
    $gp cmdlineOpts opt    
    $gp plot $plot

    return [::pwtk::gp::execDisplay_ $gp opt]
}
#******


#****f* 5.8. Parameter Scans/::pwtk::multiplot
# SYNOPSIS
proc ::pwtk::multiplot {args} {
    # USAGE
    #   ::pwtk::multiplot  ?PLOTTING-OPTIONS?  DATAFN_LIST1  ?DATAFN_LIST2? ...
    #
    #   where DATAFN_LIST1, DATAFN_LIST2, ... are lists of datafiles or functions to plot.    
    #
    # PLOTTING OPTIONS
    #   See ::pwtk::plot
    #
    # ARGUMENTS
    # * DATAFN_LIST1 --- list of datafiles and/or functions to plot in the 1st plot
    # * DATAFN_LIST2 --- list of datafiles and/or functions to plot in the 2nd plot
    # * ...
    #
    # PURPOSE
    #   ::pwtk::multiplot plots data as the multiplot. Each list of data
    #   (DATAFN_LIST) is plotted in a separate plot, i.e.,
    #   DATAFN_LIST1 in plot-1, DATAFN_LIST2 in plot-2, etc.
    #
    #   If the datafiles were created with the ::pwtk::write command,
    #   they are closed prior to being plotted.
    #
    #   This is meant as a fast way of plotting multi-plots. For a
    #   more elaborate and configurable multi-plotting, use the
    #   ::pwtk::gp::multiplot object-oriented interface instead.
    #
    # EXAMPLE    
    #   scanpar k [seq 2 2 8] {
    #      scanpar ecut [seq 10 4 30] {
    #         set head scf.k$k.ecut$ecut
    #         SYSTEM "ecutwfc = $ecut"
    #         K_POINTS (automatic) "$k $k $k   1 1 1"
    #         runPW $head
    #         write k.$k.dat [pwo_totene $head.out]
    #      }
    #   }
    #   
    #   # plot each datafile separately and also all of them together
    #   
    #   multiplot -xl "ecutwfc (Ry)" -yl "Total energy (Ry)" -u 2:3 \
    #             k.2.dat k.4.dat k.6.dat k.8.dat { k.2.dat k.4.dat k.6.dat k.8.dat }
    #
    # RETURN VALUE
    # * a list of created images (for file terminals)
    # * an empty string (for non-file terminals)
    #
    # SOURCE

    variable write_fid
   
    # parse args
    set arguments "DATAFN_LIST1  ?DATAFN_LIST2? ..."
    plotParseOpt_
    
    ifnotempty opt(u) { set opt(u) "u $opt(u)" }
    ifset opt(xl) ''
    ifset opt(yl) ''
    
    # plot's name

    if { $opt(out) ne {} } {
        set head [headname $opt(out) .$opt(t)]
    } else {
        set id [incr ::pwtk::gp::multiplot_id]
        set head multiplot-$id
    }

    # plot

    finish [concat {*}$args]

    set nplot 0
    foreach datafnList $args {
        foreach datafn $datafnList {
            if { [file exists $datafn] } {
                # datafn is a file
                set with [expr { $opt(w) eq {} ? $::pwtk::gp::gp(datafile_with) : $opt(w) }]
                append plot($nplot) "[squote $datafn] $opt(u) w $with, "
            } else {
                # datafn is a function, skip $opt(u)
                set with [expr { $opt(w) eq {} ? $::pwtk::gp::gp(function_with) : $opt(w) }]
                append plot($nplot) "$datafn w $with, "
            }
        }
        set plot($nplot) [string trim $plot($nplot) {, }]
        incr nplot
    }
    
    set gp [::pwtk::gp::multiplot new -o landscape -s $opt(s) auto $nplot $head.$opt(t)]
    $gp cmdlineOpts opt
    
    for {set i 0} {$i < $nplot} {incr i} {
        $gp plot $plot($i)
    }

    return [::pwtk::gp::execDisplay_ $gp opt]
}
#******


# internal...
proc ::pwtk::splotParseOpt_ {} {
    uplevel 1 {
        ::pwtk::gp::defaultCmdlineOpts_ splot options usage
        set usage "[fmtUsage_ $usage]  $arguments"
        set narg 1
        deprecatedOpts_ $::pwtk::gp::deprecated_options args
        parseOpt_
        ::pwtk::gp::checkCmdlineOpts_ opt        
    }    
}


#****f* 5.8. Parameter Scans/::pwtk::heatmap
# SYNOPSIS
proc ::pwtk::heatmap {args} {    
    # USAGE
    #   ::pwtk::heatmap  ?SPLOT-OPTIONS?  ?PLOTTING-OPTIONS?  DATAFN
    #
    #   where DATAFN is either a datafile or a function to plot.
    #
    #   For SPLOT-OPTIONS, see ::pwtk::splot.
    #   For PLOTTING-OPTIONS, see ::pwtk::plot.
    #    
    # SPLOT OPTIONS
    #   See ::pwtk::splot (N.B. the -type option is ignored).
    #
    # PLOTTING OPTIONS   
    #    See ::pwtk::plot
    #
    # ARGUMENT
    # * DATAFN --- datafile or function to plot
    #
    # PURPOSE
    # A fast way of making a heatmap from the x, y, f(x,y) tabulated
    # data. For a more elaborate and configurable 3D plotting, use the
    # ::pwtk::gp::splot object-oriented interface instead.    
    #
    # If the datafile was created with the ::pwtk::write command, it
    # is closed prior to being plotted.
    #
    # The PWTK's predefined color palettes can be accessed with the
    # -pal option. To invert a palette, use "-pal {PALETTE negative}",
    # where PALETTE is one of:
    #
    # image:pwtk-palette.png
    # 
    # Note that for PALETTE only a substring that uniquely identifies it is
    # required.  For example, "-pal pa" selects the "pale-rainbow" palette.
    #
    # RETURN VALUE
    # * the name of created image (for file terminals)
    # * an empty string (for other terminals)
    #
    # SOURCE

    variable write_fid

    # parse args
    ::pwtk::ignoredOpts_ -type $args
    set arguments "DATAFN"
    splotParseOpt_

    # plot's name

    if { $opt(out) ne {} } {
        set head [headname $opt(out) .$opt(t)]
    } else {
        if { [file exists $args] } {
            set head heatmap-[file tail [file rootname $args]]
        } else {
            set id [incr ::pwtk::gp::heatmap_id]
            set head heatmap-$id
        }
    }

    # datafile or function ?

    if { [file exists $args] } {
        # lastarg is a file
        finish $args
        set datafn [squote $args]
    } else {
        # lastarg is a function
        set datafn $args
    }

    # specific-options post-processing

    set gp [splotCreateConfigure_ map {l nosurf} opt $head]
    set with [concat w $opt(w) $opt(clw)]
    
    # plot
    
    if { $opt(contour) } {
        $gp plot [concat $datafn $opt(u), $datafn $opt(u) $with]
    } else {
        $gp plot [concat $datafn $opt(u)]
    }

    return [::pwtk::gp::execDisplay_ $gp opt]
}
#******



#****f* 5.8. Parameter Scans/::pwtk::splot
# SYNOPSIS 
proc ::pwtk::splot {args} {    
    # USAGE
    #   ::pwtk::splot  ?SPLOT-OPTIONS?  ?PLOTTING-OPTIONS?  DATAFN
    #
    #   where DATAFN is either a datafile or a function to plot.
    #
    #   SPLOT-OPTIONS are:
    #   
    #      -type TYPE
    #      -pal  PALETTE
    #      -i    INTERPOLATION
    #      -contour
    #      -cc   CONTOUR_COLOR
    #      -clw  CONTOUR_LINEWIDTH
    #   
    #      -zt   ZTICS
    #      -cbt  CBTICS
    #      -mz   MZTICS
    #      -mcb  MCBTICS
    #      -zl   ZLABEL
    #      -cbl  CBLABEL
    #      -zr   ZRANGE  
    #      -cbr  CBRANGE  
    #      -zf   ZFORMAT 
    #      -cbf  CBFORMAT 
    #
    #   For PLOTTING-OPTIONS, see ::pwtk::plot.
    #
    # SPLOT OPTIONS
    
    # Options specific for 3D surface plots:
    
    # * -type TYPE    --- type of the Gnuplot splot: surface | both (default = surface; "TYPE = both" means surface + heatmap)
    # * -pal PALETTE  --- color palette for the splot (PWTK has a dozen predefined palettes, see the image below)
    # * -i NX,NY      --- interpolation degree along X- and Y-axis
    #                     (default is set to auto-optimal interpolation)
    # * -contour      --- plot contours
    # * -cc  CONTOUR_COLOR --- assigns contour color
    # * -clw CONTOUR_LINEWIDTH --- contour linewidth

    # * -zt   ZTICS   --- Z-axis tics (aka ztics)
    # * -cbt  CBTICS  --- color-box tics (aka cbtics)
    
    # * -mz   MZTICS  --- frequency of minor tics marks for Z axis
    # * -mcb  MCBTICS --- frequency of minor tics marks for color box (CB)
    
    # * -zl   ZLABEL  --- Z-axis label
    # * -cbl  CBLABEL --- CB label
    
    # * -zr   ZRANGE  --- Z-axis range specified as MIN:MAX
    # * -cbr  CBRANGE --- CB range specified as MIN:MAX
    
    # * -zf   ZFORMAT --- format for the Z-axis numbers (in C syntax)
    # * -cbf  CBFORMAT --- format for the color box    
    #
    # PLOTTING OPTIONS   
    #    See ::pwtk::plot
    #
    # ARGUMENT
    # * DATAFN --- datafile or function to plot
    #
    # PURPOSE
    # A fast way of making an splot from the x, y, f(x,y) tabulated
    # data or an f(x,y) function. For a more elaborate 3D plotting,
    # use the ::pwtk::gp::splot object-oriented interface instead.
    #
    # If the datafile was created with the ::pwtk::write command, it
    # is closed prior to being plotted.
    #
    # The PWTK's predefined color palettes can be accessed with the
    # -pal option. To invert a palette, use "-pal {PALETTE negative}",
    # where PALETTE is one of:
    #
    # image:pwtk-palette.png
    #
    # Note that for PALETTE only a substring that uniquely identifies it is
    # required.  For example, "-pal pa" selects the "pale-rainbow" palette.
    #
    # RETURN VALUE
    # * the name of created image (for file terminals)
    # * an empty string (for non-file terminals)
    #
    # SOURCE

    variable write_fid

    # parse args
    set arguments "DATAFN"
    splotParseOpt_

    # plot's name

    if { $opt(out) ne {} } {
        set head [headname $opt(out) .$opt(t)]
    } else {
        if { [file exists $args] } {
            set head splot-[file tail [file rootname $args]]
        } else {
            set id [incr ::pwtk::gp::splot_id]
            set head splot-$id
        }
    }

    # datafile or function ?

    if { [file exists $args] } {
        # lastarg is a file
        finish $args
        set datafn [squote $args]
    } else {
        # lastarg is a function
        set datafn $args
    }

    # post-process specific options & create configured 'splot' object

    set gp [splotCreateConfigure_ $opt(type) l opt $head]
    set with [concat w $opt(w) $opt(clw)]
    
    # plot
    
    $gp plot [concat $datafn $opt(u) $with]

    return [::pwtk::gp::execDisplay_ $gp opt]
}
#******


# internal...
proc ::pwtk::splotCreateConfigure_ {type w optName head} {
    # PURPOSE
    #   1. Postprocess a few specific 'splot' options
    #   2. Create a configured ::pwtk::gp::splot object
    #
    # ARGUMENTS
    # * type -- $opt(type) for ::pwtk::splot and 'map' for ::pwtk::heatmap
    # * w    -- default value for opt(w)
    # * optName -- name of 'opt' array
    # * head -- rootname for splot image
    #
    # SOURCE
    
    upvar $optName opt

    set opts ""
    ifnotempty opt(pal) { append opts "[list -pal $opt(pal)] " }
    ifnotempty opt(cc)  { append opts "[list -cc $opt(cc)] " }
    if { ! $opt(contour) } { append opts "-nocontour " }
    
    ifnotempty opt(u)   { set opt(u)   "u $opt(u)" }
    ifset opt(w) $w 

    set gp [::pwtk::gp::splot new -type $type -s $opt(s) {*}$opts $head.$opt(t)]
    $gp cmdlineOpts opt

    return $gp
}
