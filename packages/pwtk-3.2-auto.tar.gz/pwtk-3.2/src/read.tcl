#
# $RCSfile: read.tcl,v $ --
#
#      This file contains a few auxiliary routines used by
#      load_from**I set of commands that read QE input files.
#
# Copyright (c) 2021  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: read.tcl,v 1.2 2021/05/04 05:50:01 tone Exp $ 
#

#****f* Internals/::pwtk::getNonEmptyLine
# SYNOPSIS
proc ::pwtk::getNonEmptyLine {fileChannel} {
    # PURPOSE
    #   Read the first non-empty line from the file-channel.
    # SOURCE
    uplevel "::fnml::readline_ $fileChannel"
}
#******

#****f* Internals/::pwtk::firstWord
# SYNOPSIS
proc ::pwtk::firstWord {line} {
    # PURPOSE
    #   Return the first word from the line where delimiter for words
    #   is either space or comma (usefull for parsing namelists from
    #   input, where  &INPUT,var=value ... / is allowed.
    # SOURCE
    
    return [lindex [split [string trim $line] {, }] 0]
}
#******

#****f* Internals/::pwtk::readNamelists
# SYNOPSIS
proc ::pwtk::readNamelists {inputFile namelistList {must_exist 0}} {
    # PURPOSE
    #   Read namelists from the QE input file and return them in the
    #   PWTK syntax.
    #
    #   This routine is used internally by PWTK in load_from*** set of commands.
    #
    # ARGUMENTS
    # * inputFile -- QE input file to read
    # * namelistList -- list of namelists to read
    # * must_exist -- (optional) must the namelists exist (default = no)
    #
    # SOURCE
    
    set fid [open $inputFile r]
    set output {}
    
    foreach nml $namelistList {
        seek $fid 0 start
        set nmlContent [::fnml::getContent $nml $fid $must_exist 0]
        if { $nmlContent != {} } {
            append output "[string toupper $nml] { $nmlContent }\n"
        }
    }
    close $fid
    
    return $output
}
#******


#****f* Internals/::pwtk::readNml
# SYNOPSIS
proc ::pwtk::readNml {fileChannel nmlOrigName {nmlPWTKname {}} {must_exist 0} {match_first 0}} {
    # PURPOSE
    #   Read the namelist from the fileChannel of e.g. opened QE input
    #   file, return its content in the PWTK syntax, and increment
    #   fileChannel to the point just after the namelist.
    #
    #   This routine is used internally by PWTK in load_from*** set of commands.
    #
    # ARGUMENTS
    # * fileChannel -- QE input file to read
    # * nmlOrigName -- name of the namelist to read from the fileChannel
    
    # * nmlPWTKname  -- (optional) if not empty, replace nmlOrigName with 
    #                  nmlPWTKname in the returned PWTK formated namelist.
    
    # * must_exist -- (optional) must the namelists exist (default = no)

    # * match_first -- (optional) if true then the first non-empty
    #                  line must start with the $nmlName word (default = 0)
    #
    # SIDE EFFECTS
    #   If namelist is not present an error will be raised.
    #
    # RETURN VALUE
    #   Namelist in the PWTK syntax, e.g.,: NAMELIST { ... }
    #
    # SOURCE
        
    if { $nmlPWTKname eq {} } {
        set nmlName [string toupper $nmlOrigName]
    } else {
        set nmlName [string toupper $nmlPWTKname]
    }

    set nmlContent [::fnml::getContent $nmlOrigName $fileChannel $must_exist $match_first]
    if { $nmlContent ne {} } {
        return "$nmlName { [string trim $nmlContent] }\n"
    } else {
        return ""
    }
}
#******


#****f* Internals/::pwtk::readNml_w_affix
# SYNOPSIS
proc ::pwtk::readNml_w_affix {fileChannel nmlOrigName {nmlPWTKname {}} {nmlList {}} {cardList {}} {must_exist 0} {match_first 0}} {
    # PURPOSE
    #   Read the namelist.affix from the fileChannel of an opened QE
    #   input file and return its content in the PWTK syntax. The
    #   fileChannel is incremented to the point just after the namelist.
    #
    #   This routine is used internally by PWTK in load_from*** set of commands.
    #
    # ARGUMENTS
    # * fileChannel -- QE input file to read
    # * nmlOrigName -- name of the namelist to read from the fileChannel

    # * nmlPWTKname  -- (optional) if not empty, replace
    #                  nmlOrigName with nmlPWTKname in the returned PWTK
    #                  formated namelist

    # * nmlList -- (optional) list of namelist names (use to query
    #              the end of affix); if empty, the affix card is assumed to
    #              extend till the EOF
    
    # * cardList -- (optional) list of card names (use to query
    #              the end of affix); if empty, 
    
    # * must_exist -- (optional) must the namelists exist (default = no)

    # * match_first -- (optional) if true then the first non-empty
    #                  line must start with the $nmlName word (default = 0)    
    #
    # REMARK
    #   If both nmlList and cardList are empty, the affix card is
    #   assumed to extend till the EOF.
    #
    # SIDE EFFECTS
    #   If namelist is not present an error will be raised if $must_exist == true
    #
    # RETURN VALUE
    #   Namelist with affix in the PWTK syntax, e.g.,:
    #      NAMELIST { ... } { ... }    if affix exists
    #   or
    #      NAMELIST { ... } { ... }    otherwise
    #
    # SOURCE

    # read the namelist
    
    if { $nmlPWTKname eq {} } {
        set nmlName [string toupper $nmlOrigName]
    } else {
        set nmlName [string toupper $nmlPWTKname]
    }
    set nmlContent [::fnml::getContent $nmlOrigName $fileChannel $must_exist $match_first]
    # N.B. if the namelist is not found, $fileChannel is at [eof],
    # hence affix will be {}, which is correct !
    
    # prepare for reading the affix
    
    set nml_re  [::pwtk::nmlL2regexp $nmlList]
    set card_re [::pwtk::cardL2regexp $cardList]

    # read till the EOF or the first keyword
    
    set affix {}
    set offset [tell $fileChannel]
    while { ! [eof $fileChannel] } {
        set line [::pwtk::getNonEmptyLine $fileChannel]
        set first [::pwtk::firstWord $line]

        if { ($nml_re ne {} && [regexp -nocase $nml_re $first]) \
                 || ($card_re ne {} && [regexp $card_re $first]) } {
            seek $fileChannel $offset
            break
        }
        append affix $line\n
        set offset [tell $fileChannel]        
    }
    
    if { $affix ne {} } {
        return "$nmlName { [string trim $nmlContent] } { [string trim $affix] }\n"
    } else {
        if { $nmlContent ne {} } {
            return "$nmlName { [string trim $nmlContent] }\n"
        } else {
            return ""
        }
    }
}
#******

#****f* Internals/::pwtk::readCards
# SYNOPSIS
proc ::pwtk::readCards {inputFile cardList {closingKeywordList {}}} {
    # PURPOSE
    #   Read cards from the QE input file and return them in the
    #   PWTK syntax.
    #
    #   This routine is used internally by PWTK in load_from*** set of commands.
    #
    # WARNING
    #   This routine assumes that card-keywords are case sensitive in
    #   QE input files (i.e. ATOMIC_POSITIONS != atomic_positions)
    #
    #   This routine also implicitly assumes that cards are specified
    #   after the namelists, which is the recipe explicitly followed
    #   by QE. If instead namelists are specified after the cards in
    #   the input file, this routine will fail to correctly parse the
    #   cards from the input.
    #
    # ARGUMENTS
    # * inputFile -- QE input file to read
    # * cardList -- list of cards to read
    # * closingKeywordList -- list of keywords that are used to close the 
    #                         cards (e.g. ENDRULES, END_POSITIONS, ...)
    #
    # SOURCE
    if { $cardList eq {} } {
        return ""
    }
    foreach card $cardList {
        # BEWARE: for closed cards, card may consist of "card closingKeywordList"
        lassign $card card close
        lappend cards $card
    }
    set card_re  [::pwtk::cardL2regexp $cards]
    set close_re [::pwtk::cardL2regexp $closingKeywordList]

    set output  {}
    set inside_card 0

    foreach line [split [::pwtk::readFile $inputFile] \n] {
                
        set line [string trim $line]
	set word [lindex $line 0]
        
	if { [regexp $card_re $word] } {
	    if { $inside_card } {
		append output "\}\n"
	    }
	    append output "$word [lrange $line 1 end] \{\n"
	    set inside_card 1	    
	    continue
	}
        if { $close_re != {} && [regexp $close_re $word] } {
	    if { $inside_card } {
		# close the card
		append output "\}\n"
	    }
	    set inside_card 0
	    continue
	}
        
        if { $inside_card && ! [regexp {^#|^!} $word] } {
            append output $line\n
	}
    }
    
    if { $inside_card } {
        # close the last card
        append output "\}\n"
    }

    return $output    
}
#******
