#
# mopdos.tcl 
#
#      This file contains routines for calculating and ploting MOPDOS,
#      i.e., DOS projected to molecular orbitals with molecularpdos.x.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#


#****f* MOPDOS/::pwtk::mopdos_run
# SYNOPSIS
proc ::pwtk::mopdos_run {args} {
    # PURPOSE
    #   A very configurable workflow for calculating and plotting DOS
    #   projected to molecular orbitals (aka MOPDOS).
    #
    #   The workflow requires minimal input data specs for
    #   moleculardos.x (see the example below). In particular, all
    #   i_atmwfc_* and i_bnd_* variables are automatically assigned by
    #   the workflow itself.    
    #
    # USAGE
    #   ::pwtk::mopdos_run  ?SPECIFIC-OPTIONS?  ?PLOTTING-OPTIONS?  HEAD  MOLECULE  MOLATOMS
    #
    #   where SPECIFIC-OPTIONS are:
    #
    #       -scf
    #       -nscf KGRID
    #       -e    EFERMI
    #       -emin EMIN
    #       -emax EMAX
    #
    #       -homo HOMO_INDEX 
    #       -mo   MO_INDICES 
    #       -molatoms   MOL_ATOMS 
    #       -otheratoms OTHER_ATOMS 
    #       -mollab     MOL_LABEL 
    #       -otherlab   OTHER_LABEL
    #
    #  PLOTTING-OPTIONS:
    #
    #       -top 
    #       -descend 
    #       -yrel  YREL 
    #       -rymax RYMAX 
    #       -ylp   Y_LABEL_PDOS 
    #       -lx    LABEL_X_POS 
    #       -ly    LABEL_Y_POS
    #
    #       -out   ROOTNAME
    #       -w_dw  WITH 
    #       -w_mol WITH 
    #       -w_mol_dw WITH 
    #       -fc    FILLCOLOR 
    #       -fc_dw FILLCOLOR 
    #       -fc_mol FILLCOLOR 
    #       -fc_mol_dw FILLCOLOR
    #
    #
    #   For other PLOTTING-OPTIONS, see: ::pwtk::plot.
    #   Ignored PLOTTING-OPTIONS: -u

    # ARGUMENTS
    # * HEAD --- the name of the whole structure;
    #            the corresponding files will be named as prefix.$HEAD.postfix    
    # * MOLECULE --- the name of the molecule;
    #                the corresponding files will be named as prefix.fragment_$MOLECULE.postfix
    # * MOLATOMS --- indices of molecular atoms in the whole structure
    #
    
    # SPECIFIC OPTIONS
    # * -scf   --- perform an SCF pw.x calculation of the whole structure (the Fermi energy is
    #              taken from this SCF calculation unless the -nscf or -e option is specified)
    
    # * -nscf {K1 K2 K3  ?SK1 SK2 SK3?} ---
    #                   perform NSCF pw.x calculation of the whole structure using the
    #                   provided automatic k-point grid;
    #                   if SK1,SK2,SK3 shifts are omitted, a non-shifted k-mesh is used;
    #                   (the Fermi energy is taken from this NSCF calculation unless the -e option is specified)

    # * -e EFERMI  --- Fermi energy (either a floating-point number or a pw.x output file
    #                  from where the Fermi energy is taken)
    
    # * -emin EMIN --- the minimum-energy with respect to Fermi energy (in eV) to be
    #                  used for projwfc.x & molecularpdos.x, i.e., Emin is set to: Emin = EMIN + Efermi

    # * -emax EMAX --- the maximum-energy with respect to Fermi energy (in eV) to be
    #                  used for projwfc.x & molecularpdos.x, i.e., Emax x is set to: Emax = EMAX + Efermi

    # * -homo HOMO_INDEX --- index of the molecular HOMO orbital
    #                        (if specified, MOs are labeled as ...HOMO-2 HOMO-1, HOMO, LUMO, LUMO+1...;
    #                         otherwise, MOs are labeled as MO-1, MO-2...
    
    # * -mo   MO_INDICES --- indices of MOs used for DOS projections
    #                        (default = all molecular MOs)
    
    # * -molatoms   MOL_ATOMS --- a subset of molecular atoms used for PDOS plot
    #                             (default = MOLATOMS)    
    # * -otheratoms OTHER_ATOMS --- a subset of atoms of the rest of the structure used for PDOS plot
    #                               (default = all atoms - MOLATOMS)
    
    # * -mollab     MOL_LABEL --- a molecular label in PDOS plot (default = mol)
    # * -otherlab   OTHER_LABEL --- a label for the rest of the structure in PDOS plot (default = other)

    # PLOTTING OPTIONS
    # * -top     --- plot MOPDOS above PDOS (default = bottom, i.e., PDOS above MOPDOS)
    # * -descend --- plot MO projections in descending order from top to bottom (default = ascend)
    
    # * -yrel  YREL  --- relative Y-size of PDOS plot wrt single MOPDOS plot
    # * -rymax RYMAX --- relative YMAX (i.e. upper bound of Y-range) wrt maximum-MOPDOS for MOPDOS
    # * -ylp   Y_LABEL_PDOS --- Y-label for PDOS (default = PDOS; N.B. -yl is used for MOPDOS)
    # * -lx    LABEL_X_POS  --- relative X position of MO labels in the MOPDOS plot
    # * -ly    LABEL_Y_POS  --- relative Y position of MO labels in the MOPDOS plot

    # * -out   ROOTNAME  --- rootname for the Gnuplot-script and, for file terminals,
    #                        the output image file (default = the value of the HEAD argument)
    # * -w_dw  WITH --- Gnuplot's "with" plot specification for the 'other' spin-down PDOS
    # * -w_mol WITH --- Gnuplot's "with" plot specification for the 'molecular' PDOS
    # * -w_mol_dw WITH --- Gnuplot's "with" plot specification for the 'molecular' spin-down PDOS
    # * -fc    FILLCOLOR --- fill color for the 'other' *DOS filledcurve (e.g. -fc {lt 1} or -fc {fc "cyan"})
    # * -fc_dw FILLCOLOR --- fill color for the 'other' spin-down *DOS filledcurve
    # * -fc_mol FILLCOLOR    --- fill color for the 'molecular' *DOS filledcurve          
    # * -fc_mol_dw FILLCOLOR --- fill color for the 'molecular' spin-down *DOS filledcurve
    #
    
    # For other PLOTTING OPTIONS, see ::pwtk::plot
    #

    # DESCRIPTION
    #   The workflow's sequence of jobs is:
    #
    #      pw.x SCF (optional, requested by -scf)
    #       |
    #      pw.x NSCF (optional, requested by -nscf)
    #       |
    #      projwfc.x
    #       |
    #       +-- pw.x SCF (molecule only)
    #       |
    #       +-- projwfc.x (molecule only)
    #       |
    #      moleculardos.x
    #       |
    #      PLOTTING
    #
    #   This workflow makes two plots:
    #   * PDOS plot with projections to 'molecule' and to the rest of the structure (nicknamed as 'other')
    #   * MOPDOS plot with projections to molecular orbitals
    #
    #   DEFAULTS
    #   * PDOS is plotted above MOPDOS (to revert the order, use the -top option).

    #   * MO projections to all molecular MOs are plotted;
    #     to project to a subset of MOs, use the -mo option

    #   * MOs are labeled as MO-1, MO-2...;
    #     to label MOs wrt HOMO, use the -homo option (in this case,
    #     MOs will be labeled as ...HOMO-1, HOMO, LUMO, LUMO+1...).
    
    #   * MO projections are plotted in ascending order from top to bottom,
    #     i.e., low MOs at the top, high MOs at the bottom
    #     (use the -descend option to revert the order).

    #   * For 'molecular' PDOS, all atoms specified by MOLATOMS are used,
    #     and for 'other' "all - MOLATOMS" atoms are used. To use a subset of
    #     the corresponding atoms, use the -molatoms and -otheratoms options.
    
    #
    # EXAMPLE
    #   load_fromPWI scf.CO-Pt111.in
    #
    #   set inp { ngauss = 0, degauss = 0.01, DeltaE  = 0.05 }
    #   PROJWFC $inp
    #   MOPDOS  $inp
    #
    #   mopdos_run -scf -nscf {8 8 8} -t png  $head
    #
    # RETURN VALUE
    #   Filename of the created MOPDOS plots (for file terminals) or the
    #   empty string (for window terminals).
    #
    # SOURCE

    printTitle MOPDOS_RUN "Running the MOPDOS workflow"
    print "Workflow options & arguments :  $args\n" 

    # parse command-line options & arguments
    
    mopdosParseOpts_

    print "Calculating projections onto selected molecular orbitals\nusing pw.x, projwfc.x, and molecularpdos.x codes"
    print $molInfo
    
    # calculate

    input_pushpop {        
        input_clear IONS CELL
        printTitle "Performing calculations of the whole structure"
        
        # SCF + NSCF & fetch Efermi
        SCF_NSCF_
        Efermi_

        # projwfc.x
        print PROJWFC "Performing projwfc.x calculation\n"
        set full_xml [PROJWFC_xml_ $head $opt(emin) $opt(emax) $Efermi]
        
        # calculate a molecule
        input_pushpop {
            printTitle "Performing calculations of the '$mol' fragment (aka molecule)"
            print SCF "Performing SCF pw.x calculation of the '$mol' fragment\n"
            
            CONTROL " calculation = 'scf', prefix = '$fragment' "
            ::pwtk::pwi::deleteAtoms $other_atoms
            runPW pw.$fragment.scf.in

            print PROJWFC "Performing projwfc.x calculation of the '$mol' fragment\n"
            # N.B. set prefix explicitly
            #      (otherwise the prefix of the whole structure would be used)
            PROJWFC " prefix = '$fragment' "
            set mol_xml [PROJWFC_xml_ $fragment]
        }
        
        # molecularpdos.x
        
        printTitle "Performing molecularpdos.x calculation"

        MOPDOS [subst {
            xmlfile_full = '$full_xml'
            xmlfile_part = '$mol_xml'
            fileout      = '$head.proj_to_$mol'
        }]
        if { $opt(emin) ne {} } { MOPDOS " Emin = $opt(emin)+$Efermi " }
        if { $opt(emax) ne {} } { MOPDOS " Emax = $opt(emax)+$Efermi " }
        
        # i_atmwfc_beg_full & i_atmwfc_end_full
        
        lassign [infoFromPRO_ $mol_atoms projwfc.$head.out] i_beg i_end
        
        print "Finding the first and last molecular states from projwfc.$head.out:
   * i_atmwfc_beg_full = $i_beg
   * i_atmwfc_end_full = $i_end\n"
        
        MOPDOS [subst {
            i_atmwfc_beg_full = $i_beg
            i_atmwfc_end_full = $i_end
        }]
        
        runMOLECULARPDOS molecularpdos.$head.in
    }
    printTitle "Projecting DOS"
    
    return [mopdosPlot_]
}
#******


#****f* MOPDOS/::pwtk::mopdos_plot
# SYNOPSIS
proc ::pwtk::mopdos_plot {args} {
    # USAGE
    #   ::pwtk::mopdos_plot  ?SPECIFIC-OPTIONS?  ?PLOTTING-OPTIONS?  HEAD  MOLECULE  MOLATOMS
    #
    # DESCRIPTION
    #   The usage of this command is fully analogous to ::pwtk::mopdos_run, but
    #   only plotting is performed (i.e. calculations are skipped).
    #
    #   This command requires the output files produced by ::pwtk::mopdos_run; also
    #   the QE input data used by ::pwtk::mopdos_run are needed.
    #
    # SEE
    #   ::pwtk::mopdos_run
    #
    # SOURCE
    
    printTitle MOPDOS_PLOT "Plotting MOPDOS"
    print "Options & arguments :  $args" 
    
    mopdosParseOpts_
    print $molInfo

    Efermi_
    return [mopdosPlot_]
}
#******


#****if* Internals/::pwtk::mopdos_spin
# SYNOPSIS
proc ::pwtk::mopdos_spin {mopdosFile} {
    # DESCRIPTION
    #    Query if $mopdosFile corresponds to spin-polarized case.
    #
    # RETURN VALUE
    # 1 -- if spin-polarized
    # 0 -- otherwise
    #
    # SOURCE
    
    fileMustExist $mopdosFile MOPDOS
    
    set fid [open $mopdosFile r]
    gets $fid line
    close $fid

    # format of spin-pol molecularpdos.x filout header:
    #
    #   0 1          2  3    4
    #   # ibnd_part  E (eV)  tot_up(E)  tot_dw(E)
    #     ...        ...     ...        ...
    
    if { [lindex $line 4] == "tot_up(E)" } {
        return 1
    }
    return 0
}
#******


# internal...
proc ::pwtk::mopdosParseOpts_ {} {
    # PURPOSE
    #   Parse the command line options for mopdos_run & mopdos_plot
    
    uplevel 1 {
        ::pwtk::gp::defaultCmdlineOpts_ plot options usage workflow

        ignoredOpts_ -u $args
        
        addOpts_ options usage {
            {scf         "perform an SCF calculation prior to the BANDS pw.x calculation"}
            {nscf.arg {} "the k-point grid for the optional NSCF pw.x calculation"}
            {e.arg    {} "Fermi energy (either a floating-point number or a pw.x output file from where the Fermi energy is taken"}
            {emin.arg {} "Emin for molecularpdos.x with respect to Fermi energy (in eV)"}
            {emax.arg {} "Emax for molecularpdos.x with respect to Fermi energy (in eV)"}

            {homo.arg       {} "index of the molecular HOMO orbital (if not given MO's are labeled as MO-1, MO-2...)"}
            {mo.arg         {} "indices of molecular orbitals to project to"}
            {molatoms.arg   {} "list of molecular atoms to project to in PDOS plot"}
            {otheratoms.arg {} "list of atoms of the rest of the structure to project to in PDOS plot"}
            {mollab.arg     mol   "label for the molecule in the PDOS plot"}
            {otherlab.arg   other "label for the \"other\" atoms in the PDOS plot"}

            {top            "plot MOPDOS at the top (default = bottom)"}
            {descend        "descending top-down order of MOPDOS plots (i.e higher states are plotted first, default = ascend)"}
            {yrel.arg  2.5  "relative Y-size of PDOS plot wrt single MOPDOS plot"}
            {rymax.arg 0.7  "relative YMAX (i.e. upper bound of Y-range) wrt maximum-MOPDOS for MOPDOS"}
            {ylp.arg  PDOS  "Y-label for PDOS (-yl is used for MOPDOS)"}
            {lx.arg    0.85 "relative X position of MO labels in the MOPDOS plot"}
            {ly.arg    0.5  "relative Y position of MO labels in the MOPDOS plot"}
            
            {w_dw.arg     {} "Gnuplot's \"with\" plot specification for the spin-down (MO)PDOS"}
            {w_mol.arg    {} "Gnuplot's \"with\" plot specification for molecular (MO)PDOS"}
            {w_mol_dw.arg {} "Gnuplot's \"with\" plot specification for the spin-down molecular (MO)PDOS"}

            {fc.arg        {} "fill color for the (MO)PDOS filledcurve"}
            {fc_dw.arg     {} "fill color for the spin-down (MO)PDOS filledcurve"}
            {fc_mol.arg    {} "fill color for the molecular (MO)PDOS filledcurve"}
            {fc_mol_dw.arg {} "fill color for the molecular spin-down (MO)PDOS filledcurve"}
        } {
            -scf {-nscf KGRID} {-e EFERMI} {-emin EMIN} {-emax EMAX}
            {-homo HOMO_INDEX} {-mo MO_INDICES} {-molatoms MOL_ATOMS} {-otheratoms OTHER_ATOMS} {-mollab MOL_LABEL} {-otherlab OTHER_LABEL}
            -top -descend  {-yrel YREL} {-rymax RYMAX} {-ylp Y_LABEL_PDOS} {-lx LABEL_X_POS} {-ly LABEL_Y_POS}
            {-w_dw WITH} {-w_mol WITH} {-w_mol_dw WITH}
            {-fc FILLCOLOR} {-fc_dw FILLCOLOR} {-fc_mol FILLCOLOR} {-fc_mol_dw FILLCOLOR} 
        }

        # N.B. do not assign a default value for -xl here; it is assigned in ::pwtk::dosPlot_
        setOpts_ options [subst {
            yl  MOPDOS
            yf  ''
            tm  0.5
            bm  3
            
            w        {$::pwtk::gp::gp(dos_with)}
            w_dw     {$::pwtk::gp::gp(dos_with_dw)}
            w_mol    {$::pwtk::gp::gp(dos_with_mol)}
            w_mol_dw {$::pwtk::gp::gp(dos_with_mol_dw)}

            fc    {$::pwtk::gp::gp(dos_fill_color)}
            fc_dw {$::pwtk::gp::gp(dos_fill_color_dw)}

            fc_mol    {$::pwtk::gp::gp(dos_fill_color_mol)}
            fc_mol_dw {$::pwtk::gp::gp(dos_fill_color_mol_dw)}            
        }]

        set narg 3
        set usage "[fmtUsage_ $usage]   HEAD  MOLECULE  MOLATOMS"
        parseOpt_

        checkOType_ -emin $opt(emin) double number
        checkOType_ -emax $opt(emax) double number
        checkOType_ -homo $opt(homo) integer number
        checkOType_ -mo         $opt(mo)         rangestring  "list of positive integer numbers (i.e. list of MO indices)"
        checkOType_ -molatoms   $opt(molatoms)   rangestring  "list of positive integer numbers (i.e. list of molecular atoms)"
        checkOType_ -otheratoms $opt(otheratoms) rangestring  "list of positive integer numbers (i.e. list of other atoms)"
        
        checkOTypeStrict_ -nscf  $opt(nscf) {numberlist nonnegint}  "list of non-negative integer numbers (i.e. automatic k-point grid specs)"
        checkOTypeStrict_ -yrel  $opt(yrel)  double number
        checkOTypeStrict_ -rymax $opt(rymax) double number
        checkOTypeStrict_ -lx    $opt(lx)    double number
        checkOTypeStrict_ -ly    $opt(ly)    double number
        
        if { ! [file exists $opt(e)] && ! [string is double $opt(e)] } {
            ::pwtk::error "expected a real number or a pw.x output file for the Fermi energy, but got \"$opt(e)" 1
        }
        ::pwtk::gp::checkCmdlineOpts_ opt

        # command-line arguments
        
        lassign $args head mol mol_atoms

        if { $opt(out) eq {} } {
            set plotname mopdos.$head
        } else {
            set plotname mopdos.[headname $opt(out) .$opt(t)]
        }

        set mopdos $head.proj_to_$mol.mopdos; # name of molecularpdos.x MOPDOS file
        set fragment fragment_${mol}.$head;   # rootname for molecular files
        set other    without_${mol}.$head;    # rootname for the rest of the structure
        
        set nat [::pwtk::pwi::getNAtoms]
        set mol_atoms   [lsort -unique -increasing -integer [parseRangeString $mol_atoms $nat]]
        set other_atoms [parseRangeStringNotIn $mol_atoms $nat]
        # check
        intlist_in_range1_ $mol_atoms $nat
        if { $other_atoms eq {} } {
            ::pwtk::error "no atoms in the rest of the structure" 1
        }

        ifempty opt(mollab) { set opt(mollab) $mol }
        ifempty opt(molatoms) { set opt(molatoms) $mol_atoms }
        ifempty opt(otheratoms) { set opt(otheratoms) $other_atoms }        

        if { $plotname ne $head } {
            set plotInfo "\n- plotting filenames:      $plotname.POSTFIX"
        }
        set molInfo "
Structure name:            $head
- files will be named as:  PREFIX.$head.POSTFIX[varvalue plotInfo]

Molecule's name:              $mol
Indices of molecular atoms:   $mol_atoms
Indices of other atoms:       $other_atoms
Rootname of molecular files:  $fragment
   - files will be names as:  PREFIX.$fragment.POSTFIX 
   - naming of the rest part:         $other.POSTFIX
"  
    }
}


# internal
proc ::pwtk::mopdosPlot_ {} {
    # PURPOSE
    #   Plot the MOPDOS

    # default = MOPDOS at the bottom (OPT: -top)
    # MOPDOS order: ASCEND (OPT: -descend)

    # some cmd-options and their meaning:
    #
    # * opt(ylp)     -- PDOS Y-label (-yl is used for MOPDOS)
    # * opt(homo)    -- index of HOMO orbital (if not given MO's are labeled as MO-$index)
    # * opt(top)     -- MOPDOS at the top
    # * opt(descend) -- descending top-down order of MOPDOS plot
    # * opt(yrel)    -- relative Y-size of PDOS plot wrt MOPDOS (default: 2)
    # * opt(rymax)   -- relative Y-range wrt max. MOPDOS
    
    uplevel 1 {
        # sum LDOSes for $mol_atoms & $other_atoms
        print LDOS "Projecting DOS to:"
        print      "- molecular atoms:  $opt(molatoms)\n        LDOS file:  $fragment.ldos\n
- other atoms:  $opt(otheratoms)\n    LDOS file:  $other.ldos\n"
        
        sumldos -f $head -n $opt(molatoms)   $fragment.ldos
        sumldos -f $head -n $opt(otheratoms) $other.ldos
        
        printTitle "Plotting the molecular-orbitals projected DOS"

        # DOS filledcurves are used only if one of -scf -nscf -e was specified
        
        if { !$opt(scf) && $opt(nscf) eq {} && $opt(e) eq {} } {
            # Efermi is unspecified
            ifset opt(xl) "Energy (eV)"
        } else {
            ifset opt(xl) "{\{/${::pwtk::gp::gp(font)}-Italic E\} − \{/${::pwtk::gp::gp(font)}-Italic E\}_F (eV)}"
            set dos_fill 1
        }

        # get info from the *.mopdos file
        
        array set info [infoFromMOPDOS_ $mopdos]

        # variables
        
        if { $opt(mo) eq {} } {
            set opt(mo) [seq $info(ibnd_min) $info(ibnd_max)]
        } else {
            set opt(mo) [lsort -unique -increasing -integer [parseRangeString $opt(mo) $info(ibnd_max)]]
        }
        
        set nproj [llength $opt(mo)]        
        set spin  [mopdos_spin $mopdos]
        set ymax  [expr $opt(rymax)*$info(dos_max)]
        set yrange {[-(spin*ymax):((1+spin)*nproj-spin)*ymax]}
        
        lassign [split $opt(xr) :] xmin xmax
        ifset xmin [expr $info(emin) - $Efermi]
        ifset xmax [expr $info(emax) - $Efermi]

        # sizes:
        #   PDOS   ~ yrel --> ps = yrel/(nproj+yrel)
        #   MOPDOS ~ nproj --> ms = 1 - yrel/(nproj+yrel)
        #   relative (screen) size of bottom margin: rbm ~ 0.15 (a guess)

        set ps [format %.3f [expr $opt(yrel)/($opt(yrel) + $nproj)]]
        set rbm 0.15
        
        # labels
        
        foreach i $opt(mo) {
            if { $opt(homo) eq {} } {
                set label($i) MO−$i
            } else {
                set di [expr $i - $opt(homo)]
                if { $di < 0 } {
                    set label($i) HOMO−[expr abs($di)]
                } elseif { $di == 0 } {
                    set label($i) HOMO
                } elseif { $di == 1 } {
                    set label($i) LUMO
                } else {
                    set label($i) LUMO+[expr $di-1]
                }
            }             
        }

        # PDOS_PLOT
        
        # -w -w_mol -fc -fc_mol
        ifexist dos_fill {
            set pdos_plot " \\
   '$other.ldos' u (\$1-Efermi):(\$1-Efermi <= 0.0 ? \$2 : 0/0) not w filledcurve y1=0.0 $opt(fc), \\
   '$fragment.ldos' u (\$1-Efermi):(\$1-Efermi <= 0.0 ? \$2 : 0/0) not w filledcurve y1=0.0 $opt(fc_mol), "
        }
        append pdos_plot " \\
   '$other.ldos' u (\$1-Efermi):(\$2) t '$opt(otherlab)' w $opt(w), \\
   '$fragment.ldos' u (\$1-Efermi):(\$2) t '$opt(mollab)' w $opt(w_mol)"        

        if { $spin } {
            # -w_dw -w_mol_dw -fc -fc_mol_dw
            ifexist dos_fill {
                append pdos_plot ", \\
   '$other.ldos' u (\$1-Efermi):(\$1-Efermi <= 0.0 ? -\$3 : 0/0) not w filledcurve y1=0.0 $opt(fc_dw), \\
   '$fragment.ldos' u (\$1-Efermi):(\$1-Efermi <= 0.0 ? -\$3 : 0/0) not w filledcurve y1=0.0 $opt(fc_mol_dw)"
            }
            append pdos_plot ", \\
   '$other.ldos' u (\$1-Efermi):(-\$3) not '$opt(otherlab)' w $opt(w_dw), \\
   '$fragment.ldos' u (\$1-Efermi):(-\$3) not '$opt(mollab)' w $opt(w_mol_dw)"
        }

        # MOPDOS_PLOT
        
        if { ! $opt(descend) } {
            # reorder opt(mo)
            set opt(mo) [lsort -decreasing -integer $opt(mo)]
        }
        
        foreach i $opt(mo) {
            incr ii
            set i1 [expr $ii - 1]
            
            set y    "\$3 + $i1*yspan"
            set y_dw "-\$4 + $i1*yspan"
            
            append mopdos_plot "\\
   '$mopdos' u (\$2-Efermi):(\$2-Efermi <= 0.0 && \$1 == $i ? $y: 0/0) not w filledcurve $opt(fc_mol), \\
   '$mopdos' u (\$2-Efermi):(\$1 == $i ? $y : 0/0) not w $opt(w_mol), "
            
            if { $spin } {
                append mopdos_plot "\\
   '$mopdos' u (\$2-Efermi):(\$2-Efermi <= 0.0 && \$1 == $i ? $y_dw : 0/0) not w filledcurve $opt(fc_mol_dw), \\
   '$mopdos' u (\$2-Efermi):(\$1 == $i ? $y_dw : 0/0) not w $opt(w_mol_dw), "                
            }

            append keys   "set label '$label($i)' at xkey,($i1+ly)*yspan left font ',$::pwtk::gp::gp(fontSize.nx1)'\n"
            append arrows "set arrow nohead from xmin,$i1*yspan to xmax,$i1*yspan lt -1\n"
        }        
        set mopdos_plot [string trim $mopdos_plot {, }]
        
        # create & configure Gnuplot object

        set ypad [xlabel_yoffset_ $opt(t)]
        
        set gp [::pwtk::gp::plot new -s $opt(s) $plotname.$opt(t)]
        $gp cmdlineOpts opt
        ifempty $opt(yt) { $gp unset ytics }
        $gp options [list xlabel "offset 0,$ypad" ylabel "offset 0.5"]
        $gp add "
Efermi = $Efermi

spin  = $spin
nproj = $nproj

# X-range
xmin = $xmin
xmax = $xmax
set xrange [rangequote xmin:xmax]

# Y-range
ymax  = $ymax
ymin  = -spin*ymax
yspan = ymax - ymin

# MO label position
lx = $opt(lx)
ly = $opt(ly)/(spin+1.0)
xkey = xmin + lx*(xmax-xmin)

# sizes and origin
rbm = $rbm

set multiplot
set origin 0.0,0.0
"
        if { $opt(top) } {
            # PDOS (bottom plot)
            
            $gp add "# PDOS"
            $gp options [list size 1.0,rbm+$ps*(1-rbm) ylabel [squote $opt(ylp)]]
            $gp plot $pdos_plot

            # MOPDOS (top plot)

            $gp add "# MOPDOS"
            $gp options [list origin 0.0,rbm+$ps*(1-rbm) size 1.0,(1-$ps)*(1-rbm) bmargin 0 ylabel [squote $opt(yl)] yrange [rangequote $yrange] format.x '']
            $gp unset xlabel ytics
            $gp add $arrows
            $gp add $keys
            $gp plot $mopdos_plot
            
        } else {
            # MOPDOS (bottom plot)
            
            $gp add "# MOPDOS"
            $gp unset ytics
            $gp options [list size 1.0,rbm+(1-$ps)*(1-rbm) yrange $yrange]
            $gp add $arrows
            $gp add $keys
            $gp plot $mopdos_plot
                         
            # PDOS (top plot)
            
            $gp add "# PDOS"            
            ifnotempty opt(yt) { $gp set ytics $opt(yt) }
            $gp options [list origin 0.0,rbm+(1-$ps)*(1-rbm) size 1.0,$ps*(1-rbm) bmargin 0 ylabel [squote $opt(ylp)]  format.x '']
            $gp unset xlabel yrange arrow label
            $gp plot $pdos_plot
        }

        ::pwtk::gp::execDisplay_ $gp opt
    }
}


# internal...
proc ::pwtk::PROJWFC_xml_ {name {Emin {}} {Emax {}} {Efermi {}}} {
    # PURPOSE
    #   Perform projwfc.x calculation and return the full pathname of
    #   the atomic_proj.xml file

    PROJWFC " filpdos = '$name' "
    EminEmax_ $Emin $Emax $Efermi PROJWFC
    runPROJWFC projwfc.$name

    set prefix [::pwtk::input::namelistGetVarValue CONTROL prefix trim]
    ifset prefix pwscf

    set xml [file join [outdir_query -hard] $prefix.save atomic_proj.xml]
    fileMustExist $xml "projwfc.x atomic_proj.xml"                

    return $xml
}


# internal...
proc ::pwtk::infoFromMOPDOS_ {moprojFile} {
    # PURPOSE
    #   Read the molecularpdos.x *.mopdos file and extract the basic info.
    # RETURN VALUE
    #   Info returned as a list of key-value pairs suitable for "array set".
    
    fileMustExist $moprojFile "molecularpdos.x *.mopdos"

    set ibnd_min 100000
    set ibnd_max 0
    set emin +1e10
    set emax -1e10
    set dos_max 0.0    

    set fid [open $moprojFile r]
    while { [gets $fid line] >= 0 } { 
        if { ! [regexp {^\s*$} $line] } {
            # non-empty line
            lassign $line ibnd E dos dos_dw
            if { [string index $ibnd 0] ne "#" } {
                if { $ibnd < $ibnd_min } { set ibnd_min $ibnd }
                if { $ibnd > $ibnd_max } { set ibnd_max $ibnd }
                if { $E < $emin } { set emin $E }
                if { $E > $emax } { set emax $E }
                if { $dos > $dos_max } { set dos_max $dos }
                if { $dos_dw ne {} && $dos_dw  > $dos_max  } { set dos_max $dos_dw }
            }
        }
    }
    close $fid

    return [list ibnd_min $ibnd_min ibnd_max $ibnd_max emin $emin emax $emax dos_max $dos_max]
}


# internal ...
proc ::pwtk::infoFromPRO_ {mol_atoms proFile} {
    # PURPOSE
    #   determine i_atmwfc_beg_full & i_atmwfc_end_full based on
    #   $mol_atoms and projwfc.x output file
    #
    # RETURN VALUE
    #   The first and the last index of molecular states to be used
    #   for i_atmwfc_beg_full & i_atmwfc_end_full

    fileMustExist $proFile "projwfc.x output"

    # projwfc.x output:
    #
    #   state #   1: atom   1 (O  ), wfc  1 (l=0 m= 1)
    #   0     1   2  3      4
 
    foreach stateLine [::pwtk::egrep {^ +state #} $proFile] {
        set atom [lindex $stateLine 4]
        if { [lindex $stateLine 4] in $mol_atoms } {
            lappend states [string trim [lindex $stateLine 2] :]
        }
    }

    # check that states form a continuous sequence of indices

    if { ! [::pwtk::type::intseq $states] } {
        uplevel 1 [list ::pwtk::error "states belonging to molecular atoms does not form a continuous sequence\n- mol_atoms: $mol_atoms\n- states:    $states" 1]
    }

    return [list [lindex $states 0] [lindex $states end]]
}
