#
# $RCSfile: path.tcl,v $ --
#
#      This file contains some commands assosiated with the neb.x path files.
#
# Copyright (c) 2023-2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: path.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#


#****f* ::pwtk::path/::pwtk::path::nImages
# SYNOPSIS
proc ::pwtk::path::nImages {pathFile} {
    # PURPOSE
    #   Get the number of images in the 'pathFile' neb.x path file.
    # SOURCE
    
    ::pwtk::fileMustExist $pathFile "neb.x path file"

    set pathL [split [::pwtk::readFile $pathFile] \n]
    set ind [lsearch $pathL {NUMBER OF IMAGES*}]
    return [string trim [lindex $pathL $ind+1]]
}
#******


#****f* ::pwtk::path/::pwtk::path::energies
# SYNOPSIS
proc ::pwtk::path::energies {pathFile} {
    # PURPOSE
    #   Get total energies from the path file and identify the TS image.
    #
    # BEWARE
    #   Energies in the path file are in Hartrees
    #
    # ARGUMENTS
    # * pathFile -- neb.x path file
    # * index -- index of image for which to return the energy
    #
    # RETURN VALUE
    #   Dictionary with the following keys: nImages iTS Emax E(1) E(2)... E(nImage),
    #   where:
    #   * nImages -- number of images
    #   * iTS -- index of the TS image
    #   * Emax -- energy of the TS
    #   * E(1), E(2)... E(nImage) -- energies of images (nImage == number of images)
    #
    # SOURCE
    
    ::pwtk::fileMustExist $pathFile "neb.x path file"

    set iTS  1
    set Emax -1e20
    set pathL [split [::pwtk::readFile $pathFile] \n]

    set nImages [::pwtk::path::nImages $pathFile]

    foreach ind [lsearch -all $pathL Image:*] {
        incr i
        if { $i > $nImages } {
            # we are past the 'ENERGIES, POSITIONS AND GRADIENTS' section
            break
        }
        set E($i) [lindex $pathL $ind+1]
        if { $E($i) > $Emax } {
            set Emax $E($i)
            set iTS $i
        }
    }
    
    set result [dict create nImages $nImages iTS $iTS Emax $Emax]
    for {set i 1} {$i <= $nImages} {incr i} {
        dict append result E($i) $E($i)
    }
    return $result
}
#******


#****f* ::pwtk::path/::pwtk::path::energy
# SYNOPSIS
proc ::pwtk::path::energy {pathFile index} {
    # PURPOSE
    #   Get the index-th total energy from the neb.x path file.
    # ARGUMENTS
    # * pathFile -- neb.x path file
    # * index -- index of image for which to return the energy
    #
    # RETURN VALUE
    #   The total energy of the index-th image. If image is out of
    #   range, an empty string is returned.
    #
    # SOURCE

    set index [::pwtk::nebi::image_in_range_ $index [::pwtk::path::nImages $pathFile] ]
    return [dict get [::pwtk::path::energies $pathFile] E($index)]
}
#******


#****f* ::pwtk::path/::pwtk::path::getNAtoms
# SYNOPSIS
proc ::pwtk::path::getNAtoms {pathFile} {
    # PURPOSE
    #   Get number of atoms from the neb.x path file.
    # RETURN VALUE
    #   Number of atoms in the pathFile; if the pathFile is corrupt
    #   and the number of atoms cannot be determined, 0 is returned.
    # SOURCE

    ::pwtk::fileMustExist $pathFile "neb.x path file"    

    set ims [lsearch -all  [split [::pwtk::readFile $pathFile] \n]  Image:*]
    if { [llength $ims] == 0 } { return 0 }
    set i1  [expr [lindex $ims 0] + 2]
    set i2  [expr [lindex $ims 1] - 1]
    
    return [expr $i2 - $i1 + 1]
}
#******



#****f* ::pwtk::path/::pwtk::path::initialize
# SYNOPSIS
proc ::pwtk::path::initialize {pathFile} {
    # PURPOSE    
    #   Initialize the content of the NEB path file, such that neb.x
    #   considers it as a fresh path file as to force the calculation
    #   of all images.
    #
    #   This command is usually used only by PWTK internally.
    #    
    # RETURN VALUE
    #   The content of initialized path file.
    #
    # SOURCE
    
    set new_path  "RESTART INFORMATION
       0
       0
       0
"
    set ind 1
    foreach line [split [::pwtk::readFile $pathFile] \n] {
        if { $line != {} } {
            # replace ****************** that may appear in forces by zeros
            set line [regsub -all {\*\*\*+} $line 0.000000000000]
            if { $ind > 4 } {
                append new_path $line\n
            }
        }
        incr ind
    }
    return $new_path
}
#******

#****f* ::pwtk::path/::pwtk::path::fixAtoms
# SYNOPSIS
proc ::pwtk::path::fixAtoms {pathFile atomList {fixString "0 0 0"}} {
    # PURPOSE
    #   Similar to ::pwtk::path::relaxAtoms, but fixes instead of
    #   relaxes atoms (i.e. default fixString = {0 0 0})
    # SOURCE
    return [::pwtk::path::relaxAtoms $pathFile $atomList $fixString]
}
#******


#****f* ::pwtk::path/::pwtk::path::relaxAtoms
# SYNOPSIS
proc ::pwtk::path::relaxAtoms {pathFile atomList {relaxString "1 1 1"}} {
    # PURPOSE
    #   Relax the specified atoms in the neb.x PATH file by setting
    #   if_pos(*) flags to 'relaxString'.
    #
    #   In the neb.x PATH file, all atoms have the if_pos(*) flags and
    #   fixing/relaxing of atoms needs to be specifically set.
    #
    #   The if_pos(*) flags of the atoms not in $atomList are not touched.
    #
    # ARGUMENTS
    # * pathFile  -- the neb.x PATH file
    # * atomList  -- list of atoms (indices) to be immobilized (list of atoms can also have a
    #                symbolic compact syntax supported by ::pwtk::parseRangeString)
    # * relaxString -- list of if_pos(:) values (optional, default = {1 1 1})
    #
    # RETURN VALUE
    #   None.
    #
    # SOURCE


    # check arguments

    ::pwtk::fileMustExist  $pathFile "neb.x PATH"

    set natoms   [::pwtk::path::getNAtoms $pathFile]
    set atomList [lsort -integer -unique [::pwtk::parseRangeString $atomList $natoms]]

    if { ! [::pwtk::type::numberlist binary -strict $relaxString] } {
        ::pwtk::error "expected a list of three binary numbers for relaxString, but got: $relaxString" 1
    }

    # read path file

    set im 0
    foreach line [split [::pwtk::readFile $pathFile] \n] {
        if { [lindex $line 0] eq "Image:" } {
            set im [lindex $line 1]
        }
        if { $im == 1 } {
            if { [llength $line] == 9 } {
                incr nat
                if { $nat in $atomList } {
                    # replace ****************** that may appear in forces by zeros
                    set line [regsub -all {\*\*\*+} $line 0.000000000000]

                    # fmt  = "(3(2X,F18.12),3(2X,F18.12),3(2X,I1))"
                    set line [format {  %18.12f  %18.12f  %18.12f  %18.12f  %18.12f  %18.12f  %1d  %1d  %1d} {*}[lrange $line 0 5] {*}$relaxString]
                }
            }
        }
        append new_path $line\n
    }

    ::pwtk::file_backup $pathFile
    writeFile $pathFile $new_path
    #return $new_path
}
#******


#****a* 5.6. Structural Utilities/nebi_struct_utils
# DESCRIPTION
# Routines for querying the neb.x structural data from the neb.x path file.
# 
#******

#****f* nebi_struct_utils/::pwtk::nebi::path2xsf
# SYNOPSIS
proc ::pwtk::nebi::path2xsf {pathFile} {
    # PURPOSE
    #   Transform "pathFile" into the XSF formatted data.
    #
    # BEWARE
    #   In the path-to-xsf conversion, the current neb.x input data
    #   are used for the Bravais lattice vectors and atomic symbols
    #   (hence 'pathFile' should be compatible with the current neb.x
    #   input data). For this reason, the command is implemented
    #   within the ::pwtk::nebi namespace.
    #
    # ARGUMENTS
    # * pathFile -- neb.x path file to tranform to XSF formatted data
    #
    # RETURN VALUE
    #   The XSF formatted data corresponding to pathFile.
    #
    # SOURCE
    
    set primVecs [::pwtk::pwi::getPrimVec angstrom]
    set nat      [::pwtk::input::namelistGetVarValue SYSTEM nat]
    set path_nat [::pwtk::path::getNAtoms $pathFile]

    if { $nat != $path_nat } {
        ::pwtk::error "cannot transform the neb.x '$pathFile path file into AXSF
because the current number of atoms ($nat) differ from the number of
atoms in the path file ($path_nat)" 1
    }
    
    foreach atm [::pwtk::nebi::getAtmSymbList] {
        set symb([incr ia]) $atm
    }

    #
    # convert the PATH file to the XSF file
    #
    set pd [open $pathFile r]
    
    while { ! [eof $pd] } {

        gets $pd line

        if { [regexp {NUMBER OF IMAGES} $line] } {

            gets $pd line
            set nimages [lindex $line 0]
	
            append result "ANIMSTEPS $nimages\n"
            append result "CRYSTAL\n"
            append result "PRIMVEC\n"
            append result $primVecs\n

        } elseif { [regexp {ENERGIES, POSITIONS AND GRADIENTS} $line] } {
            
            for {set ii 1} {$ii <= $nimages} {incr ii} {
                gets $pd line; # Image string
                gets $pd line; # energy

                append result "PRIMCOORD $ii\n"
                append result "$nat\n"

                for {set ia 1} {$ia <= $nat} {incr ia} {
                    gets $pd line

                    set x [expr {[lindex $line 0] * $::pwtk::bohr2angs}]
                    set y [expr {[lindex $line 1] * $::pwtk::bohr2angs}]
                    set z [expr {[lindex $line 2] * $::pwtk::bohr2angs}]
                    # make forces compatible with the neb.x AXSF files
                    set fx [expr {[lindex $line 3] / $::pwtk::bohr2angs}]
                    set fy [expr {[lindex $line 4] / $::pwtk::bohr2angs}]
                    set fz [expr {[lindex $line 5] / $::pwtk::bohr2angs}]
                    
                    append result [format $::pwtk::fmt_coor(7) $symb($ia) $x $y $z $fx $fy $fz]
                }
            }            
            # we are done
            close $pd
            return $result
        }
    }
    close $pd
    return ""
}
#******

#****f* nebi_struct_utils/::pwtk::nebi::path2imageAtmPos
# SYNOPSIS
proc ::pwtk::nebi::path2imageAtmPos {args} {
    # USAGE
    #   ::pwtk::nebi::path2imageAtmPos ?-k? ?-ifpos? pathFile index
    #
    # PURPOSE
    #   Get the atomic positions of the index-th image from the neb.x path file.
    #
    # BEWARE
    #   The current neb.x input data are used for atomic symbols
    #   (hence 'pathFile' should be compatible with the current neb.x
    #   input data). For this reason, the command is implemented
    #   within the ::pwtk::nebi namespace.
    #
    # OPTIONS
    # * -k ... precede atomic positions with the ATOMIC_POSITIONS keyword
    # * -ifpos ... return atmPos (symb x y z ifx ify ifz) instead of Coor (symb x y z)
    #
    # ARGUMENTS
    # * pathFile -- neb.x path file
    # * index -- index of image for which to return atomic positions
    #
    # SOURCE

    set narg 2
    set usage "pathFile index"
    set options {
        {k     "precede atomic positions with the ATOMIC_POSITIONS keyword"}
        {ifpos "return atmPos (symb x y z ifx ify ifz) instead of Coor (symb x y z)"}
    }
    ::pwtk::parseOpt_
    lassign $args pathFile index

    set pathL [split [::pwtk::readFile $pathFile] \n]
    set ims [lsearch -all $pathL Image:*]

    set nimages [llength $ims]
    set index [::pwtk::nebi::image_in_range_ $index $nimages]    
    
    set i1 [expr [lindex $ims $index-1] + 2]
    if { $index < $nimages } {
        set i2 [expr [lindex $ims $index] - 1]
    } else {
        # for index == nimages, the above recipe does not work for 'i2'
        set i1m [expr [lindex $ims $index-2] + 2]
        set i2m [expr [lindex $ims $index-1] - 1]
        set i2  [expr $i1 + $i2m - $i1m]
    }

    set natp [expr $i2 - $i1 + 1]
    set nati [::pwtk::nebi::getNAtoms]
    
    if { $natp != $nati } {
        ::pwtk::error "the number of input atoms ($nati) differ from the number of atoms in the path file ($natp);
cannot assign atomic symbols to atomic positions from the '$pathFile' path file" 1
    }
    
    set symbols [::pwtk::nebi::getAtmSymbList]
    set coor    [lrange $pathL $i1 $i2]

    if { $opt(k) } {
        set result "ATOMIC_POSITIONS (bohr)\n"
    }
    if { $opt(ifpos) } {
        append result [join [lmap s $symbols xyz $coor {
            format $::pwtk::fmt_atmPos(7) {*}[concat $s [lrange $xyz 0 2] [lrange $xyz 6 8]]
        }] ""]
    } else {
        append result [join [lmap s $symbols xyz $coor {
            format $::pwtk::fmt_atmPos(4) {*}[concat $s [lrange $xyz 0 2]]
        }] ""]
    }

    return $result
}
#******
