#
# dos.tcl 
#
#      This file contains routines for calculating and ploting total
#      DOS with dos.x.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#


#****f* DOS/::pwtk::dos_run
# SYNOPSIS
proc ::pwtk::dos_run {args} {
    # PURPOSE
    #   A configurable workflow for calculating and plotting total DOS.
    #
    # USAGE
    #   ::pwtk::dos_run  ?SPECIFIC-OPTIONS?  ?PLOTTING-OPTIONS?  HEAD
    #
    #   where SPECIFIC-OPTIONS are:
    #
    #       -scf
    #       -nscf KGRID
    #       -gap
    #       -intdos
    #       -e    EFERMI
    #       -emin EMIN
    #       -emax EMAX
    #
    #  PLOTTING-OPTIONS:
    #
    #       -out   ROOTNAME
    #       -w     WITH
    #       -w_dw  WITH
    #       -fc    FILL_COLOR
    #       -fc_dw FILL_COLOR
    #       -iw    WITH
    #       -itc   INTDOS_TEXTCOLOR
    #
    #   For other PLOTTING-OPTIONS, see: ::pwtk::plot.
    #   Ignored PLOTTING-OPTIONS: -u
    #
    # SPECIFIC OPTIONS
    # * -scf   --- perform an SCF pw.x calculation (the Fermi energy is taken
    #              from this SCF calculation unless the -nscf or -e option is specified)
    
    # * -nscf {K1 K2 K3  ?SK1 SK2 SK3?} ---
    #                   perform NSCF pw.x calculation using the provided automatic k-point grid;
    #                   if SK1,SK2,SK3 shifts are omitted, a non-shifted k-mesh is used;
    #                   (the Fermi energy is taken from this NSCF calculation unless the -e option is specified)

    # * -gap       --- report the band gap using the fixed-occupations pw.x calculation 
    #                  (either SCF, NSCF, or both, depending on the -scf & -nscf options);
    #                  if the input-data correpond to smearing or tetrahedra occupations,
    #                  PWTK additionally performs the fixed-occupations SCF and for -nscf also
    #                  fixed-occupations NSCF pw.x calculations, ensuring that pw.x
    #                  prints the line: "highest occupied, lowest unoccupied level (ev): ....";
    #                  N.B.: do not apply this option for metals
    
    # * -intdos    --- plot also integrated DOS

    # * -e EFERMI  --- Fermi energy (either a floating-point number or a pw.x output file
    #                  from where the Fermi energy is taken)
    
    # * -emin EMIN --- the minimum-energy with respect to Fermi energy (in eV) to be
    #                  used for dos.x, i.e., Emin of dos.x is set to: Emin = EMIN + Efermi
    
    # * -emax EMAX --- the maximum-energy with respect to Fermi energy (in eV) to be
    #                  used for dos.x, i.e., Emax of dos.x is set to: Emax = EMAX + Efermi

    # PLOTTING OPTIONS
    # * -out   ROOTNAME  --- rootname for the Gnuplot-script and, for file terminals,
    #                        the output image file (default = the value of the HEAD argument)
    # * -w     WITH      --- Gnuplot's "with" plot specs for the DOS
    # * -w_dw  WITH      --- Gnuplot's "with" plot specs for the spin-down DOS
    # * -fc    FILLCOLOR --- fill color for the DOS filledcurve (e.g. -fc {lt 1} or -fc {fc "cyan"})
    # * -fc_dw FILLCOLOR --- fill color for the spin-down DOS filledcurve
    # * -iw    WITH      --- Gnuplot's "with" plot specs for the Integrated DOS
    # * -itc   TEXTCOLOR --- textcolor of Integrated DOS label and y2tics
    #
    # For other PLOTTING OPTIONS, see ::pwtk::plot
    #
    # ARGUMENTS
    # * HEAD -- the rootname for files, which will be named as prefix.$HEAD.postfix
    #
    # DESCRIPTION
    #   Run a workflow of calculations to calculate and plot the dos.x
    #   DOS. The sequence of jobs is:
    #
    #      pw.x SCF (optional, requested by -scf)
    #       |
    #       +--> for -gap if needed: pw.x fixed-occupations SCF
    #      (|)                        |
    #       +<---------------------- pw.x fixed-occupations NSCF
    #       |
    #      pw.x NSCF (optional, requested by -nscf)
    #       |
    #      dos.x
    #       |
    #      PLOTTING
    #
    # BEWARE
    #   This workflow performs dos.x calculation, implying that
    #   an SCF (or *relax) pw.x calculation must be performed prior to
    #   using this workflow, unless the -scf option is specified,
    #   which performs such an SCF calculation.
    #
    # EXAMPLE
    #   load_fromPWI scf.$head.in
    #
    #   DOS { DeltaE  = 0.05 }
    #   dos_run -scf -nscf {8 8 8} -emin -10  -t png  $head
    #
    # RETURN VALUE
    #   Filenames of the created DOS plot (for file terminals) or the
    #   empty string (for window terminals).
    #
    # SOURCE

    printTitle DOS_RUN "Running the DOS workflow"
    print "Workflow options & arguments :  $args" 

    # pase command-line options
    
    dosParseOpts_

    # calculate

    input_pushpop {        
        input_clear IONS CELL
        
        # SCF + NSCF calcs & fetch Efermi
        SCF_NSCF_
        Efermi_

        # dos.x
        dosCalc_
    }

    # plot
    
    return [dosPlot_]
}
#******


#****f* DOS/::pwtk::dos_plot
# SYNOPSIS
proc ::pwtk::dos_plot {args} {
    # USAGE
    #   ::pwtk::dos_plot ?SPECIFIC-OPTIONS?  ?PLOTTING-OPTIONS?  HEAD
    #
    # DESCRIPTION
    #   The usage of this command is fully analogous to ::pwtk::dos_run, but
    #   the command skips calculations and only plots DOS.
    #
    #   This command requires the same QE input data as ::pwtk::dos_run, and
    #   the output files produced by ::pwtk::dos_run must exist.
    #
    # SEE
    #   ::pwtk::dos_run
    #
    # SOURCE
    
    printTitle DOS_PLOT "Plotting total DOS"
    print "Options & arguments :  $args\n" 

    dosParseOpts_
    fixedSCFsetup_
    Efermi_
    return [dosPlot_]
}
#******


#****if* Internals/::pwtk::dos_spin
# SYNOPSIS
proc ::pwtk::dos_spin {dosFile} {
    # DESCRIPTION
    #    Query if $dosFile corresponds to spin-polarized case.
    #
    # RETURN VALUE
    # 1 -- if spin-polarized
    # 0 -- otherwise
    #
    # SOURCE
    
    ::pwtk::fileMustExist $dosFile DOS
    
    set fid [open $dosFile r]
    gets $fid line
    close $fid

    # format of dos.x fildos header:
    #
    #   0  1 2      3
    #   #  E (eV)   dosup(E)     dosdw(E)   Int dos(E) EFermi =   12.792 eV
    #      ...      ...          ...        ...
    
    if { [lindex $line 3] == "dosup(E)" } {
        return 1
    }
    return 0
}
#******


# internal...
proc ::pwtk::SCF_NSCF_ {} {
    # PURPOSE
    #   Perform optional SCF + NSCF calcs for dos_run, pdos_run, and bands_run
    
    uplevel 1 {
        # setup
        
        if { $opt(nscf) ne {} } {
            lassign $opt(nscf) nk1 nk2 nk3 sk1 sk2 sk3
            ifset sk1 0
            ifset sk2 0
            ifset sk3 0
            set kgrid [list $nk1 $nk2 $nk3 $sk1 $sk2 $sk3]
        }

        ifset opt(gap) 0
        fixedSCFsetup_
        
        # pw.x SCF

        if { $opt(scf) } {
            print SCF "Performing requested SCF pw.x calculation\n"
            CONTROL { calculation = 'scf' }
            runPW pw.$head.scf
        }

        # pw.x fixed SCF + NSCF

        input_pushpop {
            if { $fixed_needed } {
                fixedSCF_NSCF_
            }
        }
        
        # pw.x NSCF

        if { $opt(nscf) ne {} } {
            print NSCF "Performing requested NSCF pw.x calculation using:"
            print      "\n   K_POINTS (automatic) { $nk1 $nk2 $nk3   $sk1 $sk2 $sk3 }\n"
            
            CONTROL { calculation = 'nscf' }
            K_POINTS (automatic) $kgrid
            runPW pw.$head.nscf
        }
    }
}


# internal...
proc ::pwtk::fixedSCFsetup_ {} {
    uplevel 1 {
        # in some cases, band-gap either cannot be calculated or PWTK
        # cannot handle it for some specific cases; in such cases, gap_ok = 0

        set gap_ok $opt(gap)
        set fixed_needed 0; # is the fixed SCF needed?

        if { $opt(gap) } {
            set occ [::pwtk::input::namelistGetVarValue SYSTEM -nocase occupations trim]
            switch -glob -- $occ {
                from_input {
                    ::pwtk::warning "cannot determine band gap for occupations = 'from_input'"
                    set gap_ok 0
                }
                smearing - tetrahedra* {
                    # magnetization ?
                    set nspin    [::pwtk::input::namelistGetVarValue SYSTEM -nocase nspin]
                    set noncolin [::pwtk::input::namelistGetVarValue SYSTEM -nocase noncolin]
                    set cmag     [::pwtk::input::namelistGetVarValue SYSTEM -nocase constrained_magnetization]
                    foreach i {1 2 3} {
                        ifset fmag [::pwtk::input::namelistGetVarValue SYSTEM -nocase fixed_magnetization($i)]
                    }
                
                    if { $nspin == 4 || [is_true $noncolin] } {
                        ::pwtk::warning "PWTK cannot yet determine band gap for noncollinear calculation"
                        set gap_ok 0
                    }
                    if { $cmag ne {} || $fmag ne {} } {
                        ::pwtk::warning "PWTK cannot yet determine band gap for constrained_magnetization/fixed_magnetization calculation"
                        set gap_ok 0
                    }
                    
                    set fixed_needed $gap_ok; # fixed is needed for smearing & tetrahedra* if $gap_ok
                    set opt(scf)     $gap_ok; # fixed needs opt(scf)

                    if { $gap_ok } {
                        infoMsg "for occupations = '$occ', the -gap option requires\nadditional fixed-occupations pw.x calculation"
                    }
                }
                fixed - {} {
                    set nbnd [::pwtk::input::namelistGetVarValue SYSTEM -nocase nbnd]
                    if { $nbnd eq {} } {
                        infoMsg "the 'nbnd' SYSTEM variable is not set;\nrequired by occupations = 'fixed' for calculating the band gap"
                    }
                }
            }
        }
    }
}


# internal...
proc ::pwtk::fixedSCF_NSCF_ {} {
    # N.B. this routine is called if $gap_ok
    uplevel 1 {
        if { ! [file exists pw.$head.scf.out] } {
            # just in case
            ::pwtk::warning "Cannot perform a fixed-occupations SCF calculation
because the 'pw.$head.scf.out' file does not exist.\n\nUse the -scf option."
            set gap_ok 0
            set fixed_needed 0
            
        } else {
            set nbnd   [::pwtk::pwo::nbnd pw.$head.scf.out]
            set totmag [::pwtk::pwo::totmag pw.$head.scf.out]
            
            print SCF "Performing requested fixed-occupations SCF pw.x calculation\n"        

            # for fixed-occupations use tot_magnetization instead of starting_magnetization
            
            foreach typ [::pwtk::pwi::getAtomicLabels] {
                SYSTEM "starting_magnetization($typ) ="
            }
            if { $nspin == 2 && $totmag ne {} } {
                set totmag [expr round($totmag)]
                infoMsg "setting tot_magnetization = $totmag"
                # magnetic fixed-occupations pw.x needs to be performed in a separate outdir directory
                set outdir [outdir_backup fixed]
                CONTROL " outdir = '$outdir' "
            }
            SYSTEM [subst {
                nbnd = $nbnd
                tot_magnetization = $totmag
                occupations =
                smearing =
                degauss =
            }]

            # SCF
            
            input_pushpop {
                ELECTRONS {
                    startingpot = 'file'
                    startingwfc = 'file'
                }
                runPW pw.$head.scf.fixed
            }

            # NSCF
            
            if { $opt(nscf) ne {} } {
                print NSCF "Performing requested fixed-occupations NSCF pw.x calculation using:"
                print      "\n   K_POINTS (automatic) { $nk1 $nk2 $nk3   $sk1 $sk2 $sk3 }\n"
                
                CONTROL { calculation = 'nscf' }
                K_POINTS (automatic) $kgrid
                runPW pw.$head.nscf.fixed
            }
        }
    }
}

# internal
proc ::pwtk::Efermi_ {} {
    # PURPOSE
    #   Get the Fermi energy for dos_plot, pdos_run, and bands_plot.
    # BEWARE
    #   This routine must be kept compatible with ::pwtk::SCF_NSCF_
    
    uplevel 1 {
        # pw.x SCF

        if { $opt(scf) } {
            set pwo pw.$head.scf.out
            if { [file exist $pwo] } {
                print "Fermi energy (from $pwo):          [::pwtk::pwo::efermi $pwo] eV"
            }
        }

        # pw.x fixed.SCF

        ifset fixed_needed 0
        if { $fixed_needed } {
            set pwo_gap pw.$head.scf.fixed.out
            if { [file exist $pwo_gap] } {
                print "Fermi energy (from $pwo_gap):    [::pwtk::pwo::efermi $pwo_gap] eV"
            }
        }
        
        # pw.x NSCF

        if { $opt(nscf) ne {} } {
            set pwo pw.$head.nscf.out
            if { [file exist $pwo] } {
                print "Fermi energy (from $pwo):         [::pwtk::pwo::efermi $pwo] eV"
            }
            
            if { $fixed_needed } {
                set pwo_gap pw.$head.nscf.fixed.out            
                if { [file exist $pwo_gap] } {
                    print "Fermi energy (from $pwo_gap):   [::pwtk::pwo::efermi $pwo_gap] eV"
                }
            }
        }

        ifexist pwo {
            fileMustExist $pwo "pw.x output file"
            set nbnd   [::pwtk::pwo::nbnd   $pwo]
            set Efermi [::pwtk::pwo::efermi $pwo]
            set Ehomo  $Efermi
            set Elumo  [::pwtk::pwo::elumo  $pwo]
        } else {
            set pwo {}
        }

        ifexist pwo_gap {
            fileMustExist $pwo_gap "pw.x output file"
            set Ehomo [::pwtk::pwo::efermi $pwo_gap]
            set Elumo [::pwtk::pwo::elumo  $pwo_gap]
                
            if { $Elumo > $Ehomo || $pwo eq {} } {
                set Efermi $Ehomo
                set pwo $pwo_gap
            }
        } else {
            set pwo_gap $pwo
        }

        # -e option (Fermi energy)

        if { [file exists $opt(e)] } {
            # pwoFile
            set pwo $opt(e)
            ifset pwo_gap $pwo
            set Efermi [::pwtk::pwo::efermi $pwo]
            if { ! [string is double -strict $Efermi] } {
                ::pwtk::warning "failed to get the Fermi energy (or highest occupied level) from the '$opt(e) file"
                set Efermi {}
            } else {
                print "Fermi energy (from $pwo):   $Efermi eV"

                ifnotexist Ehomo {
                    set Ehomo [::pwtk::pwo::efermi $opt(e)]
                    set Elumo [::pwtk::pwo::elumo  $opt(e)]
                }
                ifnotexist nbnd {
                    set nbnd [::pwtk::pwo::nbnd $pwo]
                }
            }
        } else {
            # number or empty string ?
            checkOType_ -e $opt(e) double "number or an existing pw.x output file"
            ifnotempty opt(e) {
                # number
                set pwo "from command line"
                set Efermi $opt(e)

                ifnotexist Ehomo {
                    set Ehomo $Efermi
                    set Elumo {}
                }
            }
        }

        if { ! [info exists Efermi] || $Efermi eq {} } {
            # unspecified Fermi energy, use 0.0
            set pwo "not set"
            set Efermi 0.0

            ifnotexist Ehomo {
                set Ehomo $Efermi
                set Elumo {}
            }
        }

        # report the Fermi energy that will be used for plotting
        
        if { [file exists $pwo] } {
            print "\nFor plotting, the Fermi energy from $pwo fill be used
Fermi energy (from $pwo):   $Efermi eV\n"
        } else {
            print "For plotting, the following Fermi energy fill be used
Fermi energy ($pwo):   $Efermi eV\n"
        }

        # report Band gap if requested & $gap_ok

        ifset gap_ok 0
        if { $gap_ok } {
            if { $Elumo ne {} } {
                set gap [expr $Elumo - $Ehomo]

                print "Band Gap (from $pwo_gap):
- highest occupied level (eV) :     $Ehomo
- lowest unoccupied level (eV):     $Elumo"

                if { $Elumo > $Ehomo} {
                    print "- band gap (eV)               :     [format %.4f $gap]\n"
                } else {
                    ::pwtk::warning "in the pw.x '$pwo_gap' output file:\n\n   lowest unoccupied level > highest occupied level"
                }

            } else {
                if { $pwo eq "not set" || $pwo eq "from command line" } {
                    ::pwtk::warning "cannot report the band gap without any of the -scf, -nscf, or -e FILE option"
                } else {
                    ::pwtk::warning "cannot report the band gap because too few bands were calculated;\nincrease the 'nbnd' variable in the SYSTEM namelist"
                }
                set gap_ok 0
            }
        }
    }
}


# internal
proc ::pwtk::dosPlot_ {} {
    # PURPOSE
    #   Plot the DOS

    uplevel 1 {
        print PLOT "Plotting the total DOS\n"

        # DOS filledcurves are used only if one of -scf -nscf -e was specified
        
        if { !$opt(scf) && $opt(nscf) eq {} && $opt(e) eq {} } {
            # Efermi is unspecified
            ifset opt(xl) "Energy (eV)"
        } else {
            ifset opt(xl) "{\{/${::pwtk::gp::gp(font)}-Italic E\} − \{/${::pwtk::gp::gp(font)}-Italic E\}_F (eV)}"
            set dos_fill 1
        }

        set ypad [xlabel_yoffset_ $opt(t)]
        set spin [dos_spin $dos]
    
        set gp [::pwtk::gp::plot new -s $opt(s) $plotname.$opt(t)]
        $gp cmdlineOpts opt
        $gp options [list xlabel "offset 0,$ypad" ylabel "offset 0.5"]
        ifempty opt(key) { $gp unset key }
        $gp add "Efermi = $Efermi"

        ifexist dos_fill {
            set plot "'$dos' u (\$1-Efermi):(\$1-Efermi <= 0.0 ? \$2 : 0/0) not w filledcurve y1=0.0 $opt(fc), "
        }
        append plot "'$dos' u (\$1-Efermi):(\$2) w $opt(w)"
        
        if { $spin } {
            ifexist dos_fill {
                append plot ", '$dos' u (\$1-Efermi):(\$1-Efermi <= 0.0 ? -\$3 : 0/0) not w filledcurve y1=0.0 $opt(fc_dw)"
            }
            append plot ", '$dos' u (\$1-Efermi):(-\$3) w $opt(w_dw)"            
        }
        if { $opt(intdos) } {
            # Integrated DOS
            $gp set ytics nomirror
            ifempty opt(y2t) { $gp set y2tics "autofreq textcolor $opt(itc)" }
            ifempty opt(y2l) { $gp set y2label "'Integrated DOS (electron)' textcolor $opt(itc)" }
            append plot ", '$dos' u (\$1-Efermi):(\$[expr 3+$spin]) axes x1y2 w $opt(iw)"
        }
        
        $gp plot $plot
        
        ::pwtk::gp::execDisplay_ $gp opt
    }
}


# internal...
proc ::pwtk::dosParseOpts_ {} {
    # PURPOSE
    #   Parse the command line options for dos_calc & dos_plot
    uplevel 1 {
        ::pwtk::gp::defaultCmdlineOpts_ plot options usage workflow
        
        ignoredOpts_ -u $args
        
        addOpts_ options usage {
            {scf         "perform an SCF calculation prior to the BANDS pw.x calculation"}
            {nscf.arg {} "the k-point grid for the optional NSCF pw.x calculation"}
            {gap         "report band gap using fixed-occupations pw.x calculation"}
            {intdos      "plot also integrated DOS"}
            {e.arg    {} "Fermi energy (either a floating-point number or a pw.x output file from where the Fermi energy is taken"}
            {emin.arg {} "Emin for dos.x with respect to Fermi energy (in eV)"}
            {emax.arg {} "Emax for dos.x with respect to Fermi energy (in eV)"}

            {w_dw.arg  {} "Gnuplot's \"with\" plot specs for the spin-down DOS"}
            {fc.arg    {} "fill color for the DOS filledcurve"}
            {fc_dw.arg {} "fill color for the spin-down DOS filledcurve"}
            {iw.arg    {} "Gnuplot's \"with\" plot specs for the Integrated DO"}
            {itc.arg   {} "textcolor of Integrated-DOS label"}

        } {
            -scf {-nscf KGRID} -gap  -intdos
            {-e EFERMI} {-emin EMIN} {-emin EMAX}
            {-w_dw WITH} {-fc FILL_COLOR} {-fc_dw FILL_COLOR} {-iw WITH} {-itc TEXTCOLOR}
        }

        # N.B. do not assign a default value for -xl here; it is assigned in ::pwtk::dosPlot_
        setOpts_ options [subst {
            yl    DOS
            w     {$::pwtk::gp::gp(dos_with)}
            w_dw  {$::pwtk::gp::gp(dos_with_dw)}
            fc    {$::pwtk::gp::gp(dos_fill_color)}
            fc_dw {$::pwtk::gp::gp(dos_fill_color_dw)}
            iw    {$::pwtk::gp::gp(intdos_with)}
            itc   {$::pwtk::gp::gp(intdos_text_color)}
        }]

        set narg 1
        set usage "[fmtUsage_ $usage]  HEAD"
        
        parseOpt_
        checkOType_ -nscf $opt(nscf) {numberlist nonnegint}  "list of non-negative integer numbers (i.e. automatic k-point grid specs)"
        checkOType_ -emin $opt(emin) double number
        checkOType_ -emax $opt(emax) double number

        ::pwtk::gp::checkCmdlineOpts_ opt

        set head [lindex $args end]
        set dos  $head.dos

        if { $opt(out) eq {} } {
            set plotname dos.$head
        } else {
            set plotname dos.[headname $opt(out) .$opt(t)]
        }
        print "Rootname for files:    $head
Plotting filenames:    $plotname.POSTFIX\n"
    }
}

# internal...
proc ::pwtk::dosCalc_ {} {
    # PURPOSE
    #   Perform DOS calculations for dos_run and bands_run
    uplevel 1 {
        if { [info exists opt(dos)] && $opt(dos) } {
            print DOS "Performing requested DOS dos.x calculation\n"
        } else {
            print DOS "Performing DOS dos.x calculation\n"
        }
        DOS " fildos = '$dos' "
        EminEmax_ $opt(emin) $opt(emax) $Efermi DOS
        runDOS dos.$head
    }
}


# internal...
proc ::pwtk::EminEmax_ {Emin Emax Efermi nmlName} {
    # PURPOSE
    #   Set Emin and Emax namelist variables as Emin = $Emin+$Efermi & Emax likewise

    if { $Efermi ne {} } {
        if { $Emin ne {} } {
            print "Setting the Emin value to $Emin eV below the Fermi energy (Emin = $Emin+$Efermi eV)"
            $nmlName " Emin = $Emin+$Efermi "
        }
        if { $Emax ne {} } {
            print "Setting the Emax value to $Emax eV below the Fermi energy (Emax = $Emax+$Efermi eV)"
            $nmlName " Emax = $Emax+$Efermi "
        }
        if { $Emin ne {} || $Emax ne {} } { puts "" }
    }
}
