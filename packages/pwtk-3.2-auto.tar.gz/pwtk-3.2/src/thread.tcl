#
# $RCSfile: thread.tcl,v $ --
#
#      This file contains the commands for managing PWTK threads,
#      which allows for scripts to run in parallel in the
#      background. The Tcl threading extension is used.
#
# Copyright (c) 2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: thread.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#

#****a* Background Execution/Threads
# DESCRIPTION
#   While 'run -bg' and 'runXX -bg' commands can only run executables
#   in background, threads instead can run script excerpts in parallel
#   asynchronously. Hence, they are a much more flexible way of a
#   background parallel execution than the 'run* -bg' commands.
#
#   The Tcl thread package is required to use threads in PWTK (N.B. the
#   Thread package is named 'tcl-thread' in Linux distros).
#
# WARNING
#   Note that bgs (aka backgrounds, see ::pwtk::bg) are safer to use
#   than threads because bgs are completely independent from one
#   another, whereas threads share some resources such as
#   current working directory and enviromental variables. If one
#   thread changes the current working directory, then that change
#   affects all threads.
#******

# internal...
proc ::pwtk::thread_initscript_ {} {
    # PURPOSE
    #   Return the init-script for a thread so that the loaded thread
    #   is "born" in correct state.

    return $::pwtk::pkg_init_script\n[uplevel 1 ::pwtk::propagate_dump]\nupdate
    
}

#*****if* Threads/::pwtk::thread_init
# SYNOPSIS
proc ::pwtk::thread_init {} {
    # PURPOSE
    #   Load the "Thread" package. This command is called inernally by
    #   the PWTK when the treads are used.
    
    variable thread

    ifexist thread(init) { return }
    
    try {
        package require Thread
    } on error err {
        ::pwtk::error "unable to use threads; cannot find the thread package

The \"tcl-thread\" package is required for PWTK to use threads.
For GNU/Linux Debian-based distributions, it can be installed as:

   sudo apt install tcl-thread

On Fedora-based distributions, the analogous command is:

   sudo dnf install tcl-thread
" 1
    }    
    set thread(init) 1
}
#******


#****f* Threads/::pwtk::thread
# SYNOPSIS
proc ::pwtk::thread {args} {
    # USAGE
    #   thread ?-r? script ?script? ?script ...?
    #
    # OPTIONS
    # * -r ... redirect stdout of this thread to a log file
    #          (the name of the logfile is thread.scriptName.id.log)
    #
    # PURPOSE
    #   Arranges for a script, which is formed by concatenating all
    #   the script arguments, to run in a new thread in the
    #   background.  Hence, the command returns immediately. To wait
    #   for threads to finish, use the ::pwtk::thread_wait command.
    #
    # WARNING
    #   Note that bgs (aka backgrounds, see ::pwtk::bg) are safer to use
    #   than threads because bgs are completely independent from one
    #   another, whereas threads share some resources such as
    #   current-working directory and enviromental variables. If one
    #   thread changes the current working directory, then that change
    #   affects all threads.
    #
    # ARGUMENTS
    #   The script to be executed in a new thread is formed by
    #   concatenating all the script arguments. For example, the
    #   following two examples are equivalent:
    #
    #      ::pwtk::thread print "I am a new thread"
    #
    #      ::pwtk::thread {
    #          print "I am a new thread"
    #      }
    #
    # RETURN VALUE
    # * the ID of the created thread (this ID can be used for the ::pwtk::thread_wait command)
    #
    # SOURCE
    
    variable thread

    thread_init    

    set redirect 0
    if { [lindex $args 0] eq "-r" } {
        set redirect 1
        set args [lrange $args 1 end]
    }
    if { [llength $args] == 1 } {
        set args [concat {*}$args]
    }

    incr thread(count)
        
    # create a new thread 

    #set id [::thread::create $thread(initcmd)]
    set id [::thread::create [::pwtk::thread_initscript_]]
    lappend thread(ids) $id

    set head [file tail [file rootname [info script]]]
    set log thread.$head.$thread(count).log

    print THREAD "Running a script in a new thread"
    print "
Thread No.$thread(count): ID = $id"    
    if { $redirect } {
        print "Output of thread-$id is redirected to a log file:  $log"
    }
    print "Script to run in this thread:\n\n[string trim $args]\n"

    # save the current input data state
    #set peekData [::pwtk::input::peek]
    #::thread::send -async $id [list ::pwtk::input::load_state $peekData]

    #set script [::pwtk::propagate_dump]\n$args; # N.B. ::pwtk::thread_initscript_ takes care of "propagate" now
    set script $args
    
    if { $redirect } {
        ::thread::send -async $id [list ::pwtk::redirect_stdout_to $log $script]
    } else {
        ::thread::send -async $id $script
    }

    return $id
}
#******

#****f* Threads/::pwtk::thread_id
# SYNOPSIS
proc ::pwtk::thread_id {} {
    # PURPOSE
    #   Return the ID of the last created PWTK thread or an empty
    #   string if no threads were created.
    #
    # SOURCE
    variable thread
    ifexist thread(ids) {
        return [lindex $thread(ids) end]
    } else {
        return ""
    }
}
#******


#****f* Threads/::pwtk::thread_ids
# SYNOPSIS
proc ::pwtk::thread_ids {} {
    # PURPOSE
    #   Return the IDs of all existing "alive" threads.
    # SOURCE

    variable thread

    set result ""
    foreach id [varvalue thread(ids)] {
        if { [::thread::exists $id] } {
            lappend result $id
        }
    }
    return $result
}
#******


#****f* Threads/::pwtk::thread_wait
# SYNOPSIS
proc ::pwtk::thread_wait {args} {
    # USAGE
    #   thread_wait ?thread_id? ?thread_id ...?
    #
    # PURPOSE
    #   Wait for the specified threads to finish.
    #
    #   If called without arguments, the command waits for all the
    #   treads to finish.
    #
    # ARGUMENTS
    # * args ... list of IDs of threads; an empty list implies all IDs
    #    
    # SOURCE

    variable time_interval_ms
    variable thread
    
    if { $args eq "" } {
        set args [thread_ids]
    }
    if { [llength $args] == 1 } {
        set args {*}$args
    }

    print "Waiting for the threads $args to finish ...\n"
    foreach id $args {
        while { [::thread::exists $id] } {
            after $time_interval_ms
        }
        # remove this thread from thread(ids)
        set thread(ids) [lsearch -inline -all -not -exact $thread(ids) $id]
    }
}
#******

## ***internal...
#proc ::pwtk::maxlines_ {text {maxline 10}} {
#    foreach line [split $text \n] {
#        incr nl
#        if { $nl <= $maxline } {
#            append result $line\n
#        } else {
#            append result ...\n
#            return $result
#        }
#    }
#    # if we came here the text has less than lines than $maxline
#    return $text
#}
