#
# $RCSfile: di.tcl,v $ --
#
#      This file contains the procs for handling the dos.x input.
#
# Copyright (c) 2019  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: di.tcl,v 1.2 2021/05/03 14:21:08 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::di_fprint {{file {}}} { uplevel ::pwtk::di::fprint $file }
proc ::pwtk::di_clear  {}          { uplevel ::pwtk::di::clear }
proc ::pwtk::di_get    {}          { uplevel ::pwtk::di::get }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::di/::pwtk::di::fprint
# SYNOPSIS
proc ::pwtk::di::fprint {{file {}}} {
# PURPOSE
#   Print the content of dos.x input data to a file or to stdout if the
#   file was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::di $file
}
#****


#****f* ::pwtk::di/::pwtk::di::get
# SYNOPSIS
proc ::pwtk::di::get {} {
    # DESCRIPTION    
    #   Return the content of the dos.x input 
    # SOURCE

    loadDefaults_
    
    return [::pwtk::input::namelistGet DOS]
}
#******
    

#****f* ::pwtk::di/::pwtk::di::clear
# SYNOPSIS
proc ::pwtk::di::clear {} {
    # DESCRIPTION    
    #   Clear the content of the dos.x input 
    # SOURCE
    variable input_flow_list
    
    foreach name $input_flow_list {
	::pwtk::input::clear $name
    }
}
#******
    

proc ::pwtk::di::loadDefaults_ {} {
    # load some default values, when user has omitted them 

    namespace eval ::pwtk::input {
	defaultVarValue_ DOS outdir  [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
	defaultVarValue_ DOS prefix  ""
    }
}


#****f* ::pwtk::di/::pwtk::di::load_fromDI
# SYNOPSIS
proc ::pwtk::di::load_fromDI {di {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing dos.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * di -- filename of the dos.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?
    #
    # SOURCE

    ::pwtk::fileMustExist $di "dos.x input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current dos.x input data ...
	::pwtk::input::clear DOS
    }

    # read the namelist

    set output [::pwtk::readNamelists $di $::pwtk::di::input_flow_list]

    # dos.x must contain a DOS namelist
    if { $output == "" } {
	::pwtk::error "input file \"$di\" does not appear to be a dos.x input file" 1
    }

    eval $output
    ::pwtk::input::namelists_ityp2atmSymb_ $::pwtk::di::input_flow_list
}
#******
