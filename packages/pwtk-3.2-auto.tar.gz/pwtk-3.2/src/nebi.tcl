#
# $RCSfile: nebi.tcl,v $ --
#
#      This file contains the procs for handling the neb.x input.
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: nebi.tcl,v 1.5 2021/05/03 14:21:08 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::nebi_fprint    {{file {}}} { uplevel ::pwtk::nebi::fprint $file }
proc ::pwtk::nebi_get       {}          { uplevel ::pwtk::nebi::get }
proc ::pwtk::nebi_clear     {}          { uplevel ::pwtk::nebi::clear }
proc ::pwtk::nebi_visualize {}          { uplevel ::pwtk::nebi::visualize }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::nebi/::pwtk::nebi::fprint
# SYNOPSIS
proc ::pwtk::nebi::fprint {{file {}}} {
    # PURPOSE
    #   Print the content of neb.x input data to a file or to stdout if the
    #   file was not specified.
    # ARGUMENTS
    #   * file -- [optional] filename to print to (default = stdout)
    # SOURCE

    ::pwtk::input::fprint_ ::pwtk::nebi $file
}
#****


#****f* ::pwtk::nebi/::pwtk::nebi::fprint_old
# SYNOPSIS
proc ::pwtk::nebi::fprint_old {{file {}}} {
    # PURPOSE
    #   Print the content of neb.x input data in old pw.x format (for
    #   QE-4.x) either to file or to stdout if the file was not specified.
    #
    # ARGUMENTS
    #   * file -- [optional] filename to print to (default = stdout)
    # SOURCE
    
    ::pwtk::input::pushpop {

	# to make old format work, we need this:
	CONTROL { calculation = 'neb' }
    
	# shift the PATH variables to IONS namelist   
	foreach var [::pwtk::input::namelistVars_ PATH] {
	    if { $::pwtk::input::namelist(PATH,var=$var) != "" } {
		IONS " $var = $::pwtk::input::namelist(PATH,var=$var) "
	    }
	}
	::pwtk::input::namelistClear PATH
        
        set first_image 0
        set tot_charge  0
        foreach line [split [get] \n] {
            
            if { [regexp {(BEGIN|END)} $line] } {
                # strip the BEGIN & END keywords
                continue
            }

            if { [regexp FIRST_IMAGE $line] } {
                set first_image 1
                continue
            }

            if { $first_image && [regexp ATOMIC_POSITIONS $line] } {
                append output $line\nfirst_image\n
                set first_image 0
                continue
            }

            if { ! $first_image && [regexp ATOMIC_POSITIONS $line] } {
                # skip ATOMIC_POSITIONS for further images
                continue
            }

            if { [regexp {(INTERMEDIATE_IMAGE|LAST_IMAGE)} $line] } {
                append output [string tolower $line]\n
                continue
            }

            if { [regexp TOTAL_CHARGE $line] } {
                # skip TOTAL_CHARGE keyword-line
                set tot_charge 1
                continue
            } elseif { $tot_charge } {
                # skip TOTAL_CHARGE value
                set tot_charge 0
                continue
            }
            
            append output $line\n    
        }

        if { $file == {} } {
            # print to stdout
            puts stdout $output
        } else {
            if { [::pwtk::backup_io] } {
                ::pwtk::file_backup $file
            }
            ::pwtk::writeFile $file $output
        }
    }
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::clear
# SYNOPSIS
proc ::pwtk::nebi::clear {} {
    # PURPOSE
    #   Clear the stored neb.x input data.
    # SOURCE

    variable input_flow_list
    
    ::pwtk::input::clear PATH CLIMBING_IMAGES POSITIONS    
}
#****


#****f* ::pwtk::nebi/::pwtk::nebi::get
# SYNOPSIS
proc ::pwtk::nebi::get {} {
    # PURPOSE
    #   Return the content of the neb.x input.
    # SOURCE

    variable input_flow_list
    variable all_atomic_species

    set all_atomic_species [::pwtk::input::cardGetContent ATOMIC_SPECIES]

    ::pwtk::input::pushpop {
        
        # check the ntyp vs ATOMIC_SPECIES compatibility
        
        if { [::pwtk::pwi::getNTyp] != [::pwtk::input::namelistGetVarValue SYSTEM ntyp] } {
            pwtk::infoMsg "ntyp and number of species specified in ATOMIC_SPECIES card are not equal;
filtering out unused atomic species"
        }
        
        # starting from QE v4.0, the pw.x aborts if unused atomic species
        # are specified, which is what we don't want: filter-out unused
        # species
        
        ATOMIC_SPECIES [::pwtk::pwi::filterAtomicSpecies ::pwtk::nebi::getAtmSymbList]
        SYSTEM " ntyp = [::pwtk::pwi::getNTyp] "
        
        # convenient feature: make a dummy call to ELECTRONS as this
        # namelist must be always present, even if it is empty
        
        ELECTRONS {}

        set    input_ "BEGIN\n"    
        append input_ "BEGIN_PATH_INPUT\n"
        append input_ [::pwtk::input::namelistGet PATH]
        append input_ [::pwtk::input::cardGet CLIMBING_IMAGES]
        append input_ "END_PATH_INPUT\n\n"
        
        append input_ "BEGIN_ENGINE_INPUT\n"
        # namelists
        foreach name $::pwtk::pwi::namelist_flow_list {	
            ::pwtk::pwi::loadDefaults_ $name
            append input_ [::pwtk::input::namelistGet $name]
        }
        
        # cards: 
        # strip ATOMIC_POSITIONS from ::pwtk::pwi::card_flow_list because
        # ATOMIC_POSITIONS are handled below
        
        set cards [regsub -all -- ATOMIC_POSITIONS $::pwtk::pwi::card_flow_list {}]
        foreach name $cards {
            ::pwtk::pwi::loadDefaults_ $name
            append input_ [::pwtk::input::cardGet $name]
        }
        
        if { [info exists ::pwtk::input::card(POSITIONS)] } {
            # NEB atomic positions are specified with nex syntax via POSITIONS { ... } card
            append input_ "BEGIN_POSITIONS\n"
            append input_ [::pwtk::input::cardGetContent POSITIONS]
            append input_ "END_POSITIONS\n"
        } else {
            # try with old pw.x syntax via ATOMIC_POSITIONS that use the "first_image", "intermediate_image", "last_image" ...
            append input_ "BEGIN_POSITIONS\n"
            append input_ [::pwtk::input::cardGetContent ATOMIC_POSITIONS]
            append input_ "END_POSITIONS\n"
        }
        
        append input_ "END_ENGINE_INPUT\n"    
        append input_ "END\n"
        
        set result $input_
    }
    # at this point, unfiltered ATOMIC_SPECIES are restored

    unset all_atomic_species
    
    return $result
}
#****


#****f* ::pwtk::nebi/::pwtk::nebi::visualize
# SYNOPSIS
proc ::pwtk::nebi::visualize {} {
    # PURPOSE
    #   Vizualize the structure from neb.x input file with xcrysden. If
    #   xcrysden is not detected, the input file is merely printed to
    #   stdout.
    #
    # SOURCE

    global env
    if { [info exists env(XCRYSDEN_TOPDIR)] || [auto_execok xcrysden] != "" } {
	set input [::fileutil::tempfile neb.]
	::pwtk::nebi::fprint_old $input
	catch {exec xcrysden --pwi $input}
    } else {
	# we don't have xcrysden: simply print the input to
	# stdout
	::pwtk::nebi_fprint
    }
}
#****


#****f* ::pwtk::nebi/::pwtk::nebi::load_fromNEBI
# SYNOPSIS
proc ::pwtk::nebi::load_fromNEBI {nebi {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing neb.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * nebi -- filename of the neb.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?
    #
    # SOURCE

    ::pwtk::fileMustExist $nebi "neb.x input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current neb.x input data ...
	::pwtk::nebi::clear
    }

    # neb.x input file must contain the PATH namelist

    if { [catch {::pwtk::readNamelists $nebi PATH 1}] } {
	::pwtk::error "input file \"$nebi\" does not appear to be a neb.x input file" 1
    }

    # parse namelists
    
    set output [::pwtk::readNamelists $nebi \
                    [concat $::pwtk::pwi::namelist_flow_list PATH]]

    # parse cards
    
    set pwi_cards [regsub ATOMIC_POSITIONS $::pwtk::pwi::card_flow_list {}]
    set card_re [join [concat $pwi_cards CLIMBING_IMAGES] |^]

    set inside_nml  0
    set inside_card 0
    
    foreach line [split [::pwtk::readFile $nebi] \n] {

	set word [::pwtk::firstWord $line]
	
	if { [regexp "^$card_re" $word] } {
	    if { $inside_card } {
		append output "\}\n"
	    }
	    append output "$word [lrange $line 1 end] \{\n"
	    set inside_card 1	    
	    continue
	}
	
	if { [regexp ^END_PATH_INPUT $word] } {
	    if { $inside_card } {
		# close the CLIMBING_IMAGES card
		append output "\}\n"
	    }
	    set inside_card 0
	    continue
	}

	# POSITIONS supercard
	
	if { [regexp ^BEGIN_POSITIONS $word] } {
	    if { $inside_card } {
		append output "\}\n"
	    }
	    append output "POSITIONS \{\n"
	    set inside_card 1
	    continue
	}
	if { [regexp ^END_POSITIONS $word] } {
	    append output "\}\n"
	    set inside_card 0
	    continue
	}
	
	if { [regexp {^(BEGIN|END)} $word] } {
	    # strip the BEGIN & END keywords
	    if { $inside_card } {
		append output "\}\n"
		set inside_card 0
	    }
	    continue
	}

        if { $inside_card && ! [regexp {^#|^!} $word] } {
            append output $line\n
	}
    }

    eval $output
    ::pwtk::input::namelists_ityp2atmSymb_ [concat $::pwtk::pwi::namelist_flow_list $::pwtk::nebi::input_flow_list]
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::getAtmSymbList
# SYNOPSIS
proc ::pwtk::nebi::getAtmSymbList {} {
    # PURPOSE
    #   Get a sequential list of atomic-symbols from ATOMIC_POSITIONS card (in the same order), i.e.:
    #      AtmSy1
    #      AtmSy2
    #      ...
    # SOURCE

    set pos [::pwtk::input::cardGetContent POSITIONS]
    if { $pos == "" } {
	# if POSITIONS is empty, perhaps the old alternative syntax is used
	set pos [::pwtk::input::cardGetContent ATOMIC_POSITIONS]
    }

    set result ""
    foreach line [split $pos \n] {
        if { [string match -nocase *first_image* $line] || [regexp ATOMIC_POSITIONS $line] || [regexp TOTAL_CHARGE $line] } { 
	    continue
	} elseif { [string match -nocase *intermediate_image* $line] || [string match -nocase *last_image* $line] } {
	    return $result
	} else {
            if { [llength $line] >= 4 } {
                lappend result [lindex $line 0]
            }
	}
    }
    return $result
}
#****


#****f* ::pwtk::nebi/::pwtk::nebi::getNAtoms
# SYNOPSIS
proc ::pwtk::nebi::getNAtoms {} {
    # PURPOSE
    #   Return the number of atoms in the POSITIONS card of the neb.x input.
    # 
    # REMARK
    #   ::pwtk::nebi::getNAtoms is not related and does not return the
    #   value of the 'nat' variable in the SYSTEM namelist.
    # 
    # SOURCE
    return [::pwtk::getNAtoms [::pwtk::nebi::getImageAtmPos 1]]
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::getNImages
# SYNOPSIS
proc ::pwtk::nebi::getNImages {} {
    # PURPOSE
    #   Return the number of explicitly specified images with
    #   ATOMIC_POSITIONS in the neb.x input.
    # 
    # REMARK
    #   ::pwtk::nebi::getNImages is not related and does not return the
    #   value of the "num_of_images" variable in the PATH namelist.
    # 
    # SOURCE

    return [llength [lsearch -all -glob [::pwtk::input::cardGetContent POSITIONS] ATOMIC_POSITIONS*] ]
}
#******



#****f* ::pwtk::nebi/::pwtk::nebi::getImage
# SYNOPSIS
proc ::pwtk::nebi::getImage {index} {
    # USAGE
    #   ::pwtk::nebi::getImage index
    #
    # PURPOSE
    #   Return the ATOMIC_POSITIONS and TOTAL_CHARGE of the index-th image.
    # 
    # REMARK
    #   ::pwtk::nebi::getImage is not related to the "num_of_images" variable.
    # 
    # ARGUMENTS
    # * index -- index of image to return (index can be also "first"
    #            and "last"; the 1st image has the index of 1)
    #
    # RETURN VALUE
    #   The specs of the index-th image from the POSITIONS card, i.e.:
    #     ATOMIC_POSITIONS (unit)
    #        AtmPos1   x1 y1 z1   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos2   x2 y2 z2   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos3   x3 y3 z3   [if_pos(1) if_pos(2) if_pos(3)]
    #    TOTAL_CHARGE
    #        tot_charge
    #   The if_pos(:) data are returned only if they exist. 
    # SOURCE
    
    set nimages [getNImages]
    if { $nimages == 0 } {
        # no image specified
        ::pwtk::error "cannot get any image because POSITIONS/ATOMIC_POSITIONS card is undefined" 1
    }    

    set index [image_in_range_ $index $nimages]    

    set iimage 0
    set record  0
    set image {}

    foreach line [split [::pwtk::input::cardGetContent POSITIONS] \n] {
        if { [regexp {IMAGE} $line] } {
            incr iimage
            set record 0
            continue
        }
        if { [regexp {ATOMIC_POSITIONS} $line] } {
            if { $iimage == $index } {
                set record 1
            }
        }
        if { $record } {
            append image $line\n
        }
    }

    return $image
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::getImageAtmPos
# SYNOPSIS
proc ::pwtk::nebi::getImageAtmPos {args} {
    # USAGE
    #   ::pwtk::nebi::getImageAtmPos [-k -if_pos] index
    #
    # OPTIONS
    # * -k      ... prepend the coordinates with the "ATOMIC_POSITIONS (unit)" line
    # * -if_pos ... add "if_pos(1) if_pos(2) if_pos(3)" fields of the 1st image to the coordinates
    #
    # PURPOSE
    #   Return the atomic positions of the requested explicitly
    #   specified image with ATOMIC_POSITIONS in the neb.x input.
    # 
    # REMARK
    #   ::pwtk::nebi::getImageAtmPos is not related to the "num_of_images" variable!
    # 
    # ARGUMENTS
    # * index -- index of image to return (index can be also "first"
    #            and "last"; the 1st image has index of 1)
    #
    # RETURN VALUE
    #   If -k option is specified, then getImageAtmPos returns atomic positions 
    #   with the keyword line:
    #     ATOMIC_POSITIONS (unit)
    #        AtmPos1   x1 y1 z1   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos2   x2 y2 z2   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos3   x3 y3 z3   [if_pos(1) if_pos(2) if_pos(3)]
    #        ....    
    #   otherwise it returns:    
    #        AtmPos1   x1 y1 z1   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos2   x2 y2 z2   [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmPos3   x3 y3 z3   [if_pos(1) if_pos(2) if_pos(3)]
    #        ....    
    #    
    # SOURCE
    
    set options {
        {k      "include the ATOMIC_POSITIONS keyword line in the result"}
        {if_pos "supplement image atomic coordinates with the if_pos(:) fields from the 1st image"}
    }
    set usage ":   ::pwtk::nebi::getImageAtmPos \[-k] index"
    array set opt [::cmdline::getoptions args $options $usage]
    if { [llength $args] != 1 } {
        ::pwtk::error "Usage $usage" 1
    }
    set index [lindex $args 0]
    
    set nimages [getNImages]
    if { $nimages == 0 } {
        # no image specified
        ::pwtk::error "cannot get any image AtmPos because POSITIONS/ATOMIC_POSITIONS card is undefined" 1
    }    

    set index [image_in_range_ $index $nimages]

    set iimage 0
    set record  0
    set image {}

    foreach line [split [::pwtk::input::cardGetContent POSITIONS] \n] {
        if { [regexp {IMAGE|CHARGE} $line] } {
            if { [regexp IMAGE $line] } {
                incr iimage
            }
            set record 0
            continue
        }
        if { [regexp {ATOMIC_POSITIONS} $line] } {
            if { $iimage == $index } {
                set record 1
                if { $opt(k) } {
                    append image $line\n
                }
                continue
            }
        }
        if { $record } {
            append image $line\n
        }
    }

    if { $opt(if_pos) && $index != 1 } {
        # we need the reference atomic-positions of the 1st image to supplement the if_pos(:) fields to the atomic-coordinates
        set image [::pwtk::coorToAtmPos $image [::pwtk::nebi::getImageAtmPos first]]
    }

    return $image
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::getImageUnit
# SYNOPSIS
proc ::pwtk::nebi::getImageUnit {index} {
    # PURPOSE
    #   Return the unit of the requested explicitly specified image
    #   with "ATOMIC_POSITIONS (unit)" in the neb.x input.
    # 
    # REMARK
    #   This command is not related to the "num_of_images" variable!
    #
    # ARGUMENTS
    # * index -- index of image to query (index can be also "first"
    #            and "last"; the 1st image has index of 1)
    #
    # SOURCE
    
    set nimages [getNImages]
    if { $nimages == 0 } {
        # no image specified
        ::pwtk::error "cannot get image unit because POSITIONS/ATOMIC_POSITIONS card is undefined" 1
    }    

    set index [image_in_range_ $index $nimages]    

    set iimage 0
    set unit    {}
    
    foreach line [split [::pwtk::input::cardGetContent POSITIONS] \n] {
        if { [regexp {ATOMIC_POSITIONS} $line] } {
            incr iimage
            if { $iimage == $index } {
                if { [llength $line] > 1 } {
                    set unit [::pwtk::trimCardFlag [lrange $line 1 end]]
                }
                break
            }
        }
    }
    return $unit
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::getImageCharge
# SYNOPSIS
proc ::pwtk::nebi::getImageCharge {args} {
    # USAGE
    #   ::pwtk::nebi::getImageCharge [-k] index
    #
    # OPTIONS
    # * -k      ... prepend the "TOTAL_CHARGE" keyword
    #
    # PURPOSE
    #   Return the total_charge of the image #index (if it was specified,
    #   else an empty string is returned).
    # 
    # REMARK
    #   This command is not related to the "num_of_images" variable!
    # 
    # ARGUMENTS
    # * index -- index of the image (index can be also "first"
    #            and "last"; the 1st image has index of 1)
    #
    # RETURN VALUE
    #   If -k option is specified, then getImageCharge returns:
    #      TOTAL_CHARGE
    #      tot_charge
    #   otherwise it returns:    
    #      tot_charge
    #   If TOTAL_CHARGE is not defined, an empty string is returned/
    #    
    # SOURCE
    
    set options {
        {k      "include the TOTAL_CHARGE keyword line in the result"}
    }
    set usage ":   ::pwtk::nebi::getImageCharge \[-k] index"
    array set opt [::cmdline::getoptions args $options $usage]
    if { [llength $args] != 1 } {
        ::pwtk::error "Usage $usage" 1
    }
    set index   [lindex $args 0]
    
    set nimages [getNImages]
    if { $nimages == 0 } {
        # no image specified
        ::pwtk::error "cannot get any image charge because POSITIONS/ATOMIC_POSITIONS card is undefined" 1
    }    

    set index [image_in_range_ $index $nimages]    

    set iimage 0
    set record  0
    set charge  {}

    foreach line [split [::pwtk::input::cardGetContent POSITIONS] \n] {
        if { [regexp {IMAGE} $line] } {
            incr iimage
            set record 0
        } elseif { [regexp {ATOMIC_POSITIONS} $line] } {
            set record 0
        } elseif { [regexp {CHARGE} $line] && $iimage == $index } {
            set record 1
            if { $opt(k) } {
                append charge $line\n
            }
            continue
        }
        if { $record } {
            append charge $line\n
        }
    }

    return $charge
}
#******



#****f* ::pwtk::nebi/::pwtk::nebi::replaceImage
# SYNOPSIS
proc ::pwtk::nebi::replaceImage {index imageData} {
    # PURPOSE
    #   Set the atomic positions & total_charge for the requested image, i.e., replace
    #   the corresponding ATOMIC_POSITIONS & TOTAL_CHARGE cards in the neb.x input.
    #
    # ARGUMENTS
    # * index -- index of image to set (index can be also "first"
    #            and "last"; the 1st image has index of 1)
    # * imageData -- atomic-positions and optionally total charge for the $index image
    #
    # Note that the TOTAL_CHARGE specs are optional but
    # ATOMIC_POSITIONS specs are mandatory in 'imageData'. If the
    # current index-th image has TOTAL_CHARGE and TOTAL_CHARGE is not
    # provided in 'imageData', the current value will be
    # maintained. To delete the TOTAL_CHARGE, use the
    # ::pwtk::nebi::deleteImageCharges command.
    # 
    # REMARK
    #   This command is not related to the "num_of_images" variable,
    #   but to FIRST_IMAGE, INTERMEDIATE_IMAGE..., LAST_IMAGE specs in
    #   the POSITIONS card (aka BEGIN_POSITIONS / END_POSITIONS).
    #
    #   Note that if index != 1 then "atmPos" will be tranformed to
    #   "coor" (the difference is that "atmPos" may contain the
    #   if_pos(:) fields but "coor" does not).
    # 
    # EXAMPLE
    #   ::pwtk::nebi::replaceImage 2 {
    #      ATOMIC_POSITIONS
    #        symb1 x1 y1 z1  ?if_pos_x1 if_pos_y1 if_pos_z1?
    #        symb2 x2 y2 z2  ?if_pos_x2 if_pos_y2 if_pos_z2?
    #        ...
    #      TOTAL_CHARGE
    #        tot_charge
    #   }
    #   N.B note that the TOTAL_CHARGE card is optional but ATOMIC_POSITIONS is mandatory
    #
    # SOURCE

    # extract atmPos
    set atmPos  [::pwtk::purifyCoor $imageData]
    if { $atmPos == {} } {
        ::pwtk::warning "no ATOMIC_POSITIONS found. Skipping ..."
        return
    }
    # extract charge (if supplied)
    set ind [string first TOTAL_CHARGE $imageData]
    if { $ind > -1 } {
        set charge  [lindex [string range $imageData $ind end] end]
    } else {
        set charge {}
    }
    
    set nimages [getNImages]
    if { $nimages == 0 } {
        # no image specified
        ::pwtk::error "cannot set any image because POSITIONS card is empty" 1
    }    

    set index [image_in_range_ $index $nimages]    
    if { $index != 1 } {
        set atmPos [::pwtk::atmPosToCoor $atmPos]
    }

    set iimage 0
    set chargeSet 0
    set positions {}
    set skip    0

    foreach line [split [::pwtk::input::cardGetContent POSITIONS] \n] {        
        if { [regexp {IMAGE} $line] } {
            if { $iimage == $index && ! $chargeSet && $charge != {} } {
                # TOTAL_CHARGE card was missing & charge was not yet written
                append positions "TOTAL_CHARGE\n$charge\n"
            }
            incr iimage
            set skip 0
        } elseif { [regexp {ATOMIC_POSITIONS} $line] } {
            if { $iimage == $index } {
                append positions $line\n$atmPos\n
                set skip 1
                continue
            } else {
                set skip 0
            }
        } elseif { [regexp {TOTAL_CHARGE} $line] } {
            if { $iimage == $index && $charge != {} } {
                append positions $line\n$charge\n
                set skip 1
                set chargeSet 1
                continue
            } else {
                set skip 0
            }
        }
        if { ! $skip } {
            append positions $line\n
        }
    }
    # take care of LAST_IMAGE if TOTAL_CHARGE record is missing
    if { $iimage == $index && ! $chargeSet && $charge != {} } {
        # TOTAL_CHARGE card was missing & charge was not yet written
        append positions "TOTAL_CHARGE\n$charge\n"
    }

    POSITIONS $positions

    return $positions
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::setImageCharges
# SYNOPSIS
proc ::pwtk::nebi::setImageCharges {args} {
    # USAGE
    #   setImageCharges charge1 ?charge2? ?charge3? ...
    # or
    #   setImageCharges {charge1 charge2 ...}    
    #
    # PURPOSE
    #   Assign TOTAL_CHARGE of charge1 to image-1, charge2 to image-2, etc.
    #
    # REMARK
    #   Assignment of charges is sequential, i.e.:
    #     charge1 ---assigned to---> image1
    #     charge2 ---assigned to---> image2
    #     ...    
    # SOURCE

    set args [concat {*}$args]
    set nl [llength $args]
    set ni [getNImages] 

    if { $nl > $ni } {
        ::pwtk::error "too many charges were specified; number of images in POSITIONS = $ni, number of specified charges = $nl" 1
    }
    
    for {set i 1} {$i <= $nl} {incr i} {
        set charge [lindex $args $i-1]
        if { ! [string is double -strict $charge] } {
            ::pwtk::error "expected a floating-point number for total charge of image #.$i, but got $charge" 1
        }
        ::pwtk::nebi::setImageCharge $i $charge
    }
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::setImageCharge
# SYNOPSIS
proc ::pwtk::nebi::setImageCharge {index charge} {
    # PURPOSE
    #   Set the TOTAL_CHARGE card for index-th image.
    # 
    # REMARK
    #   This command is not related to the "num_of_images" variable,
    #   but to the POSITIONS card (aka BEGIN_POSITIONS / END_POSITIONS).
    #
    # ARGUMENTS
    # * index -- index of the image (index can be also "first"
    #            and "last"; the 1st image has index of 1)
    # * charge -- charge of the image
    #    
    # SOURCE

    if { ! [string is double $charge] } {
        ::pwtk::error "expected a floating point number for the total_charge, but got $charge" 1
    }

    set nimages [getNImages]
    if { $nimages == 0 } {
        # no image specified
        ::pwtk::error "cannot set any image charge because POSITIONS/ATOMIC_POSITIONS card is undefined" 1
    }    

    set index [image_in_range_ $index $nimages]    

    set iimage 0
    set chargeSet 0
    set positions {}
    set skip    0

    foreach line [split [::pwtk::input::cardGetContent POSITIONS] \n] {        
        if { [regexp {IMAGE} $line] } {
            if { $iimage == $index && ! $chargeSet } {
                # TOTAL_CHARGE card was missing & charge was not yet written
                append positions "TOTAL_CHARGE\n$charge\n"
            }
            incr iimage
            set skip 0
        }
        if { [regexp {ATOMIC_POSITIONS} $line] } {
            set skip 0
        }
        if { [regexp {TOTAL_CHARGE} $line] } {
            if { $iimage == $index } {
                append positions $line\n$charge\n
                set skip 1
                set chargeSet 1
                continue
            } else {
                set skip 0
            }
        }
        if { ! $skip } {
            append positions $line\n
        }
    }
    # take care of LAST_IMAGE if TOTAL_CHARGE record is missing
    if { $iimage == $index && ! $chargeSet } {
        # TOTAL_CHARGE card was missing & charge was not yet written
        append positions "TOTAL_CHARGE\n$charge\n"
    }
        
    POSITIONS $positions

    return $positions
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::getPositions
# SYNOPSIS
proc ::pwtk::nebi::getPositions {{index ""} {positions_only 0}} {
    # PURPOSE
    #   Get POSITIONS from the neb.x input data, i.e.:
    #      FIRST_IMAGE
    #        ATOMIC_POSITIONS
    #        AtmSy1  x1 y1 z1  [if_pos(1) if_pos(2) if_pos(3)]
    #        AtmSy2  x2 y2 z2  [if_pos(1) if_pos(2) if_pos(3)]
    #        ...
    #      INTERMEDIATE_IMAGE
    #        ...
    #      LAST_IMAGE
    #        ...
    #
    #   If index is specified, then only atomic-positions of the
    #   index-th image are returned.
    #
    # ARGUMENTS
    #   * index -- (optional) if index is specified, then only the atomic positions
    #              of the index-th image in the neb.x input are returned (first-image = 1)
    #   * positions_only -- (optional) if true and if index is specified,
    #                       return only positions (i.e. skip the TOTAL_CHARGE card)
    #
    # SOURCE

    set pos  [::pwtk::skipEmptyLines [::pwtk::input::cardGetContent POSITIONS]]
    set posL [split $pos \n]
    
    if { $index != "" } {
        set indices [lsearch -all -glob $posL *IMAGE]
        set nimages [llength $indices]
        set index   [image_in_range_ $index $nimages]    
       
        set ind [lindex $indices $index-1]
        if { $index == $nimages } {
            set pos [join [lrange $posL $ind+1 end] \n]
        } else {
            set ind1 [lindex $indices $index]
            set pos [join [lrange $posL $ind+1 $ind1-1] \n]
        }
    }

    if { ! [string is boolean $positions_only] } {
        ::pwtk::warning "expected a boolean 'positions_only' argument, but got $positions_only"
        set positions_only 0
    }
    if { $positions_only } {
        set aux $pos
        set pos {}
        foreach line [split $aux \n] {
            if { [string match *CHARGE* $line] } {
                break
            } else {
                append pos $line\n
            }
        }
    }
    return $pos
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::substituteAtom
# SYNOPSIS
proc ::pwtk::nebi::substituteAtom {atomIndex newType} {
    # PURPOSE 
    #   Substitute a specified atom in all ATOMIC_POSITIONS cards with a new atomic type.
    #
    # ARGUMENTS
    # * atomIndex -- index of the atom to substitute (the first atom has index 1)
    # * newType -- new atomic type
    #
    # SOURCE

    set ind -999
    set newPos ""
    foreach line [split [::pwtk::input::cardGetContent POSITIONS] \n] {
        if { [string match "*ATOMIC_POSITIONS*" $line] } {
            set ind 0
        }
        if { $atomIndex == $ind } {
            append newPos "$newType [lrange $line 1 end]\n"
        } else {
            append newPos $line\n
        }
        incr ind
    }
    POSITIONS $newPos

    return [::pwtk::input::cardGetContent POSITIONS]
}
#******

#****f* ::pwtk::nebi/::pwtk::nebi::substituteAtoms
# SYNOPSIS
proc ::pwtk::nebi::substituteAtoms {args} {
    # USAGE
    #   ::pwtk::nebi::substituteAtoms atomIndex1 newType1 ?atomIndex2 newType2 ...?
    # or
    #   ::pwtk::nebi::substituteAtoms { atomIndex1 newType1 ?atomIndex2 newType2 ...? }
    #
    # PURPOSE 
    #   Substitute specified atoms in all ATOMIC_POSITIONS cards with
    #   new atomic types. The first atom has index 1.
    #
    # ARGUMENTS
    # * args -- atom-index & new-atom-type list in the following format: atomIndex1 newType1 atomIndex2 newType2  ...
    #
    # EXAMPLE
    #   ::pwtk::nebi::substituteAtoms 1 Li 2 O 
    # SOURCE

    foreach {ind type} [concat {*}$args] {
        ::pwtk::nebi::substituteAtom $ind $type
    }
    return [::pwtk::input::cardGetContent POSITIONS]
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::POSITIONS_fromCRD
# SYNOPSIS
proc ::pwtk::nebi::POSITIONS_fromCRD {crdFile} {
    # PURPOSE
    #   Load POSITIONS from neb.x CRD file.
    # SOURCE
    ::pwtk::fileMustExist $crdFile "neb.x CRD"
    POSITIONS [::pwtk::readFile $crdFile]
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::POSITIONS_fromAXSF
# SYNOPSIS
proc ::pwtk::nebi::POSITIONS_fromAXSF {args} {
    # USAGE
    #   POSITIONS_fromAXSF [-ifpos] axsfFile
    #
    # OPTIONS
    #   * -ifpos ... copy if_pos(:) fields from the current (old) coordinates
    #
    # PURPOSE
    #   Load the neb.x POSITIONS from the AXSF file.
    #
    # ARGUMENTS
    #   * axsfFile -- name of the AXSF file
    #
    # SOURCE
    
    set options {
        {ifpos  "copy if_pos(:) fields from current (old) coordinates"}
    }
    array set opt [::cmdline::getoptions args $options [list [lindex [info level 0] 0] options:]]

    if { [llength $args] > 1 } {
        pwtk::error "wrong usage: should be ::pwtk::nebi::POSITIONS_fromAXSF \[-ifpos] axsfFile, but got:\n
::pwtk::nebi::POSITIONS_fromAXSF $args" 1
    }
    
    # parse AXSF-file
    set axsfFile [lindex $args 0]   
    ::pwtk::fileMustExist $axsfFile AXSF

    set nimages [::pwtk::xsf::getAnimsteps $axsfFile]
        
    for {set i 1} {$i <= $nimages} {incr i} {
        set atmPos($i) [::pwtk::atmPosToCoor [::pwtk::xsf::getPrimCoor $axsfFile $i]]
        if { $i == 1 } {
            if { $opt(ifpos) } {
                # transform coor to atmPos
                set atmPos($i) [::pwtk::coorToAtmPos $atmPos($i) [::pwtk::nebi::getImageAtmPos first]]
            }
            # now clear old POSITIONS
            ::pwtk::input::clear POSITIONS
            set image FIRST_IMAGE
        } elseif { $i == $nimages } {
            set image LAST_IMAGE
        } else {
            set image INTERMEDIATE_IMAGE
        }
        append positions "$image\nATOMIC_POSITIONS angstrom\n$atmPos($i)\n"
    }
    if { [info exists positions] } {
        POSITIONS $positions
    }
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::POSITIONS_fromPATH
# SYNOPSIS
proc ::pwtk::nebi::POSITIONS_fromPATH {pathFile} {
    # PURPOSE
    #   Load POSITIONS from neb.x PATH file.
    # BEWARE
    #   Atoms are fixed according to the if_pos(:) specs in the PATH file.
    # SOURCE

    ::pwtk::fileMustExist $pathFile "neb.x path file"

    set pathL [split [::pwtk::readFile $pathFile] \n]
    # trim the empty elements at the end
    while { [lindex $pathL end] eq "" } {
        set pathL [lrange $pathL 0 end-1]
    }
    set ims   [lsearch -all $pathL Image:*]
    set nImage [llength $ims]

    for {set i 1} {$i <= $nImage} {incr i} {
        set i1($i) [expr [lindex $ims $i-1] + 2]
        set i2($i) [expr [lindex $ims $i] - 1]
    }
    # the above fails for i2($nImage), hence recalculate it:
    set ii [expr $nImage - 1]
    set i2($nImage) [expr $i1($nImage) + $i2($ii) - $i1($ii)]

    set natp [expr $i2(1) - $i1(1) + 1]
    set nati [::pwtk::nebi::getNAtoms]

    if { $natp != $nati } {
        ::pwtk::error "the number of input atoms ($nati) differ from the number of atoms in the path file ($natp);
cannot assign atomic symbols to atomic positions from the '$pathFile' path file" 1
    }
    
    set symbols [::pwtk::nebi::getAtmSymbList]    

    # 1st image
    
    set image   [join [lmap s $symbols xyz [lrange $pathL $i1(1) $i2(1)] {
        format $::pwtk::fmt_atmPos(7) {*}[concat $s [lrange $xyz 0 2] [lrange $xyz 6 8]]
    }] \n]     
    set positions "
FIRST_IMAGE
ATOMIC_POSITIONS (bohr)
$image
"
    # intermediate images
    
    for {set i 2} {$i < $nImage} {incr i} {
        set image [join [lmap s $symbols xyz [lrange $pathL $i1($i) $i2($i)] {            
            format $::pwtk::fmt_atmPos(4) {*}[concat $s [lrange $xyz 0 2]]
        }] \n]     
        append positions "
INTERMEDIATE_IMAGE
ATOMIC_POSITIONS (bohr)
$image
"
    }
    
    # last image
    
    set image [join [lmap s $symbols xyz [lrange $pathL $i1($nImage) $i2($nImage)] {
        format $::pwtk::fmt_atmPos(4) {*}[concat $s [lrange $xyz 0 2]]
    }] \n]     
    append positions "
LAST_IMAGE
ATOMIC_POSITIONS (bohr)
$image
"
    # input positions
    
    POSITIONS $positions
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::deleteImageCharges
# SYNOPSIS
proc ::pwtk::nebi::deleteImageCharges {args} {
    # USAGE
    #   ::pwtk::nebi::deleteImageCharges index1 ?index2 ...?
    # or
    #   ::pwtk::nebi::deleteImageCharges { index1 ?index2 ...? }
    #
    # PURPOSE
    #   Delete TOTAL_CHARGE of index1, index2... images from the POSITIONS card.
    #
    #   The first image has index == 1; last image has index == end
    #
    #   Indices can be also specified as end-N, which means N-th image
    #   before the last one (e.g., if there are 4 images, end-1 means
    #   the 3rd image).
    #
    # ARGUMENTS
    # * index1, index2... --- indices of images for which to delete the TOTAL_CHARGE specs
    #
    # REMARK
    #   This command is not related to the "num_of_images" variable,
    #   but to FIRST_IMAGE, INTERMEDIATE_IMAGE..., LAST_IMAGE specs in
    #   the POSITIONS card (aka BEGIN_POSITIONS / END_POSITIONS).
    #
    # SOURCE

    set nimages [::pwtk::nebi::getNImages]    

    # store POSITIONS to data array
    ::pwtk::nebi::positions2data_ data

    foreach index [lsort -decreasing -integer [concat {*}$args]] {
        set index [image_in_range_ $index $nimages]    
    
        # delete the image charge

        if { [info exist data(charge,$index)] } {
            unset data(charge,$index)
        }
    }

    # load POSITIONS from data
    POSITIONS [::pwtk::nebi::data2positions_ data]    
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::deleteImages
# SYNOPSIS
proc ::pwtk::nebi::deleteImages {args} {
    # USAGE
    #   ::pwtk::nebi::deleteImages index1 ?index2 ...?
    # or
    #   ::pwtk::nebi::deleteImages { index1 ?index2 ...? }
    #
    # PURPOSE
    #   Delete index1, index2... images from the POSITIONS card.
    #
    #   First image has index == 1; last image has index == end
    #
    #   Indices can be also specified as end-N, which means N-th image
    #   before the last one (e.g., if there are 4 images, end-1 means
    #   the 3rd image).
    #
    # ARGUMENTS
    # * index1, index2... --- indices of images to delete from the POSITIONS card.
    #
    # REMARK
    #   This command is not related to the "num_of_images" variable,
    #   but to FIRST_IMAGE, INTERMEDIATE_IMAGE..., LAST_IMAGE specs in
    #   the POSITIONS card (aka BEGIN_POSITIONS / END_POSITIONS).
    #
    # SOURCE

    foreach index [lsort -decreasing -integer [concat {*}$args]] {
        ::pwtk::nebi::deleteImage_ $index
    }
}
#******


#****if* Internals/::pwtk::nebi::deleteImage_
# SYNOPSIS
proc ::pwtk::nebi::deleteImage_ {index} {
    # PURPOSE
    #   Delete the index-th image from the POSITIONS card.
    #
    # ARGUMENT
    # * index --- index of image to delete
    #
    # REMARK
    #   ::pwtk::nebi::deleteImage is not related to the "num_of_images"
    #   variable, but to FIRST_IMAGE, INTERMEDIATE_IMAGE...,
    #   LAST_IMAGE specs in the POSITIONS card (aka BEGIN_POSITIONS / END_POSITIONS).
    #
    # SOURCE

    set nimages [::pwtk::nebi::getNImages]    
    set index [image_in_range_ $index $nimages]    
    
    # store POSITIONS to data array
    ::pwtk::nebi::positions2data_ data

    # delete image

    for {set im $index} {$im < $nimages} {incr im} {
        set im1 [expr $im + 1]
        set data(unit,$im) $data(unit,$im1)
        if { [info exist data(charge,$im1)] } {
            set data(charge,$im) $data(charge,$im1)
        } elseif { [info exist data(charge,$im)] } {
            unset data(charge,$im)
        }
        for {set ia 1} {$ia <= $data(nat)} {incr ia} {
            # BEWARE: only the first image has the if_pos() ix iy iz
            # fields hence these fields should not be copied (this way
            # the if_pos() fields always remain on the image 1, even
            # if original image 1 is deleted)
            foreach e {sy x y z} {
                set data($e,$im,$ia) $data($e,$im1,$ia)
            }
        }
    }
    incr data(nimages) -1
    
    # load POSITIONS from data
    POSITIONS [::pwtk::nebi::data2positions_ data]
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::addImage
# SYNOPSIS
proc ::pwtk::nebi::addImage {args} {
    # USAGE
    #   ::pwtk::nebi::addImage ?-before | -after? index imageData 
    #
    # PURPOSE
    #   Add a new image to the POSITIONS card. If the first image is
    #   being added, the if-pos fields of the incoming first image
    #   will be used.
    #
    # OPTIONS
    # * -before ... add a new image before the index-th image (this is default)
    # * -after  ... add a new image after the index-th image
    #
    # ARGUMENTS
    # * index --- the index of the reference image
    # * imageData -- image-data specs for the new image consisting of ATOMIC_POSITIONS
    #                and, optionally, TOTAL_CHARGE cards.
    #
    # EXAMPLE
    #   ::pwtk::nebi::addImage -before 1 {
    #       ATOMIC_POSITIONS
    #         H 0.0 0.0 0.0   0 0 0
    #         H 0.0 0.0 0.7   0 0 1
    #       TOTAL_CHARGE
    #         0.0
    #   }
    # SOURCE    
    
    set narg 2
    set usage   "?-before | -after? index imageData"
    set options {
        {before "add image before the index-th image"}
        {after  "add image after the index-th image"}
    }
    ::pwtk::parseOpt_
    if { $opt(before) && $opt(after) } {
        ::pwtk::error "exclusive -before & -after options specified" 1
    }
    if { $opt(before) + $opt(after) == 0 } {
        # -before is default
        set opt(before) 1
    }

    lassign $args index imageData

    set nimage [::pwtk::nebi::getNImages]    
    set index  [::pwtk::parseIndex1 $index $nimage]
    
    # transform -after to -before
    if { $opt(after) } {
        set index [expr max(1,$index+1)]
    }

    # for -before, index must be within [1,nimage+1]
    set index [expr max(1,min($index,$nimage+1))]
    
    # store POSITIONS to data array
    ::pwtk::nebi::positions2data_ data

    # shift im to im+1
    for {set im $nimage} {$im >= $index} {incr im -1} {
        set im1 [expr $im + 1]
        set data(unit,$im1)   $data(unit,$im)
        if { [info exist data(charge,$im)] } {
            set data(charge,$im1) $data(charge,$im)
        }
        for {set ia 1} {$ia <= $data(nat)} {incr ia} {
            foreach e {sy x y z ix iy iz} {
                set data($e,$im1,$ia) $data($e,$im,$ia)
            }
        }
    }

    # insert image
    set nat [::pwtk::nebi::image2data_ $imageData image]
    if { $nimage } {
        if { $nat != $data(nat) } {
            ::pwtk::error "wrong number of atoms in imageData ($nat), but should be $data(nat)" 1
        }
    } else {
        # only this image exist; set data(nat)
        set data(nat) $nat
    }

    set data(unit,$index) $image(unit)
    for {set ia 1} {$ia <= $data(nat)} {incr ia} {
        foreach e {sy x y z ix iy iz} {
            set data($e,$index,$ia) $image($e,$ia)
        }
    }
    if { [info exist image(charge)] } {
        set data(charge,$index) $image(charge)
    }    
    incr data(nimages)

    # load new data into the POSITIONS card
    POSITIONS [::pwtk::nebi::data2positions_ data]
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::addImageCoor_fromXSF
# SYNOPSIS
proc ::pwtk::nebi::addImageCoor_fromXSF {args} {
    # USAGE
    #   ::pwtk::nebi::addImageCoor_fromXSF ?-before | -after? imageIndex xsfFile ?xsfIndex?
    #
    # PURPOSE
    #   Add a new image's atomic Coor (aka ATOMIC_POSITIONS) from the
    #   XSF file to the POSITIONS card.
    #
    # OPTIONS
    # * -before ... add a new image positions before the index-th image
    # * -after  ... add a new image positions after the index-th image
    #
    # ARGUMENTS
    # * imageIndex --- the image's index
    # * xsfFile --- the XSF file from where to load the image's atomic coordinates
    # * xsfIndex --- (optional) the index of structure in the XSF file (default = 1)
    #
    # EXAMPLE
    #   ::pwtk::nebi::addImageCoor_fromXSF -before 1 file.xsf
    #
    # SOURCE

    set argum   $args
    set nargmin 2
    set nargmax 3
    set usage   "?-before | -after? imageIndex xsfFile ?xsfIndex?"
    set options {
        {before "add image before the index-th image"}
        {after  "add image after the index-th image"}
    }
    ::pwtk::parseOpt_
    lassign $args imageIndex xsfFile xsfIndex

    ::pwtk::fileMustExist $xsfFile xsfFile
    ::pwtk::ifset xsfIndex 1

    set xsfIndex [image_in_range_ $xsfIndex [::pwtk::xsf::getAnimsteps $xsfFile]]

    # if "nat" in the SYSTEM namelist is undefined, define it
    if { [::pwtk::input::namelistGetVarValue SYSTEM nat]  == "" } {
        SYSTEM " nat = [::pwtk::xsf::getNAtoms $xsfFile] "
    }
    set unit [::pwtk::xsf::getPrimCoorUnit $xsfFile]
    set coor [::pwtk::atmPosToCoor [::pwtk::purifyCoor [::pwtk::xsf::getPrimCoor $xsfFile $xsfIndex]]]
    if { $coor eq "" } {
        pwtk::error "no coordinates found in the XSF file: $xsfFile" 1
    }
    set imageData "ATOMIC_POSITIONS $unit\n$coor"
    if { [llength $args] == 2 } {
        addImage {*}[lrange $argum 0 end-1] $imageData
    } else {
        addImage {*}[lrange $argum 0 end-2] $imageData
    }
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::addImageCoor_fromPWO
# SYNOPSIS
proc ::pwtk::nebi::addImageCoor_fromPWO {args} {
    # USAGE
    #   ::pwtk::nebi::addImageCoor_fromPWO ?-before | -after? imageIndex pwoFile ?pwoIndex?
    #
    # PURPOSE
    #   Add a new image's ATOMIC_POSITIONS from the PWO file to the
    #   POSITIONS card.
    #
    # OPTIONS
    # * -before ... add a new image positions before the index-th image
    # * -after  ... add a new image positions after the index-th image
    #
    # ARGUMENTS
    # * imageIndex --- the image's index
    # * pwoFile -- the PWO file from where to load the image's atomic positions
    # * pwoIndex -- (optional) the index of structure in the PWO file (default = end)
    #
    # EXAMPLE
    #   ::pwtk::nebi::addImagePos_fromPWO -before 1 relax.out
    #
    # SOURCE

    set argum   $args
    set nargmin 2
    set nargmax 3
    set usage   "?-before | -after? imageIndex pwoFile ?pwoIndex?"
    set options {
        {before "add image before the index-th image"}
        {after  "add image after the index-th image"}
    }
    ::pwtk::parseOpt_    
    lassign $args imageIndex pwoFile pwoIndex
    
    ::pwtk::fileMustExist $pwoFile "pw.x output"

    # if "nat" in the SYSTEM namelist is undefined, define it
    if { [::pwtk::input::namelistGetVarValue SYSTEM nat]  == "" } {
        SYSTEM " nat = [::pwtk::pwo::nat $pwoFile] "
    }

    set imageData [::pwtk::pwo::getAtmPos -k $pwoFile {*}$pwoIndex]
    if { $imageData eq "" } {
        pwtk::error "no coordinates found in the pw.x output file: $pwoFile" 1
    }
    if { $pwoIndex eq {} } {
        addImage {*}[lrange $argum 0 end-1] $imageData
    } else {
        addImage {*}[lrange $argum 0 end-2] $imageData
    }
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::addImageCoor_fromCRD
# SYNOPSIS
proc ::pwtk::nebi::addImageCoor_fromCRD {args} {
    # USAGE
    #   ::pwtk::nebi::addImageCoor_fromCRD ?-before | -after? imageIndex crdFile crdIndex
    #
    # PURPOSE
    #   Add a new image's ATOMIC_POSITIONS from the CRD file to the
    #   POSITIONS card.
    #
    # OPTIONS
    # * -before ... add a new image positions before the index-th image
    # * -after  ... add a new image positions after the index-th image
    #
    # ARGUMENTS
    # * imageIndex --- the image's index 
    # * crdFile  -- the CRD file from where to load the image's atomic positions
    # * crdIndex -- the index of the image in the CRD file to use for the added image
    #
    # EXAMPLE
    #   ::pwtk::nebi::addImageCoor_fromCRD -before 1 positions.crd 2
    #
    # SOURCE

    set argum $args
    set narg  3
    set usage "?-before | -after? imageIndex crdFile crdIndex"
    set options {
        {before "add image before the index-th image"}
        {after  "add image after the index-th image"}
    }
    ::pwtk::parseOpt_
    lassign $args imageIndex crdFile crdIndex

    ::pwtk::fileMustExist $crdFile "neb.x CRD"

    # load the CRD file into the 'data' array
    positions2data__ data [::pwtk::skipEmptyLines [readFile $crdFile]]

    # if "nat" in the SYSTEM namelist is undefined, define it
    set nat [::pwtk::input::namelistGetVarValue SYSTEM nat]
    if { $nat eq {} } {
        SYSTEM " nat = $data(nat) "
    } elseif { $nat != $data(nat) } {
        ::pwtk::error "number of atoms in the $crdFile file is $data(nat), but should be $nat" 1
    }

    addImage {*}[lrange $argum 0 end-2] [data2image_ data $crdIndex]
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::fixAtoms
# SYNOPSIS
proc ::pwtk::nebi::fixAtoms {atomList {fixString "0 0 0"}} {
    # PURPOSE
    #   Fix the specified atoms in the neb.x POSITIONS card by setting
    #   if_pos(:) flags to 'fixString'.
    #
    #   N.B.: according to neb.x syntax, only THE FIRST_IMAGE atoms are fixed
    #
    # ARGUMENTS
    # * atomList  -- list of atoms (indices) to be immobilized (list of atoms can also have a 
    #                symbolic compact syntax supported by ::pwtk::parseRangeString)    
    # * fixString -- list of if_pos(:) values (optional, default = {0 0 0})
    #
    # SOURCE
    
    set unit       [::pwtk::nebi::getImageUnit 1]    
    set im1_atmPos [::pwtk::nebi::getImageAtmPos -if_pos 1]
    if { $im1_atmPos eq {} } {
        ::pwtk::error "POSITIONS card is empty: cannot fix atoms [join $atomList ,]" 1
    }

    # check that indices are in range

    set natoms [::pwtk::nebi::getNAtoms]
    set atomList [lsort -integer -unique [::pwtk::parseRangeString $atomList $natoms]]
    foreach index $atomList { ::pwtk::int_in_range1_ $index $natoms }
    
    # parse im1_atmPos
    
    set nat 0
    foreach line [split $im1_atmPos \n] {
        if { [llength $line] == 4 || [llength $line] == 7 } {     
            incr nat
            set atmPos($nat) $line
        }
    }

    # immobilize atoms
    
    foreach ind $atomList {
	if { $ind > 0 && $ind <= $nat} {
	    set coor [lrange $atmPos($ind) 0 3]
	    set atmPos($ind) [concat $coor $fixString]
	}
    }
    
    # build new atmPos

    set atmp {}
    for {set ia 1} {$ia <= $nat} {incr ia} {
	append atmp $atmPos($ia)\n
    }

    # load $atmp into the FIRST_IMAGE's ATOMIC_POSITIONS 

    ::pwtk::nebi::replaceImage 1 "ATOMIC_POSITIONS $unit\n$atmp"
}
#******


#****f* ::pwtk::nebi/::pwtk::nebi::fixAtoms1st
# SYNOPSIS
proc ::pwtk::nebi::fixAtoms1st  {natoms {fixString "0 0 0"}} {
    # PURPOSE
    #   Fix the first 'natoms' atoms in the POSITIONS card by setting
    #   if_pos(:) flags to 'fixString' (default = {0 0 0}).
    #
    #   N.B.: according to neb.x syntax, only THE FIRST_IMAGE atoms are fixed
    #
    # ARGUMENTS
    # * natoms -- number of atoms to fix as specified by $fixString
    # * fixString -- list of 3 if_pos(:) values (optional, default = {0 0 0})
    # SOURCE
    
    ::pwtk::nebi::fixAtoms 1-$natoms  $fixString
}
#******

#****f* ::pwtk::nebi/::pwtk::nebi::fixAtomsLast
# SYNOPSIS
proc ::pwtk::nebi::fixAtomsLast {natoms  {fixString "0 0 0"}} {
    # PURPOSE
    #   Fix the last 'natoms' atoms in the POSITIONS card by setting
    #   if_pos(:) flags to 'fixString' (default = {0 0 0}).
    #
    #   N.B.: according to neb.x syntax, only THE FIRST_IMAGE atoms are fixed
    #
    # ARGUMENTS
    # * natoms -- number of atoms to fix as specified by $fixString
    # * fixString -- list of 3 if_pos(:) values (optional, default = {0 0 0})
    # SOURCE

    set nat  [::pwtk::nebi::getNAtoms]
    set from [expr $nat-$natoms+1]
    ::pwtk::nebi::fixAtoms $from-$nat  $fixString
}
#******


#****f* ::pwtk::path/::pwtk::nebi::fixAtoms_inPATH
# SYNOPSIS
proc ::pwtk::nebi::fixAtoms_inPATH {pathFile_or_pathContent} {
    # PURPOSE
    #   Revamp the content of the neb.x PATH file such that the
    #   fixAtoms if_pos(*) fields correspond to the currently stored
    #   neb.x input POSITIONS data.
    #
    # BEWARE
    #   This routine leaves the pathFile intact, but instead returns
    #   the content of the revamped PATH file.
    #
    # ARGUMENT
    # * pathFile_or_pathContent -- either the neb.x PATH file or its content
    #
    # RETURN VALUE
    #   The content of the revamped PATH file.
    #
    # SOURCE

    if { [file exists $pathFile_or_pathContent] } {
        set pathContent [::pwtk::readFile $pathFile_or_pathContent]
    } else {
        set pathContent $pathFile_or_pathContent
    }

    ::pwtk::nebi::positions2data_ data

    # read path file & fix atoms according to the current NEBI data

    set im 0
    foreach line [split $pathContent \n] {
        if { [lindex $line 0] eq "Image:" } {
            set im [lindex $line 1]
        }
        if { $im == 1 } {
            if { [llength $line] == 9 } {
                incr nat
                ::pwtk::ifset data(ix,1,$nat) 1
                ::pwtk::ifset data(iy,1,$nat) 1
                ::pwtk::ifset data(iz,1,$nat) 1

                # fmt  = "(3(2X,F18.12),3(2X,F18.12),3(2X,I1))"
                set line [format {  %18.12f  %18.12f  %18.12f  %18.12f  %18.12f  %18.12f  %1d  %1d  %1d} {*}[lrange $line 0 5] $data(ix,1,$nat) $data(iy,1,$nat) $data(iz,1,$nat)]
            }
        }
        append new_path $line\n
    }
    ::pwtk::ifnotexist new_path {
        ::pwtk::error "expected a PATH file or a PATH content, but got:\n$pathFile_or_pathContent" 1
    }

    return $new_path
}
#******


# internal...
proc ::pwtk::nebi::image2data_ {imageData imageArrayName} {
    upvar $imageArrayName image

    set imageData [::pwtk::skipEmptyLines $imageData]
    
    set ia 0
    set atoms 0
    set charge 0
    foreach line [split $imageData \n] {
        set line [string trim $line]
        switch -glob -- $line {
            TOTAL_CHARGE      { set atoms 0; set charge 1 }            
            ATOMIC_POSITIONS* { set atoms 1; set charge 0
                # get unit
                set image(unit) [::pwtk::trimCardFlag [lrange $line 1 end]]
            }
            default {
                if { $atoms } {
                    incr ia
                    lassign $line image(sy,$ia) \
                        image(x,$ia)  image(y,$ia)  image(z,$ia) \
                        image(ix,$ia) image(iy,$ia) image(iz,$ia) 
                }
                if { $charge } {
                    lassign $line image(charge)
                }
            }
        }
    }

    return $ia    
}


# internal...
proc ::pwtk::nebi::positions2data_ {dataArrayName} {
    # PURPOSE
    #   Load POSITIONS card from the currently stored input data into
    #   the 'dataArray', where dataArray is the name of the array
    #   variable. On output, dataArray holds the following elements:
    #
    #     nimages
    #     nat
    #     unit,$im
    #     x,$im,$ia    y,$im,$ia    z,$im,$ia
    #     ix,$im,$ia  iy,$im,$ia   iz,$im,$ia
    #     charge,$im
    
    upvar $dataArrayName data

    positions2data__ data [::pwtk::skipEmptyLines [::pwtk::input::cardGetContent POSITIONS]]
}
# internal...
proc ::pwtk::nebi::positions2data__ {dataArrayName pos} {
    # PURPOSE
    #   The "workhorse" proc for the ::pwtk::nebi::positions2data_
    upvar $dataArrayName data

    if { $pos eq {} } {
        array set data [list nimages 0 nat 0]
        return
    }

    set im 0
    foreach line [split $pos \n] {
        set line [string trim $line]
        switch -glob -- $line {
            *IMAGE { incr im;   set atoms 0; set charge 0; set ia 0 }
            TOTAL_CHARGE      { set atoms 0; set charge 1 }            
            ATOMIC_POSITIONS* { set atoms 1; set charge 0
                # get unit
                set data(unit,$im) [::pwtk::trimCardFlag [lrange $line 1 end]]
            }
            default {
                if { $atoms } {
                    incr ia
                    lassign $line data(sy,$im,$ia) \
                        data(x,$im,$ia)  data(y,$im,$ia)  data(z,$im,$ia) \
                        data(ix,$im,$ia) data(iy,$im,$ia) data(iz,$im,$ia) 
                }
                if { $charge } {
                    lassign $line data(charge,$im)
                }
            }
        }
    }
    set data(nimages) $im
    set data(nat) $ia    
    return
}


# internal...
proc ::pwtk::nebi::data2positions_ {dataArrayName} {
    upvar $dataArrayName data

    set result {}
    
    for {set im 1} {$im <= $data(nimages)} {incr im} {
        if { $im == 1 } {
            set typ 7
            set result "FIRST_IMAGE\n"
        } else {
            set typ 4
            if { $im < $data(nimages) } {
                append result "INTERMEDIATE_IMAGE\n"
            } else {
                append result "LAST_IMAGE\n"
            }
        }
        append result "ATOMIC_POSITIONS $data(unit,$im)\n"
    
        for {set ia 1} {$ia <= $data(nat)} {incr ia} {
            append result [format $::pwtk::fmt_atmPos($typ) $data(sy,$im,$ia) \
                               $data(x,$im,$ia)  $data(y,$im,$ia)  $data(z,$im,$ia) \
                               $data(ix,$im,$ia) $data(iy,$im,$ia) $data(iz,$im,$ia)]
        }
        if { [info exist data(charge,$im)] } {
            append result "TOTAL_CHARGE\n$data(charge,$im)\n"
        }
    }
    return $result
}

# internal...
proc ::pwtk::nebi::data2image_ {dataArrayName index} {
    # PURPOSE
    #   Return the $index-th image data from the data array.

    upvar $dataArrayName data

    set index  [image_in_range_ $index $data(nimages)]
    set result "ATOMIC_POSITIONS $data(unit,$index)\n"

    for {set ia 1} {$ia <= $data(nat)} {incr ia} {
        append result [format $::pwtk::fmt_atmPos(7) $data(sy,$index,$ia) \
                           $data(x,$index,$ia)  $data(y,$index,$ia)  $data(z,$index,$ia) \
                           $data(ix,$index,$ia) $data(iy,$index,$ia) $data(iz,$index,$ia)]
    }
    ::pwtk::ifexist data(charge,$index) {
        append result IMAGE_CHARGE\n$data(charge,$index)\n
    }
    return $result
}


#****if* Internals/::pwtk::nebi::image_in_range_
# SOURCE
proc ::pwtk::nebi::image_in_range_ {index nimages} {
    # check that index is in [1,nimages] range (allow symbolic indexes)
    set index [uplevel 1 [list ::pwtk::parseIndex1 $index $nimages]]
    if { $index < 1 || $index > $nimages } {
        uplevel 1 [list ::pwtk::error "image index $index is out of range, should be within \[1, $nimages\]" 1]
    }
    return $index
}
#******        

