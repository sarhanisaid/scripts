#
# $RCSfile: neb_utils.tcl,v $ --
#
#      This file contains some utility commands for running NEB
#      calculations.
#
# Copyright (c) 2023-2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: neb_utils.tcl,v 1.0 2023/03/07 17:00:01 kokalj Exp $



# The following utility commands for running NEB calculations are defined below:
#
# auto_neb ?-noCI_thr threshold?  ?-CI_thr threshold?  head
#
# manual_neb ?-CI CI_LIST?  ?-noCI_thr threshold?  ?-CI_thr threshold?  head
#
# fast_neb ?-CI CI_LIST?  ?-fast_thr threshold?  ?-noCI_thr threshold?  ?-CI_thr threshold?  auto|manual
#
# re_spin_neb ...


#****a* 5.3.4. Run Utilities/neb.x utilities
# DESCRIPTION
#   Collection of utility routines, associated with running the calculations.
#
#******


namespace eval ::pwtk {
    variable noCI_path_thr 0.8
    variable neb_options {
        {noCI_thr.arg {}  "threshold for the preliminary no-CI calculation"}
        {CI_thr.arg   {}  "threshold for the CI calculation" }
        {onlyCI           "use only CI calculation in preliminary NEB (skip the 'no-CI' calculation)"}
        {artn             "refine the neb.x calculated activation energy with the ARTn plugin"}
    }

    # default ARTn parameters for refining the activation energy and TS
    variable default_ARTN_PARAMETERS {
        engine_units = 'qe'
        struc_format_out = 'xsf'
        verbose = 2
        ninit = 0
        forc_thr = 0.001
        eigval_thr = -0.005
        eigen_step_size = 0.3
        lpush_final = .false.
    }
}


#****f* neb.x utilities/::pwtk::auto_neb
# SYNOPSIS
proc ::pwtk::auto_neb {args} {
    # USAGE
    #   ::pwtk::auto_neb ?-noCI_thr THRESHOLD?  ?-CI_thr THRESHOLD?  ?-onlyCI?  ?-artn?  HEAD
    #
    # PURPOSE
    #   Perform no-CI + auto-CI NEB calculations, and plot the
    #   resulting energy profile along MEP (minimum-energy path).
    #
    #   First, the "no-CI" NEB is performed up to a reduced threshold to
    #   stabilize the minimum-energy path and then CI-NEB is restarted
    #   with CI_scheme = 'auto' using a full-precision threshold.
    #
    #   After the NEB calculations are finished, the activation energy
    #   can be refined with the ARTn plugin by specifying the -artn
    #   option (it requires QE compiled with the ARTn plugin enabled).
    #   For ARTn, if the ARTN_PARAMETERS namelist is undefined or empty, PWTK
    #   uses its default (stored in $::pwtk::default_ARTN_PARAMETERS).
    #
    #
    # OPTIONS
    # * -noCI_thr THRESHOLD ... path threshold for the preliminary no-CI NEB calculation;
    #                           if not specified, a default preliminary-threshold is used.

    # * -CI_thr THRESHOLD ... path threshold for the CI-NEB calculation;
    #                         if not specified, the current path_thr is used, but
    #                         if path_thr is not set, the neb.x default is used.

    # * -onlyCI ... skip the 'no-CI' calculation, i.e., perform only CI calculation

    # * -artn ... refine the activation energy with the ARTn pw.x calculation
    #             (this option requires QE compiled with the ARTn plugin enabled)
    #
    #
    # ARGUMENTS
    # * HEAD ... the rootname for the I/O files
    #
    # SIDE EFFECTS    
    #   "prefix" and outdir_postfix are set to HEAD, whereas all
    #   other modifications are popped away after complition because
    #   both calculations are performed with input_pushpop.
    #
    # SOURCE

    variable noCI_path_thr
    variable neb_options

    print NEB "no-CI + auto-CI NEB calculation\n"
    
    set narg 1
    set options $neb_options
    set usage "?-noCI_thr threshold?  ?-CI_thr threshold?  ?-onlyCI?  ?-artn?  HEAD"
    ::pwtk::parseOpt_
    ::pwtk::checkOType_ -noCI_thr $opt(noCI_thr) {number posreal} "positive real number"
    ::pwtk::checkOType_ -CI_thr   $opt(CI_thr)   {number posreal} "positive real number"
    set head [::pwtk::headname $args]
    
    ifset opt(noCI_thr) $noCI_path_thr

    outdir_postfix $head
    CONTROL " prefix = '$head' "

    ::pwtk::input::pushpop {
        # 1. run no-CI NEB
        if { ! $opt(onlyCI) } {
            ::pwtk::input::pushpop {
                PATH "
                   CI_scheme = 'no-CI'
                   path_thr  = $opt(noCI_thr)
                "
                runNEB neb.$head.no-CI
            }
            PATH {
                restart_mode = 'restart'
            }         
        } 

        # 2. run auto CI-NEB
        PATH {
            CI_scheme  = 'auto'
        }
        ifnotempty opt(CI_thr) {
            PATH " path_thr = $opt(CI_thr) "
        }
        runNEB neb.$head.auto

        # 3. plot MEP
        neb_plot $head

        # 4. ARTn refinement of the activation energy
        if { $opt(artn) } {
            neb_refine_artn $head
        }
    }
}
#******


#****f* neb.x utilities/::pwtk::manual_neb
# SYNOPSIS
proc ::pwtk::manual_neb {args} {
    # USAGE
    #   ::pwtk::manual_neb  ?-noCI_thr THRESHOLD?  ?-CI_thr THRESHOLD?  ?-CI CI_LIST?  ?-onlyCI?  ?-artn?  HEAD
    #
    # PURPOSE
    #   Perform no-CI + manual-CI NEB calculations, and plot the
    #   resulting energy profile along MEP (minimum-energy path).
    #
    #   First, the "no-CI" NEB is performed up to a reduced threshold to
    #   stabilize the minimum-energy path and then CI-NEB is restarted
    #   with CI_scheme = 'manual' using a full-precision threshold.
    #
    #   After the NEB calculations are finished, the activation energy
    #   can be refined with the ARTn plugin by specifying the -artn
    #   option (it requires QE compiled with the ARTn plugin enabled).
    #   For ARTn, if the ARTN_PARAMETERS namelist is undefined or empty, PWTK
    #   uses its default (stored in $::pwtk::default_ARTN_PARAMETERS).
    #
    # OPTIONS
    # * -noCI_thr THRESHOLD ... path threshold for the preliminary no-CI NEB calculation;
    #                           if not specified a default preliminary-threshold is used.

    # * -CI_thr THRESHOLD ... path threshold for the CI-NEB calculation;
    #                         if not specified, the current path_thr is used, but
    #                         if path_thr is not set, the neb.x default is used.

    # * -CI CI_LIST ... list of climbing-images for the CLIMBING_IMAGES card

    # * -onlyCI ... skip the 'no-CI' calculation, i.e., perform only CI calculation

    # * -artn ... refine the activation energy with the ARTn pw.x calculation
    #             (this option requires QE compiled with the ARTn plugin enabled)
    #
    # ARGUMENTS
    # * HEAD ... the rootname for the I/O files
    #
    # SIDE EFFECTS    
    #   "prefix" and outdir_postfix are set to HEAD, whereas all
    #   other modifications are popped away after completion because
    #   both calculations are performed with input_pushpop.
    #
    # SOURCE
    
    variable noCI_path_thr
    variable neb_options

    print NEB "no-CI + manual-CI NEB calculation\n"

    set narg 1
    set options [concat $neb_options {
        {CI.arg   {} "list of climbing images for the CLIMBING_IMAGES card"}
    }]
    set usage "?-noCI_thr THRESHOLD?  ?-CI_thr THRESHOLD?  ?-CI CI_LIST?  ?-onlyCI?  ?-artn?  HEAD"
    ::pwtk::parseOpt_
    ::pwtk::checkOType_ -noCI_thr $opt(noCI_thr) {number posreal} "positive real number"
    ::pwtk::checkOType_ -CI_thr   $opt(CI_thr)   {number posreal} "positive real number"
    ::pwtk::checkOType_ -CI       $opt(CI)    {numberlist posint} "list of positive integer numbers"
    set head $args

    ifset opt(noCI_thr) $noCI_path_thr

    outdir_postfix $head
    CONTROL " prefix = '$head' "

    ::pwtk::input::pushpop {
        # 1. run no-CI NEB
        if { ! $opt(onlyCI) } {
            ::pwtk::input::pushpop {
                PATH "
                   CI_scheme = 'no-CI'
                   path_thr  = $opt(noCI_thr)
                "
                runNEB neb.$head.no-CI
            }
            PATH {
                restart_mode = 'restart'
            }
        }

        # 2. run manual CI-NEB
        PATH {
            CI_scheme    = 'manual'
        }
        ifnotempty opt(CI_thr) {
            PATH " path_thr = $opt(CI_thr) "
        }
        ifnotempty opt(CI) {
            CLIMBING_IMAGES $opt(CI)
        }
        runNEB neb.$head.manual

        # 3. plot MEP
        neb_plot $head

        # 4. ARTn refinement of the activation energy
        if { $opt(artn) } {
            neb_refine_artn $head
        }
    }
}
#******


#****f* neb.x utilities/::pwtk::FASTNEB
# SYNOPSIS
proc ::pwtk::FASTNEB {script} {
    # PURPOSE
    #   Set the FASTNEB script.
    #
    #   FASTNEB is a script for specifying specs of how to speedup the
    #   NEB calculation of the first part of the composite
    #   ::pwtk::fast_neb NEB calculation.
    #
    #   An example of speedup would be to use only a gamma k-point.
    #
    # EXAMPLE
    #      FASTNEB {
    #            K_POINTS (gamma)
    #       }
    #
    # SOURCE
    return [::pwtk::input::script FASTNEB $script]
}
#******


#****f* neb.x utilities/::pwtk::fast_neb
# SYNOPSIS
proc ::pwtk::fast_neb {args} {
    # USAGE
    #   ::pwtk::fast_neb ?-noCI_thr THRESHOLD?  ?-fast_thr THRESHOLD?  ?-CI_thr THRESHOLD?  ?-CI CI_LIST?  ?-onlyCI?  ?-artn?  auto|manual  HEAD
    #
    # PURPOSE    
    #   Perform a composite "fast-preliminary + full-precision" NEB
    #   calculation, where the fast-preliminary calculation consists
    #   of no-CI + CI NEB calculation (CI = climbing-image). To omit
    #   the no-CI calculation, use the -onlyCI option.
    #
    #   The 'full-precision' calculation starts from the
    #   'fast-preliminary' results and involves only the CI calculation.
    #
    #   After the NEB calculations are finished, the activation energy
    #   can be refined with the ARTn plugin by specifying the -artn
    #   option (it requires QE compiled with the ARTn plugin enabled).
    #   For ARTn, if the ARTN_PARAMETERS namelist is undefined or empty, PWTK
    #   uses its default (stored in $::pwtk::default_ARTN_PARAMETERS).
    #
    #   The purpose of 'fast_neb' is to speedup the NEB calculation. The
    #   preliminary NEB is peformed with the reduced precision as set
    #   by the FASTNEB script (see ::pwtk::FASTNEB).
    #
    # OPTIONS
    # * -noCI_thr THRESHOLD ... path threshold for the preliminary fast no-CI NEB calculation
    #                           if not specified a default preliminary-threshold is used.

    # * -fast_thr THRESHOLD ... path threshold for the preliminary fast CI NEB calculation;
    #                           if not specified, the current path_thr is used, but
    #                           if path_thr is not set, the neb.x default is used.

    # * -CI_thr THRESHOLD ... path threshold for the full-precision CI-NEB calculation;
    #                         if not specified, the current path_thr is used, but
    #                         if path_thr is not set, the neb.x default is used.

    # * -CI CI_LIST ... list of climbing-images for the CLIMBING_IMAGES card

    # * -onlyCI ... skip 'no-CI' neb.x calculations, i.e. go direct to 'auto' or 'manual' CI calculation

    # * -artn ... refine the activation energy with the ARTn pw.x calculation
    #             (this option requires QE compiled with the ARTn plugin enabled)
    #
    # ARGUMENTS
    # * mode|manual ... the CI mode (auto or manual)
    # * HEAD ... the rootname for the I/O files
    #
    # SIDE EFFECTS    
    #   "prefix" and outdir_postfix are set to HEAD, whereas all
    #   other modifications are popped away after complition because
    #   both calculations are performed with input_pushpop.
    #
    # SOURCE

    variable noCI_path_thr
    variable neb_options

    set narg 2
    set usage "?-noCI_thr THRESHOLD?  ?-fast_thr THRESHOLD?  ?-CI_thr THRESHOLD?  ?-CI CI_LIST?  ?-onlyCI?  ?-artn?  auto|manual  HEAD"
    set options [concat $neb_options {
        {fast_thr.arg {}  "CI path-threshold for the preliminary fast CI-NEB calculation"}
        {CI.arg       {}  "list of climbing images for the CLIMBING_IMAGES card"}
    }]
    ::pwtk::parseOpt_
    ::pwtk::checkOType_ -noCI_thr $opt(noCI_thr) {number posreal} "positive real number"
    ::pwtk::checkOType_ -fast_thr $opt(fast_thr) {number posreal} "positive real number"
    ::pwtk::checkOType_ -CI_thr   $opt(CI_thr)   {number posreal} "positive real number"
    ::pwtk::checkOType_ -CI       $opt(CI)    {numberlist posint} "list of positive integer numbers"

    set mode [string trim [lindex $args 0] ']
    set head [lindex $args 1]

    printTitle FAST_NEB "Composite NEB calculation with CI_scheme = $mode"

    switch -exact $mode {
        auto - manual {}
        default {
            error "unknown CI_scheme \"$CI_scheme\", must be auto or manual"
        }
    }
    set onlyCI ""
    if { $opt(onlyCI) } { set onlyCI "-onlyCI" }

    set fastneb [::pwtk::input::scriptGet FASTNEB]

    if { $fastneb == {} } {
        ::pwtk::error "Cannot perform fast_neb calculation, FASTNEB script is missing" 1
    }
    
    ::pwtk::input::pushpop {        
        print "Preliminary NEB calculations with a lower accuracy:
   * calculation will be performed in subdirectory:  ./fastneb.$head.d/
   * path_thr = $opt(fast_thr)
   * FASTNEB script :
$fastneb
"        
    
        eval_in_dir fastneb.$head.d {
            # the recipe for a speedup is specified in the FASTNEB script
            eval $fastneb
        
            # perform a fast_neb calculation
            if { $mode eq "auto" } {
                auto_neb -noCI_thr $opt(noCI_thr) -CI_thr $opt(fast_thr) {*}$onlyCI $head
            } else {
                manual_neb -noCI_thr $opt(noCI_thr) -CI_thr $opt(fast_thr) -CI $opt(CI) {*}$onlyCI $head
            }
        
            # create the "initialized" path file in ../
            
            # BEWARE: take care of the PWTK restart mode, i.e., write
            # the "initialized" path file when restart is off, but if
            # restart=on, then write it only if fastneb.$head.path is
            # newer than ../$head.path
            
            set write 0
            if { ! [file exists ../$head.path] || ! [restart] } {
                set write 1
            } elseif { [file exists ../$head.path] && [file atime $head.path] > [file atime ../$head.path] } {
                set write 1
            }    
            if { $write } {
                # we need to initialize the PATH file and set the
                # fixAtoms if_pos(*) fields to those corresponding to
                # the currently stored POSITIONS supercard

                writeFile ../$head.path [::pwtk::nebi::fixAtoms_inPATH [::pwtk::path::initialize $head.path]]
            }
        }; # eval_in_dir
    }; # ::pwtk::input::pushpop

    # what is the path_thr (needed for printout)
    set path_thr $opt(CI_thr)
    ::pwtk::ifempty path_thr {
        set path_thr [::pwtk::input::namelistGetVarValue PATH path_thr]
    }
    
    print "Performing the full precision CI-NEB calculation
   * restoring original input data
   * calculation will be performed in ./
   * path_thr = $path_thr\n"

    # perform the CI-NEB calculation in restart-mode
    
    outdir_postfix $head
    CONTROL " prefix = '$head' "

    ::pwtk::input::pushpop {
        PATH [subst {
            restart_mode = 'restart'
            CI_scheme    = [squote $mode]
        }]
        ::pwtk::ifnotempty opt(CI_thr) {
            PATH " path_thr = $opt(CI_thr) "
        }

        if { $mode == "manual" && $opt(CI) != {} } {
            CLIMBING_IMAGES $opt(CI)
        }
        runNEB neb.$head.$mode

        neb_plot $head

        # ARTn refinement of the activation energy
        if { $opt(artn) } {
            neb_refine_artn $head
        }
    }
}
#******


#****f* neb.x utilities/::pwtk::SPINNEB
# SYNOPSIS
proc ::pwtk::SPINNEB {script} {
    # PURPOSE
    #   Set the SPINNEB script for the ::pwtk::re_spin_neb calculation.
    #
    #   SPINNEB is a script for setting a proper spin-polarized input
    #   for the ::pwtk::re_spin_neb calculation.
    #
    #   The problem is that for spin-polarized calculation, we need
    #   additional ATOMIC_SPECIES to define spin-up and spin-down
    #   atomic species. Hence, the ityp arrays loaded from a non
    #   spin-polarized neb.x input may have wrong ityp indices!
    #
    #   With the SPINNEB script this can be corrected because the
    #   script is executed after the old neb.x input is loaded and
    #   before the neb.x calculation is executed.
    #
    # EXAMPLE
    #   SPINNEB {
    #      SYSTEM {
    #          starting_magnetization(Fe1) = 1.0
    #          starting_magnetization(Fe2) = -1.0
    #      }
    #      ATOMIC_SPECIES {
    #         Fe1 1.0  Fe.pbe-nd-rrkjus.UPF
    #         Fe2 1.0  Fe.pbe-nd-rrkjus.UPF
    #         ...
    #      }
    #   }
    #
    # SOURCE
    return [script SPINNEB $script]
}
#******


#****f* neb.x utilities/::pwtk::re_spin_neb
# SYNOPSIS
proc ::pwtk::re_spin_neb {args} {
    # USAGE
    #   ::pwtk::re_spin_neb ?-path_thr THRESHOLD?  ?-artn?  HEAD  IND_MAGATM_LIST  OLD_NEBI  OLD_PATH
    #
    # PURPOSE
    #   Perform a spin-polarized neb.x calculation from the previous
    #   nonmagnetic NEB calculation, such that neb.x is restarted from
    #   the nonmagnetic "path" file (hence, the prefix re in
    #   re_spin_neb, i.e., re = restart)
    #
    #   |html <b>Motivation:</b> in many cases, such as chemical
    #   reactions on magnetic surfaces, structures may be reasonably
    #   predicted with nonmagnetic calculation, hence nonmagnetic +
    #   magnetic NEB may result in an overall faster calculation.
    #
    #   The magnetic specs of the new spin-polarized calculation are
    #   specified via the SPINNEB script (see ::pwtk::SPINNEB).
    #
    #   After the NEB calculation, the activation energy can be
    #   refined with the ARTn plugin by specifying the -artn option
    #   (it requires QE compiled with the ARTn plugin enabled).  For
    #   ARTn, if the ARTN_PARAMETERS namelist is undefined or empty,
    #   PWTK uses its default (stored in $::pwtk::default_ARTN_PARAMETERS).
    #
    # OPTIONS
    # * -path_thr THRESHOLD ... path threshold for the neb.x calculation, otherwise
    #                           path_thr from the $old_nebi neb.x input file or the
    #                           QE default is used, if path_thr is not set in old_nebi.

    # * -artn ... refine the activation energy with the ARTn pw.x calculation
    #             (this option requires QE compiled with the ARTn plugin enabled)
    #
    # ARGUMENTS
    # * HEAD ... the rootname for the I/O files

    # * IND_MAGATM_LIST ... list of magnetic atoms consisting of the
    #                       atom-index atom-symbol pairs (see below)

    # * OLD_NEBI -- old (previous) neb.x input file
    # * OLD_PATH -- old (previous) neb.x path file
    #
    # The structure of the 'IND_MAGATM_LIST' list is the following:
    #
    #     set IND_MAGATM_LIST {
    #         atom-index1 atom-symbol1
    #         atom-index2 atom-symbol2
    #         ...
    #     }
    #
    # where:
    # * atom-index  --- index of the atom in the structure to substitute with the new magnetic atom
    # * atom-symbol --- new atomic symbol for the 'atom-index' atom
    #
    # SIDE EFFECTS
    #   The whole "machinery" is evaluated inside ::pwtk::input::pushpop {}.
    #   For the ::pwtk::re_spin_neb, the input data are loaded from the OLD_NEBI
    #   neb.x input file, but the "outdir" from the OLD_NEBI is ignored.
    #
    #   The following settings are used for the new spin-polarized NEB
    #   calculation:
    #
    #   1.
    #      outdir_postfix $head
    #      CONTROL " prefix = '$head' "
    #      SYSTEM  { nspin = 2 }
    #
    #   2. If the ATOMIC_SPECIES card exists prior to loading the old
    #   neb.x input (OLD_NEBI), it is used instead of the one in OLD_NEBI.
    #
    #   3. If 1+2 are not sufficient for a given re_spin_neb calculation,
    #   then further tuning can be achieved with the SPINNEB script,
    #   which is executed the last before running the new neb.x
    #   calculation.    
    #
    # SOURCE

    printTitle SPIN_NEB "Running \"spin\" NEB leveraging the previous NEB calculation"

    set narg 4    
    set options {
        {path_thr.arg {} "path_thr for neb.x calculation"}
        {artn            "refine the neb.x calculated activation energy with the ARTn plugin"}
    }
    set usage "?-path_thr THRESHOLD?  ?-artn?  HEAD  IND_MAGATM_LIST  OLD_NEBI  OLD_PATH"
    ::pwtk::parseOpt_
    ::pwtk::checkOType_ -path_thr $opt(path_thr) {number posreal} "positive real number"

    lassign $args head indAtmList old_nebi old_path

    print "* old neb.x input file:  $old_nebi
* old neb.x path file:   $old_path\n"

    ::pwtk::fileMustExist $old_nebi {neb.x input}
    ::pwtk::fileMustExist $old_path {neb.x path}

    ::pwtk::input::pushpop {

        # load an old neb.x input file and turn the spin-polarized setup on

        # if ATOMIC_SPECIES exist prior to loading the neb.x input
        # file, they are kept because they may contain correct
        # spin-polarized atomic species
        #
        # otherwise rely on SPINNEB script to amend the situation
        
        set oldSpecies [::pwtk::input::cardGetContent ATOMIC_SPECIES]
        #
        load_fromNEBI $old_nebi
        #
        CONTROL [subst {
            prefix = '$head'
            outdir =
        }]
        SYSTEM  { nspin = 2 }
                 
        ifnotempty oldSpecies {
            ATOMIC_SPECIES $oldSpecies
        }
        outdir_postfix spin.$head

        # evaluate the SPINNEB script
        
        set spinneb [::pwtk::input::scriptGet SPINNEB]
        ifnotempty spinneb {
            print "* SPINNEB script :\n$spinneb\n"
            
            eval $spinneb
        }

        # replace atoms with magnetic-atoms and set their starting_magnetization
        
        foreach {ind atm} $indAtmList {
            print "* replacing atom $ind with the new type:  $atm"
            ::pwtk::nebi::substituteAtom $ind $atm
        }

        # initialize the new-path file from the old_path

        writeFile $head.path [::pwtk::path::initialize $old_path]

        # if CI_scheme eq {}, let "auto" be the default
        
        set mode [::pwtk::input::namelistGetVarValue PATH CI_scheme trim]
        ifset mode auto
        
        # run the neb.x calculation in restart mode
        
        PATH [subst {
            restart_mode = 'restart'
            CI_scheme  = [squote $mode]
        }]
        ifnotempty opt(path_thr) {
            PATH " path_thr = $opt(path_thr) "
        }
        runNEB neb.$head.$mode

        neb_plot $head

        if { $opt(artn) } {
            neb_refine_artn $head
        }
    }
}
#******


#****f* neb.x utilities/::pwtk::neb_refine_auto
# SYNOPSIS
proc ::pwtk::neb_refine_auto {args} {
    # USAGE
    #   ::pwtk::neb_refine_auto ?OPTIONS?  NEW_PREFIX  NUM_OF_IMAGES
    #
    #   where OPTIONS are:
    #
    #      -nebi NEBI
    #      -crd  CRD
    #      -path PATH
    #      -CI_scheme SCHEME
    #      -CI        INDEXES
    #      -CI_thr    THRESHOLD
    #
    # PURPOSE
    #   Refine an existing neb.x minimum-energy path (MEP) by using a
    #   denser MEP discretezation around the transition-state (TS) image.
    #
    #   This command is typically called after a converged neb.x
    #   calculation (called previous-NEB).
    #
    #   The TS image is determined from the previous-NEB path file,
    #   i.e., PREFIX.path, where the PREFIX is obtained from the value
    #   of the 'prefix' variable in the current CONTROL namelist (if
    #   the -nebi option was given, then 'prefix' is taken from the
    #   provided input).
    #
    #   For the refined NEB calculation, the previous-NEB TS-1, TS,
    #   TS+1 images are taken for the new refinement calculation. The
    #   algorithm is the following:
    #
    #   1. use the previous-NEB TS-1, TS, TS+1 images as the new
    #      FIRST_IMAGE, INTERMEDIATE_IMAGE, and LAST_IMAGE
    #
    #   2. fix the  FIRST_IMAGE and LAST_IMAGE (aka first_last_opt = .false.)
    #
    #   3. perform a new neb.x calculation with NUM_OF_IMAGES, which
    #      is specified as the command-line argument.
    #
    #   This command needs the CRD and PATH files of the
    #   previous-NEB. They can be specified with the command line
    #   options. If no options are provided, then all the needed data
    #   are taken from the current input data (as specified in the
    #   PWTK script prior to calling this command). Otherwise, the
    #   options have the following meaning.
    #
    # ARGUMENTS
    # * NEW_PREFIX -- prefix used for the new refinement neb.x calculation
    # * NUM_OF_IMAGES -- number of images for the new refinement neb.x calculation
    #
    # OPTIONS
    # * -nebi NEBI ... the neb.x input file of previous-NEB
    # * -crd  CRD  ... the neb.x crd file of previous-NEB
    # * -path PATH ... the neb.x path file of previous-NEB
    # * -CI_scheme SCHEME ... CI_scheme for the new refined neb.x calculation
    # * -CI INDEXES ... list of indexes of CLIMBING_IMAGES for the new refined 
    #                   neb.x calculation (only used for CI_scheme = 'manual')
    # * -CI_thr THRESHOLD ... the value of path_thr the new refined neb.x calculation
    # 
    # Rules:
    # * PREFIX is obtained from the value of the 'prefix' variable in
    #   the current CONTROL namelist (if the -nebi option was given,
    #   then 'prefix' is taken from the provided input).
    # * if the -crd option was not given, PREFIX.crd is assumed for the crd file
    # * if the -path option was not given, PREFIX.path is assumed for the path file
    # * if the -CI_scheme option was not given, the current value of CI_scheme is used
    # * if the -CI option was not given, the current CLIMBING_IMAGES card is used (only for CI_scheme = 'manual')
    # * if the -CI_thr option was not given, the current value of path_thr is used
    #
    # RETURN VALUE
    # * the name of the neb.x output file, which is neb.$NEW_PREFIX.$CI_scheme.out
    #
    # SOURCE

    printTitle NEB "Auto-refining neb.x MEP"
    
    set narg 2
    set usage "NEW_PREFIX  NUM_OF_IMAGES"

    ::pwtk::neb_refine_parse_and_load_
    lassign $args new_prefix num_of_images

    # get iTS, Emax, and E(i)
    foreach {var datum} [::pwtk::path::energies $pathFile] { set $var $datum }

    set firstImage [expr { $iTS > 1 ? $iTS-1 : $iTS }]
    set lastImage  [expr { $iTS < $nImages ? $iTS+1 : $iTS }]

    ::pwtk::neb_refine_exe_ 
}
#******


#****f* neb.x utilities/::pwtk::neb_refine
# SYNOPSIS
proc ::pwtk::neb_refine {args} {
    # USAGE
    #   ::pwtk::neb_refine ?OPTIONS?  FIRST_IMAGE  LAST_IMAGE  NEW_PREFIX  NUM_OF_IMAGES
    #
    #   where OPTIONS are:
    #
    #      -nebi NEBI
    #      -crd  CRD
    #      -path PATH
    #      -CI_scheme SCHEME
    #      -CI        INDEXES
    #      -CI_thr    THRESHOLD
    #
    # PURPOSE
    #   Refine an existing neb.x minimum-energy path (MEP) by using a
    #   denser MEP discretezation.
    #
    #   This command is typically called after a converged neb.x
    #   calculation (called previous-NEB).
    #
    #   This command is similar to the ::pwtk::neb_refine_auto
    #   command. The difference is that images to be used in the
    #   refined NEB calculation are not automatically determined.
    #   Instead, the portion of MEP to be refined needs to be
    #   explicitly specified with the FIRST_IMAGE and LAST_IMAGE
    #   indices.
    #    
    # ARGUMENTS
    # * FIRST_IMAGE -- take the image #.firstImage from previous-NEB as
    #                  the FIRST_IMAGE of the new refinement neb.x calculation    
    # * LAST_IMAGE -- take the image #.lastImage from previous-NEB as
    #                 the LAST_IMAGE of the new refinement neb.x calculation
    # * NEW_PREFIX -- prefix used for the new refinement neb.x calculation
    # * NUM_OF_IMAGES -- number of images for the new refinement neb.x calculation
    #
    # OPTIONS
    # * -nebi NEBI ... the neb.x input file of previous-NEB
    # * -crd  CRD  ... the neb.x crd file of previous-NEB
    # * -path PATH ... the neb.x path file of previous-NEB
    # * -CI_scheme SCHEME ... CI_scheme for the new refined neb.x calculation
    # * -CI INDEXES ... list of indexes of CLIMBING_IMAGES for the new refined 
    #                   neb.x calculation (only used for CI_scheme = 'manual'
    # * -CI_thr THRESHOLD ... the value of path_thr the new refined neb.x calculation
    #
    # RETURN VALUE
    # * the name of the neb.x output file, which is neb.$NEW_PREFIX.$CI_scheme.out
    #
    # SOURCE

    printTitle NEB "Refining neb.x MEP"
    
    set narg 4
    set usage "FIRST_IMAGE  LAST_IMAGE  NEW_PREFIX  NUM_OF_IMAGES"

    ::pwtk::neb_refine_parse_and_load_
    lassign $args firstImage lastImage new_prefix num_of_images

    # get iTS, Emax, and E(i)
    foreach {var value} [::pwtk::path::energies $pathFile] { set $var $value }

    ::pwtk::neb_refine_exe_
}
#******


# ***internal...
proc ::pwtk::neb_refine_parse_and_load_ {} {
    uplevel 1 {
        # mandatory variables: narg & usage
        set usage "?-nebi NEBI?  ?-crd CRD?  ?-path PATH?  ?-CI_scheme SCHEME?  ?-CI INDEXES?  ?-CI_thr THRESHOLD?  $usage"
        set options {
            {nebi.arg  {} "source neb.x input file"}
            {crd.arg   {} "source neb.x CRD file"}
            {path.arg  {} "source neb.x PATH file"}
            {CI_scheme.arg {} "CI_scheme for the refined neb.x calculation"}
            {CI.arg        {} "list of indexes of CLIMBING_IMAGES for the refined neb.x calculation"}
            {CI_thr.arg    {} "the value of 'path_thr' for the refined neb.x calculation" }
        }
        parseOpt_
        checkOType_ -CI     $opt(CI)     {numberlist posint} "list of positive integer numbers"
        checkOType_ -CI_thr $opt(CI_thr) {number posreal}    "positive real number"

        lassign {} nebi crdFile pathFile
        
        if { $opt(nebi) ne "" } {
            set nebi $opt(nebi)
            ::pwtk::fileMustExist $nebi "neb.x input file"
            ::pwtk::nebi::load_fromNEBI $nebi
        }
        if { $opt(crd) ne "" } {
            set crdFile $opt(crd)
        }
        if { $opt(path) ne "" } {
            set pathFile $opt(path)
        }
        
        set src_prefix [::pwtk::input::namelistGetVarValue CONTROL prefix trim]
        ifset src_prefix pwscf
        
        ifset crdFile  $src_prefix.crd
        ifset pathFile $src_prefix.path
        
        ::pwtk::fileMustExist $crdFile "neb.x CRD"
        ::pwtk::fileMustExist $pathFile "neb.x PATH"

        ::pwtk::nebi::POSITIONS_fromCRD $crdFile

        # get number of images specified in the input
    
        set nImages [::pwtk::nebi::getNImages]
        if { $nImages < 2 } {
            ::pwtk::error "Cannot refine the neb.x calculation.\nThe supplied '$crdFile' file contains less than two images" 1
        }
    }
}


#****if* Internals/::pwtk::neb_refine_exe_
# SYNOPSIS
proc ::pwtk::neb_refine_exe_ {} {

    # mandatory variables: firstImage lastImage new_prefix num_of_images
    
    uplevel 1 {
        # previous-NEB: E*(->) and E*(<-) in eV
    
        set Eact_fwd [expr $::pwtk::ha2ev*($E($iTS) - $E(1))]
        set Eact_bck [expr $::pwtk::ha2ev*($E($iTS) - $E($nImages))]

        ifset nebi -
        print "Data from the previous neb.x calculation:

  previous-NEB input file:  $nebi
  previous-NEB path file :  $pathFile
  previous-NEB crd file  :  $crdFile

image        energy (eV)
"
        for {set i 1} {$i <= $nImages} {incr i} {
            print [format "%5i    %15.6f" $i [expr $::pwtk::ha2ev*$E($i)]]
        }
        print "
climbing image = $iTS

previous-NEB activation energy (->) = [format %7.3f $Eact_fwd] eV
previous-NEB activation energy (<-) = [format %7.3f $Eact_bck] eV

Data for the refinement neb.x calculation:

  index of the previous-NEB TS image:  $iTS
  image range of the previous-NEB MEP that will be refined:  \[$firstImage, $lastImage]
  number of images for the new neb.x:  $num_of_images"        
        ifnotempty opt(CI_scheme) { print "  CI_scheme for the new neb.x:         $opt(CI_scheme)" }
        ifnotempty opt(CI_thr)    { print "  path_thr  for the new neb.x:         $opt(CI_thr)" }        
        puts ""
        
        # check image indices
        if { ! [::pwtk::type::number posint -strict $firstImage] } { ::pwtk::error "expected positive integer for 'firstImage', but got $firstImage" 1 }
        if { ! [::pwtk::type::number posint -strict $lastImage] } { ::pwtk::error "expected positive integer for 'lastImage', but got $lastImage" 1 }
        if { ! [::pwtk::type::number posint -strict $num_of_images] } { ::pwtk::error "expected positive integer for 'num_of_images', but got $num_of_images" 1 }        
        if { ($lastImage < 2 || $lastImage > $nImages) } { ::pwtk "wrong index for the last image ($lastImage)" 1 }
        if { ($lastImage - $firstImage < 1) || ($firstImage < 1) } { ::pwtk::error "wrong index for the first image (firstImage=$firstImage, lastImage=$lastImage)" 1 }
        if { $num_of_images - ($lastImage - $firstImage) < 1 } { :
            :pwtk::error "specified 'num_of_images = $num_of_images' is too small, must be > [expr $lastImage - $firstImage]" 1
        }

        #
        # get positions of images
        #

        # first image: special treatment because it has if_pos(:) records
        
        set positions "
FIRST_IMAGE
[::pwtk::nebi::getImageAtmPos -k -if_pos $firstImage]
[::pwtk::nebi::getImageCharge -k $firstImage]
"

        # intermediate images

        for {set i [expr $firstImage+1]} {$i<$lastImage} {incr i} {
            append positions "
INTERMEDIATE_IMAGE    
[::pwtk::nebi::getImage $i]
"
        }

        # last image
        
        append positions "
LAST_IMAGE
[::pwtk::nebi::getImage $lastImage]
"

        # load positions
    
        POSITIONS $positions

        # adapt the input variables

        outdir_prefix [outdir]
        outdir_postfix $new_prefix
    
        PATH [subst {
            num_of_images = $num_of_images
            first_last_opt = .false.
        }]
        if { $opt(CI_thr) ne {} } {
            PATH " path_thr = $opt(CI_thr) "
        }
        CONTROL " prefix = '$new_prefix' "

        if { $opt(CI_scheme) ne {} } {
            PATH " CI_scheme = [squote $opt(CI_scheme)] "
        }

        print "NEB input for the new neb.x:\n\n[::pwtk::input::namelistGet PATH]"
        
        if { $opt(CI) ne {} } {
            CLIMBING_IMAGES $opt(CI)
            print [::pwtk::input::namelistPrint CLIMBING_IMAGES]
        }

        

        
        # run the neb.x calculation

        set CI_scheme [::pwtk::input::namelistGetVarValue PATH CI_scheme trim]
        ifset CI_scheme no-CI
        runNEB neb.$new_prefix.$CI_scheme

        neb_plot $new_prefix

        # final printout of energies
        
        array set new [::pwtk::path::energies $new_prefix.path]
        set newE(TS) $new(Emax)
         # BEWARE: energies in the path file are in Hartrees
        set Eact_fwd [expr $::pwtk::ha2ev*($newE(TS) - $E(1))]
        set Eact_bck [expr $::pwtk::ha2ev*($newE(TS) - $E($nImages))]
        
        print "Data from the new refined neb.x calculation:

  new neb.x input  file:  neb.$new_prefix.$CI_scheme.in
  new neb.x output file:  neb.$new_prefix.$CI_scheme.out

image        energy (eV)
"
        for {set i 1} {$i <= $num_of_images} {incr i} {
            set key E($i)
            print [format "%5i    %15.6f" $i [expr $::pwtk::ha2ev*$new($key)]]
        }
        print "
climbing image = $new(iTS)

  previous_E(IS) = [format %7.3f [expr $::pwtk::ha2ev*$E(1)]] eV
  new_E(TS)      = [format %7.3f [expr $::pwtk::ha2ev*$new(Emax)]] eV
  previous_E(FS) = [format %7.3f [expr $::pwtk::ha2ev*$E($nImages)]] eV

new activation energy (->) = new_E(TS) - previous_E(IS) = [format %7.3f $Eact_fwd] eV
new activation energy (<-) = new_E(TS) - previous_E(FS) = [format %7.3f $Eact_bck] eV

merging previous and new NEB files...
"
        # merge src & new NEB dat, int, crd, and axsf files
        
        foreach {type name} [::pwtk::neb_refine_merge $src_prefix $new_prefix $firstImage $lastImage] {
            ::pwtk::print "  merged [format %-4s [string toupper $type]] file written to:  $name"
        }
        puts ""
        
        return neb.$new_prefix.$CI_scheme.out
    }
}
#******


#****f* neb.x utilities/::pwtk::neb_refine_merge
# SYNOPSIS
proc ::pwtk::neb_refine_merge {src_prefix ref_prefix iref_IS iref_FS} {
    # PURPOSE
    #   Merge the original (aka previous-NEB) and refined NEB *.dat,
    #   *.int, *.axsf, and *.xyz files. The refined NEB means a NEB
    #   calculation on a segment of the original minimum-energy path
    #   (MEP), for example, performed by the ::pwtk::neb_refine_auto
    #   or ::pwtk::neb_refine command.
    #
    #   The name of the merged files is based on the names of the
    #   refined files; if the refined files are named refined.name.*,
    #   then the merged files are named merged.name.*
    #
    # REMARK
    #   This routine is used by ::pwtk::neb_refine and ::pwtk::neb_refine_auto
    #    
    # ARGUMENTS
    # * src_prefix -- prefix of the original (source; aka previous-NEB) neb.x *.dat file (filename == $src_prefix.dat)
    # * ref_prefix -- prefix of the refined neb.x *.dat file (filename == $ref_prefix.dat)
    # * iref_IS -- source (src) image index for IS in the refined neb.x calculation
    # * iref_FS -- source (src) image index for FS in the refined neb.x calculation
    #
    # RETURN VALUE
    #   A dictionary of the merged filenames, where key is the file-type
    #   and value the file-name, i.e.:
    #
    #      dat file.dat   int file.int   axsf file.axsf   xyz file.xyz    
    #
    # SOURCE
    
    set exts {.dat .int .crd .axsf .xyz}
    foreach e $exts {
        set ext [string trim $e .]
        # if prefixes are specified 'file.$ext', strip the extension
        set srcFile($ext) [::pwtk::headname $src_prefix $exts].$ext
        set refFile($ext) [::pwtk::headname $ref_prefix $exts].$ext
        ::pwtk::fileMustExist $srcFile($ext) "neb.x $ext file"
        ::pwtk::fileMustExist $refFile($ext) "neb.x $ext file"
    }

    # read *.dat files
    proc read_datfile_ {datfile d_var dE_var err_var N_var} {
        upvar $d_var d $dE_var dE $err_var err $N_var N
        foreach line [split [::pwtk::readFile $datfile] \n] {
            if { [llength $line] == 3 } {
                incr N
                lassign $line d($N) dE($N) err($N)
            }
        }
    }
    read_datfile_ $srcFile(dat) src_d src_dE src_err src_N
    read_datfile_ $refFile(dat) ref_d ref_dE ref_err ref_N

    if { $iref_IS < 1 || $iref_FS > $src_N || $iref_IS >= $iref_FS } {
        ::pwtk::error "iref_IS & iref_FS indices are either out of range or improperly chosen,\nmust be within \[1,$src_N], but got \[$iref_IS,$iref_FS]" 1
    }

    # distance-scale to match "refined" with the "source (aka previous-NEB)
    
    set dsc [expr $src_d($iref_FS) - $src_d($iref_IS)]
    
    # merge *.dat file
     
    set dat_fmt "  %16.10f  %16.10f  %16.10f\n"
    for {set i 1} {$i <= $src_N} {incr i} {        
        if { $i <= $iref_IS || $i >= $iref_FS } {
            append result(dat) [format $dat_fmt $src_d($i) $src_dE($i) $src_err($i)]

            # save coordinates
            incr image
            set coor($image) [::pwtk::formatCoor  [::pwtk::xsf::getPrimCoor $srcFile(axsf) $i] ]
            
            if { $i == $iref_IS } {
                # insert the refined *.dat file from image 2,ref_N-1
                for {set j 2} {$j <= $ref_N-1} {incr j} {
                    set d  [expr $src_d($i) + $dsc*$ref_d($j)]
                    set dE [expr $src_dE($i) + $ref_dE($j)]
                    append result(dat) [format $dat_fmt $d $dE $src_err($i)]

                    incr image
                    set coor($image) [::pwtk::formatCoor  [::pwtk::xsf::getPrimCoor $refFile(axsf) $j] ]
                }
            }
        }
    }
    
    # read *.int files

    proc read_intfile_ {intfile d_var dE_var N_var} {
        upvar $d_var d $dE_var dE $N_var N
        foreach line [split [::pwtk::readFile $intfile] \n] {
            if { [llength $line] == 2 } {
                incr N
                lassign $line d($N) dE($N)
            }
        }
    }
    read_intfile_ $srcFile(int) src_int_d src_int_dE src_int_N
    read_intfile_ $refFile(int) ref_int_d ref_int_dE ref_int_N

    # merge *.int files
    
    set int_fmt "  %16.10f  %16.10f\n"
    
    for {set i 1} {$i <= $src_int_N} {incr i} {        
        if { $src_int_d($i) < $src_d($iref_IS) || $src_int_d($i) > $src_d($iref_FS) } {
            
            append result(int) [format $int_fmt $src_int_d($i) $src_int_dE($i)]

        } else {
            ::pwtk::ifnotexist inserted {
                # insert the refined *.int file
                for {set j 1} {$j <= $ref_int_N} {incr j} {
                    set d  [expr $src_d($iref_IS) + $dsc*$ref_int_d($j)]
                    set dE [expr $src_dE($iref_IS) + $ref_int_dE($j)]
                    append result(int) [format $int_fmt $d $dE]                    
                }
                set inserted 1
            }
        }
    }

    # merge *.axsf & *.xyz files
    
    set nat [::pwtk::xsf::getNAtoms $srcFile(axsf)]
    set result(axsf) "ANIMSTEPS $image
CRYSTAL\nPRIMVEC\n[::pwtk::xsf::getPrimVec $srcFile(axsf)]\n"
    
    for {set i 1} {$i <= $image} {incr i} {
        append result(axsf) "\nPRIMCOORD $i\n$nat 1\n$coor($i)"
        append result(xyz)  "$nat\n\n[::pwtk::formatCoor [::pwtk::atmPosToCoor $coor($i)]]\n"
    }       

    # write the resulting files

    set result_dict [dict create]
    set head merged.[::pwtk::trim_prefix refined [file rootname $refFile(dat)]]
    foreach ext {dat int axsf xyz} {
        set merFile($ext) $head.$ext
        ::pwtk::writeFile $merFile($ext) $result($ext)
        dict append result_dict $ext $merFile($ext)
    }

    # plot merged MEP

    neb_plot $head

    return $result_dict
}
#******



#****f* neb.x utilities/::pwtk::neb_plot
# SYNOPSIS
proc ::pwtk::neb_plot {args} {
    # USAGE
    #   ::pwtk::neb_plot  ?-wp WITH?  ?-artn ACTIVATION_ENERGY?  ?-aw WITH?  ?PLOTTING-OPTIONS?  ?HEAD?
    #
    # OPTIONS
    # * -wp WITH --- Gnuplot's "with" plot specs for energy points in neb.x DAT file
    #                (wp = with-points; the -w option is used for the neb.x INT file)

    # * -artn ACTIVATION_ENERGY --- the refined value of the activation energy
    #                               calculated with the ARTn plugin (it will be
    #                               displayed on the plot with the horizontal line)

    # * -aw WITH --- Gnuplot's "with" plot specs for the ARTn activation-energy line
    #
    # PLOTTING OPTIONS
    #   See ::pwtk::plot (N.B. the -u option is ignored)
    #
    # ARGUMENT
    # * HEAD --- the rootname for the neb.x DAT and INT files (i.e. $HEAD.dat, $HEAD.int)
    #
    # DESCRIPTION
    #   Plot the neb.x calculated MEP (minimum-energy path) along the reaction coordinate.
    #
    # SOURCE

    if { [auto_execok gnuplot] == {} } {
        ::pwtk::error "[procName] requires gnuplot, but gnuplot was not found"
        return
    }
    
    ::pwtk::gp::defaultCmdlineOpts_ plot options usage workflow

    ignoredOpts_ -u $args

    addOpts_ options usage {
        {wp.arg   "Gnuplot's \"with\" splot specification for NEB energy points"}
        {artn.arg "the refined value of the activation energy calculated with the ARTn plugin"}
        {aw.arg   "Gnuplot's \"with\" plot specs for the ARTn activation-energy line"}
    } {
        {-wp WITH} {-artn ACTIVATION_ENERGY}  {-aw WITH}
    }
    setOpts_ options [subst {
        xl  {'Reaction coordinate (relative units)'}
        yl  {'{/${::pwtk::gp::gp(font)}-Italic E} − {/${::pwtk::gp::gp(font)}-Italic E}_{IS} (eV)'}
        xf  '%.1f'
        xt  0,0.2
        mx  4
        my  2
        xr  0:1
        wp  {p lt 1 lw 4 pt 7 ps 1.2}
        w   {l lt 2 lw 4}
        aw  {l lt 3 lw 4}
        t   eps
        artn {}
    }]
    #yf  '%.2f'

    set narg 1
    set usage "[fmtUsage_ $usage]  HEAD"
    parseOpt_
    ::pwtk::gp::checkCmdlineOpts_ opt
    set head $args

    if { $opt(artn) eq {} } {
        set plot $head
        print NEB "Plotting MEP along the reaction coordinate\n"
    } else {
        # N.B. the gnuplot file for ::pwtk::neb_refine_artn is artn.$head.gp
        set plot $head
        set head [::pwtk::trim_prefix artn $head]
        print NEB+ARTn "Plotting MEP along the reaction coordinate\n"
    }

    fileMustExist $head.dat "neb.x DAT file"
    fileMustExist $head.int "neb.x INT file"

    set gp [::pwtk::gp::plot new -s $opt(s) $plot.$opt(t)]

    $gp cmdlineOpts opt
    if { $opt(artn) eq {} } {
        $gp unset key
        $gp plot "'$head.int' w $opt(w), '$head.dat' w $opt(wp)"
    } else {
        # -artn option
        $gp set key opaque
        $gp plot "'$head.int' not w $opt(w), '$head.dat' t 'NEB' w $opt(wp), $opt(artn) t 'ARTn' w $opt(aw)"
    }

    return [::pwtk::gp::execDisplay_ $gp opt]
}
#******


#****f* neb.x utilities/::pwtk::neb_refine_artn
# SYNOPSIS
proc ::pwtk::neb_refine_artn {args} {
    # USAGE
    #   ::pwtk::neb_refine_artn ?-nebi NEBI?  ?HEAD?
    #
    # WARNING
    #   This command requires QE compiled with the ARTn plugin enabled.
    #
    # PURPOSE
    #   Refine the neb.x calculated activation energy and TS structure
    #   with the ARTn plugin.
    #
    #   If the ARTN_PARAMETERS namelist is undefined or empty, PWTK
    #   uses its default (stored in $::pwtk::default_ARTN_PARAMETERS).
    #
    #   This command reads the neb.x energies and structures from the
    #   PREFIX.path and PREFIX.crd files, respectively. For the TS,
    #   the image with the highest energy is used and this image is
    #   refined with the ARTn plugin.
    #
    #   The PREFIX is obtained from the value of the CONTROL 'prefix'
    #   variable (if the -nebi option was given, then 'prefix' is
    #   taken from the provided input).
    #   
    # OPTION
    # * -nebi NEBI ... (optional) load the input data from the the NEBI neb.x input file
    #
    # ARGUMENT
    # * HEAD ... (optional) the prefix for the ARTn pw.x I/O files, which are named as artn-relax.HEAD.in|out
    #            (default = the value of PREFIX, see above)
    #
    # RETURN VALUE
    # * The ARTn refined value of the activation energy (in eV)
    #
    # SOURCE

    print ARTn "Refining the neb.x calculated TS with the ARTn plugin\n"
    
    set nargmin 0
    set nargmax 1
    set usage "?-nebi NEBI?  ?HEAD?"
    set options {
        {nebi.arg  {} "neb.x input file"}
    }
    parseOpt_
    lassign $args head

    ::pwtk::input::pushpop {
        if { $opt(nebi) ne {} } {
            load_fromNEBI $opt(nebi)
        }

        set nstep  [::pwtk::input::namelistGetVarValue CONTROL nstep]
        set prefix [::pwtk::input::namelistGetVarValue CONTROL prefix trim]
        ifset prefix pwscf
        ifset head $prefix        
        
        ::pwtk::fileMustExist $prefix.crd  "neb.x CRD"
        ::pwtk::fileMustExist $prefix.path "neb.x PATH"

        # path info
        foreach {var value} [::pwtk::path::energies $prefix.path] { set $var $value }

        set Eact_fwd_neb [expr $::pwtk::ha2ev*($E($iTS) - $E(1))]
        set Eact_bck_neb [expr $::pwtk::ha2ev*($E($iTS) - $E($nImages))]

        # input data for ARTn
        
        CONTROL " calculation = 'relax'  prefix = 'artn.$prefix' "
        if { $nstep eq {} } {
            infoMsg "increasing CONTROL's nstep to 400"
            CONTROL { nstep = 400 }
        }
        ATOMIC_POSITIONS_fromCRD $prefix.crd $iTS

        # if the ARTN_PARAMETERS namelist is empty, use the default            
        if { [::pwtk::input::namelistVars_ ARTN_PARAMETERS] eq {} } {
            ARTN_PARAMETERS $::pwtk::default_ARTN_PARAMETERS
        }
        
        # run the ARTn pw.x calculation and extract the energy
        artn on
        set E(artn.TS) [pwo_totene [runPW artn-relax.$head]]
        artn off
    }

    # N.B. NEB path energies are in Hartrees, hence the factor 2.0
        
    set Eact_fwd_artn [format %.3f [expr $::pwtk::ry2ev*($E(artn.TS) - 2.0*$E(1))]]
    set Eact_bck_artn [format %.3f [expr $::pwtk::ry2ev*($E(artn.TS) - 2.0*$E($nImages))]]

    # printout
        
    print "Data from the neb.x calculation ($prefix.path):\n\nimage        energy (eV)\n"
    for {set i 1} {$i <= $nImages} {incr i} {
        print [format "%5i    %15.6f" $i [expr $::pwtk::ha2ev*$E($i)]]
    }
    print "
climbing image = $iTS

NEB activation energy (->) = E(TS) - E(IS) = [format %7.3f $Eact_fwd_neb] eV
NEB activation energy (<-) = E(TS) - E(FS) = [format %7.3f $Eact_bck_neb] eV


Refined values from the ARTNn pw.x calculation:

ARTn activation energy (->) = E(TS) - E(IS) = [format %7.3f $Eact_fwd_artn] eV
ARTn activation energy (<-) = E(TS) - E(FS) = [format %7.3f $Eact_bck_artn] eV
"

    # plot
    
    neb_plot -artn $Eact_fwd_artn artn.$head

    return $Eact_fwd_artn
}
#******
    
