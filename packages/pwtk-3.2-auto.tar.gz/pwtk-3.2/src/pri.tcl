#
# $RCSfile: pri.tcl,v $ --
#
#      This file contains the procs for handling the projwfc.x input.
#
# Copyright (c) 2009  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: pri.tcl,v 1.10 2021/05/03 14:21:08 tone Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::pri_fprint {{file {}}} { uplevel ::pwtk::pri::fprint $file }
proc ::pwtk::pri_get    {}          { uplevel ::pwtk::pri::get }
proc ::pwtk::pri_clear  {}          { uplevel ::pwtk::pri::clear }


# ------------------------------------------------------------------------
#
# actual implementation of procs
#
# ------------------------------------------------------------------------

#****f* ::pwtk::pri/::pwtk::pri::fprint
# SYNOPSIS
proc ::pwtk::pri::fprint {{file {}}} {
# PURPOSE
#   Print the content of projwfc.x input data to a file or to stdout if the
#   file was not specified.
# ARGUMENTS
#   * file -- [optional] filename to print to (default = stdout)
# SOURCE

    ::pwtk::input::fprint_ ::pwtk::pri $file
}
#****


#****f* ::pwtk::pri/::pwtk::pri::get
# SYNOPSIS
proc ::pwtk::pri::get {} {
    # DESCRIPTION    
    #   Return the content of the projwfc.x input. 
    # SOURCE

    loadDefaults_
    
    return [::pwtk::input::namelistGet PROJWFC]
}
#******
    

#****f* ::pwtk::pri/::pwtk::pri::clear
# SYNOPSIS
proc ::pwtk::pri::clear {} {
    # DESCRIPTION    
    #   Clear the content of the projwfc.x input.
    # SOURCE
    variable input_flow_list
    
    foreach name $input_flow_list {
	::pwtk::input::clear $name
    }
}
#******
    

proc ::pwtk::pri::loadDefaults_ {} {
    # load some default values, when user has omitted them 

    namespace eval ::pwtk::input {
	defaultVarValue_ PROJWFC outdir  [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
	defaultVarValue_ PROJWFC prefix  ""
    }
}


#****f* ::pwtk::pri/::pwtk::pri::load_fromPRI
# SYNOPSIS
proc ::pwtk::pri::load_fromPRI {pri {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing projwfc.x input file. 
    #
    #   If clear_existing == 1, then the current input will be cleared, but
    #   otherwise the data will be simply added to the existing data.
    #
    # ARGUMENTS
    # * pri -- filename of the projwfc.x input file from which to extract the input data
    # * clear_existing -- [optional] should the current input data be cleared?
    #
    # SOURCE

    ::pwtk::fileMustExist $pri "projwfc.x input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current projwfc.x input data ...
	::pwtk::input::clear PROJWFC
    }

    # read the namelists

    set output [::pwtk::readNamelists $pri $::pwtk::pri::input_flow_list]

    # projwfc.x must contain a PROJWFC namelist
    if { $output == "" } {
	::pwtk::error "input file \"$pri\" does not appear to be a projwfc.x input file" 1
    }

    eval $output
    ::pwtk::input::namelists_ityp2atmSymb_ $::pwtk::pri::input_flow_list
}
#******
