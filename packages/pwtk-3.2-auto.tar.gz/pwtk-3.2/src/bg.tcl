#
# $RCSfile: bg.tcl,v $ --
#
#      This file contains the implementation framework for running
#      scripts in background (aka backgrounds or bgs), enabling their
#      concurrent/parallel execution. The main command is ::pwtk:bg
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: bg.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#


#****a* Background Execution/Backgrounds
# DESCRIPTION
#   While 'run -bg' and 'runXX -bg' commands can only run executables
#   in background, bgs (aka backgrounds) can run script excerpts in
#   the background parallelly. Hence, they are a much more flexible way
#   of a concurrent/parallel execution than the 'run* -bg'
#   commands. Backgrounds (::pwtk::bg) are also safer to use than
#   threads (::pwtk::thread)
#******


#****f* Backgrounds/::pwtk::bg
# SYNOPSIS
proc ::pwtk::bg {args} {
    # USAGE
    #   bg  ?-r?  ?-s?  ?-np?  ?-id ID?  ?-fid FID?  script ?script? ?script ...?
    #    
    # OPTIONS
    # * -r ... redirect stdout of the job to a log file
    #          (the name of the logfile is bg.$scriptName.$id.log)
    # * -s ... silent mode, i.e., do not print the bg's info messages to stdout
    # * -np ... do not use the propagate mechanism
    #           (default = use propagate, see: ::pwtk::propagate)    

    # * -fid FID ... (used internally by PWTK) kind of File-ID used for assembling
    #                the filename of the script to execute in the background

    # * -id ID ... (used internally by PWTK) ID number 
    #
    # REMARK
    #   Options -s, -np, -fid, -id are typically only used internally by PWTK.
    #
    # PURPOSE
    #   Arranges for a script, formed by concatenating all the script
    #   arguments, to run in a background (technically, the script is
    #   executed by launching a new PWTK process in the background).
    #   Hence, the command returns immediately. To wait for the job to
    #   finish, use the ::pwtk::bg_wait command.
    #
    # ARGUMENTS
    #   The script to be executed in a background is formed by
    #   concatenating all the script arguments. For example, the
    #   following two examples are equivalent:
    #
    #      ::pwtk::bg print "I am a new bg job"
    #
    #      ::pwtk::bg {
    #          print "I am a new bg job"
    #      }
    #
    # RETURN VALUE
    # * the ID of the created background job (this ID can be used for
    #   the ::pwtk::bg_wait command)
    #
    # SOURCE

    variable bg

    set id [incr bg(count)]
    set index  $id
    set findex $id
    set bg($id,redirect) 0
    
    set options {
        {r         "redirect the stdout of this bg job to a log file"}
        {s         "silent mode"}
        {np        "do not use the propagate mechanism (default = use propagate)"}
        {fid.arg {} "the File-ID used for assembling the filename of the script"}
        {id.arg  {} "the explicit ID number"}
    }
    set nargmin 1
    set nargmax -1
    set usage "?-r?  ?-id ID?  ?-fid FID?  script ?script? ?script ...?"
    ::pwtk::parseOpt_
    
    if { $opt(r) } {
        set bg($id,redirect) 1
    }
    if { $opt(id) ne {} } {
        set index $opt(id)
    }    
    if { $opt(fid) ne {} } {
        set findex $opt(fid)
    }    
    if { [llength $args] == 1 } {
        set args [concat {*}$args]
    }

    if { [set head [file tail [file rootname [info script]]]] ne {} } {
        append head .
    }

    set scr bg.${head}$findex.pwtk
    set log bg.${head}$findex.log

    if { !$opt(s) } {
        print BG "Background job No.$index" 
        print "Script to run for background job-$index:\n\n[string trim $args]\n"
    }
    print "Script to run for background job-$index written to: $scr"
    if { $bg($id,redirect) } {
        print "Output of background job-$index redirected to a log file:  $log"
        set bg($id,log) [open $log w]
    }
    puts ""
    
    if { $opt(np) } {
        writeFile $scr $::pwtk::pkg_init_script\n$args
    } else {
        writeFile $scr $::pwtk::pkg_init_script\n[::pwtk::propagate_dump]\n$args
    }

    set bg($id,chan) [open [list | tclsh $scr] r]
    fconfigure $bg($id,chan) -blocking 0 -buffering line
    fileevent  $bg($id,chan) readable [list ::pwtk::bg_fileevent_ $id]

    return $id
}
#******


# Internal...
proc ::pwtk::bg_fileevent_ {id} {
    variable bg
    variable state

    if { ! [info exists bg($id,chan)] } {
        return
    }    
    if { ! [eof $bg($id,chan)] } {
        set res [gets $bg($id,chan)]
        if { $bg($id,redirect) } {
            fprint $bg($id,log) $res
        } else {
            print $res
        }
    } else {
        # job done: close the channels
        if { [catch {close $bg($id,chan)} errorInfo] } {
            pwtk::error "an error occured while executing the background job-$id:\n\n$errorInfo" $state(stopOnError)
        }
        set bg($id,done) 1
        unset bg($id,chan)

        if { $bg($id,redirect) && [catch {} err] } {            
            ::pwtk::error "error closing the background job-id log file\n\n$err" $state(stopOnError)
        }        
    }
}


#****f* Backgrounds/::pwtk::bg_wait
# SYNOPSIS
proc ::pwtk::bg_wait {args} {
    # USAGE
    #   bg_wait ?-s? ?bg_id1? ?bg_id2 ...?
    #
    # PURPOSE
    #   Wait for the specified pwtk::bg (aka background) jobs to finish.
    #
    #   If called without arguments, the command waits for all the
    #   pwtk::bg (aka background) jobs to finish.
    #
    # OPTION
    # * -s ... silent mode, i.e., do not print the "waiting" message
    #
    # ARGUMENTS
    # * list of IDs of background jobs; an empty list implies all IDs
    #    
    # SOURCE

    variable bg
    variable time_interval_ms

    set silent 0
    if { [lindex $args 0] eq "-s" } {
        set silent 1
        set args [lrange $args 1 end]
    }    
    if { $args eq "" } {
        set args [seq 1 $bg(count)]
    }
    if { [llength $args] == 1 } {
        set args [concat {*}$args]
    }
    if { ! [::pwtk::type::numberlist integer -strict $args] } {
        ::pwtk::error "expecting list of integers for job IDs, but got $args" 1
    }

    if { [llength $args] > 1 } { set s s }
    if { ! $silent } {
        print [concat Waiting for the background job[varvalue s] [join $args {, }] to finish ...]\n
    }

    foreach id $args {
        while { [info exists bg($id,chan)] } {
            vwait ::pwtk::bg($id,done)
        }
    }
}
#******
