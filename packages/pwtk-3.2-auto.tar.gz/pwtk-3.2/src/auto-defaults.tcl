#
# $RCSfile: auto-defaults.tcl,v $ --
#
#      In this file, default values of some namelist variables are set
#      for the (semi)auto defined inputs in auto-inputs.tcl.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: auto-defaults.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#

proc ::pwtk::cpppi::loadDefaults_ {} {
   ::pwtk::input::defaultVarValue_ CPPP prefix {}
   ::pwtk::input::defaultVarValue_ CPPP outdir [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
}

proc ::pwtk::kcwi::loadDefaults_ {} {
   ::pwtk::input::defaultVarValue_ KCW_CONTROL prefix {}
   ::pwtk::input::defaultVarValue_ KCW_CONTROL outdir [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
}

proc ::pwtk::d3hessi::loadDefaults_ {} {
   ::pwtk::input::defaultVarValue_ D3HESS prefix {}
   ::pwtk::input::defaultVarValue_ D3HESS outdir [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
}

proc ::pwtk::oscdft_ppi::loadDefaults_ {} {
   ::pwtk::input::defaultVarValue_ OSCDFT_PP prefix {}
   ::pwtk::input::defaultVarValue_ OSCDFT_PP outdir [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
}

proc ::pwtk::ppacfi::loadDefaults_ {} {
   ::pwtk::input::defaultVarValue_ PPACF prefix {}
   ::pwtk::input::defaultVarValue_ PPACF outdir [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
}

proc ::pwtk::pprismi::loadDefaults_ {} {
   ::pwtk::input::defaultVarValue_ RISM_INPUTPP prefix {}
   ::pwtk::input::defaultVarValue_ RISM_INPUTPP outdir [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
}

proc ::pwtk::bgw2pwi::loadDefaults_ {} {
   ::pwtk::input::defaultVarValue_ INPUT_BGW2PW prefix {}
   ::pwtk::input::defaultVarValue_ INPUT_BGW2PW outdir [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
}

proc ::pwtk::pw2bgwi::loadDefaults_ {} {
   ::pwtk::input::defaultVarValue_ INPUT_PW2BGW prefix {}
   ::pwtk::input::defaultVarValue_ INPUT_PW2BGW outdir [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
}

proc ::pwtk::pw2gwi::loadDefaults_ {} {
   ::pwtk::input::defaultVarValue_ INPUT_PW2GW prefix {}
   ::pwtk::input::defaultVarValue_ INPUT_PW2GW outdir [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
}

proc ::pwtk::pw2wan90i::loadDefaults_ {} {
   ::pwtk::input::defaultVarValue_ INPUT_PW2WAN prefix {}
   ::pwtk::input::defaultVarValue_ INPUT_PW2WAN outdir [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
}

proc ::pwtk::pwcondi::loadDefaults_ {} {
   ::pwtk::input::defaultVarValue_ INPUTCOND outdir [::pwtk::getDir_ QEdir(ESPRESSO_TMPDIR)]
}

proc ::pwtk::ld1i::loadDefaults_ {} {
   ::pwtk::input::defaultVarValue_ LD1_INPUT prefix {}
}

