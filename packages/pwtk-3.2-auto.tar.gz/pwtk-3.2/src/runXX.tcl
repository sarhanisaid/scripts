#
# $RCSfile: runXX.tcl,v $ --
#
#      This file contains the runXX and rerunXX procs for running QE programs,
#      where XX = PW, PH, PP, NEB...
#
#
# Copyright (c) 2009--2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: runXX.tcl,v 1.14 2021/05/07 13:24:43 tone Exp $ 
#

#****a* 5.3. Run Calculations/5.3.2. Run Supported Programs (aka runCmd)
#
# DESCRIPTION
#
#   PWTK's runCmd, rerunCmd, and dryrunCmd commands for runing the QE
#   programs, supported by PWTK, where Cmd = PW, PH, PP... standing for
#   pw.x, ph.x, pp.x, etc.
#
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::dryrunPW
# SYNOPSIS
proc ::pwtk::dryrunPW {} {
    # USAGE
    #   dryrunPW
    #
    # DESCRIPTION
    # Make a fast pw.x dry-run (as to query the info).
    #
    # RETURN VALUE
    # Name of the output file of the pw.x dry-run.
    #
    # SOURCE
    set prog    [findExecutable pw.x]
    set head    [fileutil::tempfile pw.dry-run.]; # make a unique filenames because several jobs may be running
    
    input_pushpop {
        CONTROL   { calculation = 'scf', prefix = 'pwscf' }
        ELECTRONS { electron_maxstep = 0 }
        ::pwtk::pwi::fprint $head.in

        download_needed_PPs_ ::pwtk::pwi

        # create the outdir & wfcdir
    
        outdir_create
        wfcdir_create    

        # make a simple serial run
        
        catch {
            close [open pwscf.EXIT w]
            eval exec [serial_prefix] $prog -in $head.in > $head.out
        }
        file delete pwscf.EXIT; # just in case

        # check for error in the dryrun output file
        if { [dryrunFailed $head.out pw.x] } {
            dryrunError_ $head.out pw.x 
        }
    }
    return $head.out
}
#*****


#internal...
proc ::pwtk::dryrunError_ {output prog} {
    variable error

    set errMsg "An error accured during the $prog dryrun!!!
For details see the output file: [file join [pwd] $output]

Error INFO:
  error detected on line number: $error(line_number)
  error type  : $error(type)
  error string: $error(line)"

    uplevel 1 [list ::pwtk::error $errMsg 1]    
}


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::one_atom_dryrunPW
# SYNOPSIS
proc ::pwtk::one_atom_dryrunPW {} {
    # DESCRIPTION    
    # Make a single atom pw.x dry-run. Prior to calling this command,
    # a user should define at least the Bravais lattice, i.e., ibrav
    # and either celldm(i) (alternatively A,B,C...) or CELL_PARAMETERS.
    #
    # The command finds a usable pseudo-potential file and performs a
    # single-atom dry-run (useful for querying the lattice vectors if
    # ibrav != 0). 
    #
    # This command is used internally by PWTK.
    #
    # RETURN VALUE
    # Name of the output file of the pw.x dry-run.
    #
    # SOURCE

    input_pushpop {
        proc getPP_ {dir} {
            if { [file exists $dir] } {
                set pp [file tail [lindex [glob -nocomplain $dir/*.UPF] 0]]
                if { [file readable [file join $dir $pp]] } {
                    set atom [::pwtk::pseudo::elemFromPPName $pp]
                    CONTROL "pseudo_dir = '$dir'"
                    SYSTEM "nat = 1 , ecutwfc = 15.0"
                    ATOMIC_SPECIES "$atom 1.0 $pp"
                    ATOMIC_POSITIONS (alat) "$atom 0.0 0.0 0.0"
                    return $pp
                }
            }
            return {}
        }

        foreach pdir [list $::env(PWTK)/examples/pseudo [pseudo_dir] \
                          [::pwtk::input::namelistGetVarValue CONTROL -nocase pseudo_dir trim] \
                          {*}[varvalue ::env(ESPRESSO_PSEUDO)] $::env(HOME)/espresso/pseudo] {
            if { [set pp [getPP_ $pdir]] ne {} } {
                return [dryrunPW]
            }
        }
        if { $pp eq {} } {
            # no PP located, download Si.pz-vbc.UPF from the web
            CONTROL "pseudo_dir = '[::fileutil::tempdir]'"
            pseudo_download Si.pz-vbc.UPF
            if { [getPP_ [::fileutil::tempdir]] ne {} } {
                return [dryrunPW]
            }
        }
        
        # if we came here, we failed to locate a PP file
        ::pwtk::error "failed to find a pseudopotential UPF file" 1
    }
}
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runXX
# SYNOPSIS
proc ::pwtk::runXX {prog args} {
    # USAGE
    #   runXX PROG ?OPTIONS?  INPUT  ?OUTPUT?  ?&?
    #
    # PURPOSE
    #   A general runCmd routine that associates the PROG QE executable
    #   with the corresponding specific 'runCmd' command. For example:
    #
    #      runXX pw.x ?OPTIONS? INPUT ?OUTPUT?  ?&?
    #
    #   is equivalent to:
    #
    #      runPW ?OPTIONS? INPUT ?OUTPUT?  ?&?
    #    
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append   --- treat the output file in append mode (default = overwrite)
    #   * -serial   --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX   --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX  --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE  --- explicitly specify the executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARUMENTS
    # * PROG   --- name of the QE program (e.g. pw.x, ph.x, pp.x, ...)
    # * INPUT  --- either name of the input file or the headname (i.e. rootname
    #              of the input name without the file extension)
    # * OUTPUT --- (optional) name of the output file
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #
    # SOURCE
 
    variable prog2runCmd; # array that maps from prog to runCmd

    # runCmd == $prog2runCmd($prog)
    ifnotexist prog2runCmd($prog) {
        ::pwtk::error "cannot map '$prog' to runCmd because the '$prog' executable has no registered runCmd" 1
    }
    return [$prog2runCmd($prog) {*}$args]
}
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::rerunXX
# SYNOPSIS
proc ::pwtk::rerunXX {prog args} {
    # USAGE 
    #   rerunXX PROG ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    # DESCRIPTION    
    #   A general rerunCmd routine that associates the PROG executable
    #   with the corresponding specific rerunCmd command (beware
    #   that not all executables have the rerunCmd). For example:
    #
    #      rerunXX pw.x ?OPTIONS? INPUT ?OUTPUT?  ?&?
    #
    #   is equivalent to:
    #
    #      rerunPW ?OPTIONS? INPUT ?OUTPUT?  ?&?
    #    
    #   Rerun restarts the calculation. The OUTPUT file is treated in
    #   append mode, whereas the rest is the same as for the
    #   ::pwtk::runXX routine.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -serial  --- run calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the pw.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * PROG   --- name of the QE program (e.g. pw.x, ph.x, pp.x, ...)
    # * INPUT  --- either name of the input file or the headname
    #              (i.e. rootname of the input name without the file extension_
    # * OUTPUT --- (optional) name of the output file
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #
    # SOURCE

    variable prog2runCmd; # array that maps from prog to runCmd

    # runCmd == $prog2runCmd($prog)
    ifnotexist prog2runCmd($prog) {
        ::pwtk::error "cannot map '$prog' to runCmd because the '$prog' executable has no registered runCmd" 1
    }
    set rerunCmd ::pwtk::re[namespace tail $prog2runCmd($prog)]
    if { [info procs $rerunCmd] eq {} } {
        ::pwtk::error "the '$prog' executables does not have the rerunCmd command" 1
    }
    return [$rerunCmd {*}$args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runPW
# SYNOPSIS
proc ::pwtk::runPW {args} {
    # USAGE
    #   runPW ?OPTIONS?  INPUT  ?OUTPUT?  ?&?
    #
    #   Options are:
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #     -outdir_clean
    #
    # DESCRIPTION    
    #   Run the pw.x calculation. Prior to running calculation, this routine will:
    #   * construct the pw.x input file from the specified input data
    #   * create the outdir directory if it does not yet exist
    #
    #   See ::pwtk::findExecutable for how the pw.x executable is located.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append       --- treat the output file in append mode (default = overwrite)
    #   * -serial       --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX       --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX      --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE         --- explicitly specify the pw.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #   * -outdir_clean --- clean the outdir prior to running calculations
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the pw.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the pw.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #
    #
    # SOURCE
    variable state

    treat_run_ {*}$args

    # clean outdir if requested
    
    run_outdir_clean_

    # create the outdir & wfcdir
    
    outdir_create
    wfcdir_create    
        
    # run the calculation

    return [eval {makeInputAndRun_ ::pwtk::pwi pw.x} $args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::rerunPW
# SYNOPSIS
proc ::pwtk::rerunPW {args} {
    # USAGE 
    #   rerunPW ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    # DESCRIPTION    
    #   Re-run (restart) the pw.x calculation. Prior to running, this
    #   routine will set the restart_mode='restart'.  The output-file
    #   will be treated in append mode, whereas the rest is the same
    #   as for the ::pwtk::runPW routine.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -serial  --- run calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the pw.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the pw.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the pw.x output will be stored (optional)
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    input_pushpop {
        CONTROL { 
            restart_mode = 'restart' 
        }

        # take care of plugins restart
        plugins_restart_ pw.x

        #ENVIRON {
        #    environ_restart = .true.
        #}
        
        # remove the outdir_clean option from $args as it prevents the true restart
        remove_the_outdir_clean_option_
        
        set result [eval {runPW -append} $args]
    }
    return $result
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::dryrunCP
# SYNOPSIS
proc ::pwtk::dryrunCP {} {
    # USAGE
    #   dryrunCP
    #
    # DESCRIPTION
    # Make a fast cp.x dry-run (as to query the info). Beware that
    # this is not really a dry-run and will take a while.
    #
    # WARNINGS
    # This is not really a dry-run and the calculation will take a
    # while.
    
    # RETURN VALUE
    # Name of the output file of the cp.x dry-run.
    #
    # SOURCE
    set prog    [findExecutable cp.x]
    set head    [fileutil::tempfile cp.dry-run.]; # make a unique filenames because several jobs may be running

    # cp.x does not support a true dryrun and it takes a while; inform the user
    ::pwtk::infoMsg "cp.x dryrun is not really a dry-run and will take a while"
    
    input_pushpop {
        CONTROL   { nstep = 0, prefix = 'cp' }
        ELECTRONS { electron_maxstep = 0 }
        input_clear AUTOPILOT
        ::pwtk::cpi::fprint $head.in

        download_needed_PPs_ ::pwtk::cpi        

        # create the outdir & wfcdir
    
        outdir_create
        wfcdir_create    

        catch {
            close [open cp.EXIT w]
            eval execute [prefix] $prog -in $head.in > $head.out
        }
        file delete cp.EXIT; # just in case

        # check for error in the dryrun output file
        if { [dryrunFailed $head.out cp.x] } {
            dryrunError_ $head.out cp.x
        }
    }
    return $head.out
}
#*****


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runCP
# SYNOPSIS
proc ::pwtk::runCP {args} {
    # USAGE
    #   runCP ?OPTIONS?  INPUT  ?OUTPUT?  ?&?
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #     -outdir_clean
    #
    # DESCRIPTION    
    #   Run the cp.x calculation. Prior to running calculation, this routine will:
    #     * construct the cp.x input file from the specified input data
    #     * create the outdir directory if it does not yet exist
    #
    #   See the ::pwtk::findExecutable for how the cp.x executable is located.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append       --- treat the output file in append mode (default = overwrite)
    #   * -serial       --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX       --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX      --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE         --- explicitly specify the cp.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #   * -outdir_clean --- clean the outdir prior to running calculations
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the cp.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the cp.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #
    # SOURCE
    
    # handle treatrun
    treat_run_ {*}$args

    # clean outdir if requested
    
    run_outdir_clean_

    # create the outdir & wfcdir
    
    outdir_create
    wfcdir_create    
        
    # run the calculation

    return [eval {makeInputAndRun_ ::pwtk::cpi cp.x} $args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::rerunCP
# SYNOPSIS
proc ::pwtk::rerunCP {args} {
    # USAGE 
    #   rerunCP ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    # DESCRIPTION
    #   Re-run (restart) the cp.x calculation. Prior to running, this
    #   routine will set the restart_mode='restart' but only if
    #   restart_mode is undefined or 'from_scratch'.  The output-file
    #   will be treated in append mode, whereas the rest is the same
    #   as for the ::pwtk::runCP routine.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -serial  --- run calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the cp.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the cp.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the cp.x output will be stored (optional)
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    input_pushpop {
        set restart_mode [::pwtk::input::namelistGetVarValue CONTROL restart_mode trim]
        if { $restart_mode == "" || $restart_mode == "from_scratch" } {         
            CONTROL { 
                restart_mode = 'restart' 
            }
        }
        
        # take care of plugins restart
        plugins_restart_ cp.x

        #ENVIRON {
        #    environ_restart = .true.
        #}
        
        # remove the outdir_clean option from $args as it prevents true restart
        remove_the_outdir_clean_option_
        
        set result [eval {runCP -append} $args]
    }
    return $result
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runPH
# SYNOPSIS
proc ::pwtk::runPH {args} {
    # USAGE
    #   runPH ?OPTIONS?  INPUT  ?OUTPUT?  ?&?
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # DESCRIPTION
    #   Construct the ph.x input file from the specified input data and run the ph.x program.
    #   See the ::pwtk::findExecutable for how the ph.x executable is located.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the ph.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the ph.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the ph.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    return [eval {makeInputAndRun_ ::pwtk::phi ph.x} $args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::rerunPH
# SYNOPSIS
proc ::pwtk::rerunPH {args} {
    # USAGE
    #   rerunPH ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #    
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -serial  --- run calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the ph.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #    
    # PURPOSE
    #   Construct the ph.x input file from the input data and run the
    #   ph.x program in restart mode. The output-file will be treated
    #   in append mode, whereas the rest is the same as for the
    #   ::pwtk::runPH routine.
    #
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    input_pushpop {
        INPUTPH {
            recover = .true.
        }

        # take care of plugins restart
        plugins_restart_ ph.x

        set result [eval {runPH -append} $args]
    }
    return $result
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runPP
# SYNOPSIS
proc ::pwtk::runPP {args} {
    # USAGE 
    #   runPP ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the pp.x input file from the input data and run the pp.x program.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append --- treat the output file in append mode (default = overwrite)
    #   * -serial --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the pp.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the pp.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the pp.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    return [eval {makeInputAndRun_ ::pwtk::ppi pp.x} $args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runPROJWFC
# SYNOPSIS
proc ::pwtk::runPROJWFC {args} {
    # USAGE 
    #   runPROJWFC ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the projwfc.x input file from the input data and run the projwfc.x program.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the projwfc.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the projwfc.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the projwfc.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    return [eval {makeInputAndRun_ ::pwtk::pri projwfc.x} $args]
}
#******



#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runDYNMAT
# SYNOPSIS
proc ::pwtk::runDYNMAT {args} {
    # USAGE 
    #   runDYNMAT ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the dynmat.x input file from the input data and run the dynmat.x program.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the dynmat.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the dynmat.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the dynmat.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    return [eval {makeInputAndRun_ ::pwtk::dmi dynmat.x} $args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runMATDYN
# SYNOPSIS
proc ::pwtk::runMATDYN {args} {
    # USAGE 
    #   runMATDYN ?OPTIONS?  INPUT  ?OUTPUT?  ?&?
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the matdyn.x input file from the input data and run the matdyn.x program.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the matdyn.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the matdyn.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the matdyn.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option) 
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    return [eval {makeInputAndRun_ ::pwtk::mdi matdyn.x} $args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runQ2R
# SYNOPSIS
proc ::pwtk::runQ2R {args} {
    # USAGE 
    #   runQ2R ?OPTIONS?  INPUT  ?OUTPUT?  ?&?
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the q2r.x input file from the input data and run the q2r.x program.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the q2r.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the q2r.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the q2r.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option) 
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    return [eval {makeInputAndRun_ ::pwtk::q2ri q2r.x} $args]
}
#******

proc ::pwtk::runDAVID   {args} { return [uplevel ::pwtk::runDAVIDSON   $args] }
proc ::pwtk::rerunDAVID {args} { return [uplevel ::pwtk::rerunDAVIDSON $args] }

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runDAVIDSON
# SYNOPSIS
proc ::pwtk::runDAVIDSON {args} {
    # USAGE 
    #   runDAVIDSON ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the turbo_davidson.x input file from the input data and run the turbo_davidson.x program.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the turbo_davidson.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the turbo_davidson.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the turbo_davidson.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    return [eval {makeInputAndRun_ ::pwtk::davi turbo_davidson.x} $args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::rerunDAVIDSON
# SYNOPSIS
proc ::pwtk::rerunDAVIDSON {args} {
    # USAGE 
    #   rerunDAVIDSON ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    # PURPOSE    
    #   Re-run (restart) the turbo_davidson.x program. Prior to
    #   running, this routine will set the restart='restart'.
    #   The output-file will be treated in append mode, whereas the
    #   rest is the same as for the ::pwtk::runDAVIDSON routine.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the turbo_davidson.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the turbo_davidson.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the turbo_davidson.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    input_pushpop {
        LR_INPUT { 
            restart = 'restart' 
        }

        # take care of plugins restart
        plugins_restart_ turbo_davidson.x
        
        set result [eval {runDAVIDSON -append} $args]
    }
    return $result
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runLANCZOS
# SYNOPSIS
proc ::pwtk::runLANCZOS {args} {
    # USAGE 
    #   runLANCZOS ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the turbo_lanczos.x input file from the input data and run the turbo_lanczos.x program.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the turbo_lanczos.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the turbo_lanczos.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the turbo_lanczos.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args
    
    return [eval {makeInputAndRun_ ::pwtk::lani turbo_lanczos.x} $args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::rerunLANCZOS
# SYNOPSIS
proc ::pwtk::rerunLANCZOS {args} {
    # USAGE 
    #   rerunLANCZOS ?OPTIONS?  INPUT  ?OUTPUT?  ?&?
    #
    # PURPOSE    
    #   Re-run (restart) the turbo_lanczos.x program. Prior to
    #   running, this routine will set the restart='restart'.
    #   The output-file will be treated in append mode, whereas the
    #   rest is the same as for the ::pwtk::runLANCZOS routine.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the turbo_lanczos.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the turbo_lanczos.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the turbo_lanczos.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    input_pushpop {
        LR_INPUT { 
            restart = 'restart' 
        }
        
        # take care of plugins restart
        plugins_restart_ turbo_lanczos.x

        set result [eval {runLANCZOS -append} $args]
    }
    return $result
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runEELS
# SYNOPSIS
proc ::pwtk::runEELS {args} {
    # USAGE 
    #   runEELS ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the turbo_eels.x input file from the input data and run the turbo_eels.x program.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the turbo_eels.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the turbo_eels.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the turbo_eels.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    return [eval {makeInputAndRun_ ::pwtk::eelsi turbo_eels.x} $args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::rerunEELS
# SYNOPSIS
proc ::pwtk::rerunEELS {args} {
    # USAGE 
    #   rerunEELS ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    # PURPOSE    
    #   Re-run (restart) the turbo_eels.x program. Prior to
    #   running, this routine will set the restart='restart'.
    #   The output-file will be treated in append mode, whereas the
    #   rest is the same as for the ::pwtk::runEELS routine.
    #
    # OPTIONS
    #   * -bg     --- run calculation in background (synonymous with "&" as the last argument)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the turbo_eels.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the turbo_eels.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the turbo_eels.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    input_pushpop {
        LR_INPUT { 
            restart = 'restart' 
        }    

        # take care of plugins restart
        plugins_restart_ turbo_eels.x

        set result [eval {runEELS -append} $args]
    }
    return $result
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runSPECTRUM
# SYNOPSIS
proc ::pwtk::runSPECTRUM {args} {
    # USAGE 
    #   runSPECTRUM ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the turbo_spectrum.x input file from the input data and run the turbo_spectrum.x program.
    #
    # OPTIONS
    #   * -bg      --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the turbo_spectrum.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the turbo_spectrum.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the turbo_spectrum.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    return [eval {makeInputAndRun_ ::pwtk::speci turbo_spectrum.x} $args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runMAGNON
# SYNOPSIS
proc ::pwtk::runMAGNON {args} {
    # USAGE 
    #   runMAGNON ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the turbo_magnon.x input file from the input data and run the turbo_magnon.x program.
    #
    # OPTIONS
    #   * -bg      --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the turbo_magnon.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the turbo_magnon.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the turbo_magnon.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    return [eval {makeInputAndRun_ ::pwtk::magi turbo_magnon.x} $args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::rerunMAGNON
# SYNOPSIS
proc ::pwtk::rerunMAGNON {args} {
    # USAGE 
    #   rerunMAGNON ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    # PURPOSE    
    #   Re-run (restart) the turbo_magnon.x program. Prior to
    #   running, this routine will set the restart='restart'.
    #   The output-file will be treated in append mode, whereas the
    #   rest is the same as for the ::pwtk::runMAGNON routine.
    #
    # OPTIONS
    #   * -bg      --- run calculation in background (synonymous with "&" as the last argument)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the turbo_magnon.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the turbo_magnon.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the turbo_magnon.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    input_pushpop {
        LR_INPUT { 
            restart = 'restart' 
        }    

        # take care of plugins restart
        plugins_restart_ turbo_magnon.x
        
        set result [eval {runMAGNON -append} $args]
    }
    return $result
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::dryrunNEB
# SYNOPSIS
proc ::pwtk::dryrunNEB {} {
    # USAGE
    #   dryrunNEB
    #
    # DESCRIPTION
    # Make a fast neb.x dry-run (as to query the info).
    #
    # RETURN VALUE
    # Name of the output file of the neb.x dry-run.
    #
    # SOURCE
    set prog    [findExecutable neb.x]
    set head    [fileutil::tempfile neb.dry-run.]; # make a unique filenames because several jobs may be running
    
    input_pushpop {
        PATH      { nstep_path = 0 }
        CONTROL   { calculation = 'scf', prefix = 'pwscf' }
        ELECTRONS { electron_maxstep = 0 }
        ::pwtk::nebi::fprint $head.in

        download_needed_PPs_ ::pwtk::nebi
        
        # create the outdir & wfcdir
    
        outdir_create
        wfcdir_create    

        # do a simple serial run
        
        catch {
            close [open pwscf.EXIT w]
            eval exec [serial_prefix] $prog -in $head.in > $head.out
        }
        file delete pwscf.EXIT; # just in case

        # check for error in the dryrun output file
        if { [dryrunFailed $head.out neb.x] } {
            dryrunError_ $head.out neb.x
        }
    }
    return $head.out
}
#*****


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runNEB
# SYNOPSIS
proc ::pwtk::runNEB {args} {
    # USAGE 
    #   runNEB ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -outdir_clean
    #
    # PURPOSE
    #   Construct the neb.x input file from the input data and run the neb.x program.
    #
    # OPTIONS
    #   * -bg      --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the neb.x executable
    #   * -outdir_clean --- clean the outdir prior to running calculations
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the neb.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the neb.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE
    variable RUNopt

    # handle treatrun
    treat_run_ {*}$args

    # clean outdir if requested
    
    run_outdir_clean_

    # create the outdir & wfcdir
    
    outdir_create
    wfcdir_create    
    
    ::pwtk::input_pushpop {
        # neb.x requires -inp input_handle
        set RUNopt(input_handle) -inp
        set result [eval {makeInputAndRun_ ::pwtk::nebi neb.x} $args]
    }
    return $result
}
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::rerunNEB
# SYNOPSIS
proc ::pwtk::rerunNEB {args} {
    # USAGE
    #   rerunNEB ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #    
    # OPTIONS
    #   * -bg      --- run calculation in background (synonymous with "&" as the last argument)
    #   * -serial  --- run calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the neb.x executable
    #    
    # PURPOSE
    #   Construct the ph.x input file from the input data and run the
    #   ph.x program in restart mode. The output-file will be treated
    #   in append mode, whereas the rest is the same as for the
    #   ::pwtk::runNEB routine.
    #
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    input_pushpop {
        PATH {
            restart_mode = 'restart'
        }

        # take care of plugins restart
        plugins_restart_ neb.x
        
        #ENVIRON {
        #    environ_restart = .true.
        #}
        
        # remove the outdir_clean option from $args as it prevents true restart
        remove_the_outdir_clean_option_
        
        set result [eval {runNEB -append} $args]
    }
    return $result
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runDOS
# SYNOPSIS
proc ::pwtk::runDOS {args} {
    # USAGE 
    #   runDOS ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the dos.x input file from the input data and run the dos.x program.
    #
    # OPTIONS
    #   * -bg      --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the dos.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the dos.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the dos.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option) 
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    return [eval {makeInputAndRun_ ::pwtk::di dos.x} $args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runBANDS
# SYNOPSIS
proc ::pwtk::runBANDS {args} {
    # USAGE 
    #   runBANDS ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the bands.x input file from the input data and run the bands.x program.
    #
    # OPTIONS
    #   * -bg      --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the bands.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the bands.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the bands.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    return [eval {makeInputAndRun_ ::pwtk::bi bands.x} $args]
}
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runMOPDOS
# SYNOPSIS
proc ::pwtk::runMOPDOS {args} {
    # PURPOSE
    #   Shortcut for ::pwtk::runMOLECULARPDOS
    # SOURCE
    return [uplevel ::pwtk::runMOLECULARPDOS $args]
}
#******

#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runMOLECULARPDOS
# SYNOPSIS
proc ::pwtk::runMOLECULARPDOS {args} {
    # USAGE 
    #   runMOLECULARPDOS ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the molecularpdos.x input file from the input data and run the molecularpdos.x program.
    #
    # OPTIONS
    #   * -bg      --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the molecularpdos.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the molecularpdos.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the molecularpdos.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option) 
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    return [eval {makeInputAndRun_ ::pwtk::mpdi molecularpdos.x} $args]
}
#******


#****f* 5.3.2. Run Supported Programs (aka runCmd)/::pwtk::runHP
# SYNOPSIS
proc ::pwtk::runHP {args} {
    # USAGE 
    #   runHP ?OPTIONS?  INPUT  ?OUTPUT?  ?&?    
    #
    #   Options are: 
    #     -bg
    #     -append  
    #     -serial 
    #     -prefix PREFIX
    #     -postfix POSTFIX
    #     -exec EXECUTABLE
    #     -ihandle VALUE
    #
    # PURPOSE
    #   Construct the hp.x input file from the input data and run the hp.x program.
    #
    # OPTIONS
    #   * -bg      --- run calculation in background (synonymous with "&" as the last argument)
    #   * -append  --- treat the output file in append mode (default = overwrite)
    #   * -serial  --- run the calculation in serial mode (default = parallel)
    #   * -prefix PREFIX  --- explicitly specify the prefix for parallel execution
    #   * -postfix POSTFIX --- explicitly specify the postfix for parallel execution
    #   * -exec EXECUTABLE    --- explicitly specify the hp.x executable
    #   * -ihandle VALUE --- explicitly set the input handle (for the description of input handle, see ::pwtk::input_handle)
    #
    # ARGUMENTS
    # * INPUT  --- filename (or headname) to which the hp.x input file will
    #              be stored. The .in (.out) suffix will be added to headname for
    #              input (output) filename.
    # * OUTPUT --- (optional) filename to which the hp.x output will be stored
    # * &      --- (optional) run calculation in background (synonymous with the -bg option)
    #    
    # SOURCE

    # handle treatrun
    treat_run_ {*}$args

    set output [eval {makeInputAndRun_ ::pwtk::hpi hp.x} $args]

    # make a backup copy of $prefix.Hubbard_parameters.dat
    runHP_backup_HP_ $output
    return $output
}
#******

# internal...
proc ::pwtk::runHP_backup_HP_ {output} {
    # PURPOSE
    #    make a backup copy of $prefix.Hubbard_parameters.dat

    # $output can be an output file or an ID for run -bg
    
    if { [file exists $output] } {            
        set head [file rootname $output]
        set prefix [::pwtk::input::namelistGetVarValue INPUTHP prefix trim]
        ifset prefix [::pwtk::input::namelistGetVarValue CONTROL prefix trim]
        ifset prefix pwscf

        if { [file exists $prefix.Hubbard_parameters.dat] } {
            # copy the Hubbard_parameters.dat only if it is "new" (use the max offset of 2s)
        
            set tref [clock seconds]
            set tout [file mtime $output]
            set tdat [file mtime $prefix.Hubbard_parameters.dat]
            if { $::pwtk::state(restart) } {
                # in restart mode check that the output file is new
                if { $tref - $tout > 10*[time2s -real ${::pwtk::time_interval_ms}ms] } {
                    return
                }
            }
            if { $tout - $tdat <= 2 } {
                print "Making a backup copy of $prefix.Hubbard_parameters.dat to $head.Hubbard_parameters.dat\n"
                file copy -force $prefix.Hubbard_parameters.dat $head.Hubbard_parameters.dat
            }
        }
    }
}


#****f* Deprecated/::pwtk::runFLO
# SYNOPSIS
proc ::pwtk::runFLO {head {ion_dynamics {}}} { 
    deprecated "[procName] is deprecated, use \"::pwtk::flo_run\" instead"
    uplevel [list ::pwtk::flo::run $head {*}$ion_dynamics]
}
#******


#*** internal...
proc ::pwtk::run_outdir_clean_ {} {
    uplevel 1 {
        set extra_option {
            {outdir_clean   "clean the outdir before running the calculation"}
        }
        array set opt [::cmdline::getKnownOptions args $extra_option]
    
        if { $opt(outdir_clean) } {
            # clean the outdir as requested -- DANGEROUS!!!
            set outdir [::pwtk::outdir_query]
            if { $outdir != "" } {
                ::pwtk::print "Cleaning ESPRESSO_TMPDIR :   $outdir"
                ::pwtk::outdir_clean
                ::pwtk::print ""
                #::pwtk::print "------------------------ cleaning done.\n"
            }
        }    
    }
}


# internal...
proc ::pwtk::remove_the_outdir_clean_option_ {} {
    uplevel 1 {
        # remove the outdir_clean option from $args
        set ignored_options {
            {outdir_clean  "ignored option"}
        }
        array set opt [::cmdline::getKnownOptions args $ignored_options]
        
        if { $opt(outdir_clean) } {
            ::pwtk::warning "ignoring the -outdir_clean option, which disables the proper restart"
        }
    }
}


# internal...
proc ::pwtk::plugins_restart_ {prog} {    
    variable state
    variable plugin
    foreach p [varvalue plugin(list)] {
        if { [info exists state($p)] && $state($p) } {
            if { $prog in $plugin($p,programs) && $plugin($p,restartScript) ne {} } {
                infoMsg "[string toupper $p] restart mode temporarily activated while restarting $prog."
                eval $plugin($p,restartScript)
            }
        }
    }
}
