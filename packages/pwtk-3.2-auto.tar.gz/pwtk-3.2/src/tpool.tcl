#
# $RCSfile: tpool.tcl,v $ --
#
#      This file contains the implementation of a thread-pool using
#      the tpool Tcl threading extension.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: tpool.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#


#****a* Background Execution/Thread-pools
# DESCRIPTION
#   Thread-pool is a mechanism for achieving concurrency of
#   execution. It consists of multiple threads waiting for jobs to be
#   allocated for concurrent execution.
#
#   A typical usage of thread-pool would be the following: suppose we
#   have N jobs to perform on M computers or workers, where N >>
#   M. This task can be efficiently managed with a thread-pool, which
#   will initially distribute M jobs to M workers, i.e., one job per
#   worker. When the first job finishes, it submits the next job to a
#   free worker, and so on until all jobs are completed.
#
#   The Tcl thread package is required to use thread-pools in PWTK
#   (N.B. the Thread package is named 'tcl-thread' in Linux distros).
#******


#****c* Thread-pools/::pwtk::tpool
# DESCRIPTION
#    A class for creating and managing thread-pools.
#
#    The class consists of three methods: constructor, job, and wait.
#    The first is used to create a thread-pool, the second to submit
#    jobs, and the last for waiting for all jobs to finish.
#
#   For further details, see: tpool::constructor.
#
# EXAMPLE
#    set tp [::pwtk::tpool new -b 10]
#
#    foreach i [seq 1 100] {
#       $tp job {
#           ::pwtk::run_fromXSF pw.x structure-$i.xsf
#       }
#    }
#
#    $tp wait
#
#    # now we can process all the results
#
#    ...
#******

::oo::class create ::pwtk::tpool {
    variable type ;     # which type of tpool (bg, thread, or remote as requested via -b, -t, or -h, respectively)
    variable nworkers ; # number of parallel workers
    variable tpid ;     # tpool ID
    variable jobList ;  # list of jobs IDs
    variable count ;    # job counter
    variable hosts ;    # list of hosts for "remote" (as specified via -h)
    variable workerHost ; # array holding the host for each job, i.e. $workerHost($jobID)
    variable opts ;     # extra options ...
    #variable log ;      # array holding the names of log files of each job for the thread-type tpool

    #****m* ::pwtk::tpool/::pwtk::tpool::constructor
    # SYNOPSIS
    constructor {args} {
        # USAGE
        #   set tp [::pwtk::tpool new -h HOSTLIST ?-rdir DIRECTORY? ?-rpwtk FILE?]
        # or
        #   set tp [::pwtk::tpool new -b NUM ?-r?]
        # or
        #   set tp [::pwtk::tpool new -t NUM ?-r?]
        #
        # DESCRIPTION
        #   A constructor for creating a thread-pool. There are three
        #   types of thread-pools, named "bgl, "thread", and "remote".
        #
        #   The "bg" and "thread" type thread-pools are local
        #   thread-pools and create workers on the current
        #   computer. For example:
        #
        #      set tp [::pwtk::tpool new -b NUM]
        #
        #   creates NUM ::pwtk::bg workers on the current computer,
        #   whereas the "-t" option creates the ::pwtk::thread
        #   workers.
        #
        #   The "remote" thread-pool creates ::pwtk::remote workers on the specified
        #   remote computers. For example:
        #
        #      set tp [::pwtk::tpool new -h {machine1 machine2 machine3}]
        #   or
        #      set tp [::pwtk::tpool new -h {user@machine1 user@machine2 user@machine3}]
        #
        #   creates three workers, one on each specified host. To
        #   create several workers on a given computer, specify that
        #   computer multiple times in the hosts list. For example:
        #
        #      set tp [::pwtk::tpool new -h {machine1 machine1 machine2}]
        #
        #   creates two workers on machine1 and one worker on machine2.
        #
        # OPTIONS
        # * -h HOSTLIST ... creates a remote worker on each specified host in the list
        # * -b NUM      ... creates NUM ::pwtk::bg workers
        # * -t NUM      ... creates NUM ::pwtk::thread workers
        # * -r          ... redirect stdout of each job to a separate log file
        #                   (N.B. for remote workers, the stdout is always redirected to a log file)
        # * -rdir DIRECTORY ... directory of where to run calculations on remote hosts
        #                       (only for remote "-h" workers)
        # * -rpwtk FILE ... the fullpath name of the PWTK executable on the remote hosts
        #                   (only for remote "-h" workers)
        #
        # SOURCE

        set options {
            {h.arg {}   "list of hosts where to run jobs"}
            {b.arg {}   "number of ::pwtk::bg workers to run in parallel on localhost"}
            {t.arg {}   "number of ::pwtk::thread workers to run in parallel on localhost"}
            {r          "redirect the stdout of each jobs to a separate log file"}
            {rdir.arg   {}   "directory on the remote host where jobs will be run (default = mirror of the current working directory but on the remote hosts)"}
            {rpwtk.arg  pwtk "full pathname of the PWTK launcher on remote hosts"}
        }        
        set narg 0
        set usage "-h HOSTLIST ?-rdir DIRECTORY?  ?-rpwtk FILE?\nor\n-b NUM ?-r?\nor\n -t NUM ?-r?"
        ::pwtk::parseOpt_
        ::pwtk::checkOType_ -nworkers $opt(b) {number posint} "positive integer"        
        ::pwtk::checkOType_ -nworkers $opt(t) {number posint} "positive integer"        

        set tt 0
        ::pwtk::ifnotempty opt(h) { incr tt }
        ::pwtk::ifnotempty opt(b) { incr tt }
        ::pwtk::ifnotempty opt(t) { incr tt }
        if { $tt > 1 } {
            ::pwtk::error "mutually exclusive -h, -b, or -t options specified" 1
        } elseif { $tt == 0 } {
            ::pwtk::error "none of -h, -b, or -t options specified; exectly one of these options must be specified" 1
        }
        
        set opts {}
        foreach o {rdir rpwtk} {
            if { $opt($o) ne {} } { lappend opts -$o $opt($o) }
        }
        if { $opt(r) } {
            lappend opts -r
        } 
        
        ::pwtk::print TPOOL "Initializing a new thread-pool ...\n"
        ::pwtk::thread_init
        
        set hostText {}
        if { $opt(h) ne {} } {
            #
            # remote
            #
            set type remote
            set hosts $opt(h)
            set nworkers [llength $opt(h)]
            set hostText "\nworker hosts      :  [join $hosts { }]"
            
            # check that each host is alive
            foreach host $hosts {
                if { ! [pwtk::host_is_up $host] } {
                    ::pwtk::error "cannot communicate with '$host'\n\n$::errorInfo" 1
                }
            }
        } elseif { $opt(b) ne {} } {
            #
            # bg
            #
            set type bg
            set nworkers $opt(b)
        } else {
            #
            # thread
            #
            set type thread
            set nworkers $opt(t)
        }

        # create thread-pool

        #set tpid [tpool::create -minworkers $nworkers -maxworkers $nworkers -initcmd $::pwtk::thread(initcmd)]
        set tpid [tpool::create \
                      -minworkers $nworkers \
                      -maxworkers $nworkers \
                      -initcmd [::pwtk::thread_initscript_]]
        set count 0
        set jobList {}

        ::pwtk::print "thread-pool type  :  $type
number of workers :  ${nworkers}$hostText
thread-pool ID    :  $tpid\n"
    }
    #******

        
    #****m* ::pwtk::tpool/::pwtk::tpool::job
    # SYNOPSIS
    method job {args} {
        # USAGE
        #   $obj job ?-delay MS? SCRIPT
        #
        # DESCRIPTION
        #   This method submits a job to the '$obj' thread-pool.
        #
        #   If -delay option is specified, it waits for 'MS'
        #   milliseconds before the job is submitted. This is
        #   typically needed when jobs write and read from the same
        #   file (such as environ.in for ENVIRON) because otherwise
        #   file corruption can occur. This can typically happen only
        #   for the first concurrent submitted jobs because for later
        #   jobs, the probability of this happening is quite small as
        #   the previous jobs are unlikely to finish concurrently.        
        #
        # OPTIONS
        # * -delay MS ... wait for 'MS' milliseconds before submitting the job to the thread-pool.
        #
        # ARGUMENTS
        # * SCRIPT ... a PWTK script for the job
        #        
        # EXAMPLE
        #   $tp job {
        #       ::pwtk::run_fromXSF pw.x structure.xsf
        #   }
        #
        # RETURN VALUE
        # * The ID job this job.
        #
        # SOURCE

        set narg 1
        set usage "?-delay ms? SCRIPT"
        set options {
            {delay.arg 0 "delay (in milliseconds) before submitting the job"}
        }
        ::pwtk::parseOpt_
        ::pwtk::checkOTypeStrict_ -delay $opt(delay) integer integer
        lassign $args script
        
        incr count

        if { $opt(delay) > 0 } {
            # add some small delay as a precaution if jobs write the same
            # file (for example, environ.in for ENVIRON calcs)
            
            after $opt(delay)
        }
        
        if { $type eq "thread" } {
            #
            # thread
            #
            set fullScript [::pwtk::propagate_dump hard_dump]\n$script
            #set fullScript $script; # N.B. not OK because we need a hard-dump; also tpool-t.test fails otherwise

            if { "-r" in $opts } {
                set log thread.$tpid.$count.log
                my print_ $script {} "Output of job-$count redirected to a log file:  $log\n"                
                lappend jobList [tpool::post $tpid [list ::pwtk::redirect_stdout_to $log $fullScript]]                
            } else {
                my print_ $script
                lappend jobList [tpool::post $tpid $fullScript]
            }
            
        } elseif { $type eq "bg" } {
            #
            # bg
            #
            set fullScript [::pwtk::propagate_dump]\n$script

            set oo [list -s -np -id $count -fid $tpid.$count]
            if { "-r" in $opts } {
                lappend oo -r
            }
            my print_ $script

            lappend jobList [tpool::post $tpid [list ::pwtk::tpool_bg_ {*}$oo $fullScript]]
            
        } else {
            #
            # remote
            #
            set fullScript [::pwtk::propagate_dump]\n$script

            if { $count <= $nworkers } {
                set host [lindex $hosts $count-1]
            } else {
                # wait for a worker to become available (if more workers become available, use the 1st one)
                set completed [lindex [tpool::wait $tpid $jobList] 0]

                # save the available host
                set host $workerHost($completed)

                # remove the completed job from jobList
                set jobList [lsearch -all -inline -not -exact $jobList $completed]                
            }
            my print_ $script $host
            
            # submit a remote job to an available worker

            set id [tpool::post $tpid [list ::pwtk::remote -fg -np -id $count -fid $tpid.$count {*}$opts $host $fullScript]]
            set workerHost($id) $host
            lappend jobList $id
        }

        # return this job ID
        return [lindex $jobList end]
    }
    #******

    
    #****m* ::pwtk::tpool/::pwtk::tpool::wait
    # SYNOPSIS
    method wait {args} {
        # USAGE
        #   $obj wait ?jobID? ?jobID ...?
        #
        # DESCRIPTION
        #   If the method is called without any arguments, then it
        #   waits for all jobs submitted to the thread-pool to
        #   finish. Otherwise, it waits only for the specified jobs to
        #   finish.
        #
        #   This command is blocking.
        #
        # SOURCE

        set jl {}
        if { $args eq {} } {            
            set jl $jobList
        } else {
            foreach id $args {
                if { $id in $jobList } {
                    lappend jl $id
                } else {
                    ::pwtk::warning "job ID $id is not among active jobs; ignoring"
                }
            }
        }
        if { $jl eq "" } { return }

        # t.k.
        after $::pwtk::time_interval_ms
        # t.k.end
        
        set s [expr {[llength $jl] > 1 ? "s" : ""}]
        ::pwtk::print "\nWaiting for [self] job$s [join $jl {, }] to complete ...\n"
        
        while 1 {
            tpool::wait $tpid $jl running
        
            if { $running eq {} } {
                break
            } else {
                after $::pwtk::time_interval_ms
            }
        }
    }
    #******

    
    #****m* ::pwtk::tpool/::pwtk::tpool::get
    # SYNOPSIS
    method get {what} {
        # PURPOSE
        #   Query the basic tpool info, i.e.:
        #
        #      $obj get type       ... returns the type of tpool (i.e., thread, bg, or remote)
        #      $obj get nworkers   ... returns the number of tpool workers
        #      $obj get tpid       ... returns the TPool ID
        #
        # SOURCE

        switch -glob -- $what {
            type   { return $type }
            nwork* { return $nworkers }
            tpid   { return $tpid }
            default {
                ::pwtk::error "bad argument \"$what\", must be one of type, nworkers, or tpid" 1
            }
        }
    }
    #******

    # internal...
    method print_ {script {host {}} {msg {}}} {
        set add [expr { $host ne {} ? "to host: $host" : "" } ]
        ::pwtk::print TPOOL "job-${count} @ $tpid submitted $add
script of job-${count}:"
        ::pwtk::print $script
        #catch { ::pwtk::print [uplevel 2 "subst -nocommands [list $script]"] }
        if { $msg ne {} } { ::pwtk::print $msg }        
    }
}

# Internal...
proc ::pwtk::tpool_bg_ {args} {
    # PURPOSE
    #   Adopt the 'bg' machinery to be used for tpool, i.e., for tpool
    #   the script should be blocking or else tpool erroneously
    #   assumes the job is finished

    set id [::pwtk::bg {*}$args]
    bg_wait -s $id
}
