#
# $RCSfile: environ.tcl,v $ --
#
#      This file contains the procs for handling Environ
#      (http://www.quantum-environ.org/).
#
# Copyright (c) 2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: environ.tcl,v 1.3 2023/01/10 11:50:01 kokalj Exp $ 
#


# ------------------------------------------------------------------------
#
# SHORT-CUTS
#
# ------------------------------------------------------------------------

proc ::pwtk::environ_fprint    {{file {}}} { uplevel ::pwtk::environ::fprint $file }
proc ::pwtk::environ_get       {}          { uplevel ::pwtk::environ::get }
proc ::pwtk::environ_clear     {}          { uplevel ::pwtk::environ::clear }

#****f* ::pwtk::environ/::pwtk::environ::environ
# SYNOPSIS
proc ::pwtk::environ::environ {{mode {}}} {
    # PURPOSE
    #   Activate or deactivate the ENVIRON plugin. If the SWITCH
    #   argument is omitted, the current ENVIRON status is queried,
    #   which can be "on" or "off".
    #
    # USAGE    
    #    environ on
    # or
    #    environ off
    # or
    #    environ restart
    # or
    #    environ from_scratch
    # or
    #    environ
    #
    # DESCRIPTION
    # The 'environ' command can be called as:
    #
    # |html &bull; <b>environ on</b> implies adding <b>-environ</b> to POSTFIX (e.g., pw.x --environ)
    # 
    # |html &bull; <b>environ off</b> implies removing <b>-environ</b> from POSTFIX
    #
    # |html &bull; <b>environ restart</b> implies adding <b>-environ</b> to POSTFIX and setting ENVIRON { environ_restart = .true. }
    #
    # |html &bull; <b>environ from_scratch</b> implies adding <b>-environ</b> to POSTFIX and setting ENVIRON { environ_restart = .false. }
    #
    # WARNINGS 
    #   To use ENVIRON, QE needs to be compiled with Environ.
    #
    # SOURCE

    if { ! [info exists ::pwtk::state(environ)] } {
        set ::pwtk::state(environ) off
    }
 
    if { $mode != {} } {
        if { $mode == "restart" } {
            ::pwtk::print "ENVIRON restart activated (environ_restart = .true.)\n"
            ENVIRON { environ_restart = .true. }
            set mode on
        } elseif { [string match *scratch $mode] } {
            ::pwtk::print "ENVIRON restart disabled (environ_restart = .false.)\n"
            ENVIRON { environ_restart = .false. }
            set mode on
        }
        if { ! [::pwtk::type::number fboolean $mode] } {
            pwtk::error "environ mode must be boolean, but got mode = $mode" 1
        }
        
        set postfix {}
        if { [info exists ::pwtk::RUNopt(POSTFIX)] } {
            set postfix $::pwtk::RUNopt(POSTFIX)
        }
        set ind [lsearch -regexp $postfix ^-+environ]
        
        if { $mode } {                        
            ::pwtk::print "ENVIRON mode is ON\n"
            set ::pwtk::state(environ) on
            # add -environ flag to POSTFIX
            if { $ind < 0 } {
                lappend ::pwtk::RUNopt(POSTFIX) -environ
            }                
        } else {
            ::pwtk::print "ENVIRON mode is OFF\n"
            set ::pwtk::state(environ) off
            set ::pwtk::RUNopt(POSTFIX) [lsearch -inline -all -not -regexp $postfix ^-+environ]            
        }
    }
    return $::pwtk::state(environ)
}
#****


#****f* ::pwtk::environ/::pwtk::environ::fprint
# SYNOPSIS
proc ::pwtk::environ::fprint {{file {}}} {
    # PURPOSE
    #   Print the content of the ENVIRON input data (akak environ.in)
    #   to a file or to stdout if the file was not specified.
    # ARGUMENTS
    #   * file -- [optional] filename to print to (default = stdout)
    # SOURCE
    ::pwtk::input::fprint_ ::pwtk::environ $file
}
#****


#****f* ::pwtk::environ/::pwtk::environ::get
# SYNOPSIS
proc ::pwtk::environ::get {} {
    # DESCRIPTION    
    #   Returns the content of the ENVIRON input data (aka environ.in)
    # SOURCE

    variable input_flow_list

    ::pwtk::input::clear_
    loadDefaults_
    
    foreach name $input_flow_list {	
        ::pwtk::input::appendInput_ $name
    }
    
    return [::pwtk::input::get_]
}
#******


#****f* ::pwtk::environ/::pwtk::environ::clear
# SYNOPSIS
proc ::pwtk::environ::clear {} {
# PURPOSE
#   Clear the stored ENVIRON input data.
# SOURCE

    variable input_flow_list
    
    foreach name $input_flow_list {
	::pwtk::input::clear $name
    }
}
#****


#****f* ::pwtk::environ/::pwtk::environ::save_environ.in
# SYNOPSIS
proc ::pwtk::environ::save_environ.in {file} {
    # PURPOSE
    #   Save the environ data to environ.in and also its backup to a file $file.
    fprint environ.in
    ::pwtk::print "Making a backup copy of environ.in to $file\n"
    file copy -force environ.in $file
}
#****

    
#****f* ::pwtk::environ/::pwtk::environ::load_environ.in
# SYNOPSIS
proc ::pwtk::environ::load_environ.in {environFile {clear_existing 1}} {
    # PURPOSE 
    #   Load the input data from existing ENVIRON input file (aka environ.in). 
    #
    #   If clear_existing == 1, then the current input are cleared,
    #   otherwise the read data from $environFile are simply added to
    #   the existing input data.
    #
    # ARGUMENTS
    # * environFile -- filename of the ENVIRON input file (aka environ.in) from which to load the data
    # * clear_existing -- [optional] should the current ENVIRON input data be cleared?
    #
    # SOURCE

    ::pwtk::fileMustExist $environFile "ENVIRON input"

    if { [::pwtk::is_true $clear_existing] } {
	# clear the current projwfc.x input data ...
	::pwtk::environ::clear
    }

    # read the namelists

    set output [::pwtk::readNamelists $environFile $::pwtk::environ::input_flow_list]
    append output [::pwtk::readCards  $environFile $::pwtk::environ::card_flow_list]
    
    # ENVIRON input file must contain an ENVIRON namelist
    if { $output == "" } {
	::pwtk::error "input file \"$environFile\" does not appear to be an ENVIRON input file" 1
    }

    eval $output
}
#******


proc ::pwtk::environ::loadDefaults_ {} {
    # so far no defaults for environ
    return
}
