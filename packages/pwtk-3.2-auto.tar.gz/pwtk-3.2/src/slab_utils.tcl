#
# $RCSfile: slab_utils.tcl,v $ --
#
#      This file contains a few commands associated with slab calculations.
#
# Copyright (c) 2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: slab_utils.tcl,v 1.0 2023/04/21 17:00:01 kokalj Exp $ 
#


#****f* ::pwtk::pwi/::pwtk::pwi::disableDipoleCorr
# SYNOPSIS
proc ::pwtk::pwi::disableDipoleCorr {} {
    # PURPOSE    
    #   Disable dipole correction. This proc is typically used for
    #   slab calculations. By disabling the dipole correction, the
    #   vacuum thickness can be significantly reduced (e.g., via
    #   ::pwtk::pwi::incrVacuum) and an SCF convergence can be a bit
    #   easier.
    #   
    # SOURCE
    CONTROL {
        tefield  = 
        dipfield =
    }
    SYSTEM {
	edir    =  
	emaxpos = 
	eopreg  = 
	eamp    =
    }
}
#******



#****f* ::pwtk::pwi/::pwtk::pwi::dipoleCorr
# SYNOPSIS
proc ::pwtk::pwi::dipoleCorr {args} {
    # USAGE
    #   ::pwtk::pwi::dipoleCorr  ?-vac1st thicknessBohr?  ?-diplayer thicknessBohr?  ?-vac2nd thicknessBohr?  slab_thicknessBohr
    #
    # PURPOSE
    #   Set the dipole correction.
    #
    # OPTIONS
    # * -vac1st   thickness ... the thickness of vacuum from top of the slab to the dipole layer in Bohr
    # * -diplayer thickness ... the thickness of the dipole-layer in Bohr
    # * -vac2nd   thickness ... the thickness of vacuum from top of the dipole-layer to the bottom of the adjecent slab in Bohr
    #
    # ARGUMENTS
    # * slab_thicknessBohr ... slab thickness in Bohr
    #
    # DESCRIPTION    
    #   This command presuposses that surface normal is along Z and a
    #   2D slab structure is the following:
    #
    #      z=C ----------
    #          |        | vac2nd
    #          |        |
    #          +--------+ diplayer 
    #          +--------+          
    #          |        | vac1st
    #          |        |
    #          +--------+ z=slab_thickness_bohr
    #          |//SLAB//|
    #      z=0 +--------+
    #
    #   Based on this assumption, edir=3 and the emaxpos and eopreg
    #   variables are set accordingly.
    #
    #  RETURN VALUE
    #    The size of the C lattice vector in Bohr units. The C lattice
    #    vector points along the Z-direction, which is the
    #    surface-normal direction.
    #
    # SOURCE
    
    set narg 1
    set options {
        {vac1st.arg   {} "thickness of vacuum from top of the slab to the dipole layer in Bohr"}
        {diplayer.arg {} "thickness of the dipole-layer in Bohr"}
        {vac2nd.arg   {} "thickness of vacuum from top of the dipole-layer to the bottom of the adjecent slab in Bohr"}
    }
    set usage "?-vac1st thickness?  ?-diplayer thickness?  ?-vac2nd thickness?  slab_thickness"
    ::pwtk::parseOpt_

    lassign [::pwtk::dipcorrDefault_ $opt(vac1st) $opt(diplayer) $opt(vac2nd)] opt(vac1st) opt(diplayer) opt(vac2nd)
        
    ::pwtk::checkOTypeStrict_ -vac1st $opt(vac1st) {number posreal} "positive number"
    ::pwtk::checkOTypeStrict_ -vac2nd $opt(vac2nd) {number posreal} "positive number"
    ::pwtk::checkOTypeStrict_ -diplayer $opt(diplayer) {number posreal} "positive number"

    # BEWARE: all thicknesses are in Bohr !
    set slab_height $args
  
    set dipZ [expr $slab_height + $opt(vac1st)]
    set Z    [expr $slab_height + $opt(vac1st) + $opt(diplayer) + $opt(vac2nd)]

    set emaxpos [expr $dipZ / $Z]
    set eopreg  [expr $opt(diplayer) / $Z]

    CONTROL {
        dipfield = .true.
        tefield = .true.
    }
    SYSTEM  [subst {
        edir = 3
        emaxpos = $emaxpos
        eopreg = $eopreg
    }]

    ::pwtk::print ++++ "Loading dipole correction ..."
    ::pwtk::print "------------------------------
   max slab height (including adsorbate)   = [format %6.3f $slab_height] Bohr
   vacuum thickness below the dipole layer = [format %6.3f $opt(vac1st)] Bohr
   dipole-layer thickness                  = [format %6.3f $opt(diplayer)] Bohr
   vacuum thickness above the dipole layer = [format %6.3f $opt(vac2nd)] Bohr
   size of 3rd lattice vector along Z      = [format %6.3f $Z] Bohr
   (emaxpos = [format %8.6f $emaxpos], eopreg = [format %8.6f $eopreg])
"
    return $Z
}
#******


#****f* ::pwtk::pwi/::pwtk::pwi::incrVacuum
# SYNOPSIS
proc ::pwtk::pwi::incrVacuum {zBohr} {
    # ARGUMENTS
    # * zBohr ... the vacuum increasing length (in Bohr)
    #
    # PURPOSE
    #   Increase the vacuum thickness by $zBohr in the Z direction,
    #   implying that the Z component of the 3rd lattice vectors is
    #   modified.
    #
    #   Vacuum can be reduced by specifying a negative value for $zBohr.
    #
    # SOURCE

    if { $zBohr >= 0 } {
        ::pwtk::print ++++ "Increasing vacuum by $zBohr bohr"
    } else {
        ::pwtk::print ++++ "Decreasing vacuum by [regsub -- ^- $zBohr {}] bohr"
    }

    set unit       [::pwtk::input::cardGetFlags   CELL_PARAMETERS trim]
    set cell_param [::pwtk::input::cardGetContent CELL_PARAMETERS]

    set dZ 0.0
    switch -glob -nocase -- $unit {
        *alat* {
            set dZ [expr $zBohr/[::pwtk::pwi::alat]]
        }
        *bohr* {
            set dZ $zBohr
        }
        *angstrom* {
            set dZ [expr $::pwtk::bohr2angs*$zBohr]
        }
        default {
            ::pwtk::error "unknown unit \"$unit\" in CELL_PARAMETERS,
must be one of alat, bohr, or angstrom"
        }
    }
    set Zold [lindex $cell_param end]
    set Znew [expr $Zold + $dZ]
    lset cell_param end $Znew
    CELL_PARAMETERS $unit [::pwtk::m2cell $cell_param]

    ::pwtk::print "
Old Z = [format %8.4f $Zold] $unit
New Z = [format %8.4f $Znew] $unit

New cell parameters:\n"
    ::pwtk::input::cardPrint CELL_PARAMETERS
    
    return $Znew
}
#******
