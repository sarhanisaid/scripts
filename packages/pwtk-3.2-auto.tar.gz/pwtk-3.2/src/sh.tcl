#
# $RCSfile: sh.tcl,v $ --
#
#      This file contains ...
#
#      sh == Bourne shell
#
#      This is a dummy emulation of queuing system (for testing
#      purposes mainly). Instead of queuing system driver, a simple sh
#      is used. It can be used as a pwtk to shell converter (note that
#      only a subset of pwtk basic functionality can be converted to
#      the Bourne shell script).
#
#
# Copyright (c) 2009-2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: sh.tcl,v 1.3 2021/05/01 19:23:20 tone Exp $ 
#


# N.B: the ::pwtk::SH and ::pwtk::sh_profile commands are created
# dynamically by calling the ::pwtk::sh::init command

#****f* ::pwtk::sh/::pwtk::SH
# USAGE
#
# Either:
#   SH { ...script... }
#
# Or:
#   SH profile { ...script...}
#
# DESCRIPTION
# The master command for the SH dummy emulation of a batch queuing (SH
# stands for shell, e.g. #!/bin/sh). The above "profile" is a user
# defined profile for SH.  If "profile" is omitted, the "default"
# profile is used, which is guaranteed to exist because it is defined in the
# file:
# |html <a href="../config/sh.tcl">$PWTK/config/sh.tcl</a>.  Here is
# an example of how to define the default profile in the
# config/sh.tcl file:
#
#   profile default {
#      #!/bin/sh
#   }
#
# The final effect of the SH command is that the script encapsulated
# inside the SH { ... } command is submitted to "SH" via the "exec
# sh".
# 
#******

#****f* ::pwtk::sh/::pwtk::sh_profile
# USAGE
#   ::pwtk::sh_profile profileName profileSpecs ?pwtkSpecs?
#
# DESCRIPTION
#   Define a SH "profile" within the PWTK script. See also: ::pwtk::SH.
#
# ARGUMENTS
# * profileName -- name of the profile
# * profileSpecs -- definition of the 'profileName' profile
# * pwtkSpecs -- definition of the PWTK profile to be used when
#                the 'profileName' SH profile is used
#******

#****if* Internals/::pwtk::sh::init
# SYNOPSIS
proc ::pwtk::sh::init {} {
    # DESCRIPTION
    #    Initialization of the sh emulation of batch queuing system.
    #    This command is used only internally by PWTK. 
    # SOURCE
        
    # initialize the parent QUEUE 
    ::pwtk::queue::init sh sh "#"
}
#******
