#
# $RCSfile: difden.tcl,v $ --
#
#      This file contains the implementation of the DIFDEN
#      (i.e. difference-density) task. The DIFDEN manages the series
#      of calculations needed to obtain the difference plots.
#
# Copyright (c) 2009-2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: difden.tcl,v 1.11 2021/05/07 13:21:53 tone Exp $ 
#



#
# SHORT-CUTS
#

#****f* DIFDEN/::pwtk::difden_run
# DESCRIPTION
# See ::pwtk::difden::run
# SOURCE
proc ::pwtk::difden_run {prefix {difdenInput ""}} { uplevel [list ::pwtk::difden::run $prefix $difdenInput] }
#******

#****f* DIFDEN/::pwtk::difden_segmentSpec
# DESCRIPTION
# See ::pwtk::difden::segmentSpecialization
# SOURCE
proc ::pwtk::difden_segmentSpec {segmentIndex segmentSpec} { return [uplevel [list ::pwtk::difden::segmentSpecialization $segmentIndex $segmentSpec]] }
#******

#
# The workflow of the difden calculation:
# ------------------------------------------
#   
#   # difden specification
#   
#   DIFDEN {
#       segment(1) = "1-19" | 'all'
#       weight(1)  = 1.0
#       name(1)    = "name_of_segment_1"
#
#       segment(2) = "1 3 4"
#       weight(2)  = -1.0
#       name(1)    = "name_of_segment_2"
#       ...
#   }
#   
#   difden_run prefix ?difdenInput?
#
# This will peform the following calcs:
#   1. pw.x & pp.x (&INPUTPP) for segment(1)
#   2. pw.x & pp.x (&INPUTPP) for segment(2)
#   3. pp.x (&PLOT) to plot the difference
#


#****f* DIFDEN/::pwtk::difden::DIFDEN
# SYNOPSIS
proc ::pwtk::difden::DIFDEN {content} {
    # PURPOSE    
    #  Specify DIFDEN namelist for "difden" calculation (difden
    #  acronym stands for difference-density). 
    #
    #  An example of "difden" calculation is the calculation of
    #  bonding (formation) density (i.e. charge density difference).
    #  For example, consider we want to calculate/plot the charge
    #  density difference of AB system as: 
    #
    #      \Delta n(r) = n(AB;r) - [n(A;r) + n(B;r)].  
    #
    #  This would involve 3 scf + 3 pp.x (&inputpp namelist) + 1 pp.x
    #  (&plot namelist) calculations. The "difden" utility does it
    #  automatically. User only needs to define the atomic structural
    #  segments (in the example above, there are three segments: AB,
    #  A, B).
    #    
    #  Here is an example of DIFDEN namelist specification.
    #
    #    DIFDEN {
    #       segment(1) = "all"
    #       weight(1)  = 1.0
    #       name(1)    = "whole_structure"
    #
    #       segment(2) = "1 3-7"
    #       weight(2)  = -1.0
    #       name(2)    = "name_of_segment_2"
    #       
    #       segment(3) = "2 8-"
    #       weight(3)  = -1.0
    #       name(3)    = "name_of_segment_3"
    #    }    
    #
    # ARGUMENTS   
    # * content -- the DIFDEN namelist specification.
    #              It consists of the following namelist variables:
    #
    #     * nsegment -- [OPTIONAL] number of segments; if not specified, 
    #                   determined from the specification of the segment(*) array.
    #
    #     * segment(i), i=1,nsegment -- [REQUIRED] specify list of atoms belonging to the segment
    #                                   using the following syntax: "1 3 4-12 17-21"
    #                                   (also word "all" can be used, which designates all atoms)
    #                                   Examples: "all"      -- means all atoms
    #                                             "1-"       -- means all atoms (i.e. from 1 to the end)"
    #                                             "1 3-5 7-" -- means atoms 1 3 4 5 and from 7 to the end    
    #                                      
    #     * weight(i), i=1,nsegment  -- [REQUIRED] weight of the segment
    #
    #     * name(i), i=1,nsegment -- [OPTIONAL] symbolic name of the segment(i)
    #                                (used for naming the corresponding I/O files)
    #
    #     * restart -- [OBSOLETE] if true, restart the DIFDEN calculation
    #                             (use the ::pwtk::restart mechanism instead)
    #
    # SOURCE

    variable difden

    ::pwtk::input::namelist DIFDEN $content 
}


#*** internal...
proc ::pwtk::difden::parseDIFDEN_ {} {
    variable difden
    
    set segmentL ""
    set weightL  ""

    ::pwtk::ifexist difden { unset difden }
    
    foreach var [::pwtk::input::namelistVars_ DIFDEN] {
	
	set value [::pwtk::input::namelistGetVarValue DIFDEN $var trim]
	set index [lindex [split $var ()] 1]

        # allow:  DIFDEN { value = }
        if { $value == "" } {
            continue
        }

	switch -glob -- [string tolower $var] {
	    nsegment { 
		set difden(nsegment) $value
	    }
	    segment(*) {
		set difden(segment,$index)  $value
		lappend segmentL $index		
	    }
	    weight(*) {
		set difden(weight,$index) $value
		lappend weightL $index	
	    }
	    name(*) {
		set difden(name,$index) [string trim $value '\"]
	    }
	    restart {
                ::pwtk::deprecated "The use of the \"restart\" variable in the DIFDEN namelist is obsolete. 
Using PWTK's restart mechanism instead." 
                pwtk::restart on                
	    }
	    default {
		::pwtk::error "unknown variable in DIFDEN namelist"
	    }
	}
    }

    # check that segment(*) and weight(*) array elements span a sequence
    
    set sortedSL [lsort -integer $segmentL]    
    set sortedWL [lsort -integer $weightL]
    set nseg     [llength $sortedSL]
    if { ! [::pwtk::lequal $sortedSL $sortedWL] } {
	::pwtk::error "elements of segment(*) and weight(*) arrays do not match" 1
    }

    if { ! [info exists difden(nsegment)] } {
        set difden(nsegment) $nseg
    }

    set difden(first) [lindex $sortedSL 0]
    set difden(last)  [lindex $sortedSL end]
    
    if { $difden(first) != 1 } {
	::pwtk::warning "first elements of segment(*) array does not have index of 1"
    }

    set warn {}
    for {set i $difden(first)} {$i<=$difden(last)} {incr i} {
	if { [lindex $sortedSL $i-1] != $i } {
	    set warn "elements of segment(*) and weight(*) arrays are not continuous.\n(indices are $sortedSL)"
            break
	}
    }
    if { $warn != {} } {
        ::pwtk::warning $warn
    }
    
    if { $nseg != $difden(nsegment) } {
        ::pwtk::warning "the value of specified \"nsegment\" is not equal to the number of defined segments"
	set difden(nsegment) $nseg
    }    
}
#******



#****f* DIFDEN/::pwtk::difden::run
# SYNOPSIS
proc ::pwtk::difden::run {head {difdenInput ""}} {
    # PURPOSE    
    #   Run the "difden" calculation (difden acronym stands for
    #   difference-density). Before runing the "difden" calculation,
    #   user must specify the DIFDEN namelist.
    #
    # SEE ALSO
    #   For the description of DIFDEN namelist and "difden"
    #   calculations see ::pwtk::difden::DIFDEN
    #
    # ARGUMENTS    
    #   * head -- prefix for the I/O files    
    #   * difdenInput -- [OPTIONAL] content of DIFDEN namelist
    #                    (i.e. specification of DIFDEN namelist omitting 
    #                    the "DIFDEN" keyword)
    #
    # SOURCE

    
    variable difden

    ::pwtk::input::pushpop {
    
        # load defaults for pw.x (i.e. outdir, pseudo_dir, etc ...)
        ::pwtk::pwi::loadDefaults_ CONTROL
        
        if { $difdenInput != "" } {
            DIFDEN $difdenInput
        }

        printTitle_ "Performing DIFDEN calculation"
        parseDIFDEN_
        
        # print some message to stdout
        
        print_      "  number of segments to compute = $difden(nsegment)\n"
        
        for {set i $difden(first)} {$i <= $difden(last)} {incr i} {
            if { [info exists difden(segment,$i)] } {
                print_ "  segment #.$i:"
                if { [info exists difden(name,$i)] } {
                    print_ "      segment name:                    $difden(name,$i)"
                }
                print_ "      weight of this segment:          $difden(weight,$i)"
                print_ "      atoms belonging to this segment: $difden(segment,$i)"	
            }
        }
        puts ""
    
        # ------------------------------------------------------
        # STEP #1: perform the SCF & pp.x (INPUTPP) calculations
        
        print_ "Step #.1: performing the pw.x (SCF) & pp.x (&INPUTPP) calculations\n"
    
        for {set i $difden(first)} {$i <= $difden(last)} {incr i} {
            if { [info exists difden(segment,$i)] } {        
                # assign atoms to the $i-th segment
                set difden(atomList,$i) [::pwtk::parseRangeString $difden(segment,$i) [::pwtk::pwi::getNAtoms]]
        
                # run SCF pw.x && pp.x
                ::pwtk::difden::runSCF_INPUTPP_ $head $i	
            }
        }
        # ------------------------------------------------------
    

        ::pwtk::input::pushpop {
        
            # prepare input file for pp.x (PLOT) calculation
            
            PLOT " nfile = $difden(nsegment) "

            set ind 1
            for {set i $difden(first)} {$i <= $difden(last)} {incr i} {
                if { [info exists difden(weight,$i)] } {
                    PLOT "filepp($ind) = '$difden(filplot,$i)' , weight($ind) = $difden(weight,$i) "
                    incr ind
                }
            }
            ::pwtk::input::namelistClear INPUTPP

            set fileout [::pwtk::input::namelistGetVarValue PLOT fileout trim]
            if { $fileout == "" } {
                # define fileout
                set fileout $head.fileout
                PLOT " fileout = '$fileout' "
            }            

            # -----------------------------------------
            # STEP #.2: perform PP.x (PLOT) calculation

            print_ "Step #.2: performing the pp.x (&PLOT) calculation\n"
            runPP plot.$head

            if { [file exists $fileout] } {
                ::pwtk::print "Requested differential property was written to file:   $fileout\n"
            } else {
                ::pwtk::error "fileout $fileout does not exist;\nsee the $head.plot.out file for possible cause."
            }
            # -----------------------------------------       
        }
    }
}
#******


#****f* DIFDEN/::pwtk::difden::segmentSpecialization
# SYNOPSIS
proc ::pwtk::difden::segmentSpecialization {segmentIndex segmentSpec} {
    # PURPOSE 
    #
    #   Set a special treatment of a specified segment for DIFDEN. For
    #   example, let us calculate the \Delta n(r) of CO molecule as
    #   \Delta n(r) = n(CO;r) - [n(C;r) + n(O;r)].  Both standalone
    #   atoms are spin-polarized and require corresponding
    #   specification in the input file. This is the purpose of this
    #   proc. The whole DIFDEN specification would look as follows:
    #
    #      DIFDEN {
    #        name(1)    = "CO"
    #        segment(1) = "all"
    #        weight(1)  = 1.0
    #
    #        name(2)    = "C"
    #        segment(2) = 1
    #        weight(2)  = -1.0
    #
    #        name(3)    = "O"
    #        segment(3) = 2
    #        weight(3)  = -1.0
    #     }
    #
    #     # both C and O have a total magnetization of 2
    #     set spinSpecs {
    #         SYSTEM {
    #            nspin = 2
    #            tot_magnetization = 2
    #         }    
    #     }
    #     ::pwtk::difden::segmentSpecialization 2 $spinSpecs
    #     ::pwtk::difden::segmentSpecialization 3 $spinSpecs
    #      
    #     ::pwtk::difden::run CO.difden   
    #
    # ARGUMENTS
    # * segmentIndex -- which segment
    # * segmentSpec  -- specialization data for the corresponding segment
    #
    # SOURCE
    variable difden
    return [::pwtk::input::script DIFDEN.segmentSpec,$segmentIndex $segmentSpec]
}
#******


proc ::pwtk::difden::runSCF_INPUTPP_ {head index} {
    variable difden

    ::pwtk::input::pushpop {

        # --
        # handle segment specialization

        set segmentSpec [::pwtk::input::scriptGet DIFDEN.segmentSpec,$index]
        
        if { $segmentSpec != {} } {
            ::pwtk::print "Specialization for segment #.$index:\n\n[::pwtk::skipEmptyLines $segmentSpec]\n"
            eval $segmentSpec
        }
        
        # --
        # give some name to this segment
        
        if { ! [info exists difden(name,$index)] } {
            set str [regsub -all { } [normalizeRangeString__ $difden(segment,$index)] ,]
            set difden(name,$index) $str
        }
        
        # --
        # adjust the pw.x input for this SCF run
        
        set outdir [file join [::pwtk::outdir_query -hard] $difden(name,$index)]
        set prefix [::pwtk::input::namelistGetVarValue CONTROL prefix trim]
        if { $prefix == "" } {
            set prefix $difden(name,$index)
        } else {
            set prefix $prefix.$difden(name,$index)
        }
        
        CONTROL " calculation = 'scf', outdir = '$outdir' , prefix = '$prefix' "    
        
        # BEWARE: ATOMIC_POSITIONS must precede SYSTEM here !!!
        
        ::pwtk::input::cardContent ATOMIC_POSITIONS [::pwtk::pwi::getAtmPosSegment $difden(atomList,$index)]
        ::pwtk::pwi::setNAtoms
        
        # -----------
        # run the SCF
        # -----------

	::pwtk::print "Performing calculations for segment #.$index:\n"    
        runPW scf.${head}.segment_$difden(name,$index)
        
        # prepare the pp.x input file
        
        set difden(filplot,$index) $head.segment_$difden(name,$index).pp
        INPUTPP " outdir = '$outdir', prefix = '$prefix', filplot = '$difden(filplot,$index)' "
        ::pwtk::input::namelistClear PLOT; # PLOT namelist must be empty !

        # ----------------------
        # run the pp.x (INPUTPP)
        # ----------------------

        runPP inputpp.${head}.segment_$difden(name,$index)

        if { [file exists $difden(filplot,$index)] } {
            ::pwtk::print "Property written to filplot:   $difden(filplot,$index)\n"
        } else {
            ::pwtk::error "filplot $difden(filplot,$index) does not exist" 1
        }
    }
}


proc ::pwtk::difden::print_ {message} {    
    ::pwtk::print DIFDEN $message
}


proc ::pwtk::difden::printTitle_ {title} {    
    ::pwtk::printTitle DIFDEN $title
}
