#
# $RCSfile: header.tcl,v $ --
#
#      This file contains some auxiliary routines for the 'run -bg'
#      background mode.
#
# Copyright (c) 2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: header.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#

#****a* 5.3.5. Background and Remote and Delayed Execution/Background Execution
# DESCRIPTION
#   Collection of commands for background execution of jobs.
#
#******

#****a* Background Execution/Plain run and runXX commands
# DESCRIPTION
#   The plain 'run' and the runXX set of commands (e.g. runPW,
#   runPH...) run executables in background when they are called with
#   the '-bg' option. For example:
#
#      runPW -bg relax.Cu111
#
#   will run the 'pw.x -in relax.Cu111.in > relax.Cu111.out'
#   calculation in background. The command returns immediately and
#   does not wait for the calculation to finish. If there is no more
#   script to process, the PWTK will exit.
#
#   To wait for a particular background job to finish before PWTK
#   exits, one must use ::pwtk::run_wait command.
#
#******

#****f* Plain run and runXX commands/::pwtk::run_id
# SYNOPSIS
proc ::pwtk::run_id {} {
    # PURPOSE
    #   Return the ID of the last 'run -bg' background process or an
    #   empty string if there were/are no 'run -bg' background processes.
    #
    # SOURCE
    variable run
    ifexist run(bg.ID) {
        return $run(bg.ID)
    } else {
        return ""
    }
}
#******


#****f* Plain run and runXX commands/::pwtk::run_ids
# SYNOPSIS
proc ::pwtk::run_ids {} {
    # PURPOSE
    #   Return the IDs of all existing 'run -bg' background jobs.
    #
    #   A background job is considered existing if it was submitted by
    #   any among 'run* -bg' commands and was not yet monitored/waited
    #   by the ::pwtk::run_wait command, which removes it from the
    #   list of existing 'run -bg' jobs.
    #
    # SOURCE

    variable run
    if { ! [info exists run(bg.ID)] } {
        # there are no 'run -bg' background jobs
        return
    }
    set ids ""
    for {set id 1} {$id <= $run(bg.ID)} {incr id} {
        if { [info exists run(bg.PID,$id)] } {
            lappend ids $id
        }
    }
    return $ids
}
#******


#****f* Plain run and runXX commands/::pwtk::run_wait
# SYNOPSIS
proc ::pwtk::run_wait {args} {
    # USAGE
    #   run_wait ?id1? ?id2? ...
    #
    # PURPOSE
    #   Wait for the specified 'run -bg' background processes to finish.
    #
    #   If ::pwtk::run_wait is called without arguments, the command
    #   waits for all the 'run -bg' background processes to finish.
    #
    # ARGUMENTS
    # * args ... list of IDs of 'run -bg' background processes; an empty list implies all IDs
    #
    # SOURCE
    
    variable run

    if { ! [info exists run(bg.ID)] } {
        # nothing to wait for; there are no 'run -bg' background processes
        return
    }

    set all_procs 0
    set remedy_activated 0
    
    # default == wait for all processes
    if { $args eq {} } {
        set args [::pwtk::run_ids]
        set all_procs 1; # wait for all bg procs to finish
    }

    set args [concat {*}$args]
    foreach id [::pwtk::lunique $args] {
        ifexist run(bg.PID,$id) {
            lappend pids $run(bg.PID,$id)
            lappend ids  $id
        }
    }

    ifexist pids {
        set pr [expr { [llength $pids] > 1 ? "es" : "" }]
        print "Waiting for the background process$pr $pids to finish ...\n"
        
        foreach pid $pids id $ids {
            # wait for the background process $pid to finish
            pid_wait $pid
            unset run(bg.PID,$id)
            
            # now execute a remedy & postrun scripts for $pid
            ::pwtk::input::pushpop {
                variable state
                ::pwtk::input::load_state $run(bg.peek,$id)
        
                if { [remedy $run(bg.pname,$id)] } {
                    set remedy_activated 1
                    if { [checkForError $run(bg.output,$id) $run(bg.prog,$id) 0] } {
                        set remedy [remedy $run(bg.pname,$id) get]
                        ::pwtk::infoMsg "An error occured in '$run(bg.output,$id)'.\nTrying to remedy it by using the remedy script:\n$remedy"
                        ::pwtk::input::pushpop {
                            remedy $run(bg.pname,$id) clear
                            eval $remedy
                            eval $run(bg.run_cmd,$id)
                        }
                    }
                } else {
                    checkForError $run(bg.output,$id) $run(bg.prog,$id) $state(stopOnError)
                }
                
                # handle "postrun"
                
                set pname $run(bg.pname,$id)
                if { $pname eq "hp.x" } {
                    # make a backup copy of $prefix.Hubbard_parameters.dat
                    runHP_backup_HP_ $run(bg.output,$id)
                }
                set postruns [::pwtk::postruns_ $pname]
                if { $postruns ne {} } {
                    foreach name $postruns {
                        # should a postrun be done inside pushpop? NO!
                        #::pwtk::print "Evaluating the postrun script:\n$state($name)"
                        eval $state($name)        
                    }
                }            
            }
        }
    }

    if { $all_procs && $remedy_activated } {
        # there may be 'remedy' unfinished bakcground processes
        ::pwtk::run_wait
    }
}
#******


##****f* Plain run and runXX commands/::pwtk::run_pidwait
## SYNOPSIS
#proc ::pwtk::run_pidwait {PID} {
#    # PURPOSE
#    #   Wait for the PID background process on the local host to finish.
#    #
#    # ARGUMENTS
#    # * PID ... PID of the process
#    #
#    # SOURCE
#    variable run
#    variable time_interval_ms
#
#    while { [pid_exists $PID] } {	
#        after $time_interval_ms
#    }
#
#    #set cmd [list try [list exec ps -p $PID -o pid=] on error err {}]
#    #set PID [eval $cmd]
#    #while { $PID ne "" } {	
#    #    after $time_interval_ms
#    #    set PID [eval $cmd]
#    #}
#}
##******


##****f* Plain run and runXX commands/::pwtk::run-bg_get_
## SYNOPSIS
#proc ::pwtk::run-bg_get_ {key {id ""}} {
#    # PURPOSE
#    #   Get the requested info of the 'run -bg' background process.
#    #
#    # ARGUMENTS
#    # * key -- a "key" for the info to query, possibilities are prog, output, PID,
#    #          peek, remedy, remedyScript, run_cmd
#    # * id -- (optional) ID of the 'run -bg' background process (PWTK assigns a
#    #          unique ID to each 'run -bg' background process)
#    #
#    # If the 'id' argument is omitted, the requested 'key' of the last
#    # submitted 'run -bg' background job is returned.
#    #
#    # SOURCE
#    
#    variable run
#
#    if { $id eq "" && [info exists run(bg.ID)] } {
#        set id $run(bg.ID)
#    }
#    if { [info exists run(bg.PID,$id)] } {
#        if { [info exists run(bg.$key,$id)] } {
#            return $run(bg.$key,$id)
#        } else {
#            set keys [regsub -all {,[0-9]+} [regsub -all bg\. [array names run bg.*,$id] {}] {}]
#            set keys [join $keys {, }]
#            ::pwtk::error "wrong key '$key', must be one of $keys"
#            ::error {} "from ..."
#        }
#    }
#    return ""    
#}
##******


