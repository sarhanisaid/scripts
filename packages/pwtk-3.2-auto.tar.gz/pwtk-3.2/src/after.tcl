#
# $RCSfile: header.tcl,v $ --
#
#      This file contains the afterDone command.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: header.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#

#****a* 5.3.5. Background and Remote and Delayed Execution/Delayed Execution
# DESCRIPTION
#   Collection of commands for delayed execution. For example, after a
#   given calculation is completed.
#
#******


#****f* Delayed Execution/::pwtk::afterDone
# SYNOPSIS
proc ::pwtk::afterDone {args} {
    # USAGE
    #   ::pwtk::afterDone  ?OPTIONS?  OUTPUT_FILE_LIST  ?SCRIPT?
    #
    # PURPOSE
    #   Wait for the calculations associated with the list of output
    #   files specified in OUTPUT_FILE_LIST to complete. If the SCRIPT
    #   argument is supplied, it will be executed after waiting is
    #   completed (hence, the name "afterDone").
    #
    #   This command is blocking, it returns only after waiting and
    #   the execution of the optional SCRIPT are completed.
    #
    #   If maximum waiting time is exceeded (default = 2 weeks), PWTK aborts.
    #
    # OPTIONS
    # * -check TIME_INTERVAL --- check for calculations if finished every TIME_INTERVAL
    #                            (the time is specified in the format accepted by
    #                             ::pwtk::time2ms; default = 30sec)    
    # * -max TIME --- maximum waiting time (the time is specified in the format accepted
    #                 by ::pwtk::time2ms; default = 2w)
    #
    # ARGUMENTS    
    # * OUTPUT_FILE_LIST --- list of output files that need to be "completed" before
    #                        proceeding. The ::pwtk::job_done command is used to
    #                        determine if a given output file is completed.    
    # * SCRIPT -- (optional) script to execute after waiting
    #
    # SOURCE

    
    set nargmin 1
    set nargmax 2
    set usage "?-check TIME_INTERVAL?  ?-max TIME?  OUTPUT_FILE_LIST  ?SCRIPTS?"
    set options {
        {check.arg  30s    "time interval for checking"}
        {max.arg    2week  "maximum waiting time"}
    }
    ::pwtk::parseOpt_    
    lassign $args outputFileList script

    # N.B. do not check if the output files exist because they may not yet
    # (e.g. this is (almost) always the case for job schedulers)
    
    if { [llength $outputFileList] == 1 } {
        set job job
    } else {
        set job jobs
    }
    print "Waiting for the [join $outputFileList {, }] $job to be completed ..."

    set check_interval_ms   [time2ms $opt(check)]
    set max_waiting_time_ms [time2ms $opt(max)]
    set elapsed_ms 0
    
    while 1 {
        #
        after $check_interval_ms
        #
        ifnotexist waiting {
            print -nonewline "waiting .."
            set waiting 1
        }
        puts -nonewline "."
        flush stdout

        set done 1
        foreach out $outputFileList {
            if { ! [file exists $out ] || ! [job_done $out] } {
                set done 0
                break
            }
            # check if an error occured during the $out run and abort if so
            checkForError $out $out 1
        }
        if { $done } {
            puts ""
            # execute the 'script'
            set code [catch {uplevel 1 $script} result]
            return -code $code $result
            
        }

        set elapsed_ms [expr $elapsed_ms + $check_interval_ms]

        # prevent the loop going on indefinitely
        
        if { $elapsed_ms > $max_waiting_time_ms } {
            ::pwtk::abort "Maximum waiting time of $max_waiting_time_ms ms reached,
but the jobs associated with [join $outputFileList {, }] are not completed."
        }
    }
}
#******
