#
# $RCSfile: nebo.tcl,v $ --
#
#      This file contains the commands accosiated with the neb.x output.
#
# Copyright (c) 2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: nebo.tcl,v 1.0 2023/01/12 17:00:01 kokalj Exp $ 
#

#****f* ::pwtk::nebo/::pwtk::nebo::getPathLength
# SYNOPSIS
proc ::pwtk::nebo::getPathLength {nebo {index end}} {
    # PURPOSE
    #   Get path length.
    # ARGUMENTS
    # * nebo -- neb.x output file
    # * index -- which path length to return (first = 0, last = end)
    # SOURCE
    return [::pwtk::grep_field {  path length  } $nebo end-1 $index]
}
#******

#****f* ::pwtk::nebo/::pwtk::nebo::getInterImageDist
# SYNOPSIS
proc ::pwtk::nebo::getInterImageDist {nebo {index end}} {
    # PURPOSE
    #   Get inter-image distance.
    # ARGUMENTS
    # * nebo -- neb.x output file
    # * index -- which inter-image distance to return (first = 0, last = end)
    # SOURCE
    return [::pwtk::grep_field {inter-image distance =} $nebo end-1 $index]
}
#******

#****f* ::pwtk::nebo/::pwtk::nebo::getEact
# SYNOPSIS
proc ::pwtk::nebo::getEact {nebo {index end}} {
    # PURPOSE
    #   Get forward (->) activation energy.
    # ARGUMENTS
    # * nebo -- neb.x output file
    # * index -- which activation energy to return (first = 0, last = end)
    # SOURCE
    return [::pwtk::grep_field {activation energy (->)} $nebo end-1 $index]
}
#******

#****f* ::pwtk::nebo/::pwtk::nebo::getEactRev
# SYNOPSIS
proc ::pwtk::nebo::getEactRev {nebo {index end}} {
    # PURPOSE
    #   Get reverse (backward) (<-) activation energy.
    # ARGUMENTS
    # * nebo -- neb.x output file
    # * index -- which reverse activation energy to return (first = 0, last = end)
    # SOURCE
    return [::pwtk::grep_field {activation energy (<-)} $nebo end-1 $index]
}
#******

#****f* ::pwtk::nebo/::pwtk::nebo::getCI
# SYNOPSIS
proc ::pwtk::nebo::getCI {nebo {index end}} {
    # PURPOSE
    #   Get the climbing image.
    # ARGUMENTS
    # * nebo -- neb.x output file
    # * index -- which climbing image to return (first = 0, last = end)
    # SOURCE
    return [::pwtk::grep_field {climbing image =} $nebo end $index]
}
#******

#****f* ::pwtk::nebo/::pwtk::nebo::getNImages
# SYNOPSIS
proc ::pwtk::nebo::getNImages {nebo {index end}} {
    # PURPOSE
    #   Get the number of images.
    # ARGUMENTS
    # * nebo -- neb.x output file
    # SOURCE
    return [::pwtk::egrep_field { +num_of_images +=} $nebo end $index]
}
#******

