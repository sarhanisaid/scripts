#
# $RCSfile: bader.tcl,v $ --
#
#      This file contains a few procs for calculating Bader charges
#      with the "bader" program using the cube file generate by pp.x.
#
# Copyright (c) 2023  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#
# $Id: bader.tcl,v 1.3 2023/01/10 17:00:01 kokalj Exp $ 
#


#****f* BADER/::pwtk::pw_pp_bader
# SYNOPSIS
proc ::pwtk::pw_pp_bader {args} {
    # USAGE
    #   pw_pp_bader  ?-e ECUTRHO?  ?-p PLOT_NUM?  HEAD
    #
    # DESCRIPTION
    #   Calculate Bader charges by running pw.x, pp.x, and bader
    #   codes.  This workflow requires the bader program:
    #   https://theory.cm.utexas.edu/henkelman/code/bader/
    #
    #   |html &bull; <b>pw.x specifics:</b> an SCF calculation is
    #   performed. If the value of the SYSTEM ecutrho variable is
    #   smaller than the value of the -e option (or its default value
    #   of 1000 Ry, if not specified), then the ECUTRHO of the -e
    #   option is used, i.e.:
    #
    #        CONTROL { calculation = 'scf' }
    #        SYSTEM  " ecutrho = $ecutrho "
    #
    #   |html &bull; <b>pp.x specifics:</b> a CUBE file is created
    #   with PLOT_NUM value specified by the -p option (default = 17)
    #
    # OPTIONS
    # * -e ECUTRHO  ... the pw.x SYSTEM 'ecutrho' value (default = 1000 Ry)
    # * -p PLOT_NUM ... the pp.x INPUTPP 'plot_num' value (default = 17)
    #
    # ARGUMENTS
    # * HEAD -- the rootname for filenames; generate files are named PREFIX.HEAD.POSTFIX
    #
    # SOURCE

    set narg 1
    set usage "?-e ECUTRHO?  ?-p PLOT_NUM?  HEAD"
    set options {
        {e.arg 1000.0 "ecutrho for pw.x calculation"}
        {p.arg 17     "plot_num for pp.x calculation"}            
    }
    parseOpt_
    checkOTypeStrict_ e $opt(e) double number
    checkOTypeStrict_ p $opt(p) integer

    set head $args
    
    printTitle BADER "Calculating Bader charges using the pw.x --> pp.x --> bader workflow"
    
    input_pushpop {        
        # if ecutrho < $opt(e), increase it
        
        set ecutrho   [::pwtk::input::namelistGetVarValue SYSTEM ecutrho]
        ifset ecutrho [::pwtk::input::namelistGetVarValue SYSTEM ecutwfc]*4

        if { ![string is double $ecutrho] || $opt(e) > $ecutrho }  {
            print "Increasing ecutrho to :   $opt(e) Ry\n"
            SYSTEM  [subst { ecutrho = $opt(e) }]
        }

        # pw.x
        CONTROL { calculation = 'scf' }
        input_clear IONS CELL
        runPW scf.$head

        ::pwtk::pp_bader -p $opt(p) $head
    }
}
#******


#****f* BADER/::pwtk::pp_bader
# SYNOPSIS
proc ::pwtk::pp_bader {args} {
    # USAGE
    #   pp_bader ?-p PLOT_NUM? HEAD 
    #
    # DESCRIPTION    
    #   Calculate Bader charges by running pp.x and bader
    #   codes. This routine requires the bader program:
    #   https://theory.cm.utexas.edu/henkelman/code/bader/
    #
    #   pp.x specifics: a CUBE file is created with the 'plot_num'
    #   value specified by the -p option (default = 17)
    #
    # OPTIONS
    # * -p PLOT_NUM ... the pp.x INPUTPP 'plot_num' value (default = 17)
    #
    # ARGUMENTS
    # * HEAD -- the rootname for filenames; generate files are named PREFIX.HEAD.POSTFIX
    #
    # SOURCE

    set narg 1
    set usage "?-p PLOT_NUM?  HEAD"
    set options {
        {p.arg 17     "plot_num for pp.x calculation"}            
    }
    parseOpt_
    checkOTypeStrict_ p $opt(p) integer

    set head $args
    
    switch -- $opt(p) {
        0       { set prefix chdens }
        17 - 21 { set prefix pawden }
        default {
            ::pwtk::error "unsupported plot_num = $opt(p) for Bader charges, must be one of 0, 17, or 21" 1
        }
    }

    input_pushpop {
        print "Making a pp.x calculation for plot_num = $opt(p)\nCube file = $prefix.$head.cube\n"
        INPUTPP [subst {
            filplot  = '$prefix.$head.pp'
            plot_num = $opt(p)}]
        
        PLOT [subst {
            nfile     = 1 
            weight(1) = 1.0
            filepp(1) = '$prefix.$head.pp'
            fileout   = '$prefix.$head.cube' 
            iflag = 3 
            output_format = 6}]
        
        runPP $prefix.$head
    }
    
    ::pwtk::cube2bader $prefix.$head.cube
}
#******


#****f* BADER/::pwtk::cube2bader
# SYNOPSIS
proc ::pwtk::cube2bader {args} {
    # USAGE
    #   cube2bader [BADER_OPTIONS] CUBE_FILE
    #
    # DESCRIPTION
    #   Run the bader program on a supplied cube file.
    #   This routine requires the bader program:
    #   https://theory.cm.utexas.edu/henkelman/code/bader/
    #
    # ARGUMENTS
    # * BADER_OPTIONS -- options passed to the bader program
    # * CUBE_FILE     -- the filename of the cube file
    #
    # SOURCE
    
    set cube [lindex $args end]
    ::pwtk::fileMustExist $cube CUBE

    set bader [getExecutable [::pwtk::getVar_ BADER] bader]
    if { $bader eq {} } {
        ::pwtk::error "cannot find a usable \"bader\" executable" 1
    }

    set head [regsub {.cube$} $cube {}]
    try {
        execute $bader {*}$args > ${head}_bader.log
    } on error err {
        ::pwtk::writeFile ${head}_bader.error $err
    }
    if { [file exists ACF.dat] } {
        print "Renaming *.dat files to ${head}_*.dat\nFor Bader atomic charges, see:  ${head}_ACF.dat"
        file rename -force ACF.dat ${head}_ACF.dat
        file rename -force AVF.dat ${head}_AVF.dat
        file rename -force BCF.dat ${head}_BCF.dat
    } else {
        ::pwtk::error "File ACF.dat does not exist. Likely, the bader run failed!" 
    }
}
#******
