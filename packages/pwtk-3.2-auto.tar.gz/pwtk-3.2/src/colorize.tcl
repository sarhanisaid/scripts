# ------------------------------------------------------------------------
# The AUTHOR of the below code is:
#
# Richard Suchenwirth
#
# The code below is taken almost verbatim from
# https://wiki.tcl-lang.org/page/ANSI+color+control
# (changes by T.K. are marginal)
#
# The snippets published on https://wiki.tcl-lang.org/ are disrtibuted
# under BSD-type license: https://wiki.tcl-lang.org/license
# ------------------------------------------------------------------------


#****f* Internals/@
# SYNOPSIS
proc ::pwtk::@ {args} {
    # PURPOSE
    #  Colorize terminal text.
    #
    #  Taken almost verbatim from https://wiki.tcl-lang.org/page/ANSI+color+control
    #
    # EXAMPLE
    # [@ green]This text is green[@] and this text has a default color.
    # [@ it]This text is italics[@] and this text is written in defult style.
    #
    # AUTHOR
    # * Richard Suchenwirth
    # * minor modifications by Tone Kokalj
    #
    # SOURCE
    set map {
        bold 1 light 2 it 3 blink 5 invert 7 
        black 30 red 31 green 32 yellow 33 blue 34 purple 35 cyan 36 white 37 grey 38;5;243
        Black 40 Red 41 Green 42 Yellow 43 Blue 44 Purple 45 Cyan 46 White 47
    }
    set t 0
    foreach i $args {
        set ix [lsearch -exact $map $i]
        if {$ix>-1} {lappend t [lindex $map $ix+1]}
    }
    return "\033\[[join $t {;}]m"
}
#******
