#
# lobster.tcl 
#
#      This file contains a few commands for performing the analysis
#      of chemical bonding with the LOBSTER program.
#
# Copyright (c) 2024  Anton Kokalj   Email: tone.kokalj@ijs.si
#
#
# This file is distributed under the terms of the GNU General Public
# License. See the file `LICENCE' in the root directory of the present
# distribution, or http://www.gnu.org/copyleft/gpl.txt .
#
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# ANTON KOKALJ BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
# AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
#


# TODO:
# * for no -xE, disable xtics if they are not specified ?

# ------------------------------------------------------------------------
# SHORCUTS
# ------------------------------------------------------------------------

#****f* LOBSTER/::pwtk::lobster_plot
# SEE
#    ::pwtk::lobster::plot
# SYNOPSIS
proc ::pwtk::lobster_plot {args} { uplevel 1 ::pwtk::lobster::plot $args }
#******

#****f* LOBSTER/::pwtk::lobster_multiplot
# SEE
#    ::pwtk::lobster::multiplot
# SYNOPSIS
proc ::pwtk::lobster_multiplot {args} { uplevel 1 ::pwtk::lobster::multiplot $args }
#******

#****f* LOBSTER/::pwtk::lobster_sumdos
# SEE
#    ::pwtk::lobster::sumdos
# SYNOPSIS
proc ::pwtk::lobster_sumdos {atomList {doscar {}}} { uplevel 1 [list ::pwtk::lobster::sumdos $atomList $doscar] }
#******

#****f* LOBSTER/::pwtk::lobster_getinfo
# SEE
#    ::pwtk::lobster::getinfo
# SYNOPSIS                            
proc ::pwtk::lobster_getinfo {file} { uplevel 1 [list ::pwtk::lobster::getinfo $file] }
#******

#****f* LOBSTER/::pwtk::lobster_datafy
# SEE
#    ::pwtk::lobster::datafy
# SYNOPSIS                            
proc ::pwtk::lobster_datafy {file} { uplevel 1 [list ::pwtk::lobster::datafy $file] }
#******


# ------------------------------------------------------------------------
# COMMANDS
# ------------------------------------------------------------------------


#****f* LOBSTER/::pwtk::lobster_run
# SYNOPSIS
proc ::pwtk::lobster_run {args} {
    # USAGE
    #    ::pwtk::lobster_run  ?SPECIFIC-OPTIONS?  ?PLOTTING-OPTIONS?  ?STANDARD-PLOTTING-OPTIONS?  HEAD  ?LOBSTER_INPUT_DATA?
    #
    #    where SPECIFIC-OPTIONS are:
    #
    #       -scf
    #       -nscf KGRID
    #       -dir  DIR
    #       -threads OMP_NUM_THREADS
    #
    #   For PLOTTING-OPTIONS, see: ::pwtk::lobster::multiplot    
    #   For STANDARD-PLOTTING-OPTIONS, see: ::pwtk::plot
    #
    # SPECIFIC OPTIONS
    # * -scf  --- perform an SCF pw.x calculation (I/O filenames are pw.HEAD.scf.in|out)
    
    # * -nscf {K1 K2 K3  ?SK1 SK2 SK3?} ---
    #             perform NSCF pw.x calculation using the provided automatic k-point grid;
    #             if SK1,SK2,SK3 are omitted, a non-shifted k-mesh is used
    #             (I/O filenames are pw.HEAD.nscf.in|out)
    
    # * -dir DIR --- perform calculations in the DIR directory (useful when running multiple
    #                LOBSTER calculations for a given pw.x SCF calculation; in such cases, each
    #                LOBSTER calculation can be run in a different subdirectory)
    
    # * -threads OMP_NUM_THREADS --- number of OpenMP threads used by LOBSTER (if omitted,
    #                                LOBSTER will use all available threads even if the
    #                                OMP_NUM_THREADS enviromental variable is defined)
    #
    # ARGUMENTS
    # * HEAD -- the rootname for files, i.e., the pw.x I/O files will be
    #           named pw.HEAD.scf.in|out and pw.HEAD.nscf.in|out
        
    # * LOBSTER_INPUT_DATA -- (optional) lobster input data, i.e., the content of the lobsterin file;
    #                         if not specified, the content of the LOBSTER card is used (if defined)
    #
    # DESCRIPTION
    #   Perform a LOBSTER analysis of chemical bonding (this command requires the
    #   LOBSTER program: http://www.cohp.de/ ). The sequence of jobs is:
    #
    #      pw.x SCF (optional, requested by -scf)
    #       |
    #       |
    #      pw.x NSCF (optional, requested by -nscf)
    #       |
    #       |
    #      lobster
    #       |
    #       |
    #      PLOTTING       
    #
    #   The LOBSTER input data can be specified in three ways:
    #   * via the LOBSTER_INPUT_DATA command-line argument 
    #   * via the LOBSTER card (if the LOBSTER_INPUT_DATA command-line argument is unspecified)
    #   * via the 'lobsterin' input file (if the LOBSTER card is undefined and
    #     the LOBSTER_INPUT_DATA command-line argument unspecified;
    #     otherwise PWTK overwrites the 'lobsterin' file
    #
    # RETURN VALUE
    # * filenames of created plots (for file terminal) or empty string (for window terminal)
    #
    # SOURCE

    printTitle LOBSTER_RUN "Running the LOBSTER workflow"
    print "Workflow options & arguments :  $args\n"
    
    # check for lobster
    
    set lobster [getExecutable [::pwtk::getVar_ LOBSTER] lobster]
    if { $lobster eq {} } {
        ::pwtk::error "cannot find a usable \"lobster\" executable" 1
    }

    # parse command-line arguments

    addOpts_ options usage {
        {scf          "perform SCF pw.x calculation"}
        {nscf.arg {}  "perform NSCF pw.x calculation using provided KGRID"}
        {dir.arg  .   "perform calculations in specified directory"}
        {threads.arg {} "number of OpenMP threads (aka OMP_NUM_THREADS)"}
    } {
        -scf {-nscf KGRID} {-dir DIRECTORY} {-threads OMP_NUM_THREADS}
    }

    set nargmin 1
    set usage "[fmtUsage_ $usage]  ?SPECIFIC-OPTIONS?  ?PLOTTING-OPTIONS?  ?STANDARD-PLOTTING-OPTIONS?  HEAD  ?LOBSTER_INPUT_DATA?"
    parseKnownOpt_
    checkOType_ -nscf $opt(nscf) {numberlist nonnegint}  "list of non-negative integer numbers (i.e. automatic k-point grid specs)"

    set head      [lindex $args end-1]
    set lobsterin [lindex $args end]    
    if { [llength $lobsterin] == 1 } {
        set head $lobsterin
        set lobsterin {}
        set args [lrange $args 0 end-1]
    } else {
        set args [lrange $args 0 end-2]
    }
    
    # trim head from prefixes/postfixes
    set t {scf nscf relax vc-relax md vc-md} 
    set head [trim_prefix $t [trim_postfix [join $t {.in }].in $head]]
    
    # lobster input

    file mkdir $opt(dir)
    ifset lobsterin [::pwtk::input::cardGetContent LOBSTER]
    if { $lobsterin ne {} } {
        writeFile [file join $opt(dir) lobsterin] $lobsterin
    }
    if { $lobsterin eq {} && ! [file exists [file join $opt(dir) lobsterin]] } {
        ::pwtk::error "missing lobsterin input data " 1
    }

    # if *scf.in file does not exist in $opt(dir), try to create a link
    
    if { $opt(dir) ne "." && !$opt(scf) && $opt(nscf) eq {} } {
        foreach pre {pw. {}} {
            if { ! [file exists [file join $opt(dir) ${pre}$head.scf.in]] \
                     && [file exists ${pre}$head.scf.in] } {
                file link [file join $opt(dir) ${pre}$head.scf.in] ${pre}$head.scf.in            
            }
            if { ! [file exists [file join $opt(dir) ${pre}$head.nscf.in]] \
                           && [file exists ${pre}$head.nscf.in] } {
                file link [file join $opt(dir) ${pre}$head.nscf.in] ${pre}$head.nscf.in
            }

        }
        if { [glob -directory $opt(dir) -nocomplain *scf.in] eq {} } {
            ::pwtk::error "cannot find a usable pw.x input file" 1
        }
    }

    # calculations
    
    set plots {}
    eval_in_dir $opt(dir) {

        # pw.x

        input_pushpop {
            if { $opt(scf) || $opt(nscf) ne {} } {
                infoMsg "temporarily setting SYSTEM { nosym = .true. } for LOBSTER"
                CONTROL { wf_collect = .true. }
                SYSTEM  { nosym = .true. }
                SCF_NSCF_
            }
        }

        # lobster

        print LOBSTER "Performing LOBSTER calculation\n"
        
        ifexist ::env(OMP_NUM_THREADS) {
            set save_threads $::env(OMP_NUM_THREADS)
            unset ::env(OMP_NUM_THREADS)
        }
        ifnotempty opt(threads) {
            set ::env(OMP_NUM_THREADS) $opt(threads)
        }    

        try {
            execute $lobster
        } on error err {
            variable state
            ::pwtk::error "An error occured while executing lobster !!!\n\nError INFO:\n$err" $state(stopOnError)
        }

        ifexist save_threads {
            set ::env(OMP_NUM_THREADS) $save_threads
        }

        # plot i0 (e.g. total / average)

        set llist {}
        foreach car {
            DOSCAR DOSCAR.LSO COOPCAR COHPCAR COBICAR
            DOSCAR.LCFO COOPCAR.LCFO COHPCAR.LCFO COBICAR.LCFO
        } {
            if { [file exists $car.lobster] } {
                incr nplot
                array set info [::pwtk::lobster::getinfo $car]
                set nproj($car) $info(nproj)
                lappend llist [list $car i0]
            }
        }
        ifnotempty llist {
            set nx [expr { $nplot > 8 ? 5 : 4 }]            
            set nx [expr { "-nx" ni $args ? "-nx $nx" : {} }]
            lappend plots [::pwtk::lobster::multiplot {*}$args {*}$nx $llist $head-i0]
        }

        # plot projections to atoms / fragments / interactions
        
        foreach {prop cardatL} {
            DOS {
                {DOSCAR      DOSCAR.atom}
                {DOSCAR.LSO  DOSCAR.LSO.atom}
                {DOSCAR.LCFO DOSCAR.LCFO.frag}
            }
            COOP {
                COOPCAR
                COOPCAR.LCFO
            }
            COHP {
                COHPCAR
                COHPCAR.LCFO
            }
            COBI {
                COBICAR
                COBICAR.LCFO
            }
        } {
            set llist {}
            foreach cardat $cardatL {
                set car [lindex $cardat 0]
                set dat [lindex $cardat end]
                if { [file exists $dat.dat] && $nproj($car) > 1 } {
                    for {set ip 1} {$ip < $nproj($car)} {incr ip} {
                        lappend llist [list $dat i$ip]
                    }
                }
            }
            ifnotempty llist {
                lappend plots [::pwtk::lobster::multiplot {*}$args $llist $head-$prop]
            }
        }        
    }

    # list all created plot files
    
    ifnotempty plots {
        print LOBSTER "The following plot files were created:"
        foreach plot $plots {
            print "* [file join $opt(dir) $plot]"
        }
    }

    return [varvalue plots]
}
#******


#****f* ::pwtk::lobster/::pwtk::lobster::plot
# SYNOPSIS
proc ::pwtk::lobster::plot {args} {
    # USAGE
    #   ::pwtk::lobster::plot  ?-dir DIR?  ?PLOTTING-OPTIONS?  ?STANDARD-PLOTTING-OPTIONS?  PROPERTY_INTERACTIONS_LIST  ?HEAD?
    #
    #   where PLOTTING-OPTIONS are:
    #    
    #      -xE
    #      -cohp+
    #      -int
    #      -sumspin
    #      -fill
    #      -dt_dw DASHTYPE
    #      -ft_dw TRANSPARENCY
    #
    #   For STANDARD-PLOTTING-OPTIONS, see: ::pwtk::plot
    #
    # OPTION
    # * -dir DIR       ...  the lobster files are located in the DIR directory
    #                       (i.e. DIR should be the same as used for ::pwtk::lobster_run)
    #
    # PLOTTING OPTIONS
    # * -xE             ... X-axis is the energy (default: Y-axis is the energy,
    #                       i.e., traditional COOP/COHP plotting)
    
    # * -cohp+          ... plot COHP as +COHP (default = -COHP)

    # * -int            ... plot also the integrated COHP, COOP...
    
    # * -sumspin        ... plot the sum of spin-up & spin-down channels

    # * -fill           ... use filledcurves for the COHP, COOP... plots

    # * -dt_dw DASHTYPE ... line dash-type specs for the spin-down channel, specified 
    #                       as solid_length,space_length pairs (default = 6,3)
    
    # * -ft_dw TRANSPARENCY ... filledcurve transparency factor (within [0,1]) for the
    #                           spin-down channel (default = 0.25)
    #
    # ARGUMENTS
    # * PROPERTY_INTERACTIONS_LIST ... specifies what to plot; it is a list containing the
    #                                  "property interactions" pairs (see below)
    
    # * HEAD ... (optional) the rootname for the plotting files
    #
    # DESCRIPTION
    # This command plots the LOBSTER-calculated data using the following operations:
    
    # * Transformation of pertinent *CAR*.lobster files into *CAR*.dat
    #   datafiles suitable for Gnuplot plotting (the comments at the
    #   top of these *.dat files describe the contained data and their
    #   naming).
    
    # * Plotting of the specified data from the *CAR*.dat datafiles.
    #    
    # Which LOBSTER-calculated data to plot is specified with the
    # PROPERTY_INTERACTIONS_LIST argument, which is a list consisting
    # of the "property interactionList" pairs, where:

    # * "property" is the property to plot; its name stems from the
    #    rootname of the *CAR*.lobster or *CAR*.dat file (e.g., DOS,
    #    COOP, COHP, COBI, DOS.LSO, COHP.LCFO). For DOS plots, atom
    #    and orbital projected DOSes can be plotted by adding suffixes
    #    to the DOS string (see below).

    # * "interactionList" is the list of COXX interactions or PDOS
    #   components to plot. Individual interaction (component) is
    #   specified as 'iX', where X is the interger. Interaction can
    #   also be specified with a simple algebraic expression, e.g.:
    #
    #       (i1+i2+i3)/3.0+i4
    #
    # Here is the PROPERTY_INTERACTIONS_LIST example:
    #
    #    set PROPERTY_INTERACTIONS_LIST {    
    #         COHP  {i0 (i1+i2+i3)/3.0}    
    #         COOP  {i0 (i1+i2+i3)/3.0}
    #    }
    #
    # With such a specification, two COHP curves and two COOP curves
    # would be plotted in a single plot with the first curve
    # corresponding to 'i0' and the second to '(i1+i2+i3)/3.0'.
    # 
    # The meaning of the 'iX' strings is explained in the header of
    # the transformed *CAR*.dat file (this transformation can also be
    # achieved manually with the ::pwtk::lobster::datafy command). Here
    # are two examples:
    #
    #  * header of the COHPCAR.dat file:
    #
    #     # ESCALE ; pCOHP file generated by LOBSTER. Energy is shifted such that the Fermi level lies at 0 eV.
    #     # non-shifted Emin = 3.10273e+00 eV, Emax = 1.91529e+01 eV, Efermi = 1.31341e+01 eV; npoints = 321
    #     # nspin = 2
    #     # number of interactions = 4  (including the Average)
    #     # iX indices of COHP interactions:
    #     # i0 = Average
    #     # i1 = No.1:Fe1->Ni2(2.513764596130672)
    #     # i2 = No.2:Fe1->Ni3(2.513764596130672)
    #     # i3 = No.3:Fe1->Ni4(2.513764596130672)
    #  
    #  * header of the DOSCAR.orbatom1.dat file:
    #
    #     # Projected DOS to atom 1 (Z= 26): 4s 4p_y 4p_z 4p_x 3d_xy 3d_yz 3d_z^2 3d_xz 3d_x^2-y^2
    #     # Energy is shifted such that the Fermi level lies at 0 eV.
    #     # non-shifted Emin = 3.10273151 eV, Emax = 19.15288825 eV, Efermi = 13.13407947 eV; npoints = 321
    #     # nspin = 2
    #     # nproj = 10  (including the sum)
    #     # iX indices of DOS components:
    #     # i0 = sum
    #     # i1 = 4s
    #     # i2 = 4p_y
    #     # i3 = 4p_z
    #     # i4 = 4p_x
    #     # i5 = 3d_xy
    #     # i6 = 3d_yz
    #     # i7 = 3d_z^2
    #     # i8 = 3d_xz
    #     # i9 = 3d_x^2-y^2
    #
    # |html <b>DOS plotting specifics</b>
    #
    # PWTK tranforms DOSCAR.lobster and DOSCAR.LSO.lobster files into
    # the following *.dat files suitable for Gnuplot plotting:
    
    # * DOSCAR.dat --- file containing total DOS and total integrated DOS
    # * DOSCAR.atom.dat --- file containing total DOS and DOSes projected to each atom
    # * DOSCAR.orbatom1.dat,
    #   DOSCAR.orbatom2.dat... --- for each atom, atom-projected DOS and
    #                              DOSes projected to individual atomic orbitals
    #
    # while DOSCAR.LCFO.lobster is transformed into the following *.dat files:

    # * DOSCAR.LCFO.dat --- file containing total DOS and total integrated DOS
    # * DOSCAR.LCFO.frag.dat --- file containing total DOS and DOSes projected to each fragment
    # * DOSCAR.LCFO.orbfrag1.dat,
    #   DOSCAR.LCFO.orbfrag2.dat... --- for each fragment, fragment-projected DOS and
    #                                   DOSes projected to individual fragment orbitals
    #
    # These files (i.e. their data) can be accessed in the
    # PROPERTY_INTERACTIONS_LIST by specifying, e.g., DOS.atom,
    # DOS.orbatom2, or DOS.LCFO.orbfrag1 as the property.
    #
    # |html <b>Summing atom and fragment DOSes</b>
    #
    # The DOSCAR.orbatomX.dat and DOSCAR.orbfragX.dat files can be
    # summed with the ::pwtk::lobster::sumdos command. For example, to
    # obtain the DOS projected to atoms 2, 3, 4, and 5, one can use:
    
    #    ::pwtk::lobster::sumdos 2-4,5 DOSCAR
        
    # which creates:
    # * DOSCAR.orbatom2-4,5.dat containing summed atomic and orbital PDOSes (if atoms 2-4,5 have compatible atomic orbitals)
    # or:
    # * DOSCAR.atom2-4,5.dat containing only summed atomic PDOS (if atoms 2-4,5 have incompatible atomic orbitals)
    #
    # Analogously:
    
    #    ::pwtk::lobster::sumdos 2-4,5 DOSCAR.LCFO
    
    # creates either DOSCAR.orbfrag2-4,5.dat or DOSCAR.frag2-4,5.dat
    # depending on whether fragments 2-4,5 have compatible fragment
    # orbitals or not.
    #
    # These files (i.e. their data) can be accessed in the
    # PROPERTY_INTERACTIONS_LIST by specifying, e.g., DOS.atom2-4,5 or
    # DOS.orbatom2-4,5 or DOS.LCFO.orbfrag2-4,5 as the property.
    #
    #
    # EXAMPLE    
    #    # plot two COOP and two COHP curves in a single plot, corresponding 
    #    # to 'i0' and average of i1,i2,i3 interactions (i.e. (i1+i2+i3)/3.0)
    #
    #    ::pwtk::lobster::plot -fill -xf '' {
    #         COOP  {i0 (i1+i2+i3)/3.0}    
    #         COHP  {i0 (i1+i2+i3)/3.0}
    #    }
    #
    #    # plot DOS projected to atom1, atom2, and the sum of atom1 and atom2
    #
    #    ::pwtk::lobster::plot -xE -fill -xf '' {
    #         DOS.atom i1
    #         DOS.atom i2
    #         DOS.atom i1+i2
    #    }
    #
    #    # plot DOS projected to atom1 and the sum of its sp orbitals and d orbitals
    #
    #    ::pwtk::lobster::plot -xE -fill -xf '' {
    #         DOS.orbatom1 {i0  i1+i2+i3+i4   i5+i6+i7+i8+i9}
    #    }
    #
    #    # N.B. to learn about the meaning of iX strings, run in the PWTK prompt:  ::pwtk::lobster::datafy DOS
    #    # and look into the generated DOSCAR.orbatom1.dat file, i.e.:    
    #    #    i0 = sum
    #    #    i1 = 4s
    #    #    i2 = 4p_y
    #    #    i3 = 4p_z
    #    #    i4 = 4p_x
    #    #    i5 = 3d_xy
    #    #    i6 = 3d_yz
    #    #    i7 = 3d_z^2
    #    #    i8 = 3d_xz
    #    #    i9 = 3d_x^2-y^2
    #
    # RETURN VALUE
    #   Filename of the created Gnuplot plot (for file terminals) or
    #   the empty string (for window terminals).
    #
    # SOURCE
    
    printTitle "Plotting LOBSTER data"

    set type plot
    set arg1 FILE_INTERACTION_LIST
    xplotParseCmdline_

    ::pwtk::eval_in_dir $opt(dir) {
        if { $opt(xE) } {
            ifset opt(yl) [label_ [lindex $FILE_INTERACTION_LIST 0] $opt(cohp+)]
        } else {
            ifset opt(xl) [label_ [lindex $FILE_INTERACTION_LIST 0] $opt(cohp+)]
        }

        set ax2 [expr { $opt(xE) ? "y2l" : "x2l" }]
        if { $opt(int) && $opt($ax2) eq {} } {
            set opt($ax2) "Integrated"
        }    
        
        set font $::pwtk::gp::gp(font),[expr round(0.85*$::pwtk::gp::gp(fontSize))]
        set gp [::pwtk::gp::plot new -s $opt(s) $head.$opt(t)]
        $gp cmdlineOpts opt
        $gp set key  "top left Left reverse samplen 1 noenhanced font '$font'"
        
        if { $opt(int) } {
            if { $opt(xE) } {
                $gp options { ytics nomirror y2tics { } }
            } else {
                $gp options { xtics nomirror x2tics { } }
            }
        }

        set fileL {}
        set datL  {}
        $gp plot [plot_ opt fileL datL $FILE_INTERACTION_LIST]
        
        set result [::pwtk::gp::execDisplay_ $gp opt]
    }
    return $result
}
#******


#****f* ::pwtk::lobster/::pwtk::lobster::multiplot
# SYNOPSIS
proc ::pwtk::lobster::multiplot {args} {
    # USAGE
    #   ::pwtk::lobster::multiplot  ?-dir DIR?  ?PLOTTING-OPTIONS?  ?STANDARD-PLOTTING-OPTIONS?  PROPERTY_INTERACTIONS_LLIST  ?HEAD?
    #    
    #   where PLOTTING-OPTIONS are:
    #
    #      -xE
    #      -cohp+
    #      -int
    #      -sumspin
    #      -splitspin
    #      -fill   
    #      -dt_dw DASHTYPE
    #      -ft_dw TRANSPARENCY
    #      -nx NUMBER
    #      -np NUMBER
    #      -o  ORIENT
    #
    #   For STANDARD-PLOTTING-OPTIONS, see: ::pwtk::plot
    #
    # OPTION
    # * -dir DIR       ...  the lobster files are located in the DIR directory
    #                       (i.e. DIR should be the same as used for ::pwtk::lobster_run)
    #
    # PLOTTING OPTIONS
    # * -xE             ... X-axis is the energy (default: Y-axis is the energy,
    #                       i.e., traditional COOP/COHP plotting)
    
    # * -cohp+          ... plot COHP as +COHP (default = -COHP)

    # * -int            ... plot also the integrated COHP, COOP...
    
    # * -sumspin        ... plot the sum of spin-up & spin-down channels
    
    # * -splitspin      ... plot each spin channel in a separate plot

    # * -fill           ... use filledcurves for the COHP, COOP... plots

    # * -dt_dw DASHTYPE ... line dash-type specs for the spin-down channel, specified 
    #                       as solid_length,space_length pairs (default = 6,3)
    
    # * -ft_dw TRANSPARENCY ... filledcurve transparency factor (within [0,1]) for the
    #                           spin-down channel (default = 0.25)
    
    # * -nx NUMBER --- number of plots per row
    # * -np NUMBER --- number of plots per page
    # * -o ORIENT  --- page orientation for EPS (default = portrait); if -s is specified, this option is ignored
    #
    # ARGUMENTS
    # * PROPERTY_INTERACTIONS_LLIST ... specifies what to plot; it is a list of PROPERTY_INTERACTIONS lists
    #                                   (see ::pwtk::lobster::plot); each PROPERTY_INTERACTIONS list is
    #                                   plotted into a separate plot.
    
    # * HEAD ... (optional) the rootname for the plotting files
    #
    # DESCRIPTION
    # This command plots the LOBSTER-calculated data in a multiplot
    # consisting of several plots. It usage is analogous to the
    # ::pwtk::lobster::plot command, with two differences:
    
    # * it accepts extra plotting options (-splitspin, -nx, -np, -o)

    # * instead of the PROPERTY_INTERACTION list argument, the first
    #   command-line argument is a list of PROPERTY_INTERACTION lists
    #   (aka PROPERTY_INTERACTION_LLIST)
    #
    # The PROPERTY_INTERACTION_LLIST is a list of PROPERTY_INTERACTIONS lists.
    # Here is an example: 
    #
    #    set PROPERTY_INTERACTIONS_LLIST {
    #       { DOS   i0 }
    #       { COOP  {i0 (i1+i2+i3)/3.0} }
    #       { COHP  {i0 (i1+i2+i3)/3.0} }
    #    }
    #
    # With such a specification, a multiplot with three plots would be
    # created. The first plot contains the total DOS, the second plot
    # two COOP curves, and the third plot two COHP curves with the
    # first curve corresponding to 'i0' and the second to '(i1+i2+i3)/3.0'.
    #
    # For further info, see ::pwtk::lobster::plot
    #
    # EXAMPLE
    #    # plot total DOS and average COOP and COHP, each in a
    #    # separate plot arranged in a 3x1 matrix layout
    #
    #    ::pwtk::lobster::multiplot -nx 3 -fill {
    #         { DOS  i0 }
    #         { COOP i0 }
    #         { COHP i0 }
    #    }
    #
    #    # plot average and the first three individual interactions
    #    # for COOP, COHP, and COBI (each property in its own plot)
    #
    #    ::pwtk::lobster::multiplot -nx 3 {
    #         { COOP {i0 i1 i2 i3} }
    #         { COHP {i0 i1 i2 i3} }
    #         { COBI {i0 i1 i2 i3} }
    #    }    
    #
    #    # for atoms 1, 2 and atoms 3-5 (each in a separate plot),
    #    # plot atomic DOS and DOS projected to s and p orbitals
    #    # (atoms 1-5 are assumed to be of the same type; for atoms
    #    # 3-5, the average is plotted)   
    #    #
    #    # X-axis is used for the energy if -xE is specified
    #
    #    ::pwtk::lobster::multiplot -nx 3 -xE {
    #         { DOS.orbatom1   {i0 i1 i2 i3 i4} }
    #         { DOS.orbatom2   {i0 i1 i2 i3 i4} }
    #         { DOS.orbatom3-5 {i0/3 i1/3 i2/3 i3/3 i4/3} }
    #    }
    #
    #    # N.B. to learn about the meaning of iX strings, run in the PWTK prompt:  ::pwtk::lobster::datafy DOS
    #    # and look into the generated DOSCAR.orbatom1.dat file, i.e.:    
    #    #    i0 = sum
    #    #    i1 = 2s
    #    #    i2 = 2p_y
    #    #    i3 = 2p_z
    #    #    i4 = 2p_x
    #
    # RETURN VALUE
    #   Filename(s) of the created Gnuplot plot(s) (for file terminals) or
    #   the empty string (for window terminals).
    #
    # SOURCE
    
    printTitle "Multiplotting LOBSTER data"

    set type multiplot
    set arg1 FILE_INTERACTION_LLIST
    xplotParseCmdline_

    ::pwtk::eval_in_dir $opt(dir) {        
        set nplot [llength $FILE_INTERACTION_LLIST]
        if { $opt(splitspin) } {
            set nspin [dict get [getinfo [lobsterfile_ [lindex [lindex $FILE_INTERACTION_LLIST 0] 0]]] nspin]
            set nplot [expr $nspin*$nplot]
        }
        set ax2 [expr { $opt(xE) ? "y2l" : "x2l" }]
        if { $opt(int) && $opt($ax2) eq {} } {
            set opt($ax2) "Integrated"
        }
        
        array set mp [::pwtk::gp::multiplot_array $nplot $opt(np) $opt(nx)]
        set font $::pwtk::gp::gp(font),[expr round(0.85*$mp(fsize))]

        set gp [::pwtk::gp::multiplot new -o $opt(o) -s $opt(s) auto $nplot $opt(np) $opt(nx) $head.$opt(t)]
        $gp cmdlineOpts opt
        $gp set key  "top left Left reverse samplen 1 noenhanced font '$font'"

        if { $opt(int) } {
            if { $opt(xE) } {
                $gp options { ytics nomirror y2tics { } }
            } else {
                $gp options { xtics nomirror x2tics { } }
            }
        }

        set fileL {}
        set datL  {}
        foreach fileInterL $FILE_INTERACTION_LLIST {
            set l [expr { $opt(xE) ? "yl" : "xl" }]
            set $l $opt($l)
            ifset $l [label_ [lindex $fileInterL 0] $opt(cohp+)]; # use the property from the first file

            $gp set ${l}abel [::pwtk::squote [varvalue $l]]
            
            if { ! $opt(splitspin) || $opt(sumspin) } {
                $gp plot [plot_ opt fileL datL $fileInterL]
            } else {
                $gp plot [plot_ opt fileL datL $fileInterL 0]
                $gp plot [plot_ opt fileL datL $fileInterL 1]
            }
        }
        set result [::pwtk::gp::execDisplay_ $gp opt]
    }    
    return $result
}
#******


#****f* ::pwtk::lobster/::pwtk::lobster::getinfo
# SYNOPSIS
proc ::pwtk::lobster::getinfo {file} {
    # PURPOSE
    #   Get info about the LOBSTER *CAR*.lobster file. The info is returned
    #   as dictionary.
    #
    # ARGUMENT
    # * file -- the *CAR.lobster file; can be abbreviated, e.g., DOS stands
    #           for DOSCAR.lobster, DOS.LCFO stands for DOSCAR.LCFO.lobster, etc.
    #
    # RETURN VALUE
    #   For CO*CAR*.lobster files, the dictionary contains the following keys:
    #   * nat   -- number of atoms (set to 0)
    #   * nproj -- number of interactions (including the Avarage)
    #   * nspin -- 1 = unpolarized; 2 = spin-polarized
    #   * npoints -- number of energy points
    #   * Emin -- non-shifted minimum energy of the energy range
    #   * Emax -- non-shifted maximum energy of the energy range
    #   * Ef   -- non-shifted Fermi energy
    #
    #   For DOSCAR*.lobster files, the dictionary contains the following keys:
    #   * nat -- number of atoms 
    #   * nproj -- number of PDOSes
    #   * pdos -- 1 if PDOS
    #   * nspin -- 1 = unpolarized; 2 = spin-polarized
    #   * volume -- cell volume
    #   * A -- lattice parameter
    #   * B -- lattice parameter
    #   * C -- lattice parameter
    #   * npoints -- number of energy points
    #   * Emin -- non-shifted minimum energy of the energy range
    #   * Emax -- non-shifted maximum energy of the energy range
    #   * Ef -- non-shifted fermi energy
    #   * nproj1 -- number of projections for PDOS of atom/fragment 1
    #   * proj1  -- list of projections for atom/fragment 1
    #   * nproj2
    #   * proj2
    #   * ... (nprojX and projX repeated for each atom/fragment)
    #  
    #
    # SOURCE

    if { [regexp {^DOS} [file tail $file]] } {
        return [::pwtk::lobster::DOSCAR_info_ $file]
    } else {
        return [::pwtk::lobster::COXXCAR_info_ $file]
    }
}
#******


#****f* ::pwtk::lobster/::pwtk::lobster::datafy
# SYNOPSIS
proc ::pwtk::lobster::datafy {file} {
    # PURPOSE
    #   Tranform the *CAR*.lobster file into *CAR*.dat datafile(s)
    #   suitable for Gnuplot plotting, i.e.:
    #   * CO*CAR.lobster is transformed into CO*CAR.dat
    
    #   * DOSCAR.lobster is transformed into:
    #     DOSCAR.dat, DOSCAR.atom.dat, DOSCAR.orbatomX.dat (X = 1 ... nat)
    
    #   * DOSCAR.LSO.lobster is transformed into:
    #      DOSCAR.LSO.dat, DOSCAR.LSO.atom.dat, DOSCAR.LSO.orbatomX.dat (X = 1 ... nat)
    
    #   * DOSCAR.LCFO.lobster is transformed into:
    #     DOSCAR.LCFO.dat, DOSCAR.LCFO.frag.dat, DOSCAR.LCFO.orbfragX.dat (X = 1 ... nfragment)
    #
    #
    # ARGUMENT
    # * file -- the *CAR.lobster file; can be abbreviated, e.g., DOS stands
    #           for DOSCAR.lobster, DOS.LCFO stands for DOSCAR.LCFO.lobster, etc.
    #
    # RETURN VALUE
    #   The info about the LOBSTER *CAR*.lobster file returned as
    #   dictionary, see ::pwtk::lobster::getinfo.
    #
    # SOURCE
    
    if { [regexp {^DOS} [file tail $file]] } {
        return [::pwtk::lobster::DOSCAR_dat_ $file]
    } else {
        return [::pwtk::lobster::COXXCAR_dat_ $file]
    }
}
#******


#****f* ::pwtk::lobster/::pwtk::lobster::sumdos
# SYNOPSIS
proc ::pwtk::lobster::sumdos {atomList {doscar DOSCAR} } {
    # USAGE
    #   ::pwtk::lobster::sumdos  atomList  ?doscar?
    #
    # ARGUMENTS
    # * atomList ... list of atoms to sum, specified in the ::pwtk::parseRangeString syntax
    #                (example: 1-4,5,7)
    # * doscar ... (optional, default = DOSCAR) lobster DOSCAR file, e.g., DOSCAR.lobster,
    #              DOSCAR.LSO.lobster, DOSCAR.LCFO.lobster; can be abbreviated, e.g.,
    #              DOS stands for DOSCAR.lobster, DOS.LCFO stands for DOSCAR.LCFO.lobster, etc.
    #
    # PURPOSE
    
    #   Sum atomic/fragment PDOSes. If compatible PDOSes are summed,
    #   both atomic/fragment PDOS and obital-projected PDOSes will be
    #   summed, otherwise only atomic/fragment PDOSes are summed. In
    #   the first case, the output filename has the orbatm*.dat (or
    #   orgfrag*.dat) suffix, wheras in the second case
    #
    # RETURN VALUE
    #   The name of the output file containing summed DOS, which has:

    #   * .orbatom*.dat or .orbfrag*.dat suffix (* stands for the
    #     compressed atom list) when both atomic/fragment and
    #     obital-projected PDOSes were summed

    #   * .atom*.dat or .frag*.dat suffix when only atomic/fragment
    #     PDOSes were summed
    #
    # SOURCE
    
    set doscar [::pwtk::lobster::lobsterfile_ $doscar]    
    set head   [file rootname $doscar]
    set lcfo   [expr { [regexp LCFO $head] ? 1 : 0 }]
    
    array set info [::pwtk::lobster::DOSCAR_info_ $doscar]
    if { $lcfo } {
        set type frag
        set types fragments
        # for LCFO, nat == number of fragments
        set info(nat) $info(nproj)
    } else {
        set type atom
        set types atoms
    }
        
    set atmL  [join [regsub -all , [regsub -all { *\- *} $atomList -] { }] ,]
    set atmL  [regsub {\-$} $atmL -$info(nat)]    
    set atomList [::pwtk::parseRangeString $atomList $info(nat)]

    if { [llength $atomList] == 0 } {
        # DOSCAR.atom.dat
        return $head.$type.dat
    } elseif { [llength $atomList] == 1 } {
        # DOSCAR.orbatomX.dat
        return $head.orb${type}$atomList.dat        
    }

    array set info [::pwtk::lobster::DOSCAR_dat_ $doscar]
    
    # check if obitals can be summed
    
    set orb 1
    set out $head.orb${type}$atmL.dat

    foreach ia $atomList {
        set ind([incr np]) $ia
    }
    for {set ip 1} {$ip < $np} {incr ip} {
        set ia  $ind($ip)
        set ia1 $ind([expr $ip + 1])
        if { $info(proj$ia) ne $info(proj$ia1) } {
            set orb 0
            set out $head.${type}$atmL.dat
            break
        }
    }

    # atom No. of the 1st DOSCAR.orbatomX.dat file
    set ia0 [lindex $atomList 0]
    
    foreach ia $atomList {
        set dat $head.orb${type}$ia.dat
        ::pwtk::fileMustExist $dat "${type}X datafied LOBSTER"
        
        set fid($ia) [open $dat r]        
        gets $fid($ia); # skip the 1st line
    }
    
    set oid [open $out w]
    
    if { $orb } {
        puts $oid "# Summed $type PDOS with orbital components for $types [join $atomList ,]"
        puts $oid "# orbital components: $info(proj1)"
        # other comment line are printed below
    } else {
        puts $oid "# Summed $type PDOS for $types [join $atomList ,]
# nspin = $nspin
# # iX indices of DOS components:
# i0 = sum"
        if { $nspin == 1 } {
            puts $oid "# energy sum"
        } else {
            puts $oid "# energy sum(up) sum(dw)"
        }
    }

    # read & write the comment lines
        
    foreach ia $atomList {
        gets $fid($ia) line
        
        while { [regexp {^ *#} $line] } {
            if { $ia == $ia0 && $orb } {
                puts $oid $line
            }
            set pos [tell $fid($ia)]
            gets $fid($ia) line
        }
        seek $fid($ia) $pos
        
        # at this point $line contains the 1st DOS-data line
        if { $ia == $ia0 } {
            set len [llength $line]
        }
    }

    if { ! $orb } {
        # set 'len' to only summed atomic DOS
        set len [expr { $nspin == 1 ? 2 : 3 }]
    }

    # read & process xDOS data

    for {set ip 1} {$ip <= $info(npoints)} {incr ip} {

        # read 

        foreach ia $atomList {
            set i 0
            foreach f [gets $fid($ia)] {
                set d($ia,$i) $f
                incr i
            }
        }    

        # energy
        puts -nonewline $oid [format %9.5f $d($ia0,0)]

        # xDOS        
        for {set i 1} {$i < $len} {incr i} {
            set pdos 0.0
            foreach ia $atomList {
                set pdos [expr $pdos + $d($ia,$i)]
            }
            puts -nonewline $oid [format " %.5f" $pdos]
        }
        puts $oid ""
    }

    # close files

    close $oid
    foreach ia $atomList { close $fid($ia) }

    return $out
}
#******


#------------------------------------------------------------------------
# INTERNAL procs
# ------------------------------------------------------------------------


# internal...
proc ::pwtk::lobster::COXXCAR_info_ {file} {
    # PURSPOSE
    #   Return the info from the header of the CO*CAR.*lobster file

    set file [::pwtk::lobster::lobsterfile_ $file]    
    set fid [open $file r]
    
    gets $fid line
    gets $fid line
    lassign $line nproj nspin npoints Emin Emax Ef

    # COXXCAR*.lobster do not contain info about number-of-atoms (nat), use 0
    set result [dict create nat 0 nproj $nproj nspin $nspin npoints $npoints Emin $Emin Emax $Emax Ef $Ef]

    for {set i 0} {$i < $nproj} {incr i} {
        gets $fid proj($i)
        dict set result i$i $proj($i)
    }
    close $fid

    return $result
}

# internal...
proc ::pwtk::lobster::COXXCAR_dat_ {file} {
    # PURSPOSE
    #   Transform CP*CAR.*lobster into CO*CAR.*dat and return the info from the header

    set file [::pwtk::lobster::lobsterfile_ $file]
    set prop [::pwtk::lobster::property_ $file 1]
    set head [file rootname $file]
    set fid [open $file r]
    set dat [open $head.dat w]
    
    gets $fid line
    puts $dat "# $line"

    gets $fid line
    #puts $dat "# $line"
    lassign $line nproj nspin npoints Emin Emax Ef

    puts $dat "# non-shifted Emin = $Emin eV, Emax = $Emax eV, Efermi = $Ef eV; npoints = $npoints
# nspin = $nspin
# number of interactions = $nproj  (including the Average)
# iX indices of $prop interactions:"
    
    # COXXCAR*.lobster do not contain info about number-of-atoms (nat), use 0
    set result [dict create nat 0 nproj $nproj nspin $nspin npoints $npoints Emin $Emin Emax $Emax Ef $Ef]

    for {set i 0} {$i < $nproj} {incr i} {
        gets $fid proj($i)
        puts $dat "# i$i = $proj($i)"
        dict set result i$i $proj($i)
    }
    for {set i 1} {$i <= $npoints} {incr i} {
        gets $fid line
        puts $dat $line        
    }

    close $fid
    close $dat
    
    return $result
}

# internal...
proc ::pwtk::lobster::DOSCAR_info_ {file} {
    # PURSPOSE
    #   Return the info from the header of the DOSCAR.lobster file
    
    set lcfo [expr { [regexp LCFO $file] ? 1 : 0 }]

    set file [::pwtk::lobster::lobsterfile_ $file]    
    set fid [open $file r]
   
    gets $fid line
    lassign $line dummy nat pdos nspin
    
    gets $fid line
    lassign $line volume A B C dummy

    ::pwtk::skiplines $fid 3; # T, CAR, comment lines
    gets $fid line
    lassign $line Emax Emin npoints Ef dummy

    # N.B. if $pdos, the value of nproj is updated at the end (see below)
    set result [dict create \
                    nat $nat nproj 0 pdos $pdos nspin $nspin \
                    volume $volume A $A B $B C $C \
                    Emin $Emin Emax $Emax Ef $Ef npoints $npoints]

    # total dos
    
    for {set i 1} {$i <= $npoints} {incr i} {
        gets $fid line
    }

    # projections
    
    set ia 0
    if { $pdos } {
        # N.B. the below 'gets' reads the projection info line
        while { [gets $fid line] > 0 } {
            
            incr ia

            # store info of this projection
            
            set proj  [string trim [lindex [split $line \;] end]]
            set nproj [expr [llength $proj] + ! $lcfo]; # for LCFO, X is dummy, hence do not add 1 (example: X 1a1 2a1 1e 2e 3a1 3e 4e 4a1)

            dict set result nproj$ia $nproj
            dict set result proj$ia  $proj

            # read PDOS
            for {set i 1} {$i <= $npoints} {incr i} {
                gets $fid line
            }
        }
    }    
    dict set result nproj [expr $ia + 1]
    close $fid
    
    return $result
}

# internal...
proc ::pwtk::lobster::DOSCAR_dat_ {file} {
    # PURSPOSE
    #   Transform DOSCAR*.lobster into DOSCAR.dat, DOSCAR.$type.dat, and
    #   DOSCAR.orb${type}$id.dat files, where type = atom or frag and
    #   id = sequential index of atom or fragment.
    #
    #   The info about DOSCAR*.lobster is returned as dictionary.
    #

    set file [::pwtk::lobster::lobsterfile_ $file]
    set head [file rootname $file]

    # LCFO ?
    
    set lcfo [expr { [regexp LCFO $head] ? 1 : 0 }]
    set type [expr { $lcfo ? "frag" : "atom" }]

    # open files
    
    set fid [open $file r]
    set dat [open $head.dat w]
    set atm [open $head.$type.dat w]

    # DOSCAR*.lobster: header
    
    gets $fid line
    #puts $dat "# $line"
    lassign $line dummy nat pdos nspin
    
    gets $fid line
    #puts $dat "# $line"
    lassign $line volume A B C dummy
    
    gets $fid line; # temperature
    #puts $dat "# $line"

    gets $fid line; # CAR
    #puts $dat "# $line"

    gets $fid line; # comment
    #puts $dat "# $line"

    gets $fid line
    #puts $dat "# $line"
    lassign $line Emax Emin npoints Ef dummy
    puts $dat "# Total DOS and integrated total DOS
# Energy is shifted such that the Fermi level lies at 0 eV.
# non-shifted Emin = $Emin eV, Emax = $Emax eV, Efermi = $Ef eV; npoints = $npoints
# nspin = $nspin
# iX indices of DOS components:
# i0 = total DOS"
    if { $nspin == 1 } {
        puts $dat "# energy    DOS      integrated-DOS"
    } else {
        puts $dat "# energy    DOS(up)   DOS(dw)   integrated-DOS(up) integrated-DOS(dw)"
    }

    # N.B. if $pdos, the value of nproj is updated at the end (see below)
    set result [dict create \
                    nat $nat nproj 0 pdos $pdos nspin $nspin \
                    volume $volume A $A B $B C $C \
                    Emin $Emin Emax $Emax Ef $Ef npoints $npoints]

    # DOSCAR*.lobster: data
    
    for {set i 1} {$i <= $npoints} {incr i} {
        # nspin = 1: energy  DOS     IntegratedDOS
        # nspin = 2: energy  DOS(up) DOS(dw)  IntegratedDOS(up) IntegratedDOS(dw)
        gets $fid line
        puts $dat $line

        set tdos($i) [format %.5f [lindex $line 1]]
        if { $nspin == 2 } {
            set tdos_dw($i) [format %.5f [lindex $line 2]]
        }
    }
    close $dat

    # DOSCAR*.lobster: projections

    if { $pdos } {
        # N.B. the below 'gets' reads the projection info line
        while { [gets $fid line] > 0 } {
            incr ia

            set what  [string trim [lindex [split $line \;] 1]]
            set proj  [string trim [lindex [split $line \;] end]]
            set pdat  [open $head.orb${type}$ia.dat w]; # each atom/frag into a separate datafile
            
            puts $pdat "# Projected DOS to $type $ia ($what): $proj"
            
            if { $lcfo } {
                # strip X, which is dummy; example: X 1a1 2a1 1e 2e 3a1 3e 4e 4a1
                set proj [lrange $proj 1 end]
            }
            set nproj [expr [llength $proj] + 1]

            puts $pdat "# Energy is shifted such that the Fermi level lies at 0 eV.
# non-shifted Emin = $Emin eV, Emax = $Emax eV, Efermi = $Ef eV; npoints = $npoints
# nspin = $nspin
# nproj = $nproj  (including the sum)
# iX indices of DOS components:"

            set x 0
            set proj_spin {}
            foreach p [concat sum $proj] {
                puts $pdat "# i$x = $p"
                incr x
                append proj_spin "${p}(up) ${p}(dw) "
            }
            if { $nspin == 1 } {
                puts $pdat "# energy sum $proj"
            } else {                
                puts $pdat "# energy $proj_spin"
            }

            # add info of this projection to dictionary            
            dict set result nproj$ia $nproj
            dict set result proj$ia  $proj

            # read & write this PDOS
            for {set i 1} {$i <= $npoints} {incr i} {
                gets $fid line
                set E($i) [format %9.5f [lindex $line 0]]
                set dos   [lrange $line 1 end]

                if { $nspin == 1 } {
                    set sum($i,$ia) [format %.5f [::tcl::mathop::+ {*}$dos]]
                    puts $pdat "$E($i) $sum($i,$ia) $dos"
                } else {                    
                    foreach {up dw} $dos { lappend dos_up $up; lappend dos_dw $dw }
                    set sum_up($i,$ia) [format %.5f [::tcl::mathop::+ {*}$dos_up]]
                    set sum_dw($i,$ia) [format %.5f [::tcl::mathop::+ {*}$dos_dw]]
                    puts $pdat "$E($i) $sum_up($i,$ia) $sum_dw($i,$ia) $dos"
                    unset dos_up dos_dw
                }
            }

            close $pdat
        }

        # for LCFO, nat == number of fragments
        if { $lcfo } { set nat $ia }
        
        # write atom/frag DOS file (i.e. DOS projected to each atom/frag in a separate column)

        puts $atm "# [regsub frag $type fragment] projected DOS (n$type = $nat)
# Energy is shifted such that the Fermi level lies at 0 eV.
# non-shifted Emin = $Emin eV, Emax = $Emax eV, Efermi = $Ef eV; npoints = $npoints   
# nspin = $nspin
# nproj = [expr $nat + 1]  (including the total DOS)
# iX indices of DOS components (tot = total DOS; ${type}X = DOS projected to [regsub frag $type fragment]X):
# i0 = tot"

        set cols [expr { $nspin == 1 ? [format " %7s" tot] : [format " %7s %7s" tot(up) tot(dw)] }]
        for {set ia 1} {$ia <= $nat} {incr ia} {
            if { $nspin == 1 } {
                append cols [format " %7s" ${type}$ia]
            } else {
                append cols [format " %7s %7s" ${type}${ia}(up) ${type}${ia}(dw)]
            }
            puts $atm "# i$ia = ${type}$ia"
        }     
        puts $atm "# energy  $cols"
        
        for {set i 1} {$i <= $npoints} {incr i} {
            set xdos " $tdos($i)"
            if { $nspin == 2 } {
                append xdos " $tdos_dw($i)"
            }
            for {set ia 1} {$ia <= $nat} {incr ia} {
                if { $nspin == 1 } {
                    append xdos " $sum($i,$ia)"
                } else {
                    append xdos " $sum_up($i,$ia) $sum_dw($i,$ia)"
                }
            }
            puts $atm "$E($i) $xdos"
            unset xdos
        }
        close $atm
        #dict set result nproj $ia
        dict set result nproj [expr $nat+1]
    }
    
    close $fid
    
    return $result
}

# internal...
proc ::pwtk::lobster::xplotParseCmdline_ {} {
    uplevel 1 {
        print "Options & arguments :  $args\n"

        ::pwtk::gp::defaultCmdlineOpts_ plot options usage workflow

        ::pwtk::addOpts_ options usage {
            {dir.arg . "perform calculations in specified directory"}
            
            {xE        "X-axis is the energy (default: Y-axis is the energy"}
            {cohp+     "plot COHP as +COHP (default: -COHP)"}
            {int       "plot also the integrated COHP, COOP..."}
            {sumspin   "plot the sum of spin-up & spin-down channels"}
            {splitspin "plot each spin component in a separate plot"}
            {fill      "use filledcurves for COHP, COOP... plots"}
            
            {dt_dw.arg  6,3  "line dash type for the spin-down channel"}
            {ft_dw.arg  0.25 "filledcurve transparency factor for the spin-down channel"}

            {o.arg  {}   "paper orientation for EPS (portrait, landscape)"}
            {nx.arg -1   "number of plots per row"}
            {np.arg -1   "number of plots per page"}
        } {
            {-dir DIR}
            -xE -cohp+ -int -sumspin -splitspin -fill
            {-dt_dw DASHTYPE} {-ft_dw TRANSPARENCY}
            {-o ORIENT} {-nx NX} {-np NP}
        }      
        ::pwtk::setOpts_ options [subst {
            xr  :
            yr  :
            y2r 0:
        }]
        #tm  0.9
        #bm  3.1
        
        set nargmin 1
        set nargmax 2
        set usage "[::pwtk::fmtUsage_ $usage]  $arg1  ?HEAD?"
        ::pwtk::parseOpt_
        ::pwtk::gp::checkCmdlineOpts_ opt

        lassign $args $arg1 head
        
        if { $head eq {} } {
            set id [incr ::pwtk::gp::${type}_id]
            set head ${type}-$id
        }

        set l [expr { $opt(xE) ? "xl" : "yl" }]
        ifset opt($l) "{/${::pwtk::gp::gp(font)}-Italic E} − {/${::pwtk::gp::gp(font)}-Italic E}_F (eV)"
    }
}

# internal ...
proc ::pwtk::lobster::plot_ {optVar fileLVar datLVar fileInterL {spinId {}}} {
    # PURPOSE
    #   Generate and return the Gnuplot "plot" string for a single plot
    # ARGUMENTS
    # * optVar
    # * fileLVar
    # * datLVar
    # * fileInterL
    # * spinId -- (optional) spin-up = 0; spin-down = 1; default = {}

    upvar $optVar   opt
    upvar $fileLVar fileL
    upvar $datLVar  datL

    set lt 1
    set datList {}

    foreach {name exprList} $fileInterL {
        if { $exprList eq {} } {
            ::pwtk::error "malformed PROPERY_INTERACTION list;
must consist of property interactions pairs, but got: $fileInterL" 1
        }

        set file [lobsterfile_ $name]
        set tail [file tail $name]
        set prop [property_ $name $opt(cohp+)]
        set dos  [regexp {^DOS} $tail]
        set atm  [regexp {^DOS.*(atom|frag)} $tail]
        set lcfo [expr { [regexp LCFO $name] ? 1 : 0 }]
        
        if { $file ni $fileL } {
            lappend fileL $file
            set dict [datafy $file]                
        } else {
            set dict [getinfo $file]            
        }

        set nat   [dict get $dict nat]
        set nproj [dict get $dict nproj]        
        set nspin [dict get $dict nspin]
        
        if { $lcfo } {
            set type frag
            set dat  [datfile_ $name $nproj]
            set nat  $nproj
        } else {
            set type atom
            set dat  [datfile_ $name $nat]
        }
        
        if { $atm && $dat ni $datL } {     
            # sum DOSes
            set dat1 [::pwtk::lobster::sumdos [::pwtk::lobster::indices_ $dat $nat] $name]
                
            if { ![regexp orb$type $dat] && [regexp orb$type $dat1] } {
                # dat = DOSCAR.atom2-4.dat && dat1 = DOSCAR.orbatom2-4.dat is OK,
                # but not vice-versa
                set dat [regsub $type $dat orb$type]
                set prop [property_ $dat]
            }                 
            if { $dat1 ne $dat } {
                ::pwtk::error "'$dat' file does not exist; '$dat1' was created instead" 1
            }         
            lappend datL $dat
        }
        lappend datList $dat
        
        foreach expr $exprList {
            set sign 1
            if { ! $opt(cohp+) && [string match COHP* $name] } {
                set sign -1
            }

            incr ip
            if { $dos } {
                set u     [dos_using_ 0 $nspin $expr]
                set u_dw  [dos_using_ 1 $nspin $expr]
                # only total-DOS has integratedDOS
                if { $nspin == 1 } {
                    set ui    [expr { $atm ? {} : {$3} }];
                } else {
                    set ui    [expr { $atm ? {} : {$4} }];
                }
                set ui_dw [expr { $atm ? {} : {$5} }]; 
            } else {
                set u     [coxx_using_ 0 0 $nproj $expr]
                set u_dw  [coxx_using_ 1 0 $nproj $expr]
                set ui    [coxx_using_ 0 1 $nproj $expr]
                set ui_dw [coxx_using_ 1 1 $nproj $expr]
            }
            
            set ex [regsub -all { +} $expr {}]; # condensed expression            
            set ti "$prop: $ex"
            set iti "Int $prop: $ex"
            set ti2 ""
            
            if { $opt(sumspin) && $nspin > 1 } {
                set u  "$u+$u_dw"
                set ui "$ui+$ui_dw"                
                set ti2 " (up+dw)"
            } elseif { $nspin > 1 } {
                set ti2 " (up)"
            }

            if { $lt > 1 } { append plot(l,$dat) ", \\\n" }

            if { $spinId != 1 } {
                if { $opt(xE) } {
                    append plot(fc,$dat) "     '$dat' u 1:(\$1 <= 0.0 ? $sign*($u) : 0/0) not w filledcurve y1=0.0 lt $lt, \\\n"
                    append plot(l,$dat)  "     '$dat' u 1:($sign*($u)) t '${ti}$ti2' w l lt $lt lw 2"
                } else {
                    append plot(fc,$dat) "     '$dat' u (\$1 <= 0.0 ? $sign*($u) : 0/0):1 not w filledcurve x1=0.0 lt $lt, \\\n"
                    append plot(l,$dat)  "     '$dat' u ($sign*($u)):1 t '${ti}$ti2' w l lt $lt lw 2"
                }

                # for DOS: DOSCAR.*atom*dat does not have integrated DOS !!!!
                if { $opt(int) && !$atm} {
                    if { $opt(xE) } {
                        append plot(l,$dat) ", '$dat' u 1:($sign*($ui)) axes x1y2 t '${iti}$ti2' w l lt $lt"
                    } else {
                        append plot(l,$dat) ", '$dat' u ($sign*($ui)):1 axes x2y1 t '${iti}$ti2' w l lt $lt"
                    }
                }
            }
            
            if { !$opt(sumspin) && $nspin > 1 && $spinId != 0 } {
                if { $dos } {
                    set sign -1
                }
                set ti2 " (dw)"
                if { $opt(xE) } {
                    append plot(fc,$dat) "     '$dat' u 1:(\$1 <= 0.0 ? $sign*($u_dw) : 0/0) not w filledcurve y1=0.0 fs transparent solid $opt(ft_dw) lt $lt, \\\n"
                } else {
                    append plot(fc,$dat) "     '$dat' u (\$1 <= 0.0 ? $sign*($u_dw) : 0/0):1 not w filledcurve x1=0.0 fs transparent solid $opt(ft_dw) lt $lt, \\\n"
                }
                if { $spinId eq {} } {
                    append plot(l,$dat) ", \\\n"
                }
                if { $opt(xE) } {
                    append plot(l,$dat)  "     '$dat' u 1:($sign*($u_dw)) t '${ti}$ti2' w l lt $lt lw 2 dt ($opt(dt_dw))"
                } else {
                    append plot(l,$dat)  "     '$dat' u ($sign*($u_dw)):1 t '${ti}$ti2' w l lt $lt lw 2 dt ($opt(dt_dw))"
                }
                if { $opt(int) && !$atm} {
                    if { $opt(xE) } {
                        append plot(l,$dat) ", '$dat' u 1:($sign*($ui_dw)) axes x1y2 t '${iti}$ti2' w l lt $lt dt ($opt(dt_dw))"
                    } else {
                        append plot(l,$dat) ", '$dat' u ($sign*($ui_dw)):1 axes x2y1 t '${iti}$ti2' w l lt $lt dt ($opt(dt_dw))"
                    }                        
                }
            }
            incr lt
        }
    }

    foreach dat $datList {
        if { $opt(fill) } {
            append plt $plot(fc,$dat)
        }
        append plt $plot(l,$dat)
    }

    return $plt
}

# internal...
proc ::pwtk::lobster::property_ {name {plus_cohp 0}} {
    # PURPOSE
    #   Map from (abbreviated) lobster CAR filename to property name, i.e.:
    #   * COOP --> COOP
    #   * DOSCAR.LSO --> DOS.LSO
    #   * DOSCAR.LCFO.lobster --> DOS.LCFO
    
    set name [regsub CAR [::pwtk::trim_postfix {lobster dat} [string trimright $name .]] {}]
    if { ! $plus_cohp && [string match COHP* $name] } {
        set name −$name
    }
    return $name
}

# internal...
proc ::pwtk::lobster::label_ {name {plus_cohp 0}} {
    # PURPOSE
    #   Map from (abbreviated) *.dat filename to axis-label name, i.e.:
    #   * COOP --> COOP    
    #   * DOSCAR.LSO.atom --> DOS.LSO
    #   * DOSCAR.LCFO.atom1-3.dat --> DOS.LCFO
    set name [property_ [file tail $name]]
    return [regsub {\.o?r?b?(atom|frag)[0-9,\-]*} $name {}]
}

# internal...
proc ::pwtk::lobster::datfile_ {name {nat {}}} {
    # PURPOSE
    #   Map from abbreviated name to datafied LOBSTER *.dat filename, i.e.:
    #   * COHP            --> COHPCAR.dat
    #   * DOSCAR.LSO.atom1 --> DOSCAR.LSO.atom1.dat
    #   * DOS.LSO.atom1    --> DOSCAR.LSO.atom1.dat
    #   * DOS.atom1-3      --> DOSCAR.atom1-3.dat

    set prop [regsub CAR [::pwtk::trim_postfix {lobster dat} [string trimright $name .]] {}]    
    set a [lindex [split $prop .] 0]
    set b [join [lrange [split $prop .] 1 end] .]
    set b [regsub {\-$} $b "-$nat"]
    return [regsub {\.\.} ${a}CAR.$b.dat .]
}

# internal...
proc ::pwtk::lobster::lobsterfile_ {name} {
    # PURPOSE
    #   Map from abbreviated name to LOBSTER filename, i.e.:
    #   * COHP --> COHPCAR.lobster
    #   * COHP.LCFO --> COHPCAR.LCFO.lobster
    #   * DOSCAR.LSO --> DOSCAR.LSO.lobster    
    #   * DOSCAR.LCFO --> DOSCAR.LCFO.lobster
    #   * DOSCAR.LSO.atom1 --> DOSCAR.LSO.lobster
    #   * DOS.LSO.orbatom1 --> DOSCAR.LSO.lobster

    set prop [regsub CAR [::pwtk::trim_postfix {lobster dat} [string trimright $name .]] {}]

    if { [regexp {(atom|frag)} $prop] } {
        set prop [file rootname $prop]
    }
    set a [lindex [split $prop .] 0]
    set b [join [lrange [split $prop .] 1 end] .]
    return [regsub {\.\.} ${a}CAR.$b.lobster .]
}

# internal...
proc ::pwtk::lobster::indices_ {name {nat {}}} {
    # PURPOSE
    #   Map from (abbreviated) DOS name to atom indices, i.e.:
    #   * DOSCAR.LSO.atom1 --> 1
    #   * DOS.LSO.orbatom1,2,3 --> 1,2,3
    #   * DOSCAR.LSO.orbatom1-5   --> 1-5
    #   * DOSCAR.LSO.orbatom3- 10 --> 3-10
    
    set prop [regsub CAR [::pwtk::trim_postfix {lobster dat} [string trimright $name .]] {}]
    if { [regexp {(atom|frag)} $prop] } {
        set suf [file extension $prop]
        set ind [regsub {\.o?r?b?(atom|frag)} $suf {}]
        return  [regsub {\-$} $ind "-$nat"]
    }
    return {}
}

# internal...
proc ::pwtk::lobster::normalize_interaction_expr_ {interExpr} {
    # PURPOSE
    #   Return a "normalized" interaction-expression

    # i.X to iX
    set interExpr [regsub -all {i\.} $interExpr i]
    
    # a(verage) to i0
    set interExpr [regsub -all {av?e?r?a?g?e?} $interExpr i0]
    
    # add spaces around +, -, /, *, (, )
    set interExpr [regsub -all {[\+\-\*\/\(\)]} $interExpr { \0 }]
    
    # just one space around +, -, /, *
    return [string trim [regsub -all { +} $interExpr { }]]
}

# internal...
proc ::pwtk::lobster::coxx_using_ {whichSpin integrated nproj interExpr} {
    # PURPOSE
    #   Transform COXX interaction-expression into the "using" expression for the Gnuplot.
    #
    # ARGUMENTS
    # * whichSpin:  0 = spin-up,  1 = spin-dw
    # * integrated: 0 = property, 1 = integratedProperty
    # * nproj:      number of projections in the COXXCAR.lobster file
    # * interExpr:  interaction-expression

    set interExpr [normalize_interaction_expr_ $interExpr]
    
    foreach c $interExpr {
        if { [string is double -strict $c] } {
            # $c is a number?
            append using $c
        } elseif { [regexp {[\+\-\*\/\(\)]} $c] } {
            # $c is a primitive + - * / operator or parenthesis
            append using $c
        } elseif { [regexp {^i[0-9]+} $c] } {
            # $c is iX
            set i [regsub {^i} $c {}]
            append using "\$[expr 2*$nproj*$whichSpin + 2*($i+1) + $integrated]"
        } else {
            ::pwtk::error "error parsing the interaction expression \"$interExpr\"; unsupported character or unknown interaction \"$c\"; expected +, -, /, *, (, ), or iX, where X is an integer"
        }
    }
    return $using
}

# internal...
proc ::pwtk::lobster::dos_using_ {whichSpin nspin interExpr} {
    # PURPOSE
    #   Transform DOS interaction-expression into the "using" expression for the Gnuplot.
    #
    # ARGUMENTS
    # * whichSpin:  0 = spin-up,  1 = spin-dw
    # * nspin:      1 = non-polarized, 2 = spin-polarized
    # * interExpr:  interaction-expression

    set interExpr [normalize_interaction_expr_ $interExpr]
    
    foreach c $interExpr {
        if { [string is double -strict $c] } {
            # $c is a number?
            append using $c
        } elseif { [regexp {[\+\-\*\/\(\)]} $c] } {
            # $c is a primitive + - * / operator or parenthesis
            append using $c
        } elseif { [regexp {^i[0-9]+} $c] } {
            # $c is iX
            set i [regsub {^i} $c {}]
            append using "\$[expr 2 + $nspin*$i + $whichSpin]"
        } else {
            ::pwtk::error "error parsing the interaction expression \"$interExpr\"; unsupported character or unknown interaction \"$c\"; expected +, -, /, *, (, ), or iX, where X is an integer"
        }
    }
    return $using
}

