#!/usr/bin/env bash
# setup_pwtk_path.sh
# Finds the pwtk executable, puts its directory first in PATH, removes older
# pwtk directories from PATH, and records the change in ~/.bashrc.
#
# Usage:
#   source setup_pwtk_path.sh [search_dir]    # updates the current shell too
#   ./setup_pwtk_path.sh [search_dir]         # updates ~/.bashrc only

BASHRC="$HOME/.bashrc"
MARK_BEGIN="# >>> pwtk path >>>"
MARK_END="# <<< pwtk path <<<"
SEARCH_DIR="${1:-$PWD}"

die() {
    echo "Error: $*" >&2
    return 1 2>/dev/null || exit 1
}

# True if version $1 is strictly older than version $2
ver_lt() {
    [ "$1" != "$2" ] && [ "$(printf '%s\n' "$1" "$2" | sort -V | head -n1)" = "$1" ]
}

# Print the version of a pwtk executable: VERSION file next to it, else a number in the script
get_version() {
    local real dir v
    real=$(readlink -f "$1")
    dir=$(dirname "$real")
    if [ -f "$dir/VERSION" ]; then
        v=$(tr -d '[:space:]' < "$dir/VERSION")
    else
        v=$(grep -m1 -oE '[0-9]+(\.[0-9]+)+' "$real")
    fi
    echo "${v:-0}"
}

# 1. Locate the pwtk executable
exe=$(find "$SEARCH_DIR" -maxdepth 2 -type f -name pwtk -perm -u+x 2>/dev/null | head -n1)
[ -n "$exe" ] || die "pwtk executable not found under $SEARCH_DIR"
exe=$(readlink -f "$exe")
newdir=$(dirname "$exe")
newver=$(get_version "$exe")
echo "Found pwtk $newver at $exe"

# 2. Rebuild PATH without the new directory and without older pwtk directories
new_path=""
removed=()
IFS=: read -ra entries <<< "$PATH"
for d in "${entries[@]}"; do
    [ -z "$d" ] && continue
    rd=$(readlink -f "$d" 2>/dev/null || echo "$d")
    # The new directory is re-added at the front below
    [ "$rd" = "$newdir" ] && continue

    if [ -x "$d/pwtk" ] && [ "$(readlink -f "$d/pwtk")" != "$exe" ]; then
        oldver=$(get_version "$d/pwtk")
        if ver_lt "$oldver" "$newver"; then
            removed+=("$d (pwtk $oldver)")
            continue
        fi
    fi
    new_path="${new_path:+$new_path:}$d"
done

# 3. Put the new directory first and apply it to this shell
export PATH="$newdir${new_path:+:$new_path}"

if [ "${#removed[@]}" -gt 0 ]; then
    echo "Removed older pwtk from PATH:"
    printf '  %s\n' "${removed[@]}"
else
    echo "No older pwtk found in PATH."
fi

# 4. Write the setting to ~/.bashrc (replacing any previous block from this script)
[ -f "$BASHRC" ] || touch "$BASHRC"
sed -i "\|$MARK_BEGIN|,\|$MARK_END|d" "$BASHRC"
{
    echo "$MARK_BEGIN"
    echo "# added by setup_pwtk_path.sh"
    echo "export PATH=\"$newdir:\$PATH\""
    echo "$MARK_END"
} >> "$BASHRC"
echo "Updated $BASHRC"

# Warn about older directories added to .bashrc by hand, since those lines are not removed
for d in "${removed[@]}"; do
    dir=${d%% (pwtk *}
    grep -nF "$dir" "$BASHRC" | grep -v "pwtk path" | sed 's/^/  Check ~\/.bashrc line /' || true
done

# 5. Source ~/.bashrc
source "$BASHRC" 2>/dev/null || true
echo "Done. pwtk is now: $(command -v pwtk)"
