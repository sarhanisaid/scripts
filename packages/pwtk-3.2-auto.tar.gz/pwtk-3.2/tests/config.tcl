# PURPOSE
#   This is a config file for running tests and examples.
#   It sets:
#     (1) remote variable to plain values to enable connection to localhost
#     (2) ::pwtk::gp::gp(pause) to $PWTK_PAUSE enviromental variable or to
#         5 seconds if PWTK_PAUSE is not defined; this way plotting
#         windows close after some time

array set ::pwtk::remote {
    rsync  {rsync -avu}
    rsh    ssh
    rcp    rcp
    time_interval 15s
}


::pwtk::ifnotexist ::env(PWTK_PAUSE) {
    set ::env(PWTK_PAUSE) 5
}

::pwtk::propagate [subst {
    set ::pwtk::gp::gp(pause) $::env(PWTK_PAUSE)
    set ::env(PWTK_PAUSE) $::env(PWTK_PAUSE)    
}]
