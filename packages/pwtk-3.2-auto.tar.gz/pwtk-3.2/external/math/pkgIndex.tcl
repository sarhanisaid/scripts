if {![package vsatisfies [package provide Tcl] 8.5]} {return}
package ifneeded math::linearalgebra     1.1.6 [list source [file join $dir linalg.tcl]]
