#
# $Id: pkgIndex.tcl,v 1.1 2015/01/12 17:33:06 kokalj Exp $
#
package ifneeded ssh 1.0 [list source [file join $dir ssh.tcl]]
